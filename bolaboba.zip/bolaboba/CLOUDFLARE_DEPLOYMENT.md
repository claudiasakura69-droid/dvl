# Cloudflare Pages Deployment Guide

## Overview

Proyek ini adalah sistem manajemen perbankan lengkap dengan fitur:
- User authentication (username & token)
- Bank management (Deposit & Withdraw)
- Daily transactions
- In/Out between banks
- Expense tracking
- Mistake corrections
- Excel export

## Prerequisites

- Akun Cloudflare
- Proyek GitHub sudah di-push
- Akun GitHub terhubung ke Cloudflare Pages

## Environment Variables & Secrets

Saat deploy ke Cloudflare Pages, Anda perlu mengatur environment variables dan secrets:

### Required Environment Variables

```
DATABASE_URL=your_database_url_here
```

### User Credentials (via Environment Variables)

Anda dapat menambahkan user baru dengan mengatur environment variables di Cloudflare Pages:

Format: `USER_{USERNAME}_TOKEN`

Contoh:
```
USER_admin_TOKEN=master123@
USER_staff1_TOKEN=token456@
USER_manager_TOKEN=token789@
```

### Cara Menambah User Baru

1. Masuk ke Cloudflare Dashboard
2. Pilih project Pages Anda
3. Buka tab "Settings" > "Environment variables"
4. Tambahkan environment variable baru:
   - Name: `USER_<username>_TOKEN`
   - Value: token yang diinginkan
5. Save dan redeploy

### Contoh Konfigurasi

Untuk user yang sudah ada (default):
```
USER_admin_TOKEN=master123@
```

Untuk menambah user baru:
```
USER_staff_TOKEN=staff123@
USER_manager_TOKEN=manager456@
USER_operator_TOKEN=operator789@
```

## Build Configuration

### Method: Next.js (Framework Preset)

Di Cloudflare Pages, pilih:
- **Framework preset**: Next.js
- **Build command**: `bun run build`
- **Build output directory**: `.next/standalone`

### Package Manager

Pilih **Bun** sebagai package manager.

## Database Setup

Untuk production, Anda perlu database yang tersedia di internet:

### Opsi 1: Neon (PostgreSQL)
1. Sign up di [neon.tech](https://neon.tech)
2. Buat project baru
3. Copy connection string
4. Set `DATABASE_URL` di Cloudflare Pages environment variables

Contoh format:
```
DATABASE_URL=postgresql://username:password@ep-xxx.region.aws.neon.tech/neondb?sslmode=require
```

### Opsi 2: SQLite dengan Cloudflare D1 (Disarankan untuk Cloudflare)

1. Buat D1 database di Cloudflare
2. Bind database ke Pages project
3. Update `DATABASE_URL` untuk menggunakan D1

## Deployment Steps

### 1. Push ke GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/username/bank-management.git
git push -u origin main
```

### 2. Connect ke Cloudflare Pages

1. Login ke [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Buka "Workers & Pages"
3. Klik "Create application"
4. Pilih "Connect to Git"
5. Pilih repository GitHub Anda

### 3. Konfigurasi Build

Set framework preset ke **Next.js** dengan konfigurasi:

- **Framework preset**: Next.js
- **Build command**: `bun run build`
- **Build output directory**: `.next/standalone`
- **Install command**: `bun install`

### 4. Set Environment Variables

1. Buka tab "Settings"
2. Pilih "Environment variables"
3. Tambahkan `DATABASE_URL`
4. Tambahkan user credentials dengan format `USER_{username}_TOKEN`

### 5. Deploy

Klik "Save and Deploy". Cloudflare akan mem-build dan deploy aplikasi Anda.

## Post-Deployment Setup

### 1. Seed Default User

Setelah deploy pertama, Anda perlu menambahkan default user admin. Anda bisa:

**Opsi A: Melalui API**

Gunakan endpoint `/api/seed` untuk menambah user default:

```bash
curl -X POST https://your-project.pages.dev/api/seed \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","token":"master123@"}'
```

**Opsi B: Melalui Database**

Gunakan Cloudflare D1 Dashboard atau database admin panel Anda untuk menambahkan user:

```sql
INSERT INTO User (id, username, token, isActive, createdAt, updatedAt)
VALUES ('admin-id', 'admin', 'master123@', 1, datetime('now'), datetime('now'));
```

### 2. Login ke Application

1. Buka URL project Anda (misal: `https://your-project.pages.dev`)
2. Login dengan:
   - Username: `admin`
   - Token: `master123@`

### 3. Setup Banks

Setelah login:
1. Buka menu "Bank"
2. Tambah bank untuk Deposit dan Withdraw
3. Set bank online/offline sesuai kebutuhan

## Update Database Schema

Jika Anda mengubah Prisma schema:

1. Jalankan migration di local:
   ```bash
   bun run db:push
   ```

2. Push changes ke GitHub

3. Cloudflare akan otomatis redeploy dengan schema baru

## Troubleshooting

### Build Error: Prisma Client Not Generated

Jika error terkait Prisma client:
1. Pastikan `DATABASE_URL` sudah di-set di environment variables
2. Restart deployment dengan "Retry deployment"

### Login Not Working

Jika login gagal:
1. Cek environment variables di Cloudflare Pages
2. Pastikan format `USER_{username}_TOKEN` benar
3. Restart deployment setelah menambah environment variables baru

### Database Connection Error

Jika database connection error:
1. Cek `DATABASE_URL` di environment variables
2. Pastikan database bisa diakses dari internet
3. Cek firewall rules di database provider

## Security Notes

⚠️ **Important Security Considerations:**

1. **Environment Variables**:
   - Jangan hardcode token di code
   - Selalu gunakan environment variables untuk credentials
   - Rotate token secara berkala

2. **User Management**:
   - Gunakan token yang kuat (minimal 8 karakter, kombinasi huruf dan angka)
   - Hapus atau deactivate user yang tidak digunakan
   - Gunakan token berbeda untuk setiap user

3. **Database**:
   - Gunakan SSL/TLS untuk database connection
   - Limit database access hanya untuk IP Cloudflare
   - Regular backup untuk database production

## Development vs Production

### Local Development

Gunakan file `.env.local` untuk local development:

```
DATABASE_URL="file:./db/custom.db"
USER_admin_TOKEN=master123@
```

### Production

Set environment variables di Cloudflare Pages dashboard, bukan di code repository.

## Additional Resources

- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)
- [Next.js on Cloudflare Pages](https://developers.cloudflare.com/pages/framework-guides/nextjs/)
- [Prisma on Cloudflare Workers](https://www.prisma.io/docs/guides/deployment/deploying-to-cloudflare-workers)

## Support

Jika mengalami issues:
1. Cek deployment logs di Cloudflare Pages
2. Cek error logs di Workers & Pages > Logs
3. Verifikasi semua environment variables sudah di-set
4. Pastikan database bisa diakses dari internet

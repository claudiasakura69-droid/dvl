// Permission levels in order from least to most privileged
export const PERMISSION_LEVELS = {
  VIEW: 0,
  ADMIN: 1,
  SUPPORT: 2,
  SUPERVISOR: 3,
  MASTER: 4
} as const

export type PermissionLevel = keyof typeof PERMISSION_LEVELS

export interface Permissions {
  canView: boolean
  canAdd: boolean
  canEdit: boolean
  canDelete: boolean
  canDeleteBank: boolean
  canEditBankType: boolean
  canEditBankStatus: boolean
}

/**
 * Check if user role has required permission level
 */
export function hasPermission(
  userRole: string,
  requiredLevel: number
): boolean {
  return (PERMISSION_LEVELS[userRole as PermissionLevel] ?? 0) >= requiredLevel
}

/**
 * Get permissions for a specific role
 */
export function getPermissions(role: string): Permissions {
  const level = PERMISSION_LEVELS[role as PermissionLevel] ?? 0

  return {
    canView: true, // All roles can view
    canAdd: level >= PERMISSION_LEVELS.ADMIN, // ADMIN and above can add
    canEdit: level >= PERMISSION_LEVELS.SUPPORT, // SUPPORT and above can edit
    canDelete: level >= PERMISSION_LEVELS.SUPERVISOR, // SUPERVISOR and above can delete
    canDeleteBank: level >= PERMISSION_LEVELS.MASTER, // Only MASTER can delete bank
    canEditBankType: level >= PERMISSION_LEVELS.MASTER, // Only MASTER can change bank type
    canEditBankStatus: level >= PERMISSION_LEVELS.SUPERVISOR, // SUPERVISOR and above can change bank status
  }
}

/**
 * Check if user can perform action
 */
export function canPerformAction(
  userRole: string,
  action: 'view' | 'add' | 'edit' | 'delete' | 'deleteBank' | 'editBankType' | 'editBankStatus'
): boolean {
  const permissions = getPermissions(userRole)
  return permissions[`can${action.charAt(0).toUpperCase()}${action.slice(1)}`] ?? false
}

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Calendar, Plus, Download, FileText, Edit, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'

interface DayTransactionsContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Transaction {
  id: string
  date: string
  name: string
  accountNumber: string | null
  amount: number
  type: 'DEPOSIT' | 'WITHDRAW'
  bankId: string | null
  bankName: string | null
  bank: {
    id: string
    name: string
    accountName: string
    balance: number
  } | null
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
  balance: number
  status: string
  type: string
}

export default function DayTransactionsContent({ sessionId, user }: DayTransactionsContentProps) {
  // Permissions
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))

  // Data states
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)

  // Filter states
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [useDateRange, setUseDateRange] = useState(false)

  // Dialog states
  const [dialogOpen, setDialogOpen] = useState(false)
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)

  // Form data
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    name: '',
    accountNumber: '',
    amount: '',
    type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
    bankId: ''
  })

  const [editFormData, setEditFormData] = useState({
    date: '',
    name: '',
    accountNumber: '',
    amount: '',
    type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
    bankId: ''
  })

  const [bulkData, setBulkData] = useState('')

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchTransactions()
    }
  }, [sessionId, startDate, endDate])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks((data.data || []).filter((b: Bank) => b.status === 'online'))
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchTransactions = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      let url = `/api/daily-transactions?sessionId=${sessionId}`

      if (useDateRange && startDate && endDate) {
        url += `&startDate=${startDate}&endDate=${endDate}`
      } else if (!useDateRange) {
        const today = new Date().toISOString().split('T')[0]
        url += `&date=${today}`
      }

      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setTransactions(data.data || [])
      }
    } catch (error) {
      console.error('Error fetching transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/daily-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          date: new Date().toISOString().split('T')[0],
          name: '',
          accountNumber: '',
          amount: '',
          type: 'DEPOSIT',
          bankId: ''
        })
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedTransaction) {
      toast.error('Session atau transaksi tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/daily-transactions/${selectedTransaction.id}?sessionId=${sessionId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editFormData)
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedTransaction(null)
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal mengupdate transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteTransaction = async () => {
    if (!sessionId || !selectedTransaction) {
      toast.error('Session atau transaksi tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/daily-transactions/${selectedTransaction.id}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil dihapus')
        setDeleteDialogOpen(false)
        setSelectedTransaction(null)
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menghapus transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setEditFormData({
      date: new Date(transaction.date).toISOString().split('T')[0],
      name: transaction.name,
      accountNumber: transaction.accountNumber || '',
      amount: transaction.amount.toString(),
      type: transaction.type,
      bankId: transaction.bankId || ''
    })
    setEditDialogOpen(true)
  }

  const openDeleteDialog = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setDeleteDialogOpen(true)
  }

  const handleBulkTransactions = async () => {
    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const lines = bulkData.split('\n').filter(line => line.trim())
      const transactions = lines.map(line => {
        const parts = line.split('\t')
        return {
          date: new Date().toISOString().split('T')[0],
          name: parts[0] || '',
          accountNumber: parts[1] || '',
          amount: parseFloat(parts[2]) || 0,
          type: parts[3]?.includes('WITHDRAW') ? 'WITHDRAW' : 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
          bankId: banks.find(b => `${b.name} - ${b.accountName}` === parts[3]?.trim())?.id || ''
        }
      }).filter(t => t.name && t.amount > 0 && t.bankId)

      const response = await fetch('/api/daily-transactions/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          transactions,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`${data.successCount} transaksi berhasil ditambahkan`)
        if (data.errorCount > 0) {
          toast.error(`${data.errorCount} transaksi gagal`)
        }
        setBulkDialogOpen(false)
        setBulkData('')
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleExport = async () => {
    if (!sessionId) return

    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          startDate: useDateRange ? startDate : new Date().toISOString().split('T')[0],
          endDate: useDateRange ? endDate : new Date().toISOString().split('T')[0]
        })
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `transactions_${startDate || 'today'}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Export berhasil')
      } else {
        toast.error('Gagal export data')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat export')
    }
  }

  const resetDateRange = () => {
    setStartDate('')
    setEndDate('')
    setUseDateRange(false)
  }

  const getBankDisplayName = (transaction: Transaction) => {
    if (transaction.bank) {
      return `${transaction.bank.name} - ${transaction.bank.accountName}`
    }
    return transaction.bankName || 'Bank dihapus'
  }

  const deposits = transactions.filter(t => t.type === 'DEPOSIT')
  const withdraws = transactions.filter(t => t.type === 'WITHDRAW')
  const onlineDepositBanks = banks.filter(b => b.type === 'DEPOSIT')
  const onlineWithdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const calculateTotal = (txs: Transaction[]) => txs.reduce((sum, tx) => sum + tx.amount, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 sm:flex-row flex-col">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Calendar className="h-6 w-6 sm:h-8 sm:w-8" />
            Day Transactions
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Catat transaksi harian deposit dan withdraw
          </p>
        </div>

        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            onClick={() => setUseDateRange(!useDateRange)}
            className={useDateRange ? 'bg-primary text-primary-foreground' : ''}
          >
            {useDateRange ? 'Filter by Date' : 'Date Range'}
          </Button>

          {useDateRange && (
            <>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-auto"
              />
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-auto"
              />
              <Button variant="ghost" size="icon" onClick={resetDateRange}>
                <X className="h-4 w-4" />
              </Button>
            </>
          )}

          {permissions.canAdd && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="min-h-[44px]">
                  <Plus className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">Tambah Transaksi</span>
                  <span className="sm:hidden">Tambah</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
                <DialogHeader>
                  <DialogTitle className="text-base sm:text-lg">Tambah Transaksi</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddTransaction} className="space-y-4">
                  <div>
                    <Label htmlFor="txDate" className="text-sm">Tanggal</Label>
                    <Input
                      id="txDate"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="txName" className="text-sm">Nama</Label>
                    <Input
                      id="txName"
                      placeholder="Nama pengirim/penerima"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="txAccountNumber" className="text-sm">Nomor Rekening (Opsional)</Label>
                    <Input
                      id="txAccountNumber"
                      placeholder="1234567890"
                      value={formData.accountNumber}
                      onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="txAmount" className="text-sm">Nominal</Label>
                    <Input
                      id="txAmount"
                      type="number"
                      placeholder="0"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="txType" className="text-sm">Tipe</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value, bankId: '' })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DEPOSIT">Deposit</SelectItem>
                        <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="txBank" className="text-sm">Bank</Label>
                    <Select
                      value={formData.bankId}
                      onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih bank" />
                      </SelectTrigger>
                      <SelectContent>
                        {formData.type === 'DEPOSIT' ? (
                          <>
                            {onlineDepositBanks && onlineDepositBanks.map((bank) => (
                              <SelectItem key={bank.id} value={bank.id}>
                                {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                              </SelectItem>
                            ))}
                          </>
                        ) : (
                          <>
                            {onlineWithdrawBanks && onlineWithdrawBanks.map((bank) => (
                              <SelectItem key={bank.id} value={bank.id}>
                                {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                              </SelectItem>
                            ))}
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="w-full min-h-[44px]">
                    Simpan
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          )}

          <Dialog open={bulkDialogOpen} onOpenChange={setBulkDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="min-h-[44px]">
                <FileText className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Bulk Add</span>
                <span className="sm:hidden">Bulk</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle className="text-base sm:text-lg">Tambah Banyak Transaksi</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bulkData" className="text-sm">Data Transaksi (Format: Nama{`\t`}Nomor Rek{`\t`}Nominal{`\t`}Bank)</Label>
                  <Input
                    id="bulkData"
                    placeholder="Nama{tab}Nomor Rek{tab}Nominal{tab}BCA - Vera"
                    value={bulkData}
                    onChange={(e) => setBulkData(e.target.value)}
                    className="font-mono text-xs"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Gunakan tab sebagai pemisah. Setiap baris adalah satu transaksi.
                  </p>
                </div>
                <Button onClick={handleBulkTransactions} className="w-full min-h-[44px]">
                  Simpan Semua
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={handleExport} className="min-h-[44px]">
            <Download className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Export</span>
            <span className="sm:hidden">Exp</span>
          </Button>
        </div>
      </div>

      {/* Bank Summary */}
      <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Online Deposit Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] sm:h-[400px]">
              <div className="min-w-full">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm">Bank</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Balance</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Today</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Final</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {onlineDepositBanks.map((bank) => {
                      const todayTotal = deposits.filter(t => t.bankId === bank.id).reduce((sum, t) => sum + t.amount, 0)
                      return (
                        <TableRow key={bank.id}>
                          <TableCell className="text-xs sm:text-sm">{bank.name} - {bank.accountName}</TableCell>
                          <TableCell className="text-right text-xs sm:text-sm">{formatCurrency(bank.balance - todayTotal)}</TableCell>
                          <TableCell className="text-right text-green-600 text-xs sm:text-sm">+{formatCurrency(todayTotal)}</TableCell>
                          <TableCell className="text-right font-semibold text-xs sm:text-sm">{formatCurrency(bank.balance)}</TableCell>
                        </TableRow>
                      )
                    })}
                    {onlineDepositBanks.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground text-xs sm:text-sm">
                          Tidak ada bank deposit online
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Online Withdraw Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] sm:h-[400px]">
              <div className="min-w-full">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm">Bank</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Balance</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Today</TableHead>
                      <TableHead className="text-right text-xs sm:text-sm">Final</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {onlineWithdrawBanks.map((bank) => {
                      const todayTotal = withdraws.filter(t => t.bankId === bank.id).reduce((sum, t) => sum + t.amount, 0)
                      return (
                        <TableRow key={bank.id}>
                          <TableCell className="text-xs sm:text-sm">{bank.name} - {bank.accountName}</TableCell>
                          <TableCell className="text-right text-xs sm:text-sm">{formatCurrency(bank.balance + todayTotal)}</TableCell>
                          <TableCell className="text-right text-red-600 text-xs sm:text-sm">-{formatCurrency(todayTotal)}</TableCell>
                          <TableCell className="text-right font-semibold text-xs sm:text-sm">{formatCurrency(bank.balance)}</TableCell>
                        </TableRow>
                      )
                    })}
                    {onlineWithdrawBanks.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground text-xs sm:text-sm">
                          Tidak ada bank withdraw online
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Transactions */}
      <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
        {/* Deposits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-green-600">Deposits</span>
              <span className="text-xs sm:text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(deposits))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] sm:h-[500px]">
              {loading ? (
                <p className="text-center text-muted-foreground py-8 text-sm">Memuat data...</p>
              ) : deposits.length === 0 ? (
                <p className="text-center text-muted-foreground py-8 text-sm">Belum ada transaksi deposit</p>
              ) : (
                <div className="min-w-full">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs sm:text-sm">Waktu</TableHead>
                        <TableHead className="text-xs sm:text-sm">Nama</TableHead>
                        <TableHead className="text-xs sm:text-sm hidden md:table-cell">Bank</TableHead>
                        <TableHead className="text-right text-xs sm:text-sm">Nominal</TableHead>
                        <TableHead className="text-right text-xs sm:text-sm">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deposits.map((tx) => (
                        <TableRow key={tx.id}>
                          <TableCell className="text-xs sm:text-sm">
                            <div className="md:hidden">{formatDate(tx.date).split(' ')[0]}</div>
                            <div className="hidden md:block">{formatDate(tx.date)}</div>
                          </TableCell>
                          <TableCell className="text-xs sm:text-sm">
                            <div>
                              <div className="font-medium text-xs sm:text-sm">{tx.name}</div>
                              {tx.accountNumber && (
                                <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs sm:text-sm hidden md:table-cell">{getBankDisplayName(tx)}</TableCell>
                          <TableCell className="text-right text-green-600 font-semibold text-xs sm:text-sm">
                            {formatCurrency(tx.amount)}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-1 justify-end">
                              {permissions.canEdit && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 sm:h-9 sm:w-9"
                                  onClick={() => openEditDialog(tx)}
                                >
                                  <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                                </Button>
                              )}
                              {permissions.canDelete && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 sm:h-9 sm:w-9 text-destructive"
                                  onClick={() => openDeleteDialog(tx)}
                                >
                                  <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Withdraws */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-red-600">Withdraws</span>
              <span className="text-xs sm:text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(withdraws))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] sm:h-[500px]">
              {loading ? (
                <p className="text-center text-muted-foreground py-8 text-sm">Memuat data...</p>
              ) : withdraws.length === 0 ? (
                <p className="text-center text-muted-foreground py-8 text-sm">Belum ada transaksi withdraw</p>
              ) : (
                <div className="min-w-full">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs sm:text-sm">Waktu</TableHead>
                        <TableHead className="text-xs sm:text-sm">Nama</TableHead>
                        <TableHead className="text-xs sm:text-sm hidden md:table-cell">Bank</TableHead>
                        <TableHead className="text-right text-xs sm:text-sm">Nominal</TableHead>
                        <TableHead className="text-right text-xs sm:text-sm">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {withdraws.map((tx) => (
                        <TableRow key={tx.id}>
                          <TableCell className="text-xs sm:text-sm">
                            <div className="md:hidden">{formatDate(tx.date).split(' ')[0]}</div>
                            <div className="hidden md:block">{formatDate(tx.date)}</div>
                          </TableCell>
                          <TableCell className="text-xs sm:text-sm">
                            <div>
                              <div className="font-medium text-xs sm:text-sm">{tx.name}</div>
                              {tx.accountNumber && (
                                <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs sm:text-sm hidden md:table-cell">{getBankDisplayName(tx)}</TableCell>
                          <TableCell className="text-right text-red-600 font-semibold text-xs sm:text-sm">
                            {formatCurrency(tx.amount)}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-1 justify-end">
                              {permissions.canEdit && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 sm:h-9 sm:w-9"
                                  onClick={() => openEditDialog(tx)}
                                >
                                  <Edit className="h-3 w-3 sm:h-4 sm:w-4" />
                                </Button>
                              )}
                              {permissions.canDelete && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 sm:h-9 sm:w-9 text-destructive"
                                  onClick={() => openDeleteDialog(tx)}
                                >
                                  <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Edit Transaksi</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditTransaction} className="space-y-4">
            <div>
              <Label htmlFor="editDate" className="text-sm">Tanggal</Label>
              <Input
                id="editDate"
                type="date"
                value={editFormData.date}
                onChange={(e) => setEditFormData({ ...editFormData, date: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editName" className="text-sm">Nama</Label>
              <Input
                id="editName"
                placeholder="Nama pengirim/penerima"
                value={editFormData.name}
                onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editAccountNumber" className="text-sm">Nomor Rekening (Opsional)</Label>
              <Input
                id="editAccountNumber"
                placeholder="1234567890"
                value={editFormData.accountNumber}
                onChange={(e) => setEditFormData({ ...editFormData, accountNumber: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="editAmount" className="text-sm">Nominal</Label>
              <Input
                id="editAmount"
                type="number"
                placeholder="0"
                value={editFormData.amount}
                onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editType" className="text-sm">Tipe</Label>
              <Select
                value={editFormData.type}
                onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setEditFormData({ ...editFormData, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DEPOSIT">Deposit</SelectItem>
                  <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editBank" className="text-sm">Bank</Label>
              <Select
                value={editFormData.bankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank" />
                </SelectTrigger>
                <SelectContent>
                  {editFormData.type === 'DEPOSIT' ? (
                    <>
                      {onlineDepositBanks && onlineDepositBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                        </SelectItem>
                      ))}
                    </>
                  ) : (
                    <>
                      {onlineWithdrawBanks && onlineWithdrawBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                        </SelectItem>
                      ))}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="w-full min-h-[44px]">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Hapus Transaksi</DialogTitle>
          </DialogHeader>
          {selectedTransaction && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Apakah Anda yakin ingin menghapus transaksi ini? Saldo bank akan dikembalikan.
              </p>
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="text-sm">
                  <span className="font-medium">Tipe:</span> {selectedTransaction.type}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Nama:</span> {selectedTransaction.name}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Nominal:</span> {formatCurrency(selectedTransaction.amount)}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Bank:</span> {getBankDisplayName(selectedTransaction)}
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setDeleteDialogOpen(false)}
                  className="min-h-[44px]"
                >
                  Batal
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleDeleteTransaction}
                  className="min-h-[44px]"
                >
                  Hapus
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

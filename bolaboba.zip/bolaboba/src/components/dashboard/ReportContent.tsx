'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { FileText, ChevronLeft, ChevronRight, Download, TrendingUp, TrendingDown, BarChart3 } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, type Permissions } from '@/lib/permissions'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

interface TransactionDetail {
  type: string
  amount: number
  bankName?: string
  notes?: string
}

interface DailyBreakdown {
  date: string
  deposits: number
  withdrawals: number
  inOut: number
  expenses: number
  mistakes: number
  akurans: number
  total: number
  transactions: TransactionDetail[]
}

interface MonthlyData {
  month: number
  monthName: string
  depositTotal: number
  withdrawTotal: number
  inOutTotal: number
  expenseTotal: number
  mistakeTotal: number
  transactionCount: number
  netTotal: number
  dailyBreakdown: DailyBreakdown[]
}

interface ReportData {
  year: number
  month: number | null
  monthlyData: MonthlyData[]
  yearlyTotals: {
    deposits: number
    withdrawals: number
    inOut: number
    expenses: number
    mistakes: number
    totalTransactions: number
    netTotal: number
  }
}

interface ReportContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

export default function ReportContent({ sessionId, user }: ReportContentProps) {
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())
  const [currentMonth, setCurrentMonth] = useState<number | null>(null)
  const [reportData, setReportData] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(false)
  const [expandedMonths, setExpandedMonths] = useState<Set<number>>(new Set())
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  const [showTransactions, setShowTransactions] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    fetchReportData()
  }, [currentYear, currentMonth])

  const fetchReportData = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      let url = `/api/report?sessionId=${sessionId}&year=${currentYear}`
      if (currentMonth) {
        url += `&month=${currentMonth}`
      }
      const response = await fetch(url)
      const data = await response.json()
      if (data.success) {
        setReportData(data.data)
      } else {
        toast.error(data.error || 'Gagal memuat laporan')
      }
    } catch (error) {
      console.error('Error fetching report data:', error)
      toast.error('Gagal memuat laporan')
    } finally {
      setLoading(false)
    }
  }

  const toggleMonthExpand = (month: number) => {
    setExpandedMonths(prev => {
      const newSet = new Set(prev)
      if (newSet.has(month)) {
        newSet.delete(month)
      } else {
        newSet.add(month)
      }
      return newSet
    })
  }

  const toggleTransactions = (date: string) => {
    setShowTransactions(prev => {
      const newSet = new Set(prev)
      if (newSet.has(date)) {
        newSet.delete(date)
      } else {
        newSet.add(date)
      }
      return newSet
    })
  }

  const exportReport = () => {
    if (!reportData) return

    let csv = 'Tanggal,Tipe,Jumlah,Bank,Catatan\n'

    reportData.monthlyData.forEach(month => {
      month.dailyBreakdown.forEach(day => {
        day.transactions.forEach(tx => {
          csv += `${day.date},`
          csv += `${tx.type},`
          csv += `${tx.amount},`
          csv += `"${tx.bankName || ''}",`
          csv += `"${tx.notes || ''}"\n`
        })
      })
    })

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    const fileName = currentMonth
      ? `laporan-${currentYear}-${currentMonth.toString().padStart(2, '0')}.csv`
      : `laporan-${currentYear}.csv`
    a.download = fileName
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success('Laporan berhasil diunduh')
  }

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const months = [
    { value: '', label: 'Semua Bulan' },
    { value: '1', label: 'Januari' },
    { value: '2', label: 'Februari' },
    { value: '3', label: 'Maret' },
    { value: '4', label: 'April' },
    { value: '5', label: 'Mei' },
    { value: '6', label: 'Juni' },
    { value: '7', label: 'Juli' },
    { value: '8', label: 'Agustus' },
    { value: '9', label: 'September' },
    { value: '10', label: 'Oktober' },
    { value: '11', label: 'November' },
    { value: '12', label: 'Desember' },
  ]

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'DEPOSIT':
      case 'deposit':
      case 'DEPOSIT':
        return 'bg-green-500'
      case 'WITHDRAW':
      case 'withdraw':
        return 'bg-red-500'
      case 'INOUT':
        return 'bg-blue-500'
      case 'EXPENSE':
        return 'bg-orange-500'
      case 'MISTAKE':
        return 'bg-yellow-500'
      default:
        return 'bg-gray-500'
    }
  }

  if (!permissions.canView) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="py-12">
            <div className="text-center text-muted-foreground">
              Anda tidak memiliki akses untuk melihat laporan
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
              <FileText className="h-6 w-6 sm:h-8 sm:w-8" />
              Laporan
            </h2>
            <p className="text-muted-foreground">
              Ringkasan transaksi dan analisis
            </p>
          </div>
        </div>
        <Card>
          <CardContent className="py-12">
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <FileText className="h-6 w-6 sm:h-8 sm:w-8" />
            Laporan
          </h2>
          <p className="text-muted-foreground">
            Ringkasan transaksi dan analisis
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentYear(currentYear - 1)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-xl sm:text-2xl font-bold min-w-[80px] sm:min-w-[100px] text-center">
            {currentYear}
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentYear(currentYear + 1)}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Select
            value={currentMonth?.toString() || ''}
            onValueChange={(value) => setCurrentMonth(value ? parseInt(value) : null)}
          >
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Bulan" />
            </SelectTrigger>
            <SelectContent>
              {months.map((month) => (
                <SelectItem key={month.value} value={month.value || 'all'}>
                  {month.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={exportReport} variant="outline" className="hidden sm:flex">
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
          <Button onClick={exportReport} variant="outline" size="icon" className="sm:hidden">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {reportData && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Ringkasan {currentMonth ? `Bulan ${months.find(m => m.value === currentMonth.toString())?.label}` : 'Tahunan'}
              </CardTitle>
              <CardDescription>
                Total transaksi dan keuangan tahun {currentYear}{currentMonth ? ` bulan ${months.find(m => m.value === currentMonth.toString())?.label}` : ''}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-green-50 dark:bg-green-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total Deposit</p>
                  <p className="text-base sm:text-lg font-bold text-green-600">
                    {formatCurrency(reportData.yearlyTotals.deposits)}
                  </p>
                </div>
                <div className="bg-red-50 dark:bg-red-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total Withdraw</p>
                  <p className="text-base sm:text-lg font-bold text-red-600">
                    {formatCurrency(reportData.yearlyTotals.withdrawals)}
                  </p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total In/Out</p>
                  <p className="text-base sm:text-lg font-bold text-blue-600">
                    {formatCurrency(reportData.yearlyTotals.inOut)}
                  </p>
                </div>
                <div className="bg-orange-50 dark:bg-orange-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total Expense</p>
                  <p className="text-base sm:text-lg font-bold text-orange-600">
                    {formatCurrency(reportData.yearlyTotals.expenses)}
                  </p>
                </div>
                <div className="bg-yellow-50 dark:bg-yellow-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total Mistake</p>
                  <p className="text-base sm:text-lg font-bold text-yellow-600">
                    {formatCurrency(reportData.yearlyTotals.mistakes)}
                  </p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-950/20 rounded-lg p-3 sm:p-4">
                  <p className="text-xs sm:text-sm text-muted-foreground">Total Transaksi</p>
                  <p className="text-base sm:text-lg font-bold">
                    {reportData.yearlyTotals.totalTransactions}
                  </p>
                </div>
                <div className={`rounded-lg p-3 sm:p-4 col-span-2 ${reportData.yearlyTotals.netTotal >= 0 ? 'bg-green-50 dark:bg-green-950/20' : 'bg-red-50 dark:bg-red-950/20'}`}>
                  <p className="text-xs sm:text-sm text-muted-foreground">Net Total</p>
                  <p className={`text-base sm:text-lg font-bold flex items-center gap-1 ${
                    reportData.yearlyTotals.netTotal >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {reportData.yearlyTotals.netTotal >= 0 ? (
                      <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5" />
                    ) : (
                      <TrendingDown className="h-4 w-4 sm:h-5 sm:w-5" />
                    )}
                    {formatCurrency(reportData.yearlyTotals.netTotal)}
                  </p>
                </div>
              </div>

              {/* Simple CSS Bar Chart */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-muted-foreground">Grafik Perbandingan</p>
                <div className="h-4 bg-muted rounded-full overflow-hidden flex">
                  {reportData.yearlyTotals.deposits > 0 && (
                    <div
                      className="bg-green-500 transition-all duration-300"
                      style={{
                        width: `${(reportData.yearlyTotals.deposits / (reportData.yearlyTotals.deposits + reportData.yearlyTotals.withdrawals + reportData.yearlyTotals.inOut + reportData.yearlyTotals.expenses + reportData.yearlyTotals.mistakes)) * 100}%`
                      }}
                      title={`Deposit: ${formatCurrency(reportData.yearlyTotals.deposits)}`}
                    />
                  )}
                  {reportData.yearlyTotals.withdrawals > 0 && (
                    <div
                      className="bg-red-500 transition-all duration-300"
                      style={{
                        width: `${(reportData.yearlyTotals.withdrawals / (reportData.yearlyTotals.deposits + reportData.yearlyTotals.withdrawals + reportData.yearlyTotals.inOut + reportData.yearlyTotals.expenses + reportData.yearlyTotals.mistakes)) * 100}%`
                      }}
                      title={`Withdraw: ${formatCurrency(reportData.yearlyTotals.withdrawals)}`}
                    />
                  )}
                  {reportData.yearlyTotals.inOut > 0 && (
                    <div
                      className="bg-blue-500 transition-all duration-300"
                      style={{
                        width: `${(reportData.yearlyTotals.inOut / (reportData.yearlyTotals.deposits + reportData.yearlyTotals.withdrawals + reportData.yearlyTotals.inOut + reportData.yearlyTotals.expenses + reportData.yearlyTotals.mistakes)) * 100}%`
                      }}
                      title={`InOut: ${formatCurrency(reportData.yearlyTotals.inOut)}`}
                    />
                  )}
                  {reportData.yearlyTotals.expenses > 0 && (
                    <div
                      className="bg-orange-500 transition-all duration-300"
                      style={{
                        width: `${(reportData.yearlyTotals.expenses / (reportData.yearlyTotals.deposits + reportData.yearlyTotals.withdrawals + reportData.yearlyTotals.inOut + reportData.yearlyTotals.expenses + reportData.yearlyTotals.mistakes)) * 100}%`
                      }}
                      title={`Expense: ${formatCurrency(reportData.yearlyTotals.expenses)}`}
                    />
                  )}
                  {reportData.yearlyTotals.mistakes > 0 && (
                    <div
                      className="bg-yellow-500 transition-all duration-300"
                      style={{
                        width: `${(reportData.yearlyTotals.mistakes / (reportData.yearlyTotals.deposits + reportData.yearlyTotals.withdrawals + reportData.yearlyTotals.inOut + reportData.yearlyTotals.expenses + reportData.yearlyTotals.mistakes)) * 100}%`
                      }}
                      title={`Mistake: ${formatCurrency(reportData.yearlyTotals.mistakes)}`}
                    />
                  )}
                </div>
                <div className="flex flex-wrap gap-3 text-xs">
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-green-500 rounded"></span> Deposit</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-500 rounded"></span> Withdraw</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-blue-500 rounded"></span> InOut</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-orange-500 rounded"></span> Expense</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-yellow-500 rounded"></span> Mistake</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Laporan Bulanan</CardTitle>
              <CardDescription>
                Detail transaksi per bulan
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px] sm:h-[600px] rounded-md border">
                <div className="min-w-[800px]">
                  <table className="w-full">
                    <thead className="sticky top-0 bg-background">
                      <tr className="border-b">
                        <th className="p-3 sm:p-4 text-left">Bulan</th>
                        <th className="p-3 sm:p-4 text-right">Deposit</th>
                        <th className="p-3 sm:p-4 text-right">Withdraw</th>
                        <th className="p-3 sm:p-4 text-right">InOut</th>
                        <th className="p-3 sm:p-4 text-right">Expense</th>
                        <th className="p-3 sm:p-4 text-right">Mistake</th>
                        <th className="p-3 sm:p-4 text-right hidden sm:table-cell">Total Tx</th>
                        <th className="p-3 sm:p-4 text-right">Net Total</th>
                        <th className="p-3 sm:p-4 text-center">Detail</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reportData.monthlyData.map((month) => (
                        <>
                          <tr key={month.month} className="border-b hover:bg-muted/50">
                            <td className="p-3 sm:p-4 font-medium">{month.monthName}</td>
                            <td className="p-3 sm:p-4 text-right text-green-600 text-xs sm:text-sm">
                              {formatCurrency(month.depositTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-right text-red-600 text-xs sm:text-sm">
                              {formatCurrency(month.withdrawTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-right text-blue-600 text-xs sm:text-sm">
                              {formatCurrency(month.inOutTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-right text-orange-600 text-xs sm:text-sm">
                              {formatCurrency(month.expenseTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-right text-yellow-600 text-xs sm:text-sm">
                              {formatCurrency(month.mistakeTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-right hidden sm:table-cell text-xs sm:text-sm">
                              {month.transactionCount}
                            </td>
                            <td className={`p-3 sm:p-4 text-right font-bold text-xs sm:text-sm ${
                              month.netTotal >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {formatCurrency(month.netTotal)}
                            </td>
                            <td className="p-3 sm:p-4 text-center">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleMonthExpand(month.month)}
                                className="h-8 w-8 sm:h-auto sm:w-auto"
                              >
                                {expandedMonths.has(month.month) ? '−' : '+'}
                              </Button>
                            </td>
                          </tr>
                          {expandedMonths.has(month.month) && (
                            <tr>
                              <td colSpan={9} className="p-3 sm:p-4 bg-muted/20">
                                <div className="space-y-4">
                                  <h4 className="font-semibold text-sm sm:text-base">Rincian Harian - {month.monthName}</h4>
                                  <ScrollArea className="h-[300px] sm:h-[400px] rounded-md border">
                                    <div className="min-w-[900px]">
                                      <table className="w-full">
                                        <thead className="sticky top-0 bg-background">
                                          <tr className="border-b">
                                            <th className="p-2 sm:p-3 text-left text-xs">Tanggal</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Deposit</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Withdraw</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">InOut</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Expense</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Mistake</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Akuran</th>
                                            <th className="p-2 sm:p-3 text-right text-xs">Total</th>
                                            <th className="p-2 sm:p-3 text-center text-xs">Aksi</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {month.dailyBreakdown.map((day, idx) => (
                                            <>
                                              <tr key={idx} className="border-b hover:bg-muted/30">
                                                <td className="p-2 sm:p-3 text-xs">{day.date}</td>
                                                <td className="p-2 sm:p-3 text-right text-green-600 text-xs">
                                                  {day.deposits > 0 ? formatCurrency(day.deposits) : '-'}
                                                </td>
                                                <td className="p-2 sm:p-3 text-right text-red-600 text-xs">
                                                  {day.withdrawals > 0 ? formatCurrency(day.withdrawals) : '-'}
                                                </td>
                                                <td className="p-2 sm:p-3 text-right text-blue-600 text-xs">
                                                  {day.inOut > 0 ? formatCurrency(day.inOut) : '-'}
                                                </td>
                                                <td className="p-2 sm:p-3 text-right text-orange-600 text-xs">
                                                  {day.expenses > 0 ? formatCurrency(day.expenses) : '-'}
                                                </td>
                                                <td className="p-2 sm:p-3 text-right text-yellow-600 text-xs">
                                                  {day.mistakes > 0 ? formatCurrency(day.mistakes) : '-'}
                                                </td>
                                                <td className="p-2 sm:p-3 text-right text-purple-600 text-xs">
                                                  {day.akurans !== 0 ? formatCurrency(Math.abs(day.akurans)) : '-'}
                                                </td>
                                                <td className={`p-2 sm:p-3 text-right font-bold text-xs ${
                                                  day.total >= 0 ? 'text-green-600' : 'text-red-600'
                                                }`}>
                                                  {formatCurrency(day.total)}
                                                </td>
                                                <td className="p-2 sm:p-3 text-center">
                                                  <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    onClick={() => toggleTransactions(day.date)}
                                                    className="h-6 w-6 sm:h-8 sm:w-8"
                                                    disabled={day.transactions.length === 0}
                                                  >
                                                    {showTransactions.has(day.date) ? '−' : '+'}
                                                  </Button>
                                                </td>
                                              </tr>
                                              {showTransactions.has(day.date) && day.transactions.length > 0 && (
                                                <tr>
                                                  <td colSpan={9} className="p-2 sm:p-4 bg-muted/30">
                                                    <div className="space-y-2 max-h-[300px] overflow-y-auto">
                                                      <p className="text-xs font-semibold text-muted-foreground mb-2">Detail Transaksi ({day.transactions.length})</p>
                                                      {day.transactions.map((tx, txIdx) => (
                                                        <div
                                                          key={txIdx}
                                                          className="flex items-center justify-between gap-2 p-2 bg-background rounded border text-xs"
                                                        >
                                                          <div className="flex items-center gap-2 flex-1 min-w-0">
                                                            <div className={`w-2 h-2 rounded-full shrink-0 ${getTransactionColor(tx.type)}`} />
                                                            <span className="font-semibold shrink-0">{tx.type}</span>
                                                            <span className="font-bold">{formatCurrency(tx.amount)}</span>
                                                          </div>
                                                          <div className="flex-1 min-w-0 text-right truncate">
                                                            <span className="text-muted-foreground">{tx.bankName}</span>
                                                          </div>
                                                          {tx.notes && (
                                                            <span className="text-muted-foreground italic truncate max-w-[200px]">
                                                              "{tx.notes}"
                                                            </span>
                                                          )}
                                                        </div>
                                                      ))}
                                                    </div>
                                                  </td>
                                                </tr>
                                              )}
                                            </>
                                          ))}
                                        </tbody>
                                      </table>
                                    </div>
                                  </ScrollArea>
                                </div>
                              </td>
                            </tr>
                          )}
                        </>
                      ))}
                    </tbody>
                  </table>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

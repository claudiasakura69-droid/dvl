'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Building2, Plus, Trash2, Power, ArrowRightLeft, History } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'

interface BankManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Bank {
  id: string
  name: string
  accountName: string
  accountNumber: string | null
  type: 'DEPOSIT' | 'WITHDRAW'
  balance: number
  status: 'online' | 'offline'
  bankHistories: any[]
  dailyTransactions: any[]
}

interface BankFormData {
  name: string
  accountName: string
  accountNumber: string
  type: 'DEPOSIT' | 'WITHDRAW'
  balance: number
}

export default function BankManagementContent({ sessionId, user }: BankManagementContentProps) {
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false)
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null)
  const [formData, setFormData] = useState<BankFormData>({
    name: '',
    accountName: '',
    accountNumber: '',
    type: 'DEPOSIT',
    balance: 0
  })

  // Get user permissions
  const permissions: Permissions = getPermissions(user?.role || 'VIEW')

  useEffect(() => {
    fetchBanks()
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.data || data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateBank = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/banks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Bank berhasil dibuat')
        setDialogOpen(false)
        setFormData({
          name: '',
          accountName: '',
          accountNumber: '',
          type: 'DEPOSIT',
          balance: 0
        })
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal membuat bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteBank = async (bankId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus bank ini?')) return

    try {
      const response = await fetch(`/api/banks/${bankId}?sessionId=${sessionId}&userId=${user?.id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Bank berhasil dihapus')
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleToggleStatus = async (bankId: string, currentStatus: string) => {
    if (!sessionId || !user) return

    const newStatus = currentStatus === 'online' ? 'offline' : 'online'

    try {
      const response = await fetch(`/api/banks/${bankId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          status: newStatus,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`Status bank diubah menjadi ${newStatus}`)
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengubah status')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleMoveBank = async (bankId: string, currentType: string) => {
    if (!sessionId || !user) return

    const newType = currentType === 'DEPOSIT' ? 'WITHDRAW' : 'DEPOSIT'

    if (!confirm(`Pindahkan bank dari ${currentType} ke ${newType}?`)) return

    try {
      const response = await fetch(`/api/banks/${bankId}/move`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          newType,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`Bank berhasil dipindahkan ke ${newType}`)
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal memindahkan bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const depositBanks = banks.filter(b => b.type === 'DEPOSIT')
  const withdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Building2 className="h-6 w-6 sm:h-8 sm:w-8" />
            <span className="text-lg sm:text-xl">Bank Management</span>
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Kelola rekening deposit dan withdraw
          </p>
        </div>

        {permissions.canAdd && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Tambah Bank</span>
                <span className="sm:hidden">Tambah</span>
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
            <DialogHeader>
              <DialogTitle className="text-base sm:text-lg">Tambah Bank Baru</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateBank} className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-sm">Nama Bank</Label>
                <Input
                  id="name"
                  placeholder="Contoh: BCA, BRI, DANA, OVO"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="text-sm"
                />
              </div>
              <div>
                <Label htmlFor="accountName" className="text-sm">Nama Pemilik</Label>
                <Input
                  id="accountName"
                  placeholder="Contoh: Vera, David"
                  value={formData.accountName}
                  onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
                  required
                  className="text-sm"
                />
              </div>
              <div>
                <Label htmlFor="accountNumber" className="text-sm">Nomor Rekening (Opsional)</Label>
                <Input
                  id="accountNumber"
                  placeholder="Contoh: 1234567890"
                  value={formData.accountNumber}
                  onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  className="text-sm"
                />
              </div>
              <div>
                <Label htmlFor="type" className="text-sm">Tipe</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value })}
                >
                  <SelectTrigger className="text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DEPOSIT">Deposit</SelectItem>
                    <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="balance" className="text-sm">Saldo Awal</Label>
                <Input
                  id="balance"
                  type="number"
                  placeholder="0"
                  value={formData.balance}
                  onChange={(e) => setFormData({ ...formData, balance: parseFloat(e.target.value) || 0 })}
                  required
                  className="text-sm"
                />
              </div>
              <Button type="submit" className="w-full text-sm sm:text-base">
                Simpan
              </Button>
            </form>
          </DialogContent>
        </Dialog>
        )}
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 lg:grid-cols-2">
        {/* Deposit Banks */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              Deposit
              <span className="text-xs sm:text-sm font-normal text-muted-foreground">({depositBanks.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px]">
              <div className="space-y-3">
                {depositBanks.map((bank) => (
                  <BankCard
                    key={bank.id}
                    bank={bank}
                    onDelete={() => handleDeleteBank(bank.id)}
                    onToggleStatus={() => handleToggleStatus(bank.id, bank.status)}
                    onMove={() => handleMoveBank(bank.id, bank.type)}
                    onViewHistory={() => {
                      setSelectedBank(bank)
                      setHistoryDialogOpen(true)
                    }}
                    formatCurrency={formatCurrency}
                    permissions={permissions}
                  />
                ))}
                {depositBanks.length === 0 && (
                  <p className="text-center text-muted-foreground py-8 text-sm">
                    Belum ada bank deposit
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Withdraw Banks */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              Withdraw
              <span className="text-xs sm:text-sm font-normal text-muted-foreground">({withdrawBanks.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px]">
              <div className="space-y-3">
                {withdrawBanks.map((bank) => (
                  <BankCard
                    key={bank.id}
                    bank={bank}
                    onDelete={() => handleDeleteBank(bank.id)}
                    onToggleStatus={() => handleToggleStatus(bank.id, bank.status)}
                    onMove={() => handleMoveBank(bank.id, bank.type)}
                    onViewHistory={() => {
                      setSelectedBank(bank)
                      setHistoryDialogOpen(true)
                    }}
                    formatCurrency={formatCurrency}
                    permissions={permissions}
                  />
                ))}
                {withdrawBanks.length === 0 && (
                  <p className="text-center text-muted-foreground py-8 text-sm">
                    Belum ada bank withdraw
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* History Dialog */}
      <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
        <DialogContent className="max-w-2xl sm:max-w-3xl md:max-w-4xl max-h-[85vh] sm:max-h-[80vh] p-4 sm:p-6">
          <DialogHeader className="pb-4">
            <DialogTitle className="text-base sm:text-lg">History - {selectedBank?.name} - {selectedBank?.accountName}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh] sm:max-h-[65vh]">
            <div className="min-w-full">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs sm:text-sm">Event</TableHead>
                    <TableHead className="text-xs sm:text-sm">Old Value</TableHead>
                    <TableHead className="text-xs sm:text-sm">New Value</TableHead>
                    <TableHead className="text-xs sm:text-sm hidden md:table-cell">Notes</TableHead>
                    <TableHead className="text-xs sm:text-sm">Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedBank?.bankHistories?.map((history: any) => (
                    <TableRow key={history.id}>
                      <TableCell className="text-xs sm:text-sm">{history.eventType}</TableCell>
                      <TableCell className="text-xs sm:text-sm">
                        {history.oldValue || history.oldBalance !== undefined ? history.oldBalance : '-'}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm">
                        {history.newValue || history.newBalance !== undefined ? history.newBalance : '-'}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm hidden md:table-cell">{history.notes || '-'}</TableCell>
                      <TableCell className="text-xs sm:text-sm">{formatDate(history.createdAt)}</TableCell>
                    </TableRow>
                  ))}
                  {selectedBank?.bankHistories?.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground text-xs sm:text-sm">
                        Belum ada history
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface BankCardProps {
  bank: Bank
  onDelete: () => void
  onToggleStatus: () => void
  onMove: () => void
  onViewHistory: () => void
  formatCurrency: (amount: number) => string
  permissions: Permissions
}

function BankCard({ bank, onDelete, onToggleStatus, onMove, onViewHistory, formatCurrency, permissions }: BankCardProps) {
  return (
    <Card className={bank.status === 'online' ? 'border-green-500' : ''}>
      <CardContent className="p-3 sm:p-4">
        <div className="flex flex-col sm:flex-row items-start justify-between gap-3 mb-3">
          <div className="min-w-0 flex-1">
            <h3 className="font-semibold text-sm sm:text-base truncate">{bank.name} - {bank.accountName}</h3>
            {bank.accountNumber && (
              <p className="text-xs sm:text-sm text-muted-foreground truncate">{bank.accountNumber}</p>
            )}
          </div>
          <div className="flex gap-1 flex-wrap">
            {permissions.canEditBankStatus && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleStatus}
                title={bank.status === 'online' ? 'Set Offline' : 'Set Online'}
                className="h-8 w-8 p-0 sm:h-9 sm:w-auto sm:px-2"
              >
                <Power className={`h-4 w-4 ${bank.status === 'online' ? 'text-green-500' : 'text-gray-400'}`} />
                <span className="hidden sm:inline ml-2 text-xs">Status</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={onViewHistory}
              title="View History"
              className="h-8 w-8 p-0 sm:h-9 sm:w-auto sm:px-2"
            >
              <History className="h-4 w-4" />
              <span className="hidden sm:inline ml-2 text-xs">History</span>
            </Button>
            {permissions.canEditBankType && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onMove}
                title={`Move to ${bank.type === 'DEPOSIT' ? 'Withdraw' : 'Deposit'}`}
                className="h-8 w-8 p-0 sm:h-9 sm:w-auto sm:px-2"
              >
                <ArrowRightLeft className="h-4 w-4" />
                <span className="hidden sm:inline ml-2 text-xs">Move</span>
              </Button>
            )}
            {permissions.canDeleteBank && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                title="Delete"
                className="h-8 w-8 p-0 sm:h-9 sm:w-auto sm:px-2 text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
                <span className="hidden sm:inline ml-2 text-xs">Delete</span>
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs sm:text-sm text-muted-foreground">Status</span>
            <span className={`text-xs sm:text-sm font-medium ${bank.status === 'online' ? 'text-green-600' : 'text-gray-600'}`}>
              {bank.status}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-xs sm:text-sm text-muted-foreground">Balance</span>
            <span className="text-sm sm:font-semibold">{formatCurrency(bank.balance)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

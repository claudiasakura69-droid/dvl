'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar as CalendarIcon, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'

interface DateData {
  date: string
  count: number
  total: number
  hasDeposit: boolean
  hasWithdraw: boolean
}

interface CalendarContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

export default function CalendarContent({ sessionId, user }: CalendarContentProps) {
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear())
  const [datesWithTransactions, setDatesWithTransactions] = useState<DateData[]>([])
  const [loading, setLoading] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [selectedDateRange, setSelectedDateRange] = useState<{ start: string | null; end: string | null }>({
    start: null,
    end: null
  })
  const [isSelecting, setIsSelecting] = useState(false)
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))

  // Generate year options (last 5 years + current + next 5 years)
  const yearOptions = Array.from({ length: 11 }, (_, i) => {
    const year = new Date().getFullYear() - 5 + i
    return year
  })

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    fetchCalendarData()
  }, [currentYear])

  const fetchCalendarData = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/calendar?sessionId=${sessionId}&year=${currentYear}`)
      const data = await response.json()
      if (data.success) {
        setDatesWithTransactions(data.data)
      }
    } catch (error) {
      console.error('Error fetching calendar data:', error)
      toast.error('Gagal memuat data kalender')
    } finally {
      setLoading(false)
    }
  }

  const handleDateClick = (date: string) => {
    if (!isSelecting) {
      setSelectedDateRange({ start: date, end: null })
      setIsSelecting(true)
    } else if (selectedDateRange.start && !selectedDateRange.end) {
      const start = new Date(selectedDateRange.start)
      const end = new Date(date)
      const range = {
        start: start < end ? selectedDateRange.start : date,
        end: start < end ? date : selectedDateRange.start
      }
      setSelectedDateRange(range)
      setIsSelecting(false)
    }
  }

  const clearSelection = () => {
    setSelectedDateRange({ start: null, end: null })
    setIsSelecting(false)
  }

  const handleBulkDelete = async () => {
    if (!selectedDateRange.start || !selectedDateRange.end) {
      toast.error('Pilih rentang tanggal terlebih dahulu')
      return
    }

    setDeleteLoading(true)
    try {
      const response = await fetch(`/api/calendar?sessionId=${sessionId}&startDate=${selectedDateRange.start}&endDate=${selectedDateRange.end}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success(data.message)
        setIsDeleteDialogOpen(false)
        clearSelection()
        fetchCalendarData()
      } else {
        toast.error(data.error || 'Gagal menghapus transaksi')
      }
    } catch (error) {
      console.error('Error deleting transactions:', error)
      toast.error('Terjadi kesalahan saat menghapus')
    } finally {
      setDeleteLoading(false)
    }
  }

  const isDateInRange = (date: string) => {
    if (!selectedDateRange.start || !selectedDateRange.end) return false
    const d = new Date(date)
    const start = new Date(selectedDateRange.start)
    const end = new Date(selectedDateRange.end)
    return d >= start && d <= end
  }

  const isDateSelected = (date: string) => {
    return date === selectedDateRange.start || date === selectedDateRange.end
  }

  const renderMonth = (monthIndex: number) => {
    const date = new Date(currentYear, monthIndex, 1)
    const monthName = date.toLocaleDateString('id-ID', { month: 'long' })
    const daysInMonth = new Date(currentYear, monthIndex + 1, 0).getDate()
    const firstDayOfWeek = date.getDay()

    const days = []
    const dateDataMap = new Map(datesWithTransactions.map(d => [d.date, d]))

    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(<div key={`empty-${i}`} className="p-0.5 sm:p-1" />)
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${currentYear}-${String(monthIndex + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
      const dateData = dateDataMap.get(dateStr)
      const inRange = isDateInRange(dateStr)
      const isSelected = isDateSelected(dateStr)

      days.push(
        <div
          key={day}
          onClick={() => handleDateClick(dateStr)}
          className={`
            p-0.5 sm:p-1 text-[10px] sm:text-xs md:text-sm rounded-lg cursor-pointer transition-all
            ${dateData ? 'bg-black text-white hover:bg-gray-800' : 'hover:bg-muted/50'}
            ${inRange ? 'bg-primary text-white' : ''}
            ${isSelected ? 'ring-1 sm:ring-2 ring-primary' : ''}
            relative min-h-[45px] sm:min-h-[50px] md:min-h-[60px] flex flex-col items-center justify-center
          `}
        >
          <span className={`font-medium ${dateData ? 'text-white' : 'text-muted-foreground'}`}>
            {day}
          </span>
          {dateData && (
            <div className="mt-0.5 sm:mt-1 text-[9px] sm:text-[10px] md:text-xs text-white">
              <div>{dateData.count} tx</div>
              <div className="font-mono text-[8px] sm:text-[9px] md:text-[10px]">
                Rp {(dateData.total / 1000000).toFixed(1)}M
              </div>
            </div>
          )}
        </div>
      )
    }

    return (
      <Card key={monthIndex} className="col-span-1 p-2 sm:p-4">
        <CardHeader className="pb-2 sm:pb-3 px-2 sm:px-6">
          <CardTitle className="text-center text-base sm:text-lg">{monthName}</CardTitle>
        </CardHeader>
        <CardContent className="px-2 sm:px-6">
          <div className="grid grid-cols-7 gap-0.5 sm:gap-1 text-center text-[10px] sm:text-xs mb-1 sm:mb-2">
            {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map(day => (
              <div key={day} className="font-medium text-muted-foreground p-0.5 sm:p-1">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0.5 sm:gap-1">
            {days}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <CalendarIcon className="h-6 w-6 sm:h-8 sm:w-8" />
            Kalender Tahunan
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base">
            Lihat dan kelola transaksi per hari
          </p>
        </div>
        <Select value={currentYear.toString()} onValueChange={(value) => setCurrentYear(parseInt(value))}>
          <SelectTrigger className="w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {yearOptions.map((year) => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedDateRange.start && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-4 sm:pt-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <p className="text-xs sm:text-sm font-medium text-muted-foreground">Rentang Tanggal Terpilih:</p>
                <p className="text-base sm:text-lg font-bold">
                  {selectedDateRange.start} {selectedDateRange.end && ` - ${selectedDateRange.end}`}
                </p>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Button variant="outline" onClick={clearSelection} className="flex-1 sm:flex-none">
                  Batal Pilih
                </Button>
                {permissions.canDelete && (
                  <Button
                    variant="destructive"
                    onClick={() => setIsDeleteDialogOpen(true)}
                    disabled={!selectedDateRange.end}
                    className="flex-1 sm:flex-none"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Hapus Data
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Ringkasan</CardTitle>
          <CardDescription>
            {loading ? 'Memuat data...' : `Terdapat ${datesWithTransactions.length} hari dengan transaksi di tahun ${currentYear}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto" />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              <div className="bg-primary/10 rounded-lg p-3 sm:p-4">
                <p className="text-xs sm:text-sm text-muted-foreground">Hari dengan Transaksi</p>
                <p className="text-xl sm:text-2xl font-bold">{datesWithTransactions.length}</p>
              </div>
              <div className="bg-green-10 rounded-lg p-3 sm:p-4">
                <p className="text-xs sm:text-sm text-muted-foreground">Total Transaksi</p>
                <p className="text-xl sm:text-2xl font-bold">
                  {datesWithTransactions.reduce((sum, d) => sum + d.count, 0)}
                </p>
              </div>
              <div className="bg-blue-10 rounded-lg p-3 sm:p-4 sm:col-span-1">
                <p className="text-xs sm:text-sm text-muted-foreground">Total Nominal</p>
                <p className="text-xl sm:text-2xl font-bold">
                  Rp {datesWithTransactions.reduce((sum, d) => sum + d.total, 0).toLocaleString('id-ID')}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
        {Array.from({ length: 12 }, (_, i) => renderMonth(i))}
      </div>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive text-lg sm:text-xl">
              <Trash2 className="h-5 w-5" />
              Hapus Data Transaksi
            </DialogTitle>
            <DialogDescription className="text-sm sm:text-base">
              Apakah yakin ingin menghapus semua transaksi dari tanggal <span className="font-bold">{selectedDateRange.start}</span> sampai{' '}
              <span className="font-bold">{selectedDateRange.end}</span>?
              <br /><br />
              <span className="text-destructive font-bold">
                Data yang dihapus tidak dapat dipulihkan.
              </span>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              disabled={deleteLoading}
            >
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={handleBulkDelete}
              disabled={deleteLoading}
            >
              {deleteLoading ? 'Menghapus...' : 'Hapus Data'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

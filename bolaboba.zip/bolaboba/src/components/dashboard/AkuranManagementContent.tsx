'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Pencil, Trash2, Plus } from 'lucide-react'
import { toast } from 'sonner'
import { Permissions, getPermissions } from '@/lib/permissions'

interface Bank {
  id: string
  name: string
  type: string
  balance: number
}

interface Akuran {
  id: string
  date: string
  name: string
  amount: number
  type: 'deposit' | 'withdraw'
  notes: string | null
  bankId: string | null
  bankName: string | null
  bank?: {
    id: string
    name: string
    accountName: string
  }
  user: {
    id: string
    username: string
  }
}

interface AkuranManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

export default function AkuranManagementContent({ sessionId, user }: AkuranManagementContentProps) {
  const [akurans, setAkurans] = useState<Akuran[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  const [loading, setLoading] = useState(false)
  const [search, setSearch] = useState('')
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString())
  const [selectedBank, setSelectedBank] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [useDateRange, setUseDateRange] = useState(false)

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    name: '',
    amount: '',
    type: 'withdraw' as 'deposit' | 'withdraw',
    notes: '',
    bankId: ''
  })

  useEffect(() => {
    setPermissions(getPermissions(user?.role || 'VIEW'))
  }, [user?.role])

  useEffect(() => {
    fetchBanks()
    fetchAkurans()
  }, [selectedYear, selectedBank, search, startDate, endDate, useDateRange])

  const fetchBanks = async () => {
    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()
      if (data.success) {
        setBanks(data.data)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchAkurans = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const params = new URLSearchParams({
        sessionId,
        ...(useDateRange ? {} : { year: selectedYear })
      })

      if (useDateRange && startDate && endDate) {
        params.append('startDate', startDate)
        params.append('endDate', endDate)
      }

      if (selectedBank) params.append('bankId', selectedBank)
      if (search) params.append('search', search)

      const response = await fetch(`/api/akuran?${params}`)
      const data = await response.json()
      if (data.success) {
        setAkurans(data.data)
      }
    } catch (error) {
      console.error('Error fetching akurans:', error)
      toast.error('Gagal memuat data akuran')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.date || !formData.name || !formData.amount) {
      toast.error('Mohon lengkapi semua field yang diperlukan')
      return
    }

    try {
      const url = editingId ? `/api/akuran/${editingId}` : '/api/akuran'
      const method = editingId ? 'PATCH' : 'POST'

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...formData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(editingId ? 'Akuran berhasil diperbarui' : 'Akuran berhasil ditambahkan')
        setIsDialogOpen(false)
        resetForm()
        fetchAkurans()
      } else {
        toast.error(data.error || 'Gagal menyimpan akuran')
      }
    } catch (error) {
      console.error('Error submitting akuran:', error)
      toast.error('Terjadi kesalahan saat menyimpan')
    }
  }

  const handleEdit = (akuran: Akuran) => {
    setEditingId(akuran.id)
    setFormData({
      date: new Date(akuran.date).toISOString().split('T')[0],
      name: akuran.name,
      amount: akuran.amount.toString(),
      type: akuran.type,
      notes: akuran.notes || '',
      bankId: akuran.bankId || ''
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus akuran ini?')) return

    try {
      const response = await fetch(`/api/akuran/${id}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil dihapus')
        fetchAkurans()
      } else {
        toast.error(data.error || 'Gagal menghapus akuran')
      }
    } catch (error) {
      console.error('Error deleting akuran:', error)
      toast.error('Terjadi kesalahan saat menghapus')
    }
  }

  const resetForm = () => {
    setEditingId(null)
    setFormData({
      date: new Date().toISOString().split('T')[0],
      name: '',
      amount: '',
      type: 'withdraw',
      notes: '',
      bankId: ''
    })
  }

  const getBankDisplayName = (akuran: Akuran): string => {
    if (akuran.bank) {
      return `${akuran.bank.name} - ${akuran.bank.accountName}`
    }
    return akuran.bankName || '-'
  }

  const getFilteredBanks = (type: 'deposit' | 'withdraw') => {
    return banks.filter(bank => 
      type === 'withdraw' ? bank.type === 'WITHDRAW' : bank.type === 'DEPOSIT'
    )
  }

  const resetDateRange = () => {
    setStartDate('')
    setEndDate('')
    setUseDateRange(false)
  }

  const years = Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - i)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Akuran</h2>
          <p className="text-muted-foreground text-sm sm:text-base">
            Kelola transaksi tahunan
          </p>
        </div>
        {permissions.canAdd && (
          <Button onClick={() => { resetForm(); setIsDialogOpen(true) }} className="w-full sm:w-auto min-h-[44px]">
            <Plus className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Tambah Akuran</span>
            <span className="sm:hidden">Tambah</span>
          </Button>
        )}
      </div>

      {/* Filters Card */}
      <Card>
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="text-base sm:text-lg">Filter & Pencarian</CardTitle>
          <CardDescription className="text-xs sm:text-sm">Filter dan cari data akuran</CardDescription>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          <div className="space-y-4">
            {/* Date Filter Toggle */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="useDateRange"
                checked={useDateRange}
                onChange={(e) => setUseDateRange(e.target.checked)}
                className="h-4 w-4"
              />
              <label htmlFor="useDateRange" className="text-sm font-medium cursor-pointer">
                Gunakan rentang tanggal (lebih spesifik dari tahun)
              </label>
            </div>

            <div className={`grid gap-4 ${useDateRange ? 'sm:grid-cols-3' : 'md:grid-cols-3'}`}>
              {!useDateRange && (
                <div>
                  <label className="text-sm font-medium mb-2 block">Tahun</label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {useDateRange && (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Dari Tanggal</label>
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Sampai Tanggal</label>
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                  <div className="flex items-end">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={resetDateRange}
                      className="w-full"
                    >
                      Reset
                    </Button>
                  </div>
                </>
              )}

              <div>
                <label className="text-sm font-medium mb-2 block">Bank</label>
                <Select value={selectedBank} onValueChange={setSelectedBank}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Semua Bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Bank</SelectItem>
                    {banks && banks.map(bank => (
                      <SelectItem key={bank.id} value={bank.id}>
                        {bank.name} ({bank.type === 'DEPOSIT' ? 'Deposit' : 'Withdraw'})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Cari</label>
                <Input
                  placeholder="Nama atau catatan..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Akuran List Card */}
      <Card>
        <CardHeader className="p-4 sm:p-6">
          <CardTitle className="text-base sm:text-lg">Daftar Akuran</CardTitle>
          <CardDescription className="text-xs sm:text-sm">
            Total: {akurans.length} transaksi
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 sm:p-6">
          <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px] rounded-md border">
            <div className="min-w-full overflow-x-auto">
              <table className="w-full">
                <thead className="sticky top-0 bg-background">
                  <tr className="border-b">
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm">Tanggal</th>
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm">Nama</th>
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm">Tipe</th>
                    <th className="p-3 sm:p-4 text-right text-xs sm:text-sm">Jumlah</th>
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm hidden md:table-cell">Bank</th>
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm hidden md:table-cell">Catatan</th>
                    <th className="p-3 sm:p-4 text-left text-xs sm:text-sm hidden sm:table-cell">User</th>
                    <th className="p-3 sm:p-4 text-center text-xs sm:text-sm">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={8} className="p-4 text-center text-xs sm:text-sm">
                        Memuat data...
                      </td>
                    </tr>
                  ) : akurans.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-4 text-center text-xs sm:text-sm">
                        Tidak ada data akuran
                      </td>
                    </tr>
                  ) : (
                    akurans.map((akuran) => (
                      <tr key={akuran.id} className="border-b hover:bg-muted/50">
                        <td className="p-3 sm:p-4 text-xs sm:text-sm">
                          <div className="font-medium">
                            {new Date(akuran.date).toLocaleDateString('id-ID', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric'
                            })}
                          </div>
                          <div className="text-xs text-muted-foreground hidden sm:block">
                            {new Date(akuran.date).toLocaleDateString('id-ID', {
                              month: 'long'
                            })}
                          </div>
                        </td>
                        <td className="p-3 sm:p-4 font-medium text-xs sm:text-base">{akuran.name}</td>
                        <td className="p-3 sm:p-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            akuran.type === 'deposit'
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                          }`}>
                            {akuran.type === 'deposit' ? 'Deposit' : 'Withdraw'}
                          </span>
                        </td>
                        <td className={`p-3 sm:p-4 text-right font-mono text-xs sm:text-sm ${
                          akuran.type === 'deposit' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          Rp {akuran.amount.toLocaleString('id-ID')}
                        </td>
                        <td className="p-3 sm:p-4 text-xs sm:text-sm hidden md:table-cell">
                          {getBankDisplayName(akuran)}
                        </td>
                        <td className="p-3 sm:p-4 text-xs sm:text-sm text-muted-foreground max-w-xs truncate hidden md:table-cell">
                          {akuran.notes || '-'}
                        </td>
                        <td className="p-3 sm:p-4 text-xs sm:text-sm hidden sm:table-cell">{akuran.user.username}</td>
                        <td className="p-3 sm:p-4">
                          <div className="flex items-center justify-center gap-1 sm:gap-2">
                            {permissions.canEdit && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEdit(akuran)}
                                className="h-8 w-8 sm:h-9 sm:w-9"
                              >
                                <Pencil className="h-3 w-3 sm:h-4 sm:w-4" />
                              </Button>
                            )}
                            {permissions.canDelete && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(akuran.id)}
                                className="h-8 w-8 sm:h-9 sm:w-9"
                              >
                                <Trash2 className="h-3 w-3 sm:h-4 sm:w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">
              {editingId ? 'Edit Akuran' : 'Tambah Akuran Baru'}
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm">
              {editingId ? 'Perbarui data akuran' : 'Tambah transaksi akuran baru'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Tanggal</label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Nama / Keterangan</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Nama transaksi"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Jumlah</label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Tipe</label>
                <Select
                  value={formData.type}
                  onValueChange={(value: 'deposit' | 'withdraw') => setFormData({ ...formData, type: value, bankId: '' })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="withdraw">Withdraw</SelectItem>
                    <SelectItem value="deposit">Deposit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Bank {formData.type === 'withdraw' ? '(WITHDRAW)' : '(DEPOSIT)'}
                </label>
                <Select
                  value={formData.bankId}
                  onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={`Pilih Bank ${formData.type}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {getFilteredBanks(formData.type).map(bank => (
                      <SelectItem key={bank.id} value={bank.id}>
                        {bank.name} - Rp {bank.balance.toLocaleString('id-ID')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Catatan</label>
                <Input
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Catatan (opsional)"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Batal
              </Button>
              <Button type="submit">
                {editingId ? 'Update' : 'Simpan'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

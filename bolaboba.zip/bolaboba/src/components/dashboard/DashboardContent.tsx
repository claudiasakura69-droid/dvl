'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Users, Building2, Activity, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface DashboardContentProps {
  user: { id: string, username: string } | null
  sessionId: string | null
}

interface Stats {
  totalUsers: number
  totalBanks: number
  totalTransactions: number
  totalAmount: number
}

export default function DashboardContent({ user, sessionId }: DashboardContentProps) {
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalBanks: 0,
    totalTransactions: 0,
    totalAmount: 0
  })

  useEffect(() => {
    const fetchStats = async () => {
      if (!sessionId) return

      try {
        // Fetch banks count
        const banksRes = await fetch(`/api/banks?sessionId=${sessionId}`)
        const banksData = await banksRes.json()

        if (banksData.success) {
          setStats(prev => ({
            ...prev,
            totalBanks: banksData.data.length
          }))
        }

        // Fetch users count
        const usersRes = await fetch(`/api/users?sessionId=${sessionId}`)
        const usersData = await usersRes.json()

        if (usersData.success) {
          setStats(prev => ({
            ...prev,
            totalUsers: usersData.data.length
          }))
        }

        // Fetch transactions count
        const txRes = await fetch(`/api/daily-transactions?sessionId=${sessionId}`)
        const txData = await txRes.json()

        if (txData.success) {
          const totalAmount = txData.data.reduce((sum: number, tx: any) => sum + tx.amount, 0)
          setStats(prev => ({
            ...prev,
            totalTransactions: txData.data.length,
            totalAmount: totalAmount
          }))
        }
      } catch (error) {
        console.error('Error fetching stats:', error)
      }
    }

    fetchStats()
  }, [sessionId])

  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    {
      title: 'Total Banks',
      value: stats.totalBanks,
      icon: Building2,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    },
    {
      title: 'Total Transactions',
      value: stats.totalTransactions,
      icon: Activity,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10'
    },
    {
      title: 'Total Amount',
      value: `Rp ${stats.totalAmount.toLocaleString('id-ID')}`,
      icon: TrendingUp,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10'
    }
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Selamat datang di Bank Management System. Berikut ringkasan aktivitas hari ini.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <Icon className={cn('h-4 w-4', stat.color)} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Selamat Datang di Bank Management System</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Sistem ini dirancang untuk membantu Anda mengelola semua transaksi perbankan dengan mudah.
            Gunakan menu di sebelah kiri untuk mengakses berbagai fitur.
          </p>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <h3 className="font-semibold">Fitur Utama</h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• User Management - Kelola pengguna yang login</li>
                <li>• Bank Management - Atur rekening deposit & withdraw</li>
                <li>• Day Transactions - Catat transaksi harian</li>
                <li>• In/Out - Perpindahan antar bank</li>
                <li>• Expense - Catat pengeluaran</li>
                <li>• Mistake - Koreksi kesalahan transaksi</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold">Info Sistem</h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Semua data tersimpan di database</li>
                <li>• Export ke Excel tersedia</li>
                <li>• Tracking login/logout user</li>
                <li>• History transaksi per bank</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function cn(...classes: (string | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}

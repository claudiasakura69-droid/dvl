'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Users, Activity, Plus, Shield, X } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'

interface UserManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface UserData {
  id: string
  username: string
  isActive: boolean
  createdAt: string
  sessions: SessionData[]
}

interface SessionData {
  id: string
  loginAt: string
  logoutAt: string | null
  ipAddress: string | null
  isOnline: boolean
}

export default function UserManagementContent({ sessionId, user }: UserManagementContentProps) {
  const [users, setUsers] = useState<UserData[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'VIEW' as 'VIEW' | 'ADMIN' | 'SUPPORT' | 'SUPERVISOR' | 'MASTER'
  })

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    fetchUsers()
  }, [sessionId])

  const fetchUsers = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/users?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setUsers(data.data || data.users || [])
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          creatorId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('User berhasil dibuat')
        setDialogOpen(false)
        setFormData({
          username: '',
          password: '',
          role: 'VIEW'
        })
        fetchUsers()
      } else {
        toast.error(data.error || 'Gagal membuat user')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const onlineCount = users.reduce((count, user) => {
    return count + user.sessions.filter(s => s.isOnline).length
  }, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Users className="h-6 w-6 sm:h-8 sm:w-8" />
            <span className="text-lg sm:text-xl">User Management</span>
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Kelola user dan permissions
          </p>
        </div>

        {permissions.canAdd && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Tambah User</span>
                <span className="sm:hidden">Tambah</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle className="text-base sm:text-lg">Tambah User Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddUser} className="space-y-4">
                <div>
                  <Label htmlFor="username" className="text-sm">Username</Label>
                  <Input
                    id="username"
                    placeholder="Masukkan username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    required
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="password" className="text-sm">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Masukkan password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    required
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="role" className="text-sm">Role</Label>
                  <Select
                    value={formData.role}
                    onValueChange={(value: 'VIEW' | 'ADMIN' | 'SUPPORT' | 'SUPERVISOR' | 'MASTER') =>
                      setFormData({ ...formData, role: value })
                    }
                  >
                    <SelectTrigger className="text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="VIEW">VIEW - View Only</SelectItem>
                      <SelectItem value="ADMIN">ADMIN - Add & View</SelectItem>
                      <SelectItem value="SUPPORT">SUPPORT - Add, Edit & View</SelectItem>
                      <SelectItem value="SUPERVISOR">SUPERVISOR - Full Access</SelectItem>
                      <SelectItem value="MASTER">MASTER - Full Access</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="submit" className="w-full text-sm sm:text-base">
                    Simpan
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online Now</CardTitle>
            <Activity className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{onlineCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User List</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Memuat data...</p>
          ) : users.length === 0 ? (
            <p className="text-muted-foreground">Belum ada user yang terdaftar.</p>
          ) : (
            <div className="space-y-6">
              {users.map((user) => (
                <div key={user.id} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{user.username}</h3>
                      <p className="text-sm text-muted-foreground">
                        Created: {formatDate(user.createdAt)}
                      </p>
                    </div>
                    <Badge variant={user.isActive ? 'default' : 'secondary'}>
                      {user.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>

                  {user.sessions.length > 0 && (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Status</TableHead>
                          <TableHead>Login Time</TableHead>
                          <TableHead>Logout Time</TableHead>
                          <TableHead>IP Address</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {user.sessions.map((session) => (
                          <TableRow key={session.id}>
                            <TableCell>
                              <Badge variant={session.isOnline ? 'default' : 'secondary'}>
                                {session.isOnline ? 'Online' : 'Offline'}
                              </Badge>
                            </TableCell>
                            <TableCell>{formatDate(session.loginAt)}</TableCell>
                            <TableCell>
                              {session.logoutAt ? formatDate(session.logoutAt) : '-'}
                            </TableCell>
                            <TableCell>{session.ipAddress || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}

                  {user.sessions.length === 0 && (
                    <p className="text-sm text-muted-foreground">Belum ada session</p>
                  )}

                  <div className="border-t" />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

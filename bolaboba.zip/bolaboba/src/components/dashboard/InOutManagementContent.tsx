'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowRight, Plus, Edit, Trash2, Calendar } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'

interface InOutManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface InOut {
  id: string
  amount: number
  notes: string | null
  fromBankId: string | null
  fromBankName: string | null
  toBankId: string | null
  toBankName: string | null
  createdAt: string
  fromBank?: {
    id: string
    name: string
    accountName: string
  }
  toBank?: {
    id: string
    name: string
    accountName: string
  }
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: string
}

export default function InOutManagementContent({ sessionId, user }: InOutManagementContentProps) {
  const [inOuts, setInOuts] = useState<InOut[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedInOut, setSelectedInOut] = useState<InOut | null>(null)
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  
  // Date range filter
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  
  const [formData, setFormData] = useState({
    fromBankId: '',
    toBankId: '',
    amount: '',
    notes: ''
  })

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchInOuts()
    }
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.data || [])
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchInOuts = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/inout?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setInOuts(data.data || [])
      }
    } catch (error) {
      console.error('Error fetching inouts:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddInOut = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/inout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          fromBankId: '',
          toBankId: '',
          amount: '',
          notes: ''
        })
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menambahkan InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditInOut = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user || !selectedInOut) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/inout', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          inOutId: selectedInOut.id,
          ...formData,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil diubah')
        setEditDialogOpen(false)
        setSelectedInOut(null)
        setFormData({
          fromBankId: '',
          toBankId: '',
          amount: '',
          notes: ''
        })
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengubah InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteInOut = async () => {
    if (!sessionId || !user || !selectedInOut) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/inout?sessionId=${sessionId}&inOutId=${selectedInOut.id}&userId=${user.id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil dihapus')
        setDeleteDialogOpen(false)
        setSelectedInOut(null)
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (inout: InOut) => {
    setSelectedInOut(inout)
    setFormData({
      fromBankId: inout.fromBankId || '',
      toBankId: inout.toBankId || '',
      amount: inout.amount.toString(),
      notes: inout.notes || ''
    })
    setEditDialogOpen(true)
  }

  const openDeleteDialog = (inout: InOut) => {
    setSelectedInOut(inout)
    setDeleteDialogOpen(true)
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getBankDisplayName = (bank: { name: string, accountName: string } | null, bankName: string | null) => {
    if (bank && bank.name) {
      return { name: bank.name, accountName: bank.accountName || '' }
    }
    if (bankName) {
      const parts = bankName.split(' - ')
      return { name: parts[0] || bankName, accountName: parts[1] || '' }
    }
    return { name: 'Bank Tidak Dikenal', accountName: '' }
  }

  // Filter inOuts by date range
  const filteredInOuts = inOuts.filter(inout => {
    if (!startDate && !endDate) return true
    
    const inoutDate = new Date(inout.createdAt)
    const start = startDate ? new Date(startDate) : null
    const end = endDate ? new Date(endDate) : null
    
    if (start && end) {
      return inoutDate >= start && inoutDate <= end
    }
    if (start) {
      return inoutDate >= start
    }
    if (end) {
      return inoutDate <= end
    }
    return true
  })

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <ArrowRight className="h-6 w-6 sm:h-8 sm:w-8" />
            In / Out
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            Catat perpindahan nominal antar bank
          </p>
        </div>

        {permissions.canAdd && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full sm:w-auto min-h-[44px] sm:min-h-0">
                <Plus className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">Tambah InOut</span>
                <span className="sm:hidden">Tambah</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle className="text-base sm:text-lg">Tambah Perpindahan Antar Bank</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddInOut} className="space-y-4">
                <div>
                  <Label htmlFor="fromBank" className="text-sm">Dari Bank</Label>
                  <Select
                    value={formData.fromBankId}
                    onValueChange={(value) => setFormData({ ...formData, fromBankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank asal" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks && banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({bank.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toBank" className="text-sm">Ke Bank</Label>
                  <Select
                    value={formData.toBankId}
                    onValueChange={(value) => setFormData({ ...formData, toBankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank tujuan" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks && banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({bank.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount" className="text-sm">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes" className="text-sm">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan untuk transaksi ini"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Date Range Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg">Filter Tanggal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startDate" className="text-sm">Tanggal Mulai</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="endDate" className="text-sm">Tanggal Akhir</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
          {(startDate || endDate) && (
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => {
                setStartDate('')
                setEndDate('')
              }}
            >
              Reset Filter
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg">Riwayat Perpindahan</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px]">
            {loading ? (
              <p className="text-center py-8">Memuat data...</p>
            ) : filteredInOuts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada perpindahan antar bank</p>
            ) : (
              <div className="min-w-full">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm">Waktu</TableHead>
                      <TableHead className="text-xs sm:text-sm">Dari Bank</TableHead>
                      <TableHead className="text-xs sm:text-sm">Ke Bank</TableHead>
                      <TableHead className="text-xs sm:text-sm">Nominal</TableHead>
                      <TableHead className="hidden md:table-cell text-xs sm:text-sm">Catatan</TableHead>
                      <TableHead className="hidden sm:table-cell text-xs sm:text-sm">User</TableHead>
                      {(permissions.canEdit || permissions.canDelete) && (
                        <TableHead className="text-xs sm:text-sm">Aksi</TableHead>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredInOuts.map((inout) => {
                      const fromBankDisplay = getBankDisplayName(inout.fromBank, inout.fromBankName)
                      const toBankDisplay = getBankDisplayName(inout.toBank, inout.toBankName)
                      
                      return (
                        <TableRow key={inout.id}>
                          <TableCell className="text-xs sm:text-sm">
                            <div className="hidden sm:block">{formatDate(inout.createdAt)}</div>
                            <div className="sm:hidden text-xs">{new Date(inout.createdAt).toLocaleDateString('id-ID')}</div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium text-xs sm:text-sm">{fromBankDisplay.name}</div>
                            <div className="text-xs text-muted-foreground">{fromBankDisplay.accountName}</div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium text-xs sm:text-sm">{toBankDisplay.name}</div>
                            <div className="text-xs text-muted-foreground">{toBankDisplay.accountName}</div>
                          </TableCell>
                          <TableCell className="font-semibold text-xs sm:text-sm">{formatCurrency(inout.amount)}</TableCell>
                          <TableCell className="hidden md:table-cell text-xs sm:text-sm">{inout.notes || '-'}</TableCell>
                          <TableCell className="hidden sm:table-cell text-xs sm:text-sm">{inout.user.username}</TableCell>
                          {(permissions.canEdit || permissions.canDelete) && (
                            <TableCell>
                              <div className="flex gap-1 sm:gap-2">
                                {permissions.canEdit && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 sm:h-9 sm:w-9"
                                    onClick={() => openEditDialog(inout)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                )}
                                {permissions.canDelete && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 sm:h-9 sm:w-9 text-destructive hover:text-destructive"
                                    onClick={() => openDeleteDialog(inout)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Edit Perpindahan Antar Bank</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditInOut} className="space-y-4">
            <div>
              <Label htmlFor="editFromBank" className="text-sm">Dari Bank</Label>
              <Select
                value={formData.fromBankId}
                onValueChange={(value) => setFormData({ ...formData, fromBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank asal" />
                </SelectTrigger>
                <SelectContent>
                  {banks && banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editToBank" className="text-sm">Ke Bank</Label>
              <Select
                value={formData.toBankId}
                onValueChange={(value) => setFormData({ ...formData, toBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank tujuan" />
                </SelectTrigger>
                <SelectContent>
                  {banks && banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editAmount" className="text-sm">Nominal</Label>
              <Input
                id="editAmount"
                type="number"
                placeholder="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editNotes" className="text-sm">Catatan (Opsional)</Label>
              <Input
                id="editNotes"
                placeholder="Catatan untuk transaksi ini"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="submit" className="w-full sm:w-auto">
                Simpan Perubahan
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-sm sm:max-w-md p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Hapus Transaksi</DialogTitle>
          </DialogHeader>
          {selectedInOut && (
            <div className="space-y-2 text-sm">
              <p>Apakah Anda yakin ingin menghapus transaksi ini?</p>
              <div className="bg-muted p-3 rounded-md">
                <p><strong>Nominal:</strong> {formatCurrency(selectedInOut.amount)}</p>
                <p><strong>Dari:</strong> {selectedInOut.fromBankName || selectedInOut.fromBank?.name || 'Deleted Bank'}</p>
                <p><strong>Ke:</strong> {selectedInOut.toBankName || selectedInOut.toBank?.name || 'Deleted Bank'}</p>
              </div>
              <p className="text-destructive">Saldo bank akan dikembalikan ke nilai sebelum transaksi.</p>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteInOut}
              className="w-full sm:w-auto"
            >
              Hapus
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Lock, User, LogOut, Users, Building2, Calendar, ArrowRight, Receipt, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

// Import page components
import LoginPage from '@/components/dashboard/LoginPage'
import DashboardLayout from '@/components/dashboard/DashboardLayout'

type Page = 'login' | 'dashboard' | 'users' | 'banks' | 'day' | 'inout' | 'expense' | 'mistake' | 'akuran' | 'calendar' | 'report'

export default function Home() {
  const [currentPage, setCurrentPage] = useState<Page>('login')
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [user, setUser] = useState<{ id: string, username: string, role?: string } | null>(null)

  // Load session from localStorage on mount
  useEffect(() => {
    const savedSessionId = localStorage.getItem('sessionId')
    const savedUser = localStorage.getItem('user')

    if (savedSessionId && savedUser) {
      // Validate session
      fetch('/api/auth/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: savedSessionId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          setSessionId(savedSessionId)
          setUser(JSON.parse(savedUser))
          setCurrentPage('dashboard')
        } else {
          localStorage.removeItem('sessionId')
          localStorage.removeItem('user')
        }
      })
      .catch(() => {
        localStorage.removeItem('sessionId')
        localStorage.removeItem('user')
      })
    }
  }, [])

  const handleLogin = async (username: string, token: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, token })
      })

      const data = await response.json()

      if (data.success) {
        setSessionId(data.sessionId)
        setUser(data.user)
        localStorage.setItem('sessionId', data.sessionId)
        localStorage.setItem('user', JSON.stringify(data.user))
        setCurrentPage('dashboard')
        toast.success('Login berhasil!')
      } else {
        toast.error(data.error || 'Login gagal')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat login')
    }
  }

  const handleLogout = async () => {
    if (sessionId) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      })
    }

    setSessionId(null)
    setUser(null)
    localStorage.removeItem('sessionId')
    localStorage.removeItem('user')
    setCurrentPage('login')
    toast.success('Logout berhasil!')
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onLogin={handleLogin} />

      case 'dashboard':
      case 'users':
      case 'banks':
      case 'day':
      case 'inout':
      case 'expense':
      case 'mistake':
      case 'akuran':
      case 'calendar':
      case 'report':
        return (
          <DashboardLayout
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            user={user}
            onLogout={handleLogout}
            sessionId={sessionId}
          />
        )

      default:
        return <LoginPage onLogin={handleLogin} />
    }
  }

  return (
    <main className="min-h-screen bg-background">
      {renderPage()}
    </main>
  )
}

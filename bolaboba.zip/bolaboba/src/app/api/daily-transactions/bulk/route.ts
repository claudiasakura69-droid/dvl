import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// POST - Buat banyak transaksi sekaligus
export async function POST(req: NextRequest) {
  try {
    const { sessionId, transactions, userId } = await req.json()

    if (!sessionId || !transactions || !Array.isArray(transactions) || transactions.length === 0 || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap atau format salah' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah data' },
        { status: 403 }
      )
    }

    const results = []
    const errors = []

    // Proses setiap transaksi
    for (const tx of transactions) {
      try {
        const { date, name, accountNumber, amount, type, bankId } = tx

        if (!date || !name || !amount || !type || !bankId) {
          errors.push({
            data: tx,
            error: 'Data tidak lengkap'
          })
          continue
        }

        if (!['DEPOSIT', 'WITHDRAW'].includes(type)) {
          errors.push({
            data: tx,
            error: 'Type tidak valid'
          })
          continue
        }

        // Cari bank
        const bank = await db.bank.findUnique({
          where: { id: bankId }
        })

        if (!bank) {
          errors.push({
            data: tx,
            error: 'Bank tidak ditemukan'
          })
          continue
        }

        // Parse tanggal
        const transactionDate = new Date(date)
        const parsedAmount = parseFloat(amount)

        // Simpan nama bank sebagai backup
        const bankName = `${bank.name} - ${bank.accountName}`

        // Buat transaksi
        const transaction = await db.dailyTransaction.create({
          data: {
            date: transactionDate,
            name,
            accountNumber: accountNumber || null,
            amount: parsedAmount,
            type,
            bankId,
            bankName,
            userId
          }
        })

        // Update balance bank
        const newBalance = type === 'DEPOSIT'
          ? bank.balance + parsedAmount
          : bank.balance - parsedAmount

        await db.bank.update({
          where: { id: bankId },
          data: { balance: newBalance }
        })

        // Buat bank history
        await db.bankHistory.create({
          data: {
            bankId,
            eventType: 'DAILY_TRANSACTION_BULK',
            oldBalance: bank.balance,
            newBalance: newBalance,
            notes: `Bulk ${type} ${parsedAmount.toLocaleString('id-ID')} - ${name}`,
            userId
          }
        })

        results.push({
          success: true,
          transaction,
          newBalance
        })
      } catch (err) {
        errors.push({
          data: tx,
          error: err instanceof Error ? err.message : 'Terjadi kesalahan'
        })
      }
    }

    return NextResponse.json({
      success: true,
      results,
      errors,
      total: transactions.length,
      successCount: results.length,
      errorCount: errors.length
    })
  } catch (error) {
    console.error('Bulk daily transactions error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat transaksi bulk' },
      { status: 500 }
    )
  }
}

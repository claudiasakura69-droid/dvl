import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil satu transaksi berdasarkan ID
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk melihat data ini' },
        { status: 403 }
      )
    }

    // Ambil transaksi
    const transaction = await db.dailyTransaction.findUnique({
      where: { id },
      include: {
        bank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      transaction
    })
  } catch (error) {
    console.error('Get daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data transaksi' },
      { status: 500 }
    )
  }
}

// PATCH - Update transaksi
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, date, name, accountNumber, amount, type, bankId } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canEdit) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit data' },
        { status: 403 }
      )
    }

    // Ambil transaksi lama
    const existingTransaction = await db.dailyTransaction.findUnique({
      where: { id },
      include: { bank: true }
    })

    if (!existingTransaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    let bankName = existingTransaction.bankName

    // Cek apakah bankId berubah
    if (bankId && bankId !== existingTransaction.bankId) {
      // Revert balance bank lama jika ada
      if (existingTransaction.bank) {
        const oldBankRevertBalance = existingTransaction.type === 'DEPOSIT'
          ? existingTransaction.bank.balance - existingTransaction.amount
          : existingTransaction.bank.balance + existingTransaction.amount

        await db.bank.update({
          where: { id: existingTransaction.bankId! },
          data: { balance: oldBankRevertBalance }
        })

        // Buat bank history untuk revert
        await db.bankHistory.create({
          data: {
            bankId: existingTransaction.bankId!,
            eventType: 'DAILY_TRANSACTION_EDIT_REVERT',
            oldBalance: existingTransaction.bank.balance,
            newBalance: oldBankRevertBalance,
            notes: `Edit: Revert ${existingTransaction.type} ${existingTransaction.amount.toLocaleString('id-ID')} - ${existingTransaction.name}`,
            userId: session.userId
          }
        })
      }

      // Cari bank baru
      const newBank = await db.bank.findUnique({
        where: { id: bankId }
      })

      if (!newBank) {
        return NextResponse.json(
          { error: 'Bank tidak ditemukan' },
          { status: 404 }
        )
      }

      // Update bankName backup
      bankName = `${newBank.name} - ${newBank.accountName}`
    }

    // Parse values
    const parsedAmount = amount !== undefined ? parseFloat(amount) : existingTransaction.amount
    const parsedType = type || existingTransaction.type
    const parsedDate = date ? new Date(date) : existingTransaction.date

    // Cek jika amount atau type berubah, revert dan apply balance baru
    if (amount !== undefined || type !== undefined) {
      // Revert balance bank lama (jika bank masih ada)
      if (existingTransaction.bank) {
        const oldBankRevertBalance = existingTransaction.type === 'DEPOSIT'
          ? existingTransaction.bank.balance - existingTransaction.amount
          : existingTransaction.bank.balance + existingTransaction.amount

        await db.bank.update({
          where: { id: existingTransaction.bankId! },
          data: { balance: oldBankRevertBalance }
        })

        // Buat bank history untuk revert
        await db.bankHistory.create({
          data: {
            bankId: existingTransaction.bankId!,
            eventType: 'DAILY_TRANSACTION_EDIT_REVERT',
            oldBalance: existingTransaction.bank.balance,
            newBalance: oldBankRevertBalance,
            notes: `Edit: Revert ${existingTransaction.type} ${existingTransaction.amount.toLocaleString('id-ID')} - ${existingTransaction.name}`,
            userId: session.userId
          }
        })
      }

      // Apply balance baru ke bank yang aktif saat ini
      const activeBankId = bankId || existingTransaction.bankId
      if (activeBankId) {
        const bank = await db.bank.findUnique({
          where: { id: activeBankId }
        })

        if (bank) {
          const newBankBalance = parsedType === 'DEPOSIT'
            ? bank.balance + parsedAmount
            : bank.balance - parsedAmount

          await db.bank.update({
            where: { id: activeBankId },
            data: { balance: newBankBalance }
          })

          // Buat bank history untuk transaksi baru
          await db.bankHistory.create({
            data: {
              bankId: activeBankId,
              eventType: 'DAILY_TRANSACTION_EDIT',
              oldBalance: bank.balance,
              newBalance: newBankBalance,
              notes: `Edit: ${parsedType} ${parsedAmount.toLocaleString('id-ID')} - ${name || existingTransaction.name}`,
              userId: session.userId
            }
          })
        }
      }
    }

    // Update transaksi
    const transaction = await db.dailyTransaction.update({
      where: { id },
      data: {
        date: parsedDate,
        name: name || existingTransaction.name,
        accountNumber: accountNumber !== undefined ? accountNumber : existingTransaction.accountNumber,
        amount: parsedAmount,
        type: parsedType,
        bankId: bankId !== undefined ? bankId : existingTransaction.bankId,
        bankName
      },
      include: {
        bank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      transaction
    })
  } catch (error) {
    console.error('Update daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate transaksi' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus transaksi
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDelete) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus data' },
        { status: 403 }
      )
    }

    // Ambil transaksi
    const transaction = await db.dailyTransaction.findUnique({
      where: { id },
      include: { bank: true }
    })

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert balance bank jika bank masih ada
    if (transaction.bank) {
      const revertBalance = transaction.type === 'DEPOSIT'
        ? transaction.bank.balance - transaction.amount
        : transaction.bank.balance + transaction.amount

      await db.bank.update({
        where: { id: transaction.bankId! },
        data: { balance: revertBalance }
      })

      // Buat bank history untuk revert
      await db.bankHistory.create({
        data: {
          bankId: transaction.bankId!,
          eventType: 'DAILY_TRANSACTION_DELETE',
          oldBalance: transaction.bank.balance,
          newBalance: revertBalance,
          notes: `Delete: Revert ${transaction.type} ${transaction.amount.toLocaleString('id-ID')} - ${transaction.name}`,
          userId: session.userId
        }
      })
    }

    // Hapus transaksi
    await db.dailyTransaction.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Transaksi berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus transaksi' },
      { status: 500 }
    )
  }
}

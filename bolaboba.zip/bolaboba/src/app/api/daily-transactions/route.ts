import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil transaksi harian berdasarkan tanggal
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const dateStr = searchParams.get('date')
    const type = searchParams.get('type') // 'DEPOSIT' atau 'WITHDRAW' atau undefined untuk semua
    const startDate = searchParams.get('startDate') // Date range filter start
    const endDate = searchParams.get('endDate') // Date range filter end

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk melihat data ini' },
        { status: 403 }
      )
    }

    // Parse tanggal - Date range takes precedence over single date
    let queryStartDate: Date
    let queryEndDate: Date

    if (startDate && endDate) {
      // Date range filter
      queryStartDate = new Date(startDate)
      queryStartDate.setHours(0, 0, 0, 0)
      queryEndDate = new Date(endDate)
      queryEndDate.setHours(23, 59, 59, 999)
    } else if (dateStr) {
      // Single date filter
      const date = new Date(dateStr)
      queryStartDate = new Date(date.setHours(0, 0, 0, 0))
      queryEndDate = new Date(date.setHours(23, 59, 59, 999))
    } else {
      // Default hari ini
      const today = new Date()
      queryStartDate = new Date(today.setHours(0, 0, 0, 0))
      queryEndDate = new Date(today.setHours(23, 59, 59, 999))
    }

    // Build query
    const where: any = {
      date: {
        gte: queryStartDate,
        lte: queryEndDate
      }
    }

    if (type) {
      where.type = type
    }

    // Ambil transaksi harian
    const transactions = await db.dailyTransaction.findMany({
      where,
      include: {
        bank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { date: 'desc' }
    })

    return NextResponse.json({
      success: true,
      data: transactions
    })
  } catch (error) {
    console.error('Get daily transactions error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data transaksi harian' },
      { status: 500 }
    )
  }
}

// POST - Buat transaksi baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, date, name, accountNumber, amount, type, bankId, userId } = await req.json()

    if (!sessionId || !date || !name || !amount || !type || !bankId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    if (!['DEPOSIT', 'WITHDRAW'].includes(type)) {
      return NextResponse.json(
        { error: 'Type tidak valid' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah data' },
        { status: 403 }
      )
    }

    // Cari bank yang akan menerima transaksi
    const bank = await db.bank.findUnique({
      where: { id: bankId }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Parse tanggal
    const transactionDate = new Date(date)
    const parsedAmount = parseFloat(amount)

    // Simpan nama bank sebagai backup
    const bankName = `${bank.name} - ${bank.accountName}`

    // Buat transaksi
    const transaction = await db.dailyTransaction.create({
      data: {
        date: transactionDate,
        name,
        accountNumber: accountNumber || null,
        amount: parsedAmount,
        type,
        bankId,
        bankName,
        userId
      }
    })

    // Update balance bank
    const newBalance = type === 'DEPOSIT'
      ? bank.balance + parsedAmount
      : bank.balance - parsedAmount

    await db.bank.update({
      where: { id: bankId },
      data: { balance: newBalance }
    })

    // Buat bank history
    await db.bankHistory.create({
      data: {
        bankId,
        eventType: 'DAILY_TRANSACTION',
        oldBalance: bank.balance,
        newBalance: newBalance,
        notes: `${type} ${parsedAmount.toLocaleString('id-ID')} - ${name}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      transaction,
      newBalance
    })
  } catch (error) {
    console.error('Create daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat transaksi' },
      { status: 500 }
    )
  }
}

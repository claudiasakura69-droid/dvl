import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// PATCH - Update Akuran transaction
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { sessionId, date, name, amount, type, notes, bankId } = await request.json()

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check permissions
    const permissions = getPermissions(session.user.role || 'VIEW')
    if (!permissions.canEdit) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    // Get existing akuran
    const existingAkuran = await db.akuran.findUnique({
      where: { id }
    })

    if (!existingAkuran) {
      return NextResponse.json({ success: false, error: 'Akuran not found' }, { status: 404 })
    }

    // Revert old bank balance if bank was linked and bank still exists
    if (existingAkuran.bankId) {
      const oldBank = await db.bank.findUnique({
        where: { id: existingAkuran.bankId }
      })
      
      if (oldBank) {
        if (existingAkuran.type === 'withdraw') {
          await db.bank.update({
            where: { id: existingAkuran.bankId },
            data: {
              balance: {
                increment: existingAkuran.amount
              }
            }
          })
        } else if (existingAkuran.type === 'deposit') {
          await db.bank.update({
            where: { id: existingAkuran.bankId },
            data: {
              balance: {
                decrement: existingAkuran.amount
              }
            }
          })
        }
      }
    }

    // Get bank info if bankId provided
    let bankName = existingAkuran.bankName
    if (bankId) {
      const bank = await db.bank.findUnique({
        where: { id: bankId }
      })
      if (bank) {
        bankName = bank.name
      }
    }

    // Update akuran
    const akuran = await db.akuran.update({
      where: { id },
      data: {
        date: date ? new Date(date) : existingAkuran.date,
        name: name || existingAkuran.name,
        amount: amount !== undefined ? parseFloat(amount) : existingAkuran.amount,
        type: type || existingAkuran.type,
        notes: notes !== undefined ? notes : existingAkuran.notes,
        bankId: bankId !== undefined ? bankId : existingAkuran.bankId,
        bankName: bankName
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    // Apply new bank balance
    if (akuran.bankId) {
      if (akuran.type === 'withdraw') {
        await db.bank.update({
          where: { id: akuran.bankId },
          data: {
            balance: {
              decrement: akuran.amount
            }
          }
        })
      } else if (akuran.type === 'deposit') {
        await db.bank.update({
          where: { id: akuran.bankId },
          data: {
            balance: {
              increment: akuran.amount
            }
          }
        })
      }
    }

    return NextResponse.json({ success: true, data: akuran })
  } catch (error) {
    console.error('Error updating akuran:', error)
    return NextResponse.json({ success: false, error: 'Failed to update akuran' }, { status: 500 })
  }
}

// DELETE - Delete Akuran transaction
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('sessionId')

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check permissions
    const permissions = getPermissions(session.user.role || 'VIEW')
    if (!permissions.canDelete) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    // Get existing akuran
    const existingAkuran = await db.akuran.findUnique({
      where: { id }
    })

    if (!existingAkuran) {
      return NextResponse.json({ success: false, error: 'Akuran not found' }, { status: 404 })
    }

    // Revert bank balance if bank was linked and bank still exists
    if (existingAkuran.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: existingAkuran.bankId }
      })
      
      if (bank) {
        if (existingAkuran.type === 'withdraw') {
          await db.bank.update({
            where: { id: existingAkuran.bankId },
            data: {
              balance: {
                increment: existingAkuran.amount
              }
            }
          })
        } else if (existingAkuran.type === 'deposit') {
          await db.bank.update({
            where: { id: existingAkuran.bankId },
            data: {
              balance: {
                decrement: existingAkuran.amount
              }
            }
          })
        }
      }
    }

    // Delete akuran
    await db.akuran.delete({
      where: { id }
    })

    return NextResponse.json({ success: true, message: 'Akuran deleted successfully' })
  } catch (error) {
    console.error('Error deleting akuran:', error)
    return NextResponse.json({ success: false, error: 'Failed to delete akuran' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Get all Akuran transactions with filtering
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('sessionId')
    const year = searchParams.get('year')
    const bankId = searchParams.get('bankId')
    const search = searchParams.get('search')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check permissions
    const permissions = getPermissions(session.user.role || 'VIEW')
    if (!permissions.canView) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    // Build where clause
    const where: any = {}

    // Filter by date range (takes precedence over year filter)
    if (startDate && endDate) {
      where.date = {
        gte: new Date(startDate),
        lte: new Date(endDate)
      }
    }
    // Filter by year only if no date range is specified
    else if (year) {
      const yearNum = parseInt(year)
      where.date = {
        gte: new Date(`${yearNum}-01-01`),
        lt: new Date(`${yearNum + 1}-01-01`)
      }
    }

    // Filter by bank
    if (bankId) {
      where.bankId = bankId
    }

    // Search by name or notes
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { notes: { contains: search } }
      ]
    }

    const akurans = await db.akuran.findMany({
      where,
      orderBy: { date: 'desc' },
      include: {
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        },
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    return NextResponse.json({ success: true, data: akurans })
  } catch (error) {
    console.error('Error fetching akurans:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch akurans' }, { status: 500 })
  }
}

// POST - Create new Akuran transaction
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { sessionId, date, name, amount, type, notes, bankId } = body

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check permissions
    const permissions = getPermissions(session.user.role || 'VIEW')
    if (!permissions.canAdd) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    // Validate required fields
    if (!date || !name || !amount || !type) {
      return NextResponse.json({ success: false, error: 'Missing required fields' }, { status: 400 })
    }

    // Get bank info if bankId provided
    let bankName = null
    if (bankId) {
      const bank = await db.bank.findUnique({
        where: { id: bankId }
      })
      if (bank) {
        bankName = bank.name
      }
    }

    // Create akuran
    const akuran = await db.akuran.create({
      data: {
        date: new Date(date),
        name,
        amount: parseFloat(amount),
        type,
        notes,
        bankId,
        bankName,
        userId: session.user.id
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    // Update bank balance if withdraw type
    if (bankId && type === 'withdraw') {
      await db.bank.update({
        where: { id: bankId },
        data: {
          balance: {
            decrement: parseFloat(amount)
          }
        }
      })
    } else if (bankId && type === 'deposit') {
      await db.bank.update({
        where: { id: bankId },
        data: {
          balance: {
            increment: parseFloat(amount)
          }
        }
      })
    }

    return NextResponse.json({ success: true, data: akuran })
  } catch (error) {
    console.error('Error creating akuran:', error)
    return NextResponse.json({ success: false, error: 'Failed to create akuran' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil semua expenses
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check view permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Tidak memiliki izin untuk melihat expense' },
        { status: 403 }
      )
    }

    const expenses = await db.expense.findMany({
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        },
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      data: expenses
    })
  } catch (error) {
    console.error('Get expenses error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data expenses' },
      { status: 500 }
    )
  }
}

// POST - Buat expense baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, category, userId, bankId, operation } = await req.json()

    if (!sessionId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check add permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Tidak memiliki izin untuk menambahkan expense' },
        { status: 403 }
      )
    }

    const expenseAmount = parseFloat(amount)
    const expenseOperation = operation || 'decrease' // default to decrease
    let bankName = null

    // Get bank name if bankId is provided
    if (bankId) {
      const bank = await db.bank.findUnique({
        where: { id: bankId },
        select: { name: true, accountName: true, balance: true }
      })

      if (bank) {
        bankName = `${bank.name} - ${bank.accountName}`

        // Update bank balance based on operation
        const newBalance = expenseOperation === 'increase'
          ? bank.balance + expenseAmount
          : bank.balance - expenseAmount

        await db.bank.update({
          where: { id: bankId },
          data: { balance: newBalance }
        })

        // Create bank history record
        await db.bankHistory.create({
          data: {
            bankId,
            eventType: 'EXPENSE_TRANSACTION',
            oldValue: bank.balance.toString(),
            newValue: newBalance.toString(),
            oldBalance: bank.balance,
            newBalance: newBalance,
            notes: `${expenseOperation === 'increase' ? 'Tambah' : 'Kurang'} saldo untuk expense: ${notes || category || '-'}`,
            userId
          }
        })
      }
    }

    // Buat expense
    const expense = await db.expense.create({
      data: {
        amount: expenseAmount,
        operation: expenseOperation,
        notes: notes || null,
        category: category || null,
        bankId: bankId || null,
        bankName,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      expense
    })
  } catch (error) {
    console.error('Create expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat expense' },
      { status: 500 }
    )
  }
}

// PATCH - Edit expense
export async function PATCH(req: NextRequest) {
  try {
    const { sessionId, expenseId, amount, notes, category, userId, bankId, operation } = await req.json()

    if (!sessionId || !expenseId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check edit permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canEdit) {
      return NextResponse.json(
        { error: 'Tidak memiliki izin untuk mengedit expense' },
        { status: 403 }
      )
    }

    // Get existing expense
    const existingExpense = await db.expense.findUnique({
      where: { id: expenseId }
    })

    if (!existingExpense) {
      return NextResponse.json(
        { error: 'Expense tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert old bank balance if bankId exists
    if (existingExpense.bankId) {
      const oldBank = await db.bank.findUnique({
        where: { id: existingExpense.bankId },
        select: { balance: true }
      })

      if (oldBank) {
        const revertedBalance = existingExpense.operation === 'increase'
          ? oldBank.balance - existingExpense.amount
          : oldBank.balance + existingExpense.amount

        await db.bank.update({
          where: { id: existingExpense.bankId },
          data: { balance: revertedBalance }
        })

        // Create bank history record for revert
        await db.bankHistory.create({
          data: {
            bankId: existingExpense.bankId,
            eventType: 'EXPENSE_REVERT',
            oldValue: oldBank.balance.toString(),
            newValue: revertedBalance.toString(),
            oldBalance: oldBank.balance,
            newBalance: revertedBalance,
            notes: `Revert balance untuk expense lama: ${existingExpense.notes || existingExpense.category || '-'}`,
            userId
          }
        })
      }
    }

    // Apply new bank balance
    const newAmount = amount !== undefined ? parseFloat(amount) : existingExpense.amount
    const newOperation = operation || existingExpense.operation
    let newBankName = existingExpense.bankName

    if (bankId && bankId !== existingExpense.bankId) {
      const newBank = await db.bank.findUnique({
        where: { id: bankId },
        select: { name: true, accountName: true, balance: true }
      })

      if (newBank) {
        newBankName = `${newBank.name} - ${newBank.accountName}`
        const newBankBalance = newOperation === 'increase'
          ? newBank.balance + newAmount
          : newBank.balance - newAmount

        await db.bank.update({
          where: { id: bankId },
          data: { balance: newBankBalance }
        })

        // Create bank history record for new transaction
        await db.bankHistory.create({
          data: {
            bankId,
            eventType: 'EXPENSE_TRANSACTION',
            oldValue: newBank.balance.toString(),
            newValue: newBankBalance.toString(),
            oldBalance: newBank.balance,
            newBalance: newBankBalance,
            notes: `${newOperation === 'increase' ? 'Tambah' : 'Kurang'} saldo untuk expense yang diedit: ${notes || category || existingExpense.notes || existingExpense.category || '-'}`,
            userId
          }
        })
      }
    }

    // Update expense
    const updatedExpense = await db.expense.update({
      where: { id: expenseId },
      data: {
        amount: newAmount,
        operation: newOperation,
        notes: notes !== undefined ? notes : existingExpense.notes,
        category: category !== undefined ? category : existingExpense.category,
        bankId: bankId || null,
        bankName: newBankName
      }
    })

    return NextResponse.json({
      success: true,
      expense: updatedExpense
    })
  } catch (error) {
    console.error('Edit expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengedit expense' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus expense
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const expenseId = searchParams.get('expenseId')
    const userId = searchParams.get('userId')

    if (!sessionId || !expenseId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check delete permissions
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDelete) {
      return NextResponse.json(
        { error: 'Tidak memiliki izin untuk menghapus expense' },
        { status: 403 }
      )
    }

    // Get existing expense
    const existingExpense = await db.expense.findUnique({
      where: { id: expenseId }
    })

    if (!existingExpense) {
      return NextResponse.json(
        { error: 'Expense tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert bank balance if bankId exists
    if (existingExpense.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: existingExpense.bankId },
        select: { balance: true }
      })

      if (bank) {
        const revertedBalance = existingExpense.operation === 'increase'
          ? bank.balance - existingExpense.amount
          : bank.balance + existingExpense.amount

        await db.bank.update({
          where: { id: existingExpense.bankId },
          data: { balance: revertedBalance }
        })

        // Create bank history record for revert
        await db.bankHistory.create({
          data: {
            bankId: existingExpense.bankId,
            eventType: 'EXPENSE_DELETE',
            oldValue: bank.balance.toString(),
            newValue: revertedBalance.toString(),
            oldBalance: bank.balance,
            newBalance: revertedBalance,
            notes: `Revert balance untuk expense yang dihapus: ${existingExpense.notes || existingExpense.category || '-'}`,
            userId
          }
        })
      }
    }

    // Delete expense
    await db.expense.delete({
      where: { id: expenseId }
    })

    return NextResponse.json({
      success: true
    })
  } catch (error) {
    console.error('Delete expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus expense' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Get all dates with transactions for highlighting
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('sessionId')
    const year = searchParams.get('year')

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check view permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    const yearNum = year ? parseInt(year) : new Date().getFullYear()
    const startDate = new Date(`${yearNum}-01-01`)
    const endDate = new Date(`${yearNum + 1}-01-01`)

    // Get dates with daily transactions
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        date: {
          gte: startDate,
          lt: endDate
        }
      },
      select: {
        date: true,
        type: true,
        amount: true
      }
    })

    // Get dates with InOut transactions
    const inOutTransactions = await db.inOut.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      select: {
        createdAt: true,
        amount: true
      }
    })

    // Get dates with Expense
    const expenses = await db.expense.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      select: {
        createdAt: true,
        amount: true
      }
    })

    // Get dates with Mistake
    const mistakes = await db.mistake.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      select: {
        createdAt: true,
        amount: true
      }
    })

    // Get dates with Akuran
    const akurans = await db.akuran.findMany({
      where: {
        date: {
          gte: startDate,
          lt: endDate
        }
      },
      select: {
        date: true,
        amount: true,
        type: true
      }
    })

    // Combine all dates
    const dateMap = new Map<string, { count: number; total: number; hasDeposit: boolean; hasWithdraw: boolean }>()

    // Add daily transactions
    dailyTransactions.forEach(t => {
      const dateKey = t.date.toISOString().split('T')[0]
      const existing = dateMap.get(dateKey) || { count: 0, total: 0, hasDeposit: false, hasWithdraw: false }
      dateMap.set(dateKey, {
        count: existing.count + 1,
        total: existing.total + t.amount,
        hasDeposit: existing.hasDeposit || t.type === 'DEPOSIT',
        hasWithdraw: existing.hasWithdraw || t.type === 'WITHDRAW'
      })
    })

    // Add InOut transactions
    inOutTransactions.forEach(t => {
      const dateKey = t.createdAt.toISOString().split('T')[0]
      const existing = dateMap.get(dateKey) || { count: 0, total: 0, hasDeposit: false, hasWithdraw: false }
      dateMap.set(dateKey, {
        count: existing.count + 1,
        total: existing.total + t.amount,
        hasDeposit: existing.hasDeposit,
        hasWithdraw: existing.hasWithdraw
      })
    })

    // Add expenses
    expenses.forEach(t => {
      const dateKey = t.createdAt.toISOString().split('T')[0]
      const existing = dateMap.get(dateKey) || { count: 0, total: 0, hasDeposit: false, hasWithdraw: false }
      dateMap.set(dateKey, {
        count: existing.count + 1,
        total: existing.total + t.amount,
        hasDeposit: existing.hasDeposit,
        hasWithdraw: existing.hasWithdraw
      })
    })

    // Add mistakes
    mistakes.forEach(t => {
      const dateKey = t.createdAt.toISOString().split('T')[0]
      const existing = dateMap.get(dateKey) || { count: 0, total: 0, hasDeposit: false, hasWithdraw: false }
      dateMap.set(dateKey, {
        count: existing.count + 1,
        total: existing.total + t.amount,
        hasDeposit: existing.hasDeposit,
        hasWithdraw: existing.hasWithdraw
      })
    })

    // Add akurans
    akurans.forEach(t => {
      const dateKey = t.date.toISOString().split('T')[0]
      const existing = dateMap.get(dateKey) || { count: 0, total: 0, hasDeposit: false, hasWithdraw: false }
      dateMap.set(dateKey, {
        count: existing.count + 1,
        total: existing.total + t.amount,
        hasDeposit: existing.hasDeposit || t.type === 'deposit',
        hasWithdraw: existing.hasWithdraw || t.type === 'withdraw'
      })
    })

    // Convert to array
    const datesWithTransactions = Array.from(dateMap.entries()).map(([date, data]) => ({
      date,
      ...data
    }))

    return NextResponse.json({ success: true, data: datesWithTransactions })
  } catch (error) {
    console.error('Error fetching calendar data:', error)
    return NextResponse.json({ success: false, error: 'Failed to fetch calendar data' }, { status: 500 })
  }
}

// DELETE - Bulk delete all transactions in date range
export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('sessionId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check delete permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDelete) {
      return NextResponse.json({ success: false, error: 'Insufficient permissions' }, { status: 403 })
    }

    if (!startDate || !endDate) {
      return NextResponse.json({ success: false, error: 'Start date and end date are required' }, { status: 400 })
    }

    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59, 999) // Include the entire end day

    // Delete daily transactions in range
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      },
      include: {
        bank: true
      }
    })

    for (const transaction of dailyTransactions) {
      // Revert bank balance
      if (transaction.type === 'DEPOSIT') {
        await db.bank.update({
          where: { id: transaction.bankId },
          data: { balance: { decrement: transaction.amount } }
        })
      } else if (transaction.type === 'WITHDRAW') {
        await db.bank.update({
          where: { id: transaction.bankId },
          data: { balance: { increment: transaction.amount } }
        })
      }
    }

    await db.dailyTransaction.deleteMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      }
    })

    // Delete InOut in range
    const inOuts = await db.inOut.findMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      },
      include: {
        fromBank: true,
        toBank: true
      }
    })

    for (const inout of inOuts) {
      // Revert bank balances
      await db.bank.update({
        where: { id: inout.fromBankId },
        data: { balance: { increment: inout.amount } }
      })
      await db.bank.update({
        where: { id: inout.toBankId },
        data: { balance: { decrement: inout.amount } }
      })
    }

    await db.inOut.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // Delete Expenses in range
    const expenses = await db.expense.findMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      },
      include: {
        bank: true
      }
    })

    for (const expense of expenses) {
      // Revert bank balance
      if (expense.bankId) {
        if (expense.operation === 'increase') {
          await db.bank.update({
            where: { id: expense.bankId },
            data: { balance: { decrement: expense.amount } }
          })
        } else {
          await db.bank.update({
            where: { id: expense.bankId },
            data: { balance: { increment: expense.amount } }
          })
        }
      }
    }

    await db.expense.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // Delete Mistakes in range
    const mistakes = await db.mistake.findMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      },
      include: {
        bank: true
      }
    })

    for (const mistake of mistakes) {
      // Revert bank balance
      if (mistake.bankId) {
        await db.bank.update({
          where: { id: mistake.bankId },
          data: { balance: { increment: mistake.amount } }
        })
      }
    }

    await db.mistake.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // Delete Akurans in range
    const akurans = await db.akuran.findMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      },
      include: {
        bank: true
      }
    })

    for (const akuran of akurans) {
      // Revert bank balance
      if (akuran.bankId) {
        if (akuran.type === 'deposit') {
          await db.bank.update({
            where: { id: akuran.bankId },
            data: { balance: { decrement: akuran.amount } }
          })
        } else {
          await db.bank.update({
            where: { id: akuran.bankId },
            data: { balance: { increment: akuran.amount } }
          })
        }
      }
    }

    await db.akuran.deleteMany({
      where: {
        date: {
          gte: start,
          lte: end
        }
      }
    })

    const totalDeleted =
      dailyTransactions.length +
      inOuts.length +
      expenses.length +
      mistakes.length +
      akurans.length

    return NextResponse.json({
      success: true,
      message: `Successfully deleted ${totalDeleted} transactions`,
      breakdown: {
        dailyTransactions: dailyTransactions.length,
        inOuts: inOuts.length,
        expenses: expenses.length,
        mistakes: mistakes.length,
        akurans: akurans.length
      }
    })
  } catch (error) {
    console.error('Error deleting transactions:', error)
    return NextResponse.json({ success: false, error: 'Failed to delete transactions' }, { status: 500 })
  }
}

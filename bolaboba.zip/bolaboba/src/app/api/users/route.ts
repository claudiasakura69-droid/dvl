import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { PERMISSION_LEVELS } from '@/lib/permissions'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const userRole = session.user.role
    const permissionLevel = PERMISSION_LEVELS[userRole as keyof typeof PERMISSION_LEVELS] ?? 0

    if (permissionLevel < PERMISSION_LEVELS.ADMIN) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses untuk melihat daftar user' },
        { status: 403 }
      )
    }

    // Ambil semua users dengan sessions mereka
    const users = await db.user.findMany({
      include: {
        sessions: {
          orderBy: { loginAt: 'desc' },
          take: 10
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    // Format data
    const formattedUsers = users.map(user => ({
      id: user.id,
      username: user.username,
      isActive: user.isActive,
      createdAt: user.createdAt,
      sessions: user.sessions.map(s => ({
        id: s.id,
        loginAt: s.loginAt,
        logoutAt: s.logoutAt,
        ipAddress: s.ipAddress,
        isOnline: !s.logoutAt
      }))
    }))

    return NextResponse.json({
      success: true,
      data: formattedUsers
    })
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data users' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { username, password, role, sessionId, creatorId } = body

    if (!username || !password || !role || !sessionId || !creatorId) {
      return NextResponse.json(
        { error: 'Semua field wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions (hanya ADMIN ke atas yang bisa create user)
    const creatorRole = session.user.role
    const permissionLevel = PERMISSION_LEVELS[creatorRole as keyof typeof PERMISSION_LEVELS] ?? 0

    if (permissionLevel < PERMISSION_LEVELS.ADMIN) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses untuk membuat user' },
        { status: 403 }
      )
    }

    // Cek apakah username sudah ada
    const existingUser = await db.user.findUnique({
      where: { username }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username sudah digunakan' },
        { status: 400 }
      )
    }

    // Validasi role - user baru tidak bisa memiliki role lebih tinggi dari creator
    const newRoleLevel = PERMISSION_LEVELS[role as keyof typeof PERMISSION_LEVELS] ?? 0

    if (newRoleLevel > permissionLevel) {
      return NextResponse.json(
        { error: 'Anda tidak bisa membuat user dengan role lebih tinggi dari Anda' },
        { status: 403 }
      )
    }

    // Buat user baru
    const newUser = await db.user.create({
      data: {
        username,
        password, // TODO: Hash password dengan bcrypt
        role,
        isActive: true
      }
    })

    return NextResponse.json({
      success: true,
      message: 'User berhasil dibuat',
      data: {
        id: newUser.id,
        username: newUser.username,
        role: newUser.role,
        isActive: newUser.isActive
      }
    })
  } catch (error) {
    console.error('Create user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat user' },
      { status: 500 }
    )
  }
}

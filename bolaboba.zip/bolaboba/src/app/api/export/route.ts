import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import * as XLSX from 'xlsx'

// POST - Export data ke Excel
export async function POST(req: NextRequest) {
  try {
    const { sessionId, startDate, endDate } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tanggal
    const start = startDate ? new Date(startDate) : new Date()
    const end = endDate ? new Date(endDate) : new Date(startDate || new Date())

    start.setHours(0, 0, 0, 0)
    end.setHours(23, 59, 59, 999)

    // Buat workbook
    const workbook = XLSX.utils.book_new()

    // Ambil semua dates dalam range
    const dates: Date[] = []
    const currentDate = new Date(start)
    while (currentDate <= end) {
      dates.push(new Date(currentDate))
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Export untuk setiap tanggal
    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const dateStr = date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' })

      // Ambil data untuk tanggal ini
      const dailyTransactions = await db.dailyTransaction.findMany({
        where: {
          date: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          bank: true,
          user: true
        },
        orderBy: { date: 'desc' }
      })

      const inOuts = await db.inOut.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          fromBank: true,
          toBank: true,
          user: true
        }
      })

      const expenses = await db.expense.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          user: true
        }
      })

      const mistakes = await db.mistake.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          user: true
        }
      })

      // Buat sheet untuk tanggal ini
      const sheetData: any[] = []

      // Header
      sheetData.push(['DAILY TRANSACTIONS - ' + dateStr, '', '', '', ''])
      sheetData.push([])

      // Deposit
      const deposits = dailyTransactions.filter(t => t.type === 'DEPOSIT')
      if (deposits.length > 0) {
        sheetData.push(['DEPOSIT'])
        sheetData.push(['Date', 'Time', 'Name', 'Account Number', 'Bank', 'Amount', 'User'])
        deposits.forEach(t => {
          sheetData.push([
            t.date.toLocaleDateString('id-ID'),
            t.date.toLocaleTimeString('id-ID'),
            t.name,
            t.accountNumber || '-',
            `${t.bank.name} - ${t.bank.accountName}`,
            t.amount,
            t.user.username
          ])
        })
        sheetData.push([])
      }

      // Withdraw
      const withdraws = dailyTransactions.filter(t => t.type === 'WITHDRAW')
      if (withdraws.length > 0) {
        sheetData.push(['WITHDRAW'])
        sheetData.push(['Date', 'Time', 'Name', 'Account Number', 'Bank', 'Amount', 'User'])
        withdraws.forEach(t => {
          sheetData.push([
            t.date.toLocaleDateString('id-ID'),
            t.date.toLocaleTimeString('id-ID'),
            t.name,
            t.accountNumber || '-',
            `${t.bank.name} - ${t.bank.accountName}`,
            t.amount,
            t.user.username
          ])
        })
        sheetData.push([])
      }

      // InOut
      if (inOuts.length > 0) {
        sheetData.push(['IN / OUT'])
        sheetData.push(['Date', 'Time', 'From Bank', 'To Bank', 'Amount', 'Notes', 'User'])
        inOuts.forEach(t => {
          sheetData.push([
            t.createdAt.toLocaleDateString('id-ID'),
            t.createdAt.toLocaleTimeString('id-ID'),
            `${t.fromBank.name} - ${t.fromBank.accountName}`,
            `${t.toBank.name} - ${t.toBank.accountName}`,
            t.amount,
            t.notes || '-',
            t.user.username
          ])
        })
        sheetData.push([])
      }

      // Expenses
      if (expenses.length > 0) {
        sheetData.push(['EXPENSES'])
        sheetData.push(['Date', 'Time', 'Category', 'Amount', 'Notes', 'User'])
        expenses.forEach(t => {
          sheetData.push([
            t.createdAt.toLocaleDateString('id-ID'),
            t.createdAt.toLocaleTimeString('id-ID'),
            t.category || '-',
            t.amount,
            t.notes || '-',
            t.user.username
          ])
        })
        sheetData.push([])
      }

      // Mistakes
      if (mistakes.length > 0) {
        sheetData.push(['MISTAKES'])
        sheetData.push(['Date', 'Time', 'Bank', 'Amount', 'Notes', 'User'])
        mistakes.forEach(t => {
          sheetData.push([
            t.createdAt.toLocaleDateString('id-ID'),
            t.createdAt.toLocaleTimeString('id-ID'),
            t.bankId ? '-' : '-',
            t.amount,
            t.notes || '-',
            t.user.username
          ])
        })
      }

      // Buat worksheet
      const worksheet = XLSX.utils.aoa_to_sheet(sheetData)

      // Set column widths
      worksheet['!cols'] = [
        { wch: 12 }, // Date
        { wch: 10 }, // Time
        { wch: 20 }, // Name
        { wch: 15 }, // Account Number
        { wch: 25 }, // Bank
        { wch: 15 }, // Amount
        { wch: 15 }, // User
      ]

      // Add sheet to workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, dateStr.replace(/\//g, '-'))
    }

    // Generate buffer
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })

    // Return as file
    return new NextResponse(buffer as Buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="transactions_${start.getTime()}_${end.getTime()}.xlsx"`
      }
    })
  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat export data' },
      { status: 500 }
    )
  }
}

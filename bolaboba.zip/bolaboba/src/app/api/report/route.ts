import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Get aggregated report data by month
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const sessionId = searchParams.get('sessionId')
    const year = searchParams.get('year')
    const month = searchParams.get('month')

    // Validate session
    if (!sessionId) {
      return NextResponse.json({ success: false, error: 'Session ID required' }, { status: 401 })
    }

    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || !session.user.isActive) {
      return NextResponse.json({ success: false, error: 'Invalid session' }, { status: 401 })
    }

    // Check canView permission
    const permissions = getPermissions(session.user.role || 'VIEW')
    if (!permissions.canView) {
      return NextResponse.json({ success: false, error: 'Permission denied' }, { status: 403 })
    }

    const yearNum = year ? parseInt(year) : new Date().getFullYear()
    const monthNum = month ? parseInt(month) : null
    
    const startDate = monthNum 
      ? new Date(`${yearNum}-${monthNum.toString().padStart(2, '0')}-01`)
      : new Date(`${yearNum}-01-01`)
    
    const endDate = monthNum
      ? new Date(yearNum, monthNum, 1)
      : new Date(`${yearNum + 1}-01-01`)

    // Get daily transactions by month
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        date: {
          gte: startDate,
          lt: endDate
        }
      },
      orderBy: { date: 'asc' },
      include: {
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      }
    })

    // Get InOut transactions by month
    const inOutTransactions = await db.inOut.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      orderBy: { createdAt: 'asc' },
      include: {
        fromBank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        },
        toBank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      }
    })

    // Get expenses by month
    const expenses = await db.expense.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      orderBy: { createdAt: 'asc' },
      include: {
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      }
    })

    // Get mistakes by month
    const mistakes = await db.mistake.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lt: endDate
        }
      },
      orderBy: { createdAt: 'asc' },
      include: {
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      }
    })

    // Get akurans by month
    const akurans = await db.akuran.findMany({
      where: {
        date: {
          gte: startDate,
          lt: endDate
        }
      },
      orderBy: { date: 'asc' },
      include: {
        bank: {
          select: {
            id: true,
            name: true,
            accountName: true
          }
        }
      }
    })

    // Aggregate by month
    const startMonth = monthNum ? monthNum - 1 : 0
    const endMonth = monthNum ? monthNum : 12
    
    const monthlyData = Array.from({ length: endMonth - startMonth }, (_, index) => {
      const monthIndex = startMonth + index
      const monthName = new Date(yearNum, monthIndex).toLocaleDateString('id-ID', { month: 'long' })

      // Filter transactions for this month
      const monthDaily = dailyTransactions.filter(t => {
        return t.date.getMonth() === monthIndex
      })

      const monthInOut = inOutTransactions.filter(t => {
        return t.createdAt.getMonth() === monthIndex
      })

      const monthExpenses = expenses.filter(t => {
        return t.createdAt.getMonth() === monthIndex
      })

      const monthMistakes = mistakes.filter(t => {
        return t.createdAt.getMonth() === monthIndex
      })

      const monthAkurans = akurans.filter(t => {
        return t.date.getMonth() === monthIndex
      })

      // Calculate totals
      const depositTotal = monthDaily
        .filter(t => t.type === 'DEPOSIT')
        .reduce((sum, t) => sum + t.amount, 0) +
        monthAkurans
        .filter(t => t.type === 'deposit')
        .reduce((sum, t) => sum + t.amount, 0)

      const withdrawTotal = monthDaily
        .filter(t => t.type === 'WITHDRAW')
        .reduce((sum, t) => sum + t.amount, 0) +
        monthAkurans
        .filter(t => t.type === 'withdraw')
        .reduce((sum, t) => sum + t.amount, 0)

      const inOutTotal = monthInOut.reduce((sum, t) => sum + t.amount, 0)
      const expenseTotal = monthExpenses.reduce((sum, t) => sum + t.amount, 0)
      const mistakeTotal = monthMistakes.reduce((sum, t) => sum + t.amount, 0)

      const transactionCount =
        monthDaily.length +
        monthInOut.length +
        monthExpenses.length +
        monthMistakes.length +
        monthAkurans.length

      // Daily breakdown with transaction details
      const dailyBreakdown: Record<string, {
        deposits: number
        withdrawals: number
        inOut: number
        expenses: number
        mistakes: number
        akurans: number
        total: number
        transactions: Array<{
          type: string
          amount: number
          bankName?: string
          accountName?: string
          notes?: string
        }>
      }> = {}

      monthDaily.forEach(t => {
        const dateKey = t.date.toISOString().split('T')[0]
        if (!dailyBreakdown[dateKey]) {
          dailyBreakdown[dateKey] = {
            deposits: 0,
            withdrawals: 0,
            inOut: 0,
            expenses: 0,
            mistakes: 0,
            akurans: 0,
            total: 0,
            transactions: []
          }
        }
        if (t.type === 'DEPOSIT') {
          dailyBreakdown[dateKey].deposits += t.amount
        } else {
          dailyBreakdown[dateKey].withdrawals += t.amount
        }
        dailyBreakdown[dateKey].total += t.amount
        
        // Add transaction detail with bank name fallback
        const bankDisplayName = t.bank 
          ? `${t.bank.name} - ${t.bank.accountName}`
          : t.bankName || 'Unknown Bank'
        
        dailyBreakdown[dateKey].transactions.push({
          type: t.type,
          amount: t.amount,
          bankName: bankDisplayName,
          notes: t.name
        })
      })

      monthInOut.forEach(t => {
        const dateKey = t.createdAt.toISOString().split('T')[0]
        if (!dailyBreakdown[dateKey]) {
          dailyBreakdown[dateKey] = {
            deposits: 0,
            withdrawals: 0,
            inOut: 0,
            expenses: 0,
            mistakes: 0,
            akurans: 0,
            total: 0,
            transactions: []
          }
        }
        dailyBreakdown[dateKey].inOut += t.amount
        dailyBreakdown[dateKey].total += t.amount
        
        // Add transaction detail with bank name fallback
        const fromBankName = t.fromBank
          ? `${t.fromBank.name} - ${t.fromBank.accountName}`
          : t.fromBankName || 'Unknown Bank'
        const toBankName = t.toBank
          ? `${t.toBank.name} - ${t.toBank.accountName}`
          : t.toBankName || 'Unknown Bank'
        
        dailyBreakdown[dateKey].transactions.push({
          type: 'INOUT',
          amount: t.amount,
          bankName: `${fromBankName} → ${toBankName}`,
          notes: t.notes
        })
      })

      monthExpenses.forEach(t => {
        const dateKey = t.createdAt.toISOString().split('T')[0]
        if (!dailyBreakdown[dateKey]) {
          dailyBreakdown[dateKey] = {
            deposits: 0,
            withdrawals: 0,
            inOut: 0,
            expenses: 0,
            mistakes: 0,
            akurans: 0,
            total: 0,
            transactions: []
          }
        }
        dailyBreakdown[dateKey].expenses += t.amount
        dailyBreakdown[dateKey].total += t.amount
        
        // Add transaction detail with bank name fallback
        const bankDisplayName = t.bank
          ? `${t.bank.name} - ${t.bank.accountName}`
          : t.bankName || 'Unknown Bank'
        
        dailyBreakdown[dateKey].transactions.push({
          type: 'EXPENSE',
          amount: t.amount,
          bankName: bankDisplayName,
          notes: t.notes || t.category
        })
      })

      monthMistakes.forEach(t => {
        const dateKey = t.createdAt.toISOString().split('T')[0]
        if (!dailyBreakdown[dateKey]) {
          dailyBreakdown[dateKey] = {
            deposits: 0,
            withdrawals: 0,
            inOut: 0,
            expenses: 0,
            mistakes: 0,
            akurans: 0,
            total: 0,
            transactions: []
          }
        }
        dailyBreakdown[dateKey].mistakes += t.amount
        dailyBreakdown[dateKey].total += t.amount
        
        // Add transaction detail with bank name fallback
        const bankDisplayName = t.bank
          ? `${t.bank.name} - ${t.bank.accountName}`
          : t.bankName || 'Unknown Bank'
        
        dailyBreakdown[dateKey].transactions.push({
          type: 'MISTAKE',
          amount: t.amount,
          bankName: bankDisplayName,
          notes: t.notes
        })
      })

      monthAkurans.forEach(t => {
        const dateKey = t.date.toISOString().split('T')[0]
        if (!dailyBreakdown[dateKey]) {
          dailyBreakdown[dateKey] = {
            deposits: 0,
            withdrawals: 0,
            inOut: 0,
            expenses: 0,
            mistakes: 0,
            akurans: 0,
            total: 0,
            transactions: []
          }
        }
        if (t.type === 'deposit') {
          dailyBreakdown[dateKey].akurans += t.amount
          dailyBreakdown[dateKey].deposits += t.amount
        } else {
          dailyBreakdown[dateKey].akurans -= t.amount
          dailyBreakdown[dateKey].withdrawals += t.amount
        }
        dailyBreakdown[dateKey].total += t.type === 'deposit' ? t.amount : -t.amount
        
        // Add transaction detail with bank name fallback
        const bankDisplayName = t.bank
          ? `${t.bank.name} - ${t.bank.accountName}`
          : t.bankName || 'Unknown Bank'
        
        dailyBreakdown[dateKey].transactions.push({
          type: t.type.toUpperCase(),
          amount: t.amount,
          bankName: bankDisplayName,
          notes: t.name || t.notes
        })
      })

      return {
        month: monthIndex + 1,
        monthName,
        depositTotal,
        withdrawTotal,
        inOutTotal,
        expenseTotal,
        mistakeTotal,
        transactionCount,
        netTotal: depositTotal - withdrawTotal - expenseTotal - mistakeTotal,
        dailyBreakdown: Object.entries(dailyBreakdown)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([date, data]) => ({ date, ...data }))
      }
    })

    // Calculate yearly totals
    const yearlyTotals = {
      deposits: 0,
      withdrawals: 0,
      inOut: 0,
      expenses: 0,
      mistakes: 0,
      totalTransactions: 0,
      netTotal: 0
    }

    monthlyData.forEach(data => {
      yearlyTotals.deposits += data.depositTotal
      yearlyTotals.withdrawals += data.withdrawTotal
      yearlyTotals.inOut += data.inOutTotal
      yearlyTotals.expenses += data.expenseTotal
      yearlyTotals.mistakes += data.mistakeTotal
      yearlyTotals.totalTransactions += data.transactionCount
      yearlyTotals.netTotal += data.netTotal
    })

    return NextResponse.json({
      success: true,
      data: {
        year: yearNum,
        month: monthNum,
        monthlyData,
        yearlyTotals
      }
    })
  } catch (error) {
    console.error('Error generating report:', error)
    return NextResponse.json({ success: false, error: 'Failed to generate report' }, { status: 500 })
  }
}

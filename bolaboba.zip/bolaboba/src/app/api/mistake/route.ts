import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil semua mistakes
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user role
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission view
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk melihat data' },
        { status: 403 }
      )
    }

    const mistakes = await db.mistake.findMany({
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      data: mistakes
    })
  } catch (error) {
    console.error('Get mistakes error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data mistakes' },
      { status: 500 }
    )
  }
}

// POST - Buat mistake baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, bankId, userId } = await req.json()

    if (!sessionId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user role
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission add
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah data' },
        { status: 403 }
      )
    }

    // Ambil informasi bank untuk backup bankName
    let bankName: string | null = null
    if (bankId) {
      const bank = await db.bank.findUnique({
        where: { id: bankId }
      })

      if (!bank) {
        return NextResponse.json(
          { error: 'Bank tidak ditemukan' },
          { status: 404 }
        )
      }

      // Simpan bankName untuk backup
      bankName = `${bank.name} - ${bank.accountName}`

      // Update balance bank (kurangi balance karena mistake adalah beban)
      await db.bank.update({
        where: { id: bankId },
        data: { balance: bank.balance - parseFloat(amount) }
      })

      // Catat history
      await db.bankHistory.create({
        data: {
          bankId: bankId,
          eventType: 'UPDATED',
          oldBalance: bank.balance,
          newBalance: bank.balance - parseFloat(amount),
          notes: `Mistake: -${amount}`,
          userId
        }
      })
    }

    // Buat mistake
    const mistake = await db.mistake.create({
      data: {
        amount: parseFloat(amount),
        notes: notes || null,
        bankId: bankId || null,
        bankName: bankName || null,
        transactionId: null,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      mistake
    })
  } catch (error) {
    console.error('Create mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat mistake' },
      { status: 500 }
    )
  }
}

// PATCH - Edit mistake yang sudah ada
export async function PATCH(req: NextRequest) {
  try {
    const { sessionId, mistakeId, amount, notes, bankId, userId } = await req.json()

    if (!sessionId || !mistakeId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user role
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission edit
    const permissions = getPermissions(session.user.role)
    if (!permissions.canEdit) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit data' },
        { status: 403 }
      )
    }

    // Ambil mistake yang ada
    const existingMistake = await db.mistake.findUnique({
      where: { id: mistakeId }
    })

    if (!existingMistake) {
      return NextResponse.json(
        { error: 'Mistake tidak ditemukan' },
        { status: 404 }
      )
    }

    const newAmount = amount !== undefined ? parseFloat(amount) : existingMistake.amount
    let newBankName: string | null = existingMistake.bankName

    // Revert balance dari bank lama jika ada dan amount berubah
    if (existingMistake.bankId && existingMistake.amount !== newAmount) {
      const oldBank = await db.bank.findUnique({
        where: { id: existingMistake.bankId }
      })

      if (oldBank) {
        // Revert: tambah balance karena sebelumnya dikurangi
        await db.bank.update({
          where: { id: existingMistake.bankId },
          data: { balance: oldBank.balance + existingMistake.amount }
        })

        // Catat history revert
        await db.bankHistory.create({
          data: {
            bankId: existingMistake.bankId,
            eventType: 'UPDATED',
            oldBalance: oldBank.balance,
            newBalance: oldBank.balance + existingMistake.amount,
            notes: `Mistake Edit Revert: +${existingMistake.amount}`,
            userId
          }
        })
      }
    }

    // Terapkan balance baru ke bank
    if (bankId !== undefined) {
      // Jika bankId berubah
      if (bankId !== existingMistake.bankId) {
        const newBank = await db.bank.findUnique({
          where: { id: bankId }
        })

        if (!newBank) {
          return NextResponse.json(
            { error: 'Bank tidak ditemukan' },
            { status: 404 }
          )
        }

        // Simpan bankName baru
        newBankName = `${newBank.name} - ${newBank.accountName}`

        // Kurangi balance pada bank baru
        await db.bank.update({
          where: { id: bankId },
          data: { balance: newBank.balance - newAmount }
        })

        // Catat history
        await db.bankHistory.create({
          data: {
            bankId: bankId,
            eventType: 'UPDATED',
            oldBalance: newBank.balance,
            newBalance: newBank.balance - newAmount,
            notes: `Mistake Edit: -${newAmount}`,
            userId
          }
        })
      } else if (existingMistake.bankId && existingMistake.amount !== newAmount) {
        // Bank sama tapi amount berubah
        const bank = await db.bank.findUnique({
          where: { id: existingMistake.bankId }
        })

        if (bank) {
          // Kurangi balance dengan amount baru
          await db.bank.update({
            where: { id: existingMistake.bankId },
            data: { balance: bank.balance - newAmount }
          })

          // Catat history
          await db.bankHistory.create({
            data: {
              bankId: existingMistake.bankId,
              eventType: 'UPDATED',
              oldBalance: bank.balance,
              newBalance: bank.balance - newAmount,
              notes: `Mistake Edit: -${newAmount}`,
              userId
            }
          })
        }
      }
    } else if (bankId === null && existingMistake.bankId) {
      // Bank dihapus dari mistake
      newBankName = null
    }

    // Update mistake
    const updatedMistake = await db.mistake.update({
      where: { id: mistakeId },
      data: {
        amount: newAmount,
        notes: notes !== undefined ? notes : existingMistake.notes,
        bankId: bankId !== undefined ? bankId : existingMistake.bankId,
        bankName: newBankName
      }
    })

    return NextResponse.json({
      success: true,
      mistake: updatedMistake
    })
  } catch (error) {
    console.error('Edit mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengedit mistake' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus mistake
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const mistakeId = searchParams.get('mistakeId')
    const userId = searchParams.get('userId')

    if (!sessionId || !mistakeId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user role
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission delete
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDelete) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus data' },
        { status: 403 }
      )
    }

    // Ambil mistake yang ada
    const mistake = await db.mistake.findUnique({
      where: { id: mistakeId }
    })

    if (!mistake) {
      return NextResponse.json(
        { error: 'Mistake tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert balance bank jika ada bankId
    if (mistake.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: mistake.bankId }
      })

      if (bank) {
        // Tambah balance untuk revert (karena sebelumnya dikurangi)
        await db.bank.update({
          where: { id: mistake.bankId },
          data: { balance: bank.balance + mistake.amount }
        })

        // Catat history
        await db.bankHistory.create({
          data: {
            bankId: mistake.bankId,
            eventType: 'UPDATED',
            oldBalance: bank.balance,
            newBalance: bank.balance + mistake.amount,
            notes: `Mistake Delete Revert: +${mistake.amount}`,
            userId
          }
        })
      }
    }

    // Hapus mistake
    await db.mistake.delete({
      where: { id: mistakeId }
    })

    return NextResponse.json({
      success: true,
      message: 'Mistake berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus mistake' },
      { status: 500 }
    )
  }
}

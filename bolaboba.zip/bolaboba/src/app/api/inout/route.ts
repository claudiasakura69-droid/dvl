import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil semua InOut transactions
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check view permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses' },
        { status: 403 }
      )
    }

    const inOuts = await db.inOut.findMany({
      include: {
        fromBank: true,
        toBank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      data: inOuts
    })
  } catch (error) {
    console.error('Get inouts error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data InOut' },
      { status: 500 }
    )
  }
}

// POST - Buat InOut baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, fromBankId, toBankId, amount, notes, userId } = await req.json()

    if (!sessionId || !fromBankId || !toBankId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check add permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses untuk menambah data' },
        { status: 403 }
      )
    }

    if (fromBankId === toBankId) {
      return NextResponse.json(
        { error: 'Bank asal dan tujuan tidak boleh sama' },
        { status: 400 }
      )
    }

    // Cari kedua bank
    const fromBank = await db.bank.findUnique({
      where: { id: fromBankId }
    })

    const toBank = await db.bank.findUnique({
      where: { id: toBankId }
    })

    if (!fromBank || !toBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    const amountFloat = parseFloat(amount)

    // Buat InOut transaction dengan backup bank name
    const inOut = await db.inOut.create({
      data: {
        fromBankId,
        fromBankName: fromBank.name,
        toBankId,
        toBankName: toBank.name,
        amount: amountFloat,
        notes: notes || null,
        userId
      }
    })

    // Update balance kedua bank
    await db.bank.update({
      where: { id: fromBankId },
      data: { balance: fromBank.balance - amountFloat }
    })

    await db.bank.update({
      where: { id: toBankId },
      data: { balance: toBank.balance + amountFloat }
    })

    // Catat history untuk kedua bank
    await db.bankHistory.create({
      data: {
        bankId: fromBankId,
        eventType: 'UPDATED',
        oldBalance: fromBank.balance,
        newBalance: fromBank.balance - amountFloat,
        notes: `InOut: ${amountFloat} ke ${toBank.name} - ${toBank.accountName}`,
        userId
      }
    })

    await db.bankHistory.create({
      data: {
        bankId: toBankId,
        eventType: 'UPDATED',
        oldBalance: toBank.balance,
        newBalance: toBank.balance + amountFloat,
        notes: `InOut: ${amountFloat} dari ${fromBank.name} - ${fromBank.accountName}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      inOut
    })
  } catch (error) {
    console.error('Create inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat InOut' },
      { status: 500 }
    )
  }
}

// PATCH - Edit InOut yang sudah ada
export async function PATCH(req: NextRequest) {
  try {
    const { sessionId, inOutId, fromBankId, toBankId, amount, notes, userId } = await req.json()

    if (!sessionId || !inOutId || !fromBankId || !toBankId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check edit permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canEdit) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses untuk mengedit data' },
        { status: 403 }
      )
    }

    if (fromBankId === toBankId) {
      return NextResponse.json(
        { error: 'Bank asal dan tujuan tidak boleh sama' },
        { status: 400 }
      )
    }

    // Get existing InOut transaction
    const existingInOut = await db.inOut.findUnique({
      where: { id: inOutId },
      include: {
        fromBank: true,
        toBank: true
      }
    })

    if (!existingInOut) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    const amountFloat = parseFloat(amount)
    
    // Get banks
    const fromBank = await db.bank.findUnique({
      where: { id: fromBankId }
    })

    const toBank = await db.bank.findUnique({
      where: { id: toBankId }
    })

    if (!fromBank || !toBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert old balances first
    if (existingInOut.fromBank) {
      await db.bank.update({
        where: { id: existingInOut.fromBankId! },
        data: { balance: existingInOut.fromBank.balance + existingInOut.amount }
      })
    }
    if (existingInOut.toBank) {
      await db.bank.update({
        where: { id: existingInOut.toBankId! },
        data: { balance: existingInOut.toBank.balance - existingInOut.amount }
      })
    }

    // Update InOut transaction
    const updatedInOut = await db.inOut.update({
      where: { id: inOutId },
      data: {
        fromBankId,
        fromBankName: fromBank.name,
        toBankId,
        toBankName: toBank.name,
        amount: amountFloat,
        notes: notes || null
      }
    })

    // Apply new balances
    await db.bank.update({
      where: { id: fromBankId },
      data: { balance: fromBank.balance - amountFloat }
    })

    await db.bank.update({
      where: { id: toBankId },
      data: { balance: toBank.balance + amountFloat }
    })

    // Update history for old banks
    if (existingInOut.fromBank) {
      await db.bankHistory.create({
        data: {
          bankId: existingInOut.fromBankId!,
          eventType: 'UPDATED',
          oldBalance: existingInOut.fromBank.balance,
          newBalance: existingInOut.fromBank.balance + existingInOut.amount,
          notes: `InOut Edit Revert: ${existingInOut.amount} dari ${existingInOut.fromBankName || 'Deleted Bank'}`,
          userId
        }
      })
    }
    if (existingInOut.toBank) {
      await db.bankHistory.create({
        data: {
          bankId: existingInOut.toBankId!,
          eventType: 'UPDATED',
          oldBalance: existingInOut.toBank.balance,
          newBalance: existingInOut.toBank.balance - existingInOut.amount,
          notes: `InOut Edit Revert: ${existingInOut.amount} ke ${existingInOut.toBankName || 'Deleted Bank'}`,
          userId
        }
      })
    }

    // Create history for new banks
    await db.bankHistory.create({
      data: {
        bankId: fromBankId,
        eventType: 'UPDATED',
        oldBalance: fromBank.balance,
        newBalance: fromBank.balance - amountFloat,
        notes: `InOut Edit: ${amountFloat} ke ${toBank.name} - ${toBank.accountName}`,
        userId
      }
    })

    await db.bankHistory.create({
      data: {
        bankId: toBankId,
        eventType: 'UPDATED',
        oldBalance: toBank.balance,
        newBalance: toBank.balance + amountFloat,
        notes: `InOut Edit: ${amountFloat} dari ${fromBank.name} - ${fromBank.accountName}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      inOut: updatedInOut
    })
  } catch (error) {
    console.error('Edit inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengedit InOut' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus InOut dan revert balances
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const inOutId = searchParams.get('inOutId')
    const userId = searchParams.get('userId')

    if (!sessionId || !inOutId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check delete permission
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDelete) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses untuk menghapus data' },
        { status: 403 }
      )
    }

    // Get InOut transaction
    const inOut = await db.inOut.findUnique({
      where: { id: inOutId },
      include: {
        fromBank: true,
        toBank: true
      }
    })

    if (!inOut) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert balances
    if (inOut.fromBank) {
      await db.bank.update({
        where: { id: inOut.fromBankId! },
        data: { balance: inOut.fromBank.balance + inOut.amount }
      })

      // Create history for fromBank
      await db.bankHistory.create({
        data: {
          bankId: inOut.fromBankId!,
          eventType: 'UPDATED',
          oldBalance: inOut.fromBank.balance,
          newBalance: inOut.fromBank.balance + inOut.amount,
          notes: `InOut Delete: ${inOut.amount} dikembalikan ke ${inOut.fromBank.name} - ${inOut.fromBank.accountName}`,
          userId
        }
      })
    }

    if (inOut.toBank) {
      await db.bank.update({
        where: { id: inOut.toBankId! },
        data: { balance: inOut.toBank.balance - inOut.amount }
      })

      // Create history for toBank
      await db.bankHistory.create({
        data: {
          bankId: inOut.toBankId!,
          eventType: 'UPDATED',
          oldBalance: inOut.toBank.balance,
          newBalance: inOut.toBank.balance - inOut.amount,
          notes: `InOut Delete: ${inOut.amount} dikurangi dari ${inOut.toBank.name} - ${inOut.toBank.accountName}`,
          userId
        }
      })
    }

    // Delete InOut transaction
    await db.inOut.delete({
      where: { id: inOutId }
    })

    return NextResponse.json({
      success: true,
      message: 'InOut berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus InOut' },
      { status: 500 }
    )
  }
}

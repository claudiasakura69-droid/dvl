import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// GET - Ambil semua banks
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt || !session.user.isActive) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission view
    const permissions = getPermissions(session.user.role)
    if (!permissions.canView) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki akses' },
        { status: 403 }
      )
    }

    const banks = await db.bank.findMany({
      include: {
        bankHistories: {
          orderBy: { createdAt: 'desc' },
          take: 50
        }
      },
      orderBy: [
        { type: 'asc' },
        { createdAt: 'desc' }
      ]
    })

    return NextResponse.json({
      success: true,
      data: banks
    })
  } catch (error) {
    console.error('Get banks error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data banks' },
      { status: 500 }
    )
  }
}

// POST - Buat bank baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, name, accountName, accountNumber, type, balance } = await req.json()

    if (!sessionId || !name || !accountName || !type || balance === undefined) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt || !session.user.isActive) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission add
    const permissions = getPermissions(session.user.role)
    if (!permissions.canAdd) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah bank' },
        { status: 403 }
      )
    }

    // Buat bank baru
    const bank = await db.bank.create({
      data: {
        name,
        accountName,
        accountNumber: accountNumber || null,
        type,
        balance: parseFloat(balance)
      }
    })

    // Catat history
    await db.bankHistory.create({
      data: {
        bankId: bank.id,
        eventType: 'CREATED',
        newBalance: balance,
        newType: type,
        notes: `Bank ${type} baru dibuat`,
        userId: session.userId
      }
    })

    return NextResponse.json({
      success: true,
      data: bank
    })
  } catch (error) {
    console.error('Create bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat bank' },
      { status: 500 }
    )
  }
}

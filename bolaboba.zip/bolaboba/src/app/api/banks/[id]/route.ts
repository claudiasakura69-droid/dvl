import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getPermissions } from '@/lib/permissions'

// PATCH - Update bank
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, name, accountName, accountNumber, balance, type, status } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt || !session.user.isActive) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permissions
    const permissions = getPermissions(session.user.role)
    if (type && !permissions.canEditBankType) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengubah tipe bank' },
        { status: 403 }
      )
    }
    if (status && !permissions.canEditBankStatus) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengubah status bank' },
        { status: 403 }
      )
    }
    if ((name || accountName || accountNumber || balance !== undefined) && !permissions.canEdit) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit bank' },
        { status: 403 }
      )
    }

    // Cari bank yang akan diupdate
    const existingBank = await db.bank.findUnique({
      where: { id }
    })

    if (!existingBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Prepare update data
    const updateData: any = {}

    if (name) updateData.name = name
    if (accountName) updateData.accountName = accountName
    if (accountNumber !== undefined) updateData.accountNumber = accountNumber
    if (balance !== undefined) updateData.balance = parseFloat(balance)
    if (type) updateData.type = type
    if (status) updateData.status = status

    // Update bank
    const bank = await db.bank.update({
      where: { id },
      data: updateData
    })

    // Catat history jika ada perubahan balance
    if (balance !== undefined && balance !== existingBank.balance) {
      await db.bankHistory.create({
        data: {
          bankId: bank.id,
          eventType: 'UPDATED',
          oldBalance: existingBank.balance,
          newBalance: parseFloat(balance),
          notes: 'Balance diperbarui',
          userId: session.userId
        }
      })
    }

    // Catat history jika ada perubahan status
    if (status && status !== existingBank.status) {
      await db.bankHistory.create({
        data: {
          bankId: bank.id,
          eventType: 'STATUS_CHANGED',
          oldValue: existingBank.status,
          newValue: status,
          notes: `Status diubah dari ${existingBank.status} ke ${status}`,
          userId: session.userId
        }
      })
    }

    // Catat history jika ada perubahan tipe
    if (type && type !== existingBank.type) {
      await db.bankHistory.create({
        data: {
          bankId: bank.id,
          eventType: 'TYPE_CHANGED',
          oldType: existingBank.type,
          newType: type,
          notes: `Tipe diubah dari ${existingBank.type} ke ${type}`,
          userId: session.userId
        }
      })
    }

    return NextResponse.json({
      success: true,
      data: bank
    })
  } catch (error) {
    console.error('Update bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate bank' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus bank (preserve transaction data)
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt || !session.user.isActive) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission delete
    const permissions = getPermissions(session.user.role)
    if (!permissions.canDeleteBank) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus bank' },
        { status: 403 }
      )
    }

    // Cari bank yang akan dihapus
    const bank = await db.bank.findUnique({
      where: { id }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Set bankId to null and bankName in all related transactions
    await db.dailyTransaction.updateMany({
      where: { bankId: id },
      data: {
        bankId: null,
        bankName: bank.name
      }
    })

    await db.inOut.updateMany({
      where: { fromBankId: id },
      data: {
        fromBankId: null,
        fromBankName: bank.name
      }
    })

    await db.inOut.updateMany({
      where: { toBankId: id },
      data: {
        toBankId: null,
        toBankName: bank.name
      }
    })

    await db.expense.updateMany({
      where: { bankId: id },
      data: {
        bankId: null,
        bankName: bank.name
      }
    })

    await db.mistake.updateMany({
      where: { bankId: id },
      data: {
        bankId: null,
        bankName: bank.name
      }
    })

    await db.akuran.updateMany({
      where: { bankId: id },
      data: {
        bankId: null,
        bankName: bank.name
      }
    })

    // Hapus bank
    await db.bank.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Bank berhasil dihapus. Semua transaksi tetap tersimpan.'
    })
  } catch (error) {
    console.error('Delete bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus bank' },
      { status: 500 }
    )
  }
}

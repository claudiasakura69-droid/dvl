# Bank Management System

Sistem manajemen perbankan lengkap untuk tracking transaksi, saldo, dan aktivitas antar bank. Dibangun dengan Next.js 16, TypeScript, Prisma, dan shadcn/ui.

## Fitur Utama

### 🔐 Authentication
- Login dengan username & token
- Session management
- Tracking user login/logout
- Support multiple users

### 🏦 Bank Management
- Kelola rekening Deposit dan Withdraw
- Tambah, edit, hapus bank
- Set bank online/offline
- Drag & move antar deposit dan withdraw
- History lengkap untuk setiap bank
- Support untuk: BCA, BRI, BNI, Mandiri, Danamon, Dana, OVO, Gopay, Telkomsel, QRIS, dll

### 📅 Daily Transactions
- Catat transaksi deposit harian
- Catat transaksi withdraw harian
- Filter berdasarkan tanggal
- Tambah transaksi tunggal atau bulk
- Real-time balance updates
- Export ke Excel

### 💸 In / Out
- Perpindahan saldo antar bank
- Tracking perpindahan dengan notes
- History lengkap dengan timestamp
- User tracking

### 💳 Expense
- Catat pengeluaran operasional
- Kategorisasi pengeluaran
- Notes untuk setiap expense
- Export ke Excel

### ⚠️ Mistake
- Catat kesalahan transaksi
- Koreksi nominal
- Catat beban biaya kekurangan
- Tracking per bank (opsional)

### 📊 Dashboard
- Overview statistik
- Total users online
- Total banks
- Total transactions
- Total amount

### 📥 Export
- Export data ke Excel
- Filter berdasarkan tanggal
- Multi-sheet export (per tanggal)
- Include semua data (Day, InOut, Expense, Mistake)

## Tech Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **Database**: Prisma ORM (SQLite / PostgreSQL)
- **Export**: xlsx
- **Authentication**: Custom session-based auth

## Quick Start

### Prerequisites

- Node.js 18+
- Bun (package manager)
- Git

### Installation

1. Clone repository:
```bash
git clone https://github.com/username/bank-management.git
cd bank-management
```

2. Install dependencies:
```bash
bun install
```

3. Setup environment:
```bash
cp .env.example .env.local
```

Edit `.env.local` dan tambahkan:
```
DATABASE_URL="file:./db/custom.db"
USER_admin_TOKEN=master123@
```

4. Setup database:
```bash
bun run db:push
bun run prisma/seed.ts
```

5. Start development server:
```bash
bun run dev
```

6. Buka http://localhost:3000

### Default Login

- **Username**: `admin`
- **Token**: `master123@`

## Project Structure

```
├── prisma/
│   ├── schema.prisma          # Database schema
│   └── seed.ts               # Database seeding
├── src/
│   ├── app/
│   │   ├── api/              # API routes
│   │   │   ├── auth/         # Authentication endpoints
│   │   │   ├── banks/        # Bank management
│   │   │   ├── daily-transactions/
│   │   │   ├── inout/        # In/Out transactions
│   │   │   ├── expense/      # Expense management
│   │   │   ├── mistake/      # Mistake corrections
│   │   │   └── export/       # Excel export
│   │   ├── page.tsx          # Main page
│   │   └── layout.tsx
│   ├── components/
│   │   ├── dashboard/        # Dashboard components
│   │   └── ui/               # shadcn/ui components
│   ├── lib/
│   │   ├── db.ts             # Prisma client
│   │   └── utils.ts
│   └── app/
│       ├── globals.css
│       └── layout.tsx
├── db/
│   └── custom.db             # SQLite database (local)
└── package.json
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `POST /api/auth/session` - Check session validity

### Banks
- `GET /api/banks` - Get all banks
- `POST /api/banks` - Create bank
- `PUT /api/banks/[id]` - Update bank
- `DELETE /api/banks/[id]` - Delete bank
- `PUT /api/banks/[id]/status` - Toggle online/offline
- `PUT /api/banks/[id]/move` - Move between deposit/withdraw

### Daily Transactions
- `GET /api/daily-transactions` - Get transactions by date
- `POST /api/daily-transactions` - Create transaction
- `POST /api/daily-transactions/bulk` - Bulk create

### InOut
- `GET /api/inout` - Get all InOut transactions
- `POST /api/inout` - Create InOut transaction

### Expense
- `GET /api/expense` - Get all expenses
- `POST /api/expense` - Create expense

### Mistake
- `GET /api/mistake` - Get all mistakes
- `POST /api/mistake` - Create mistake

### Export
- `POST /api/export` - Export data to Excel

## User Management

### Adding New Users

Users dapat ditambahkan dengan environment variables:

Format: `USER_{username}_TOKEN`

Contoh di `.env.local`:
```
USER_admin_TOKEN=master123@
USER_staff_TOKEN=staff123@
USER_manager_TOKEN=manager456@
```

### User States

- **Active**: User dapat login
- **Inactive**: User tidak dapat login
- **Online**: User sedang memiliki session aktif
- **Offline**: User sudah logout atau session expired

## Deployment

### Cloudflare Pages

Deployment guide lengkap tersedia di [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md)

Singkatnya:
1. Push ke GitHub
2. Connect repository ke Cloudflare Pages
3. Set framework preset ke Next.js
4. Configure environment variables
5. Deploy

### Environment Variables Required

- `DATABASE_URL` - Database connection string
- `USER_{username}_TOKEN` - User credentials (multiple)

## Development

### Available Scripts

```bash
bun run dev          # Start development server
bun run build        # Build for production
bun run start        # Start production server
bun run lint         # Run ESLint
bun run db:push      # Push schema changes to database
bun run db:generate  # Generate Prisma client
bun run db:migrate   # Run database migrations
```

### Code Style

- TypeScript throughout
- shadcn/ui components preferred
- Responsive design with Tailwind CSS
- ES6+ import/export syntax

## Features in Detail

### Bank Cards

Setiap bank card menampilkan:
- Nama bank dan pemilik
- Nomor rekening (untuk bank tradisional)
- Saldo awal
- Saldo transaksi hari ini
- Saldo akhir
- Status (online/offline)

Actions:
- ✅ Set online/offline
- 🔄 Move antar deposit & withdraw
- 📜 View history
- 🗑️ Delete

### Daily Transactions

Features:
- Filter berdasarkan tanggal
- Real-time balance updates
- Support bulk transactions (format: Name{tab}AccountNo{tab}Amount{tab}Bank)
- Auto categorization (Deposit vs Withdraw)
- User tracking

### Export Excel

Format export:
- Multi-sheet Excel file
- Satu sheet per tanggal
- Categories: Deposit, Withdraw, InOut, Expense, Mistake
- Total per bank
- Total keseluruhan

## Troubleshooting

### Database Issues

```bash
# Reset database
bun run db:reset

# View database
sqlite3 db/custom.db
```

### Build Errors

```bash
# Clean build
rm -rf .next
bun run build
```

### Prisma Issues

```bash
# Regenerate client
bun run db:generate

# Push schema changes
bun run db:push
```

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Support

For issues or questions, please:
1. Check the [Troubleshooting](#troubleshooting) section
2. Review [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) for deployment issues
3. Open an issue on GitHub

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## Roadmap

- [ ] Multi-currency support
- [ ] Advanced reporting
- [ ] Email notifications
- [ ] Two-factor authentication
- [ ] Mobile app (React Native)
- [ ] Real-time updates (WebSocket)

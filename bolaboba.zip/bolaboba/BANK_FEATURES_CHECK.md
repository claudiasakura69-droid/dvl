# Bank Management Features Checklist

## ✅ Frontend Components (BankManagementContent.tsx)

### 1. **TAMBAH BANK (Add Bank)**
- ✅ Tombol "Tambah Bank" dengan icon Plus
- ✅ Dialog dengan form:
  - Nama Bank (text input)
  - Nama Pemilik (text input)
  - Nomor Rekening (text input, optional)
  - Tipe (Select: Deposit/Withdraw)
  - Saldo Awal (number input)
  - Tombol Simpan
- ✅ Permission check: `permissions.canAdd`
- ✅ Function: `handleCreateBank`
- ✅ POST ke: `/api/banks`

### 2. **TOGGLE STATUS (Online/Offline)**
- ✅ Tombol Power (ikon listrik)
- ✅ Warna berubah sesuai status:
  - Online = hijau
  - Offline = abu-abu
- ✅ Permission check: `permissions.canEditBankStatus`
- ✅ Function: `handleToggleStatus`
- ✅ PUT ke: `/api/banks/${bankId}/status`
- ✅ Confirm toast setelah status berubah

### 3. **PINDAH BANK (Deposit ↔ Withdraw)**
- ✅ Tombol ArrowRightLeft (ikon panah kanan-kiri)
- ✅ Permission check: `permissions.canEditBankType`
- ✅ Function: `handleMoveBank`
- ✅ PUT ke: `/api/banks/${bankId}/move`
- ✅ Confirm dialog sebelum memindahkan
- ✅ Toast notifikasi setelah berhasil

### 4. **DELETE BANK**
- ✅ Tombol Trash2 (ikon sampah)
- ✅ Permission check: `permissions.canDeleteBank`
- ✅ Function: `handleDeleteBank`
- ✅ DELETE ke: `/api/banks/${bankId}`
- ✅ Confirm dialog sebelum menghapus
- ✅ Preserves transaction data (SetNull pada bankId)
- ✅ Toast notifikasi setelah dihapus

### 5. **VIEW HISTORY**
- ✅ Tombol History (ikon jam)
- ✅ Dialog dengan table:
  - Event
  - Old Value
  - New Value
  - Notes
  - Time
- ✅ Function: `onViewHistory`
- ✅ Scrollable untuk banyak history

### 6. **DISPLAY LAYOUT**
- ✅ Header dengan icon Building2 dan judul "Bank Management"
- ✅ Deskripsi: "Kelola rekening deposit dan withdraw"
- ✅ Grid 2 kolom:
  - Kiri: Deposit Banks (warna hijau)
  - Kanan: Withdraw Banks (warna merah)
- ✅ Setiap kolom menampilkan jumlah bank dalam kurung
- ✅ Card bank dengan:
  - Border hijau jika status online
  - Nama bank dan pemilik
  - Nomor rekening (jika ada)
  - Status (online/offline) dengan warna
  - Balance (format Rp currency)
  - Tombol-tombol action (Status, History, Move, Delete)
- ✅ Scrollable untuk banyak bank
- ✅ Responsive design (mobile dan desktop)

---

## ✅ API Routes

### 1. **GET /api/banks**
- ✅ Check session validity
- ✅ Check permission: `canView`
- ✅ Return semua banks dengan bankHistories
- ✅ Order by: type ASC, createdAt DESC
- ✅ Status: 200 ✅

### 2. **POST /api/banks**
- ✅ Validate: sessionId, name, accountName, type, balance
- ✅ Check session validity
- ✅ Check permission: `canAdd`
- ✅ Create bank di database
- ✅ Create bank history entry
- ✅ Return success dengan data bank

### 3. **PUT /api/banks/[id]/status**
- ✅ Await params (Next.js 16 fix)
- ✅ Validate: sessionId, status (online/offline)
- ✅ Check session validity
- ✅ Check permission: `canEditBankStatus`
- ✅ Update bank status
- ✅ Create bank history entry
- ✅ Return success dengan data bank

### 4. **PUT /api/banks/[id]/move**
- ✅ Await params (Next.js 16 fix)
- ✅ Validate: sessionId, newType (DEPOSIT/WITHDRAW)
- ✅ Check session validity
- ✅ Check permission: `canEditBankType`
- ✅ Validate: bank belum di type tersebut
- ✅ Update bank type
- ✅ Create bank history entry
- ✅ Return success dengan data bank

### 5. **DELETE /api/banks/[id]**
- ✅ Await params (Next.js 16 fix)
- ✅ Check session validity
- ✅ Check permission: `canDeleteBank`
- ✅ Preserves DailyTransaction (set bankId to null, save bankName)
- ✅ Preserves InOut fromBank (set fromBankId to null, save fromBankName)
- ✅ Preserves InOut toBank (set toBankId to null, save toBankName)
- ✅ Preserves Expense (set bankId to null, save bankName)
- ✅ Preserves Mistake (set bankId to null, save bankName)
- ✅ Preserves Akuran (set bankId to null, save bankName)
- ✅ Delete bank
- ✅ Return success message

---

## ✅ Database Schema (Prisma)

### Model Bank
```prisma
model Bank {
  id          String   @id @default(cuid())
  name        String
  accountName String
  accountNumber String?
  type        String   // DEPOSIT or WITHDRAW
  balance     Float    @default(0)
  status      String   @default("offline") // online or offline
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  dailyTransactions DailyTransaction[]
  bankHistories BankHistory[]
  inOutFrom InOut[] @relation("InOutFrom")
  inOutTo   InOut[] @relation("InOutTo")
  expenses Expense[]
  mistakes Mistake[]
  akurans Akuran[]

  @@index([type])
  @@index([status])
}
```

### Model BankHistory
```prisma
model BankHistory {
  id          String   @id @default(cuid())
  bankId      String
  bank        Bank     @relation(fields: [bankId], references: [id], onDelete: Cascade)
  eventType   String   // CREATED, UPDATED, MOVED, STATUS_CHANGED
  oldValue    String?
  newValue    String?
  oldBalance  Float?
  newBalance  Float?
  oldType     String?
  newType     String?
  notes       String?
  userId      String?
  createdAt   DateTime @default(now())
}
```

---

## ✅ Permissions (src/lib/permissions.ts)

| Role      | View | Add | Edit | Delete | Delete Bank | Edit Type | Edit Status |
|-----------|------|-----|------|--------|------------|-----------|-------------|
| VIEW      | ✅   | ❌  | ❌   | ❌     | ❌          | ❌         |
| ADMIN     | ✅   | ✅  | ❌   | ❌     | ❌          | ❌         |
| SUPPORT   | ✅   | ✅  | ✅   | ❌     | ❌          | ❌         |
| SUPERVISOR| ✅   | ✅  | ✅   | ✅     | ❌          | ✅         |
| MASTER    | ✅   | ✅  | ✅   | ✅     | ✅          | ✅         |

---

## 🔍 Current Status

### Working Features:
✅ Bank list display
✅ Bank cards with all info
✅ Add bank dialog
✅ Status toggle (with permission)
✅ Move bank (with permission)
✅ Delete bank (with permission)
✅ View history
✅ API routes all returning 200
✅ Database sync complete

### Notes:
- All features are implemented and working
- Permission checks are in place
- Data is preserved when bank is deleted
- All Next.js 16 params issues are fixed
- Build successful with no errors

---

## 📝 Testing Checklist

To verify all features work:

1. **Login as MASTER user**
   - Should see all buttons (Status, History, Move, Delete)
   - Can add, edit, delete banks
   - Can change bank type and status

2. **Test Add Bank**
   - Click "Tambah Bank"
   - Fill form with all fields
   - Submit
   - Should see new bank in list
   - Toast should appear

3. **Test Status Toggle**
   - Click Power button on a bank
   - Confirm dialog
   - Status should change
   - Border color should change
   - History should show event

4. **Test Move Bank**
   - Click ArrowRightLeft button
   - Confirm dialog
   - Bank should move to other section
   - History should show event

5. **Test Delete Bank**
   - Click Trash button
   - Confirm dialog
   - Bank should be removed
   - Transaction data preserved
   - Toast should appear

6. **Test View History**
   - Click History button
   - Dialog should show with table
   - All events should be listed

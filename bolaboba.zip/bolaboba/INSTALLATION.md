# Panduan Instalasi Bank Management System

## Prasyarat

Sebelum memulai, pastikan Anda telah menginstall:
- **Node.js** (versi 18.x atau lebih tinggi)
- **Bun** (opsional, tapi disarankan untuk performa lebih baik)
- **Git** (untuk clone repository)
- **Database** (PostgreSQL untuk production, SQLite untuk development)

---

## 1. Development (Local)

### 1.1 Clone Repository

```bash
git clone <repository-url>
cd my-project
```

### 1.2 Install Dependencies

**Menggunakan Bun (disarankan):**
```bash
bun install
```

**Menggunakan NPM:**
```bash
npm install
```

### 1.3 Setup Environment Variables

Buat file `.env` di root project:

```bash
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/bank_management"

# Environment
NODE_ENV="development"
```

Untuk development, Anda bisa menggunakan SQLite:

```bash
DATABASE_URL="file:./dev.db"
```

### 1.4 Setup Database

Generate Prisma Client:
```bash
bun run db:generate
# atau
npx prisma generate
```

Push schema ke database:
```bash
bun run db:push
# atau
npx prisma db push
```

### 1.5 Jalankan Development Server

**Menggunakan Bun:**
```bash
bun run dev
```

**Menggunakan NPM:**
```bash
npm run dev
```

Server akan berjalan di `http://localhost:3000`

---

## 2. Production (Local)

### 2.1 Build Application

```bash
bun run build
# atau
npm run build
```

### 2.2 Start Production Server

```bash
bun run start
# atau
npm start
```

### 2.3 Setup Production Database

Untuk production, gunakan PostgreSQL atau MySQL:

```bash
# .env.production
DATABASE_URL="postgresql://user:password@localhost:5432/bank_management_prod"
```

Push schema:
```bash
bun run db:push
```

### 2.4 Menggunakan PM2 untuk Process Management

Install PM2:
```bash
npm install -g pm2
```

Start aplikasi dengan PM2:
```bash
pm2 start "bun run start" --name "bank-management"
pm2 save
pm2 startup
```

---

## 3. Deploy ke Cloudflare Pages

### 3.1 Persiapan

1. Install Wrangler CLI:
```bash
npm install -g wrangler
```

2. Login ke Cloudflare:
```bash
wrangler login
```

### 3.2 Setup Database

Untuk production, gunakan database eksternal seperti **Neon** (PostgreSQL) atau **PlanetScale** (MySQL):

**Contoh dengan Neon:**
1. Buat project di [Neon](https://neon.tech)
2. Copy connection string
3. Update `.env`:
```bash
DATABASE_URL="postgresql://user:password@ep-xxx.aws.neon.tech/neondb?sslmode=require"
```

### 3.3 Build untuk Cloudflare

Update `next.config.js` jika diperlukan:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  experimental: {
    serverActions: {
      allowedOrigins: ['localhost:3000', 'your-domain.pages.dev'],
    },
  },
}

export default nextConfig
```

Build:
```bash
bun run build
```

### 3.4 Deploy dengan Wrangler

```bash
wrangler pages deploy .next/static --project-name=bank-management
```

Atau gunakan Git integration di dashboard Cloudflare.

---

## 4. Environment Variables Lengkap

```bash
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/bank_management"

# Application
NODE_ENV="development"
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Security (opsional untuk production)
SESSION_SECRET="your-secret-key-here"
```

---

## 5. Struktur Project

```
my-project/
├── prisma/
│   └── schema.prisma          # Database schema
├── src/
│   ├── app/
│   │   ├── api/               # API routes
│   │   ├── page.tsx           # Homepage
│   │   └── layout.tsx         # Root layout
│   ├── components/
│   │   ├── ui/                # Shadcn UI components
│   │   └── dashboard/         # Dashboard components
│   └── lib/
│       ├── db.ts              # Prisma client
│       └── permissions.ts     # Permission system
├── public/                    # Static assets
├── .env                      # Environment variables
├── package.json
├── tsconfig.json
└── tailwind.config.ts
```

---

## 6. Membuat User Pertama (Admin)

Setelah setup database, Anda perlu membuat user pertama secara manual:

### Cara 1: Menggunakan Prisma Studio

```bash
npx prisma studio
```

Buka `http://localhost:5555` dan buat user di tabel `User` dengan:
- `username`: admin
- `password`: password_anda
- `role`: MASTER
- `isActive`: true

### Cara 2: Menggunakan Script

Buat file `create-admin.ts`:

```typescript
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  const admin = await prisma.user.create({
    data: {
      username: 'admin',
      password: 'password_anda', // TODO: Hash dengan bcrypt
      role: 'MASTER',
      isActive: true,
    },
  })
  console.log('Admin created:', admin)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
```

Run script:
```bash
bun run create-admin.ts
```

---

## 7. Troubleshooting

### 7.1 Server tidak berjalan

**Masalah:** Port 3000 sudah digunakan
```bash
# Kill process yang menggunakan port 3000
lsof -ti:3000 | xargs kill -9
# atau
fuser -k 3000/tcp
```

### 7.2 Database Connection Error

**Masalah:** DATABASE_URL salah
- Pastikan database sudah dibuat
- Cek username dan password benar
- Pastikan database server berjalan

### 7.3 Permission Denied

**Masalah:** User tidak bisa mengakses fitur

Cek role user:
- **VIEW**: Hanya bisa melihat data
- **ADMIN**: Bisa menambah dan melihat data
- **SUPPORT**: Bisa menambah, edit, dan melihat data
- **SUPERVISOR**: Bisa menambah, edit, delete, dan mengubah status bank
- **MASTER**: Full access termasuk delete bank dan edit bank type

### 7.4 Cache Browser

Jika perubahan tidak muncul:
1. Clear browser cache
2. Buka Incognito/Private window
3. Hard refresh: `Ctrl + Shift + R` (Windows) atau `Cmd + Shift + R` (Mac)

---

## 8. Commands Lengkap

```bash
# Development
bun run dev              # Start dev server
bun run lint             # Run ESLint

# Database
bun run db:push          # Push schema to database
bun run db:generate      # Generate Prisma client
bun run db:migrate       # Run migrations
bun run db:reset         # Reset database

# Production
bun run build            # Build for production
bun run start            # Start production server
```

---

## 9. Security Best Practices untuk Production

1. **Password Hashing**: Gunakan bcrypt untuk hash password user
2. **HTTPS**: Selalu gunakan HTTPS di production
3. **Environment Variables**: Jangan commit .env ke git
4. **Database**: Gunakan connection pooling untuk production
5. **Rate Limiting**: Tambah rate limiting untuk API endpoints
6. **CORS**: Konfigurasi CORS dengan benar
7. **Session Management**: Implement session timeout dan cleanup
8. **Backup**: Setup automatic backup untuk database

---

## 10. Support

Jika mengalami masalah:
1. Cek logs di `server.log` atau `dev.log`
2. Pastikan environment variables sudah benar
3. Cek database connection
4. Clear browser cache

---

## Quick Start Commands

```bash
# Clone dan install
git clone <repo-url>
cd my-project
bun install

# Setup environment
cp .env.example .env
# Edit .env dengan DATABASE_URL yang benar

# Setup database
bun run db:generate
bun run db:push

# Start server
bun run dev

# Open browser
# http://localhost:3000
```

---

## Role & Permissions

| Role | Level | Can View | Can Add | Can Edit | Can Delete | Bank Operations |
|------|-------|----------|---------|----------|-----------|-----------------|
| VIEW | 0 | ✅ | ❌ | ❌ | ❌ | ❌ |
| ADMIN | 1 | ✅ | ✅ | ❌ | ❌ | ❌ |
| SUPPORT | 2 | ✅ | ✅ | ✅ | ❌ | ❌ |
| SUPERVISOR | 3 | ✅ | ✅ | ✅ | ✅ | ✅ Status Only |
| MASTER | 4 | ✅ | ✅ | ✅ | ✅ | ✅ Full |

---

## Catatan Penting

1. **Password Security**: Password saat ini masih disimpan dalam plain text. Untuk production, implement hashing dengan bcrypt.
2. **Session Management**: Session disimpan di database dengan localStorage untuk persistensi.
3. **Port Default**: Development server berjalan di port 3000. Ubah jika diperlukan.
4. **Hot Reload**: Next.js dengan Turbopack sudah mendukung hot reload secara otomatis.

#!/bin/bash
cd /home/z/my-project
echo "Starting Bank Management Server..."
while true; do
  echo "[$(date)] Starting dev server..."
  bun run dev
  EXIT_CODE=$?
  echo "[$(date)] Server stopped with exit code: $EXIT_CODE"
  if [ $EXIT_CODE -eq 0 ]; then
    echo "[$(date)] Server stopped normally. Waiting 5 seconds before restart..."
    sleep 5
  else
    echo "[$(date)] Server crashed. Restarting immediately..."
    sleep 2
  fi
done

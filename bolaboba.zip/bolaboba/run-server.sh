#!/bin/bash
cd /home/z/my-project
echo "Starting dev server..."
while true; do
  npx next dev -p 3000
  echo "Server stopped. Restarting in 5 seconds..."
  sleep 5
done

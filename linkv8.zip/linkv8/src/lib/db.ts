import { neon } from '@neondatabase/serverless';
import { PrismaNeon } from '@prisma/adapter-neon';
import { PrismaClient } from '@prisma/client';

function createPrismaClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL || '';

  if (!connectionString || !connectionString.startsWith('postgresql://')) {
    console.warn('[db] DATABASE_URL not set or invalid. Database operations will fail.');
  }

  const sql = neon(
    connectionString && connectionString.startsWith('postgresql://')
      ? connectionString
      : 'postgresql://placeholder:placeholder@localhost/placeholder'
  );
  const adapter = new PrismaNeon(sql);

  return new PrismaClient({ adapter });
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db: PrismaClient = globalForPrisma.prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db;
}

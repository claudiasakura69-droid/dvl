export interface VerificationResult {
  zoneExists: boolean;
  pagesDomainExists: boolean;
  isVerified: boolean;
  message: string;
}

export function getCloudflareConfig() {
  const apiToken = process.env.CLOUDFLARE_API_TOKEN || "";
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID || "";
  const pagesProject = process.env.CLOUDFLARE_PAGES_PROJECT || "";

  return {
    apiToken,
    accountId,
    pagesProject,
    isConfigured: !!(apiToken && accountId && pagesProject),
  };
}

async function cfFetch(url: string, options: RequestInit = {}) {
  const config = getCloudflareConfig();
  const headers: Record<string, string> = {
    Authorization: `Bearer ${config.apiToken}`,
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  };

  const res = await fetch(url, { ...options, headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Cloudflare API error ${res.status}: ${text}`);
  }
  return res.json();
}

export async function checkZoneExists(domain: string): Promise<boolean> {
  try {
    const config = getCloudflareConfig();
    if (!config.isConfigured) return false;

    const data = await cfFetch(
      `https://api.cloudflare.com/client/v4/zones?name=${encodeURIComponent(domain)}`,
      { method: "GET" }
    );
    return Array.isArray(data.result) && data.result.length > 0;
  } catch {
    return false;
  }
}

export async function listPagesDomains(): Promise<string[]> {
  try {
    const config = getCloudflareConfig();
    if (!config.isConfigured) return [];

    const data = await cfFetch(
      `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/pages/projects/${config.pagesProject}/domains`,
      { method: "GET" }
    );
    return Array.isArray(data.result) ? data.result.map((d: { name: string }) => d.name) : [];
  } catch {
    return [];
  }
}

export async function addPagesDomain(domain: string): Promise<boolean> {
  try {
    const config = getCloudflareConfig();
    if (!config.isConfigured) return false;

    await cfFetch(
      `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/pages/projects/${config.pagesProject}/domains`,
      {
        method: "PUT",
        body: JSON.stringify({ name: domain }),
      }
    );
    return true;
  } catch {
    return false;
  }
}

export async function removePagesDomain(domain: string): Promise<boolean> {
  try {
    const config = getCloudflareConfig();
    if (!config.isConfigured) return false;

    await cfFetch(
      `https://api.cloudflare.com/client/v4/accounts/${config.accountId}/pages/projects/${config.pagesProject}/domains/${encodeURIComponent(domain)}`,
      { method: "DELETE" }
    );
    return true;
  } catch {
    return false;
  }
}

export async function checkPagesDomain(domain: string): Promise<boolean> {
  try {
    const domains = await listPagesDomains();
    return domains.includes(domain);
  } catch {
    return false;
  }
}

export async function verifyDomain(domain: string): Promise<VerificationResult> {
  const config = getCloudflareConfig();

  if (!config.isConfigured) {
    return {
      zoneExists: false,
      pagesDomainExists: false,
      isVerified: false,
      message: "Cloudflare API not configured. Set CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID, and CLOUDFLARE_PAGES_PROJECT.",
    };
  }

  try {
    const [zoneExists, pagesDomainExists] = await Promise.all([
      checkZoneExists(domain),
      checkPagesDomain(domain),
    ]);

    const isVerified = zoneExists && pagesDomainExists;

    let message = "";
    if (isVerified) {
      message = "Domain is fully verified — zone exists and is configured on Pages project.";
    } else if (!zoneExists) {
      message = "Domain zone not found in Cloudflare. Add the domain to your Cloudflare account first.";
    } else if (!pagesDomainExists) {
      message = "Domain zone exists but is not configured on the Pages project. Use auto-configure to add it.";
    }

    return { zoneExists, pagesDomainExists, isVerified, message };
  } catch (error) {
    return {
      zoneExists: false,
      pagesDomainExists: false,
      isVerified: false,
      message: `Verification failed: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

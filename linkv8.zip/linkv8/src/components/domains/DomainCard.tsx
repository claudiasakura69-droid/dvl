"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Check,
  X,
  Edit,
  Trash2,
  Shield,
  Power,
} from "lucide-react";
import type { ShortDomain } from "@/lib/types";

interface DomainCardProps {
  domain: ShortDomain;
  onEdit: (domain: ShortDomain) => void;
  onDelete: (domain: ShortDomain) => void;
  onVerify: (domain: ShortDomain) => void;
  onToggle: (domain: ShortDomain) => void;
}

export default function DomainCard({
  domain,
  onEdit,
  onDelete,
  onVerify,
  onToggle,
}: DomainCardProps) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="font-medium">{domain.domain}</h3>
              <Badge
                variant={domain.isActive ? "default" : "destructive"}
                className="text-xs"
              >
                {domain.isActive ? "Active" : "Inactive"}
              </Badge>
              {domain.isVerified ? (
                <Badge className="bg-green-500/10 text-green-600 dark:text-green-400 text-xs border-green-500/20">
                  <Check className="mr-1 h-3 w-3" /> Verified
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs">
                  <X className="mr-1 h-3 w-3" /> Unverified
                </Badge>
              )}
            </div>
            {domain.slug && (
              <p className="text-xs text-muted-foreground">
                Slug: {domain.slug}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {domain._count?.links ?? 0} links
            </p>
            <p className="text-xs text-muted-foreground">
              Created: {new Date(domain.createdAt).toLocaleDateString()}
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onVerify(domain)}
              disabled={domain.isVerified}
              className="gap-1 text-xs h-7"
            >
              <Shield className="h-3 w-3" />
              Verify
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onToggle(domain)}
              className="gap-1 text-xs h-7"
            >
              <Power className="h-3 w-3" />
              {domain.isActive ? "Deactivate" : "Activate"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(domain)}
              className="gap-1 text-xs h-7"
            >
              <Edit className="h-3 w-3" />
              Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(domain)}
              className="gap-1 text-xs h-7 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" />
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

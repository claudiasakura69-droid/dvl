"use client";
import React, { useState, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Download } from "lucide-react";
import QRCode from "react-qr-code";
import type { ShortLink } from "@/lib/types";

interface QRCodeDialogProps {
  link: ShortLink;
  open: boolean;
  onClose: () => void;
}

export default function QRCodeDialog({ link, open, onClose }: QRCodeDialogProps) {
  const [size, setSize] = useState<number>(256);
  const svgRef = useRef<SVGSVGElement>(null);
  const url = `${link.domain?.domain || "s.url"}/${link.slug}`;

  const handleDownload = useCallback(() => {
    const svg = svgRef.current;
    if (!svg) return;
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const img = new Image();
    img.onload = () => {
      canvas.width = size;
      canvas.height = size;
      ctx.drawImage(img, 0, 0, size, size);
      const pngUrl = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = pngUrl;
      a.download = `${link.slug}-qrcode.png`;
      a.click();
    };
    img.src = "data:image/svg+xml;base64," + btoa(svgData);
  }, [size, link.slug]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>QR Code for {link.slug}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 py-4">
          <div className="rounded-lg border bg-white p-4">
            <QRCode ref={svgRef} value={url} size={size / 2} level="M" bgColor="#ffffff" fgColor="#000000" />
          </div>
          <p className="text-sm text-muted-foreground break-all text-center">{url}</p>
          <div className="flex items-center gap-2">
            <Label className="text-sm">Size:</Label>
            <Select value={String(size)} onValueChange={(v) => setSize(Number(v))}>
              <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="128">128px</SelectItem>
                <SelectItem value="256">256px</SelectItem>
                <SelectItem value="512">512px</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleDownload} className="gap-2 w-full">
            <Download className="h-4 w-4" /> Download QR Code
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";
import { verifyDomain } from "@/lib/cloudflare";

// POST - Verify domain via Cloudflare API
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;

    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // Verify domain via Cloudflare
    const result = await verifyDomain(existing.domain);

    // Update domain record with verification results
    const updated = await db.shortDomain.update({
      where: { id },
      data: {
        isVerified: result.isVerified,
        verifiedAt: result.isVerified ? new Date() : null,
      },
    });

    return NextResponse.json({
      ...updated,
      verification: result,
    });
  } catch (error) {
    console.error("Error verifying domain:", error);
    return NextResponse.json({ error: "Failed to verify domain" }, { status: 500 });
  }
}

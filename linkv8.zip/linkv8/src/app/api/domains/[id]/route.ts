import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";
import { removePagesDomain, addPagesDomain, getCloudflareConfig } from "@/lib/cloudflare";

// GET - Get single domain
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const domain = await db.shortDomain.findUnique({
      where: { id },
      include: {
        links: {
          select: { id: true },
        },
      },
    });

    if (!domain) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const domainWithCount = {
      ...domain,
      _count: { links: domain.links.length },
      links: undefined,
    };

    return NextResponse.json(domainWithCount);
  } catch (error) {
    console.error("Error fetching domain:", error);
    return NextResponse.json({ error: "Failed to fetch domain" }, { status: 500 });
  }
}

// PUT - Update domain (with CF Pages cleanup on rename, verification requirement for activation)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();
    const { domain, slug, isActive, isVerified } = body;

    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // Verification rule: isActive=true requires isVerified=true
    if (isActive === true && !existing.isVerified && isVerified !== true) {
      return NextResponse.json(
        { error: "Domain must be verified before it can be activated" },
        { status: 400 }
      );
    }

    // If domain is being changed, clean up old CF Pages domain and add new one
    if (domain && domain !== existing.domain) {
      const domainConflict = await db.shortDomain.findUnique({ where: { domain } });
      if (domainConflict) {
        return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
      }

      const cfConfig = getCloudflareConfig();
      if (cfConfig.isConfigured) {
        // Remove old domain from CF Pages
        try {
          await removePagesDomain(existing.domain);
        } catch {
          // Non-critical, continue
        }
        // Add new domain to CF Pages
        try {
          await addPagesDomain(domain);
        } catch {
          // Non-critical, continue
        }
      }
    }

    const updated = await db.shortDomain.update({
      where: { id },
      data: {
        ...(domain !== undefined && { domain }),
        ...(slug !== undefined && { slug }),
        ...(isActive !== undefined && { isActive }),
        ...(isVerified !== undefined && {
          isVerified,
          ...(isVerified && !existing.isVerified ? { verifiedAt: new Date() } : {}),
          ...(!isVerified && existing.isVerified ? { verifiedAt: null } : {}),
        }),
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating domain:", error);
    return NextResponse.json({ error: "Failed to update domain" }, { status: 500 });
  }
}

// DELETE - Delete domain (optionally remove from CF Pages custom domains)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // Optionally remove from Cloudflare Pages custom domains
    const cfConfig = getCloudflareConfig();
    if (cfConfig.isConfigured) {
      try {
        await removePagesDomain(existing.domain);
      } catch {
        // Non-critical, continue with deletion
      }
    }

    await db.shortDomain.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting domain:", error);
    return NextResponse.json({ error: "Failed to delete domain" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Import JSON data (links, domains, clicks)
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { links, domains, clicks } = body as {
      links?: Array<{
        slug: string;
        domainId: string;
        type?: string;
        mode?: string;
        title?: string;
        description?: string;
        url?: string;
        targets?: Array<{
          url: string;
          clickLimit?: number;
          country?: string;
          ipList?: string;
          order?: number;
        }>;
      }>;
      domains?: Array<{
        domain: string;
        slug?: string;
        isActive?: boolean;
      }>;
      clicks?: unknown[];
    };

    const errors: string[] = [];
    let createdDomains = 0;
    let skippedDomains = 0;
    let createdLinks = 0;
    let skippedLinks = 0;

    // Import domains
    if (Array.isArray(domains) && domains.length > 0) {
      for (const d of domains) {
        if (!d.domain) {
          errors.push(`Skipped domain with empty domain value`);
          skippedDomains++;
          continue;
        }

        try {
          const existing = await db.shortDomain.findUnique({ where: { domain: d.domain } });
          if (existing) {
            skippedDomains++;
            continue;
          }

          await db.shortDomain.create({
            data: {
              domain: d.domain,
              slug: d.slug || "",
              isActive: d.isActive !== undefined ? d.isActive : true,
            },
          });
          createdDomains++;
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : String(err);
          errors.push(`Domain "${d.domain}": ${msg}`);
        }
      }
    }

    // Import links
    if (Array.isArray(links) && links.length > 0) {
      // Build a domain lookup: domain string -> domainId
      const allDomains = await db.shortDomain.findMany({
        select: { id: true, domain: true },
      });
      const domainByString = new Map(allDomains.map((d) => [d.domain, d.id]));

      for (const linkData of links) {
        if (!linkData.slug) {
          errors.push(`Skipped link with empty slug`);
          skippedLinks++;
          continue;
        }

        try {
          // Resolve domainId: could be an actual ID or a domain string
          let resolvedDomainId = linkData.domainId;

          // If the domainId is not a valid cuid, try to match by domain string
          if (resolvedDomainId && !resolvedDomainId.startsWith("c")) {
            const mapped = domainByString.get(resolvedDomainId);
            if (mapped) {
              resolvedDomainId = mapped;
            }
          }

          if (!resolvedDomainId) {
            errors.push(`Link "${linkData.slug}": No valid domain ID provided`);
            skippedLinks++;
            continue;
          }

          // Check for slug+domainId conflict
          const existing = await db.shortLink.findUnique({
            where: { slug_domainId: { slug: linkData.slug, domainId: resolvedDomainId } },
          });

          if (existing) {
            skippedLinks++;
            continue;
          }

          // Build targets array
          const targetsToCreate = linkData.targets?.length
            ? linkData.targets
            : linkData.url
              ? [{ url: linkData.url }]
              : [];

          if (targetsToCreate.length === 0) {
            errors.push(`Link "${linkData.slug}": No targets provided`);
            skippedLinks++;
            continue;
          }

          // Validate domain exists
          const domainExists = await db.shortDomain.findUnique({ where: { id: resolvedDomainId } });
          if (!domainExists) {
            errors.push(`Link "${linkData.slug}": Domain not found (${resolvedDomainId})`);
            skippedLinks++;
            continue;
          }

          await db.shortLink.create({
            data: {
              slug: linkData.slug,
              domainId: resolvedDomainId,
              type: linkData.type || "basic",
              mode: linkData.mode || "sequential",
              title: linkData.title || "",
              description: linkData.description || "",
              targets: {
                create: targetsToCreate.map((t, i) => ({
                  url: t.url,
                  clickLimit: t.clickLimit || 0,
                  country: t.country || "ALL",
                  ipList: t.ipList || "",
                  order: t.order ?? i,
                })),
              },
            },
          });

          createdLinks++;
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : String(err);
          errors.push(`Link "${linkData.slug}": ${msg}`);
        }
      }
    }

    return NextResponse.json({
      createdDomains,
      skippedDomains,
      createdLinks,
      skippedLinks,
      errors,
    });
  } catch (error) {
    console.error("Error importing data:", error);
    return NextResponse.json({ error: "Failed to import data" }, { status: 500 });
  }
}

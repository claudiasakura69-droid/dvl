import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Ambil semua users dengan sessions mereka
    const users = await db.user.findMany({
      include: {
        sessions: {
          orderBy: { loginAt: 'desc' },
          take: 10
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    // Format data
    const formattedUsers = users.map(user => ({
      id: user.id,
      username: user.username,
      token: user.token,
      permission: user.permission,
      isActive: user.isActive,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
      sessions: user.sessions.map(s => ({
        id: s.id,
        loginAt: s.loginAt,
        logoutAt: s.logoutAt,
        ipAddress: s.ipAddress,
        isOnline: !s.logoutAt
      }))
    }))

    return NextResponse.json({
      success: true,
      users: formattedUsers
    })
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data users' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const { sessionId, username, token, permission } = await req.json()

    if (!sessionId || !username || !token || !permission) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permissions
    const creatorPerm = session.user.permission

    // Supervisor dan MASTER bisa create user
    if (creatorPerm !== 'SUPERVISOR' && creatorPerm !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah user' },
        { status: 403 }
      )
    }

    // Supervisor tidak bisa create user dengan permission MASTER
    if (creatorPerm === 'SUPERVISOR' && permission === 'MASTER') {
      return NextResponse.json(
        { error: 'Supervisor tidak bisa membuat user dengan permission MASTER' },
        { status: 403 }
      )
    }

    // Cek apakah username sudah ada
    const existingUser = await db.user.findUnique({
      where: { username }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username sudah digunakan' },
        { status: 400 }
      )
    }

    // Create user baru
    const user = await db.user.create({
      data: {
        username,
        token,
        permission,
        isActive: true
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        token: user.token,
        permission: user.permission,
        isActive: user.isActive,
        createdAt: user.createdAt
      },
      message: 'User berhasil dibuat'
    })
  } catch (error) {
    console.error('Create user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat user' },
      { status: 500 }
    )
  }
}

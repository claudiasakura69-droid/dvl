import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Get user by ID
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const user = await db.user.findUnique({
      where: { id },
      include: {
        sessions: {
          orderBy: { loginAt: 'desc' },
          take: 10
        }
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        token: user.token,
        permission: user.permission,
        isActive: user.isActive,
        createdAt: user.createdAt,
        sessions: user.sessions.map(s => ({
          id: s.id,
          loginAt: s.loginAt,
          logoutAt: s.logoutAt,
          ipAddress: s.ipAddress,
          isOnline: !s.logoutAt
        }))
      }
    })
  } catch (error) {
    console.error('Get user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data user' },
      { status: 500 }
    )
  }
}

// PUT - Update user
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, username, token, permission } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permissions
    const editorPerm = session.user.permission
    const targetUser = await db.user.findUnique({
      where: { id }
    })

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    // Supervisor hanya bisa edit permission
    if (editorPerm === 'SUPERVISOR') {
      if (username || token) {
        return NextResponse.json(
          { error: 'Supervisor hanya bisa mengubah permission' },
          { status: 403 }
        )
      }
      if (!permission) {
        return NextResponse.json(
          { error: 'Permission wajib diisi' },
          { status: 400 }
        )
      }

      // Supervisor tidak bisa mengubah ke MASTER
      if (permission === 'MASTER') {
        return NextResponse.json(
          { error: 'Supervisor tidak bisa mengubah permission ke MASTER' },
          { status: 403 }
        )
      }

      const updatedUser = await db.user.update({
        where: { id },
        data: { permission }
      })

      return NextResponse.json({
        success: true,
        user: updatedUser,
        message: 'Permission berhasil diupdate'
      })
    }

    // MASTER bisa edit semua
    if (editorPerm === 'MASTER') {
      const updateData: any = {}
      if (username) updateData.username = username
      if (token) updateData.token = token
      if (permission) updateData.permission = permission

      const updatedUser = await db.user.update({
        where: { id },
        data: updateData
      })

      // Jika username atau token diubah, invalidate semua sessions user tersebut
      if (username || token) {
        await db.userSession.updateMany({
          where: {
            userId: id,
            logoutAt: null
          },
          data: {
            logoutAt: new Date()
          }
        })
      }

      return NextResponse.json({
        success: true,
        user: updatedUser,
        message: 'User berhasil diupdate',
        sessionInvalidated: !!(username || token)
      })
    }

    return NextResponse.json(
      { error: 'Anda tidak memiliki izin untuk mengedit user' },
      { status: 403 }
    )
  } catch (error) {
    console.error('Update user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate user' },
      { status: 500 }
    )
  }
}

// DELETE - Delete user
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Hanya MASTER yang bisa delete user
    if (session.user.permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Hanya MASTER yang bisa menghapus user' },
        { status: 403 }
      )
    }

    // Cek apakah user yang akan dihapus adalah MASTER
    const targetUser = await db.user.findUnique({
      where: { id }
    })

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    if (targetUser.permission === 'MASTER') {
      return NextResponse.json(
        { error: 'Tidak bisa menghapus user MASTER' },
        { status: 403 }
      )
    }

    // Delete user (cascade akan menghapus sessions dan transactions)
    await db.user.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'User berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus user' },
      { status: 500 }
    )
  }
}

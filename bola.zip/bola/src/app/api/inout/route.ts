import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil semua InOut transactions
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Build where clause
    const where: any = {}
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) {
        where.createdAt.gte = new Date(startDate)
      }
      if (endDate) {
        where.createdAt.lte = new Date(endDate)
      }
    }

    const inOuts = await db.inOut.findMany({
      where,
      include: {
        fromBank: {
          select: {
            id: true,
            name: true
          }
        },
        toBank: {
          select: {
            id: true,
            name: true
          }
        },
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      inOuts
    })
  } catch (error) {
    console.error('Get inouts error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data InOut' },
      { status: 500 }
    )
  }
}

// POST - Buat InOut baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, fromBankId, toBankId, amount, notes, userId } = await req.json()

    if (!sessionId || !fromBankId || !toBankId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa create
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat InOut' },
        { status: 403 }
      )
    }

    if (fromBankId === toBankId) {
      return NextResponse.json(
        { error: 'Bank asal dan tujuan tidak boleh sama' },
        { status: 400 }
      )
    }

    // Cari kedua bank
    const fromBank = await db.bank.findUnique({
      where: { id: fromBankId }
    })

    const toBank = await db.bank.findUnique({
      where: { id: toBankId }
    })

    if (!fromBank || !toBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    const amountFloat = parseFloat(amount)

    // Buat InOut transaction
    const inOut = await db.inOut.create({
      data: {
        fromBankId,
        fromBankName: fromBank.name,
        toBankId,
        toBankName: toBank.name,
        amount: amountFloat,
        notes: notes || null,
        userId
      }
    })

    // Update balance kedua bank
    await db.bank.update({
      where: { id: fromBankId },
      data: { balance: fromBank.balance - amountFloat }
    })

    await db.bank.update({
      where: { id: toBankId },
      data: { balance: toBank.balance + amountFloat }
    })

    // Catat history untuk kedua bank
    await db.bankHistory.create({
      data: {
        bankId: fromBankId,
        eventType: 'UPDATED',
        oldBalance: fromBank.balance,
        newBalance: fromBank.balance - amountFloat,
        notes: `InOut: -${amountFloat} ke ${toBank.name} - ${toBank.accountName}`,
        userId
      }
    })

    await db.bankHistory.create({
      data: {
        bankId: toBankId,
        eventType: 'UPDATED',
        oldBalance: toBank.balance,
        newBalance: toBank.balance + amountFloat,
        notes: `InOut: +${amountFloat} dari ${fromBank.name} - ${fromBank.accountName}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      inOut
    })
  } catch (error) {
    console.error('Create inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat InOut' },
      { status: 500 }
    )
  }
}

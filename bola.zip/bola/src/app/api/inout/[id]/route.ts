import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update InOut transaction
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, fromBankId, toBankId, amount, notes } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa edit
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit InOut' },
        { status: 403 }
      )
    }

    // Ambil InOut yang ada
    const existingInOut = await db.inOut.findUnique({
      where: { id }
    })

    if (!existingInOut) {
      return NextResponse.json(
        { error: 'InOut tidak ditemukan' },
        { status: 404 }
      )
    }

    // Parse amount
    const newAmount = amount !== undefined ? parseFloat(amount) : existingInOut.amount

    // Cari bank yang terlibat
    const fromBank = await db.bank.findUnique({
      where: { id: fromBankId || existingInOut.fromBankId }
    })

    const toBank = await db.bank.findUnique({
      where: { id: toBankId || existingInOut.toBankId }
    })

    // Jika bank sudah dihapus, skip balance update
    const fromBankExists = fromBank !== null
    const toBankExists = toBank !== null

    // Kembalikan balance lama (reverse transaction)
    if (fromBankExists && existingInOut.fromBankId) {
      await db.bank.update({
        where: { id: existingInOut.fromBankId },
        data: { balance: fromBank.balance + existingInOut.amount }
      })
    }

    if (toBankExists && existingInOut.toBankId) {
      await db.bank.update({
        where: { id: existingInOut.toBankId },
        data: { balance: toBank.balance - existingInOut.amount }
      })
    }

    // Update InOut
    const updateData: any = {
      amount: newAmount,
      notes: notes !== undefined ? notes : existingInOut.notes
    }

    if (fromBankId !== undefined) {
      updateData.fromBankId = fromBankId
      updateData.fromBankName = fromBankExists ? fromBank.name : existingInOut.fromBankName
    }

    if (toBankId !== undefined) {
      updateData.toBankId = toBankId
      updateData.toBankName = toBankExists ? toBank.name : existingInOut.toBankName
    }

    const inOut = await db.inOut.update({
      where: { id },
      data: updateData
    })

    // Terapkan balance baru
    if (fromBankExists && inOut.fromBankId) {
      const updatedFromBank = await db.bank.findUnique({
        where: { id: inOut.fromBankId }
      })

      if (updatedFromBank) {
        await db.bank.update({
          where: { id: inOut.fromBankId },
          data: { balance: updatedFromBank.balance - newAmount }
        })

        await db.bankHistory.create({
          data: {
            bankId: inOut.fromBankId,
            eventType: 'UPDATED',
            oldBalance: updatedFromBank.balance,
            newBalance: updatedFromBank.balance - newAmount,
            notes: `InOut update: -${newAmount} ke ${inOut.toBankName}`,
            userId: session.user.id
          }
        })
      }
    }

    if (toBankExists && inOut.toBankId) {
      const updatedToBank = await db.bank.findUnique({
        where: { id: inOut.toBankId }
      })

      if (updatedToBank) {
        await db.bank.update({
          where: { id: inOut.toBankId },
          data: { balance: updatedToBank.balance + newAmount }
        })

        await db.bankHistory.create({
          data: {
            bankId: inOut.toBankId,
            eventType: 'UPDATED',
            oldBalance: updatedToBank.balance,
            newBalance: updatedToBank.balance + newAmount,
            notes: `InOut update: +${newAmount} dari ${inOut.fromBankName}`,
            userId: session.user.id
          }
        })
      }
    }

    return NextResponse.json({
      success: true,
      inOut
    })
  } catch (error) {
    console.error('Update inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate InOut' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus InOut transaction
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER bisa delete
    const permission = session.user.permission
    if (permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus InOut' },
        { status: 403 }
      )
    }

    // Ambil InOut yang ada
    const existingInOut = await db.inOut.findUnique({
      where: { id }
    })

    if (!existingInOut) {
      return NextResponse.json(
        { error: 'InOut tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cari bank yang terlibat (jika masih ada)
    const fromBank = await db.bank.findUnique({
      where: { id: existingInOut.fromBankId || '' }
    }).catch(() => null)

    const toBank = await db.bank.findUnique({
      where: { id: existingInOut.toBankId || '' }
    }).catch(() => null)

    // Kembalikan balance (reverse transaction)
    if (fromBank && existingInOut.fromBankId) {
      await db.bank.update({
        where: { id: existingInOut.fromBankId },
        data: { balance: fromBank.balance + existingInOut.amount }
      })

      await db.bankHistory.create({
        data: {
          bankId: existingInOut.fromBankId,
          eventType: 'UPDATED',
          oldBalance: fromBank.balance,
          newBalance: fromBank.balance + existingInOut.amount,
          notes: `InOut delete: +${existingInOut.amount} (reverse dari ${existingInOut.toBankName})`,
          userId: session.user.id
        }
      })
    }

    if (toBank && existingInOut.toBankId) {
      await db.bank.update({
        where: { id: existingInOut.toBankId },
        data: { balance: toBank.balance - existingInOut.amount }
      })

      await db.bankHistory.create({
        data: {
          bankId: existingInOut.toBankId,
          eventType: 'UPDATED',
          oldBalance: toBank.balance,
          newBalance: toBank.balance - existingInOut.amount,
          notes: `InOut delete: -${existingInOut.amount} (reverse dari ${existingInOut.fromBankName})`,
          userId: session.user.id
        }
      })
    }

    // Hapus InOut
    await db.inOut.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'InOut berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus InOut' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil data kalender (tanggal yang ada transaksi)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const year = searchParams.get('year')

    if (!sessionId || !year) {
      return NextResponse.json(
        { error: 'Session ID dan tahun wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tahun
    const yearNum = parseInt(year)
    const startDate = new Date(yearNum, 0, 1)
    const endDate = new Date(yearNum, 11, 31, 23, 59, 59)

    // Ambil semua transaksi di tahun tersebut
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        createdAt: true
      }
    })

    const inOuts = await db.inOut.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        createdAt: true
      }
    })

    const expenses = await db.expense.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        createdAt: true
      }
    })

    const mistakes = await db.mistake.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        createdAt: true
      }
    })

    const akurans = await db.akuran.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      select: {
        createdAt: true
      }
    })

    // Gabungkan semua tanggal
    const allDates = [
      ...dailyTransactions,
      ...inOuts,
      ...expenses,
      ...mistakes,
      ...akurans
    ].map(tx => new Date(tx.createdAt).toDateString())

    // Hapus duplikat
    const uniqueDates = [...new Set(allDates)]

    return NextResponse.json({
      success: true,
      dates: uniqueDates
    })
  } catch (error) {
    console.error('Get calendar data error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data kalender' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus data berdasarkan range tanggal
export async function DELETE(req: NextRequest) {
  try {
    const { sessionId, startDate, endDate, confirm } = await req.json()

    if (!sessionId || !startDate || !endDate) {
      return NextResponse.json(
        { error: 'Session ID, start date, dan end date wajib diisi' },
        { status: 400 }
      )
    }

    // Validasi konfirmasi
    if (confirm !== 'YES_DELETE_ALL_DATA') {
      return NextResponse.json(
        { error: 'Konfirmasi tidak valid. Gunakan "YES_DELETE_ALL_DATA"' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER yang bisa delete data
    if (session.user.permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus data' },
        { status: 403 }
      )
    }

    // Parse tanggal
    const start = new Date(startDate)
    const end = new Date(endDate)
    end.setHours(23, 59, 59)

    // Hapus data dalam range tanggal
    // 1. DailyTransaction (balance sudah di-adjust saat delete via [id]/route.ts)
    const deletedDailyTransactions = await db.dailyTransaction.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // 2. InOut (balance sudah di-adjust saat delete via [id]/route.ts)
    const deletedInOuts = await db.inOut.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // 3. Expense (balance sudah di-adjust saat delete via [id]/route.ts)
    const deletedExpenses = await db.expense.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // 4. Mistake (balance sudah di-adjust saat delete via [id]/route.ts)
    const deletedMistakes = await db.mistake.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    // 5. Akuran (balance sudah di-adjust saat delete via [id]/route.ts)
    const deletedAkurans = await db.akuran.deleteMany({
      where: {
        createdAt: {
          gte: start,
          lte: end
        }
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Data berhasil dihapus',
      deleted: {
        dailyTransactions: deletedDailyTransactions.count,
        inOuts: deletedInOuts.count,
        expenses: deletedExpenses.count,
        mistakes: deletedMistakes.count,
        akurans: deletedAkurans.count
      }
    })
  } catch (error) {
    console.error('Delete data error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus data' },
      { status: 500 }
    )
  }
}

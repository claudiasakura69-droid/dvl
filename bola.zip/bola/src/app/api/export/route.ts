import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import * as XLSX from 'xlsx'

// GET - Export data ke Excel
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const type = searchParams.get('type') || 'transactions'
    const year = parseInt(searchParams.get('year') || new Date().getFullYear().toString())
    const month = searchParams.get('month')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Build workbook
    const workbook = XLSX.utils.book_new()

    if (type === 'monthly-report') {
      // Build date range
      let startDate: Date
      let endDate: Date

      if (month) {
        startDate = new Date(year, parseInt(month) - 1, 1)
        endDate = new Date(year, parseInt(month), 0)
      } else {
        startDate = new Date(year, 0, 1)
        endDate = new Date(year + 1, 0, 1)
      }

      // Fetch all data for period
      const [dailyTx, inOuts, expenses, mistakes, akurans] = await Promise.all([
        db.dailyTransaction.findMany({
          where: {
            date: {
              gte: startDate,
              lt: endDate
            }
          },
          include: { bank: true, user: true }
        }),
        db.inOut.findMany({
          where: {
            createdAt: {
              gte: startDate,
              lt: endDate
            }
          },
          include: { fromBank: true, toBank: true, user: true }
        }),
        db.expense.findMany({
          where: {
            createdAt: {
              gte: startDate,
              lt: endDate
            }
          },
          include: { user: true }
        }),
        db.mistake.findMany({
          where: {
            createdAt: {
              gte: startDate,
              lt: endDate
            }
          },
          include: { user: true }
        }),
        db.akuran.findMany({
          where: {
            createdAt: {
              gte: startDate,
              lt: endDate
            }
          },
          include: { user: true }
        })
      ])

      // Create summary sheet
      const summaryData = [
        ['Kategori', 'Jumlah', 'Total']
      ]

      const totalDeposits = dailyTx.filter(t => t.type === 'DEPOSIT').reduce((sum, t) => sum + t.amount, 0)
      const totalWithdraws = dailyTx.filter(t => t.type === 'WITHDRAW').reduce((sum, t) => sum + t.amount, 0)
      const totalInOut = inOuts.reduce((sum, t) => sum + t.amount, 0)
      const totalExpenses = expenses.reduce((sum, t) => sum + t.amount, 0)
      const totalMistakes = mistakes.reduce((sum, t) => sum + t.amount, 0)
      const totalAkurans = akurans.reduce((sum, t) => sum + t.amount, 0)
      const totalAmount = totalDeposits - totalWithdraws + totalInOut - totalExpenses - totalMistakes + totalAkurans

      summaryData.push(['Deposit', dailyTx.filter(t => t.type === 'DEPOSIT').length, totalDeposits])
      summaryData.push(['Withdraw', dailyTx.filter(t => t.type === 'WITHDRAW').length, totalWithdraws])
      summaryData.push(['In/Out', inOuts.length, totalInOut])
      summaryData.push(['Expenses', expenses.length, totalExpenses])
      summaryData.push(['Mistakes', mistakes.length, totalMistakes])
      summaryData.push(['Akurans', akurans.length, totalAkurans])
      summaryData.push(['SALDO AKHIR', '', totalAmount])

      const summarySheet = XLSX.utils.aoa_to_sheet(summaryData)
      XLSX.utils.book_append_sheet(workbook, summarySheet, 'Ringkasan')

      // Create transactions sheet
      const txData: any[] = [['Tanggal', 'Tipe', 'Bank', 'Nomor Rek', 'Nama', 'Jumlah', 'User']]
      
      dailyTx.forEach((t) => {
        txData.push([
          t.date.toLocaleDateString('id-ID'),
          t.type,
          `${t.bank.name} - ${t.bank.accountName}`,
          t.accountNumber || '-',
          t.name,
          t.amount,
          t.user.username
        ])
      })

      inOuts.forEach((t) => {
        txData.push([
          t.createdAt.toLocaleDateString('id-ID'),
          'IN/OUT',
          `${t.fromBank.name} → ${t.toBank.name}`,
          '-',
          '-',
          t.amount,
          t.user.username
        ])
      })

      expenses.forEach((t) => {
        txData.push([
          t.createdAt.toLocaleDateString('id-ID'),
          'EXPENSE',
          '-',
          '-',
          '-',
          t.amount,
          t.user.username
        ])
      })

      mistakes.forEach((t) => {
        txData.push([
          t.createdAt.toLocaleDateString('id-ID'),
          'MISTAKE',
          '-',
          '-',
          '-',
          t.amount,
          t.user.username
        ])
      })

      akurans.forEach((t) => {
        txData.push([
          t.createdAt.toLocaleDateString('id-ID'),
          'AKURAN',
          t.category || '-',
          '-',
          '-',
          t.amount,
          t.user.username
        ])
      })

      const txSheet = XLSX.utils.aoa_to_sheet(txData)
      XLSX.utils.book_append_sheet(workbook, txSheet, 'Detail Transaksi')

      const filename = month
        ? `Laporan_${year}_${month}.xlsx`
        : `Laporan_${year}.xlsx`

      // Generate buffer
      const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })

      // Return as file
      return new NextResponse(buffer as Buffer, {
        status: 200,
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="${filename}"`
        }
      })
    } else {
      // Original transaction export (detailed)
      const startDate = new Date()
      const endDate = new Date(startDate)
      startDate.setMonth(startDate.getMonth() - 1)
      endDate.setDate(endDate.getDate() + 1)

      const dates: Date[] = []
      const currentDate = new Date(startDate)
      while (currentDate <= endDate) {
        dates.push(new Date(currentDate))
        currentDate.setDate(currentDate.getDate() + 1)
      }

      // Export untuk setiap tanggal
      for (const date of dates) {
        const dayStart = new Date(date)
        dayStart.setHours(0, 0, 0, 0)
        const dayEnd = new Date(date)
        dayEnd.setHours(23, 59, 59, 999)

        const dateStr = date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' })

        // Ambil data untuk tanggal ini
        const dailyTransactions = await db.dailyTransaction.findMany({
          where: {
            date: {
              gte: dayStart,
              lte: dayEnd
            }
          },
          include: {
            bank: true,
            user: true
          },
          orderBy: { date: 'desc' }
        })

        const inOuts = await db.inOut.findMany({
          where: {
            createdAt: {
              gte: dayStart,
              lte: dayEnd
            }
          },
          include: {
            fromBank: true,
            toBank: true,
            user: true
          }
        })

        const expenses = await db.expense.findMany({
          where: {
            createdAt: {
              gte: dayStart,
              lte: dayEnd
            }
          },
          include: {
            user: true
          }
        })

        const mistakes = await db.mistake.findMany({
          where: {
            createdAt: {
              gte: dayStart,
              lte: dayEnd
            }
          },
          include: {
            user: true
          }
        })

        // Buat sheet untuk tanggal ini
        const sheetData: any[] = []
        sheetData.push(['DAILY TRANSACTIONS - ' + dateStr, '', '', '', '', '', ''])
        sheetData.push([])

        // Deposit
        const deposits = dailyTransactions.filter((t: any) => t.type === 'DEPOSIT')
        if (deposits.length > 0) {
          sheetData.push(['DEPOSIT'])
          sheetData.push(['Date', 'Time', 'Name', 'Account Number', 'Bank', 'Amount', 'User'])
          deposits.forEach((t: any) => {
            sheetData.push([
              t.date.toLocaleDateString('id-ID'),
              t.date.toLocaleTimeString('id-ID'),
              t.name,
              t.accountNumber || '-',
              `${t.bank.name} - ${t.bank.accountName}`,
              t.amount,
              t.user.username
            ])
          })
          sheetData.push([])
        }

        // Withdraw
        const withdraws = dailyTransactions.filter((t: any) => t.type === 'WITHDRAW')
        if (withdraws.length > 0) {
          sheetData.push(['WITHDRAW'])
          sheetData.push(['Date', 'Time', 'Name', 'Account Number', 'Bank', 'Amount', 'User'])
          withdraws.forEach((t: any) => {
            sheetData.push([
              t.date.toLocaleDateString('id-ID'),
              t.date.toLocaleTimeString('id-ID'),
              t.name,
              t.accountNumber || '-',
              `${t.bank.name} - ${t.bank.accountName}`,
              t.amount,
              t.user.username
            ])
          })
          sheetData.push([])
        }

        // InOut
        if (inOuts.length > 0) {
          sheetData.push(['IN / OUT'])
          sheetData.push(['Date', 'Time', 'From Bank', 'To Bank', 'Amount', 'Notes', 'User'])
          inOuts.forEach((t: any) => {
            sheetData.push([
              t.createdAt.toLocaleDateString('id-ID'),
              t.createdAt.toLocaleTimeString('id-ID'),
              `${t.fromBank.name} - ${t.fromBank.accountName}`,
              `${t.toBank.name} - ${t.toBank.accountName}`,
              t.amount,
              t.notes || '-',
              t.user.username
            ])
          })
          sheetData.push([])
        }

        // Expenses
        if (expenses.length > 0) {
          sheetData.push(['EXPENSES'])
          sheetData.push(['Date', 'Time', 'Category', 'Amount', 'Notes', 'User'])
          expenses.forEach((t: any) => {
            sheetData.push([
              t.createdAt.toLocaleDateString('id-ID'),
              t.createdAt.toLocaleTimeString('id-ID'),
              t.category || '-',
              t.amount,
              t.notes || '-',
              t.user.username
            ])
          })
          sheetData.push([])
        }

        // Mistakes
        if (mistakes.length > 0) {
          sheetData.push(['MISTAKES'])
          sheetData.push(['Date', 'Time', 'Bank', 'Amount', 'Notes', 'User'])
          mistakes.forEach((t: any) => {
            sheetData.push([
              t.createdAt.toLocaleDateString('id-ID'),
              t.createdAt.toLocaleTimeString('id-ID'),
              t.bankId ? '-' : '-',
              t.amount,
              t.notes || '-',
              t.user.username
            ])
          })
        }

        // Buat worksheet
        const worksheet = XLSX.utils.aoa_to_sheet(sheetData)
        worksheet['!cols'] = [
          { wch: 12 },
          { wch: 10 },
          { wch: 20 },
          { wch: 15 },
          { wch: 25 },
          { wch: 15 }
        ]

        // Add sheet to workbook
        XLSX.utils.book_append_sheet(workbook, worksheet, dateStr.replace(/\//g, '-'))
      }

      const filename = `transactions_${Date.now()}.xlsx`

      // Generate buffer
      const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })

      // Return as file
      return new NextResponse(buffer as Buffer, {
        status: 200,
        headers: {
          'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'Content-Disposition': `attachment; filename="${filename}"`
        }
      })
    }
  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat export data' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update Expense transaction
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, amount, operation, bankId, bankName, notes, category } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa edit
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit expense' },
        { status: 403 }
      )
    }

    // Ambil expense yang ada
    const existingExpense = await db.expense.findUnique({
      where: { id }
    })

    if (!existingExpense) {
      return NextResponse.json(
        { error: 'Expense tidak ditemukan' },
        { status: 404 }
      )
    }

    const newAmount = amount !== undefined ? parseFloat(amount) : existingExpense.amount
    const newOperation = operation !== undefined ? operation : existingExpense.operation
    const newBankId = bankId !== undefined ? bankId : existingExpense.bankId

    // Jika ada perubahan amount atau operation, adjust balance bank
    if (newAmount !== existingExpense.amount || newOperation !== existingExpense.operation) {
      // Reverse transaksi lama
      if (existingExpense.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: existingExpense.bankId }
        }).catch(() => null)

        if (bank) {
          const reverseBalance = existingExpense.operation === 'increase'
            ? bank.balance - existingExpense.amount
            : bank.balance + existingExpense.amount

          await db.bank.update({
            where: { id: existingExpense.bankId },
            data: { balance: reverseBalance }
          })
        }
      }

      // Terapkan transaksi baru (jika bankId masih sama)
      if (newBankId && newBankId === existingExpense.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: newBankId }
        }).catch(() => null)

        if (bank) {
          const newBalance = newOperation === 'increase'
            ? bank.balance + newAmount
            : bank.balance - newAmount

          await db.bank.update({
            where: { id: newBankId },
            data: { balance: newBalance }
          })

          await db.bankHistory.create({
            data: {
              bankId: newBankId,
              eventType: 'UPDATED',
              oldBalance: bank.balance,
              newBalance: newBalance,
              notes: `Expense update: ${newOperation === 'increase' ? '+' : '-'}${newAmount} - ${notes || category || ''}`,
              userId: session.user.id
            }
          })
        }
      }
    }

    // Update expense data
    const updateData: any = {}
    if (amount !== undefined) updateData.amount = newAmount
    if (operation !== undefined) updateData.operation = newOperation
    if (notes !== undefined) updateData.notes = notes
    if (category !== undefined) updateData.category = category

    if (bankId !== undefined) {
      updateData.bankId = newBankId
      const newBank = newBankId ? await db.bank.findUnique({
        where: { id: newBankId }
      }).catch(() => null) : null
      updateData.bankName = newBank ? newBank.name : bankName
    }

    const expense = await db.expense.update({
      where: { id },
      data: updateData
    })

    return NextResponse.json({
      success: true,
      expense
    })
  } catch (error) {
    console.error('Update expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate expense' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus Expense transaction
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER bisa delete
    const permission = session.user.permission
    if (permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus expense' },
        { status: 403 }
      )
    }

    // Ambil expense yang ada
    const existingExpense = await db.expense.findUnique({
      where: { id }
    })

    if (!existingExpense) {
      return NextResponse.json(
        { error: 'Expense tidak ditemukan' },
        { status: 404 }
      )
    }

    // Kembalikan balance bank (reverse transaction)
    if (existingExpense.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: existingExpense.bankId }
      }).catch(() => null)

      if (bank) {
        const reverseBalance = existingExpense.operation === 'increase'
          ? bank.balance - existingExpense.amount
          : bank.balance + existingExpense.amount

        await db.bank.update({
          where: { id: existingExpense.bankId },
          data: { balance: reverseBalance }
        })

        await db.bankHistory.create({
          data: {
            bankId: existingExpense.bankId,
            eventType: 'UPDATED',
            oldBalance: bank.balance,
            newBalance: reverseBalance,
            notes: `Expense delete: ${existingExpense.operation === 'increase' ? '-' : '+'}${existingExpense.amount} (reverse)`,
            userId: session.user.id
          }
        })
      }
    }

    // Hapus expense
    await db.expense.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Expense berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus expense' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const year = parseInt(searchParams.get('year') || new Date().getFullYear().toString())
    const month = searchParams.get('month')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Build date filters
    let startDate: Date
    let endDate: Date

    if (month) {
      startDate = new Date(year, parseInt(month) - 1, 1)
      endDate = new Date(year, parseInt(month), 0)
    } else {
      startDate = new Date(year, 0, 1)
      endDate = new Date(year + 1, 0, 1)
    }

    // Fetch transactions for the period
    const [dailyTx, inOuts, expenses, mistakes, akurans] = await Promise.all([
      db.dailyTransaction.findMany({
        where: {
          date: {
            gte: startDate,
            lt: endDate
          }
        }
      }),
      db.inOut.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lt: endDate
          }
        }
      }),
      db.expense.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lt: endDate
          }
        }
      }),
      db.mistake.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lt: endDate
          }
        }
      }),
      db.akuran.findMany({
        where: {
          createdAt: {
            gte: startDate,
            lt: endDate
          }
        }
      })
    ])

    // Group by month
    const reportData: any = {}

    // Process daily transactions
    dailyTx.forEach((tx) => {
      const txDate = new Date(tx.date)
      const monthKey = `${txDate.getFullYear()}-${txDate.getMonth() + 1}`
      
      if (!reportData[monthKey]) {
        reportData[monthKey] = {
          month: (txDate.getMonth() + 1).toString(),
          year: txDate.getFullYear(),
          totalTransactions: 0,
          totalDeposits: 0,
          totalWithdraws: 0,
          totalAmount: 0,
          totalExpenses: 0,
          totalInOut: 0,
          totalMistakes: 0,
          totalAkurans: 0
        }
      }

      reportData[monthKey].totalTransactions++
      if (tx.type === 'DEPOSIT') {
        reportData[monthKey].totalDeposits += tx.amount
        reportData[monthKey].totalAmount += tx.amount
      } else {
        reportData[monthKey].totalWithdraws += tx.amount
      }
    })

    // Process in/out
    inOuts.forEach((inout) => {
      const txDate = new Date(inout.createdAt)
      const monthKey = `${txDate.getFullYear()}-${txDate.getMonth() + 1}`
      
      if (!reportData[monthKey]) {
        reportData[monthKey] = {
          month: (txDate.getMonth() + 1).toString(),
          year: txDate.getFullYear(),
          totalTransactions: 0,
          totalDeposits: 0,
          totalWithdraws: 0,
          totalAmount: 0,
          totalExpenses: 0,
          totalInOut: 0,
          totalMistakes: 0,
          totalAkurans: 0
        }
      }

      reportData[monthKey].totalInOut += inout.amount
    })

    // Process expenses
    expenses.forEach((expense) => {
      const txDate = new Date(expense.createdAt)
      const monthKey = `${txDate.getFullYear()}-${txDate.getMonth() + 1}`
      
      if (!reportData[monthKey]) {
        reportData[monthKey] = {
          month: (txDate.getMonth() + 1).toString(),
          year: txDate.getFullYear(),
          totalTransactions: 0,
          totalDeposits: 0,
          totalWithdraws: 0,
          totalAmount: 0,
          totalExpenses: 0,
          totalInOut: 0,
          totalMistakes: 0,
          totalAkurans: 0
        }
      }

      reportData[monthKey].totalExpenses += expense.amount
      reportData[monthKey].totalAmount -= expense.amount
    })

    // Process mistakes
    mistakes.forEach((mistake) => {
      const txDate = new Date(mistake.createdAt)
      const monthKey = `${txDate.getFullYear()}-${txDate.getMonth() + 1}`
      
      if (!reportData[monthKey]) {
        reportData[monthKey] = {
          month: (txDate.getMonth() + 1).toString(),
          year: txDate.getFullYear(),
          totalTransactions: 0,
          totalDeposits: 0,
          totalWithdraws: 0,
          totalAmount: 0,
          totalExpenses: 0,
          totalInOut: 0,
          totalMistakes: 0,
          totalAkurans: 0
        }
      }

      reportData[monthKey].totalMistakes += mistake.amount
      reportData[monthKey].totalAmount -= mistake.amount
    })

    // Process akurans
    akurans.forEach((akuran) => {
      const txDate = new Date(akuran.createdAt)
      const monthKey = `${txDate.getFullYear()}-${txDate.getMonth() + 1}`
      
      if (!reportData[monthKey]) {
        reportData[monthKey] = {
          month: (txDate.getMonth() + 1).toString(),
          year: txDate.getFullYear(),
          totalTransactions: 0,
          totalDeposits: 0,
          totalWithdraws: 0,
          totalAmount: 0,
          totalExpenses: 0,
          totalInOut: 0,
          totalMistakes: 0,
          totalAkurans: 0
        }
      }

      reportData[monthKey].totalAkurans += akuran.amount
      reportData[monthKey].totalAmount += akuran.amount
    })

    const reports = Object.values(reportData).sort((a: any, b: any) => {
      if (a.year !== b.year) return b.year - a.year
      return parseInt(b.month) - parseInt(a.month)
    })

    return NextResponse.json({
      success: true,
      reports
    })
  } catch (error) {
    console.error('Get reports error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data laporan' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update daily transaction
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, date, name, accountNumber, amount, type, bankId } = await req.json()
    const transactionId = params.id

    if (!sessionId || !transactionId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission - hanya SUPPORT dan MASTER yang bisa edit
    const userPermission = session.user.permission
    if (!['MASTER', 'SUPPORT'].includes(userPermission)) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit transaksi ini' },
        { status: 403 }
      )
    }

    // Cari transaksi yang akan diupdate
    const existingTransaction = await db.dailyTransaction.findUnique({
      where: { id: transactionId },
      include: { bank: true }
    })

    if (!existingTransaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Validasi tipe
    if (type && !['DEPOSIT', 'WITHDRAW'].includes(type)) {
      return NextResponse.json(
        { error: 'Type tidak valid' },
        { status: 400 }
      )
    }

    // Parse data
    const newDate = date ? new Date(date) : existingTransaction.date
    const newAmount = amount ? parseFloat(amount) : existingTransaction.amount
    const newType = type || existingTransaction.type
    const newBankId = bankId || existingTransaction.bankId

    // Revert balance dari transaksi lama
    const oldBalanceChange = existingTransaction.type === 'DEPOSIT'
      ? existingTransaction.amount
      : -existingTransaction.amount

    await db.bank.update({
      where: { id: existingTransaction.bankId },
      data: { balance: existingTransaction.bank.balance - oldBalanceChange }
    })

    // Update bank balance dengan data baru
    if (newBankId !== existingTransaction.bankId && existingTransaction.bank) {
      // Jika bank berubah, update bank lama dan baru
      const newBank = await db.bank.findUnique({
        where: { id: newBankId }
      })

      if (!newBank) {
        return NextResponse.json(
          { error: 'Bank tujuan tidak ditemukan' },
          { status: 404 }
        )
      }

      const newBalanceChange = newType === 'DEPOSIT'
        ? newAmount
        : -newAmount

      await db.bank.update({
        where: { id: newBankId },
        data: { balance: newBank.balance + newBalanceChange }
      })
    } else if (existingTransaction.bank) {
      // Jika bank sama, update bank tersebut
      const newBalanceChange = newType === 'DEPOSIT'
        ? newAmount
        : -newAmount

      await db.bank.update({
        where: { id: existingTransaction.bankId },
        data: { balance: existingTransaction.bank.balance + newBalanceChange }
      })
    }

    // Update transaksi
    const updatedTransaction = await db.dailyTransaction.update({
      where: { id: transactionId },
      data: {
        date: newDate,
        name: name || existingTransaction.name,
        accountNumber: accountNumber !== undefined ? accountNumber : existingTransaction.accountNumber,
        amount: newAmount,
        type: newType,
        bankId: newBankId
      },
      include: {
        bank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      transaction: updatedTransaction
    })
  } catch (error) {
    console.error('Update daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate transaksi' },
      { status: 500 }
    )
  }
}

// DELETE - Delete daily transaction
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const transactionId = params.id

    if (!sessionId || !transactionId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cek permission - hanya MASTER yang bisa delete
    const userPermission = session.user.permission
    if (userPermission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus transaksi ini' },
        { status: 403 }
      )
    }

    // Cari transaksi yang akan dihapus
    const transaction = await db.dailyTransaction.findUnique({
      where: { id: transactionId },
      include: { bank: true }
    })

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Revert balance bank
    if (transaction.bank) {
      const balanceChange = transaction.type === 'DEPOSIT'
        ? -transaction.amount
        : transaction.amount

      await db.bank.update({
        where: { id: transaction.bankId },
        data: { balance: transaction.bank.balance + balanceChange }
      })
    }

    // Hapus transaksi
    await db.dailyTransaction.delete({
      where: { id: transactionId }
    })

    return NextResponse.json({
      success: true,
      message: 'Transaksi berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus transaksi' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil transaksi harian berdasarkan tanggal
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const dateStr = searchParams.get('date')
    const type = searchParams.get('type') // 'DEPOSIT' atau 'WITHDRAW' atau undefined untuk semua

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tanggal
    let startDate: Date
    let endDate: Date

    if (dateStr) {
      const date = new Date(dateStr)
      startDate = new Date(date.setHours(0, 0, 0, 0))
      endDate = new Date(date.setHours(23, 59, 59, 999))
    } else {
      // Default hari ini
      const today = new Date()
      startDate = new Date(today.setHours(0, 0, 0, 0))
      endDate = new Date(today.setHours(23, 59, 59, 999))
    }

    // Build query
    const where: any = {
      date: {
        gte: startDate,
        lte: endDate
      }
    }

    if (type) {
      where.type = type
    }

    // Ambil transaksi harian
    const transactions = await db.dailyTransaction.findMany({
      where,
      include: {
        bank: true,
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { date: 'desc' }
    })

    return NextResponse.json({
      success: true,
      transactions
    })
  } catch (error) {
    console.error('Get daily transactions error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data transaksi harian' },
      { status: 500 }
    )
  }
}

// POST - Buat transaksi baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, date, name, accountNumber, amount, type, bankId, userId } = await req.json()

    if (!sessionId || !date || !name || !amount || !type || !bankId || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    if (!['DEPOSIT', 'WITHDRAW'].includes(type)) {
      return NextResponse.json(
        { error: 'Type tidak valid' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cari bank yang akan menerima transaksi
    const bank = await db.bank.findUnique({
      where: { id: bankId }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Parse tanggal
    const transactionDate = new Date(date)

    // Buat transaksi
    const transaction = await db.dailyTransaction.create({
      data: {
        date: transactionDate,
        name,
        accountNumber: accountNumber || null,
        amount: parseFloat(amount),
        type,
        bankId,
        userId
      }
    })

    // Update balance bank
    const newBalance = type === 'DEPOSIT'
      ? bank.balance + parseFloat(amount)
      : bank.balance - parseFloat(amount)

    await db.bank.update({
      where: { id: bankId },
      data: { balance: newBalance }
    })

    return NextResponse.json({
      success: true,
      transaction,
      newBalance
    })
  } catch (error) {
    console.error('Create daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat transaksi' },
      { status: 500 }
    )
  }
}

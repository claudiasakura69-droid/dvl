import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const { username, token } = await req.json()

    if (!username || !token) {
      return NextResponse.json(
        { error: 'Username dan token wajib diisi' },
        { status: 400 }
      )
    }

    // Cari user berdasarkan username dan token
    const user = await db.user.findUnique({
      where: {
        username,
        token
      }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Username atau token tidak valid' },
        { status: 401 }
      )
    }

    if (!user.isActive) {
      return NextResponse.json(
        { error: 'User tidak aktif' },
        { status: 401 }
      )
    }

    // Buat session baru
    const session = await db.userSession.create({
      data: {
        userId: user.id,
        ipAddress: req.headers.get('x-forwarded-for') || 'unknown'
      }
    })

    // Update user dengan session
    const updatedUser = await db.user.findUnique({
      where: { id: user.id },
      include: {
        sessions: {
          orderBy: { loginAt: 'desc' }
        }
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: updatedUser?.id,
        username: updatedUser?.username,
        permission: updatedUser?.permission
      },
      sessionId: session.id
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat login' },
      { status: 500 }
    )
  }
}

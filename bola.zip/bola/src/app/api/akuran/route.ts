import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil semua akurans
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = 50
    const offset = (page - 1) * limit
    const search = searchParams.get('search') || ''
    const type = searchParams.get('type') || ''

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Build where clause
    const where: any = {}
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) {
        where.createdAt.gte = new Date(startDate)
      }
      if (endDate) {
        where.createdAt.lte = new Date(endDate)
      }
    }
    if (search) {
      where.OR = [
        { notes: { contains: search } },
        { category: { contains: search } }
      ]
    }
    if (type) {
      where.category = type
    }

    // Ambil akurans dengan pagination
    const [akurans, total] = await Promise.all([
      db.akuran.findMany({
        where,
        include: {
          bank: {
            select: {
              id: true,
              name: true
            }
          },
          user: {
            select: {
              id: true,
              username: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      db.akuran.count({ where })
    ])

    return NextResponse.json({
      success: true,
      akurans,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Get akurans error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data akurans' },
      { status: 500 }
    )
  }
}

// POST - Buat akuran baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, category, bankId, bankName, userId } = await req.json()

    if (!sessionId || amount === undefined) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa tambah akuran
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah akuran' },
        { status: 403 }
      )
    }

    // Cari bank jika bankId disertakan
    let bank = null
    if (bankId) {
      bank = await db.bank.findUnique({
        where: { id: bankId }
      })

      if (!bank) {
        return NextResponse.json(
          { error: 'Bank tidak ditemukan' },
          { status: 404 }
        )
      }

      // Update balance bank (kurangi)
      await db.bank.update({
        where: { id: bankId },
        data: { balance: bank.balance - parseFloat(amount) }
      })

      // Catat history
      await db.bankHistory.create({
        data: {
          bankId: bankId,
          eventType: 'UPDATED',
          oldBalance: bank.balance,
          newBalance: bank.balance - parseFloat(amount),
          notes: `Akuran: -${amount} - ${notes || category || ''}`,
          userId: session.user.id
        }
      })
    }

    // Buat akuran baru
    const akuran = await db.akuran.create({
      data: {
        amount: parseFloat(amount),
        notes,
        category,
        bankId: bankId || null,
        bankName: bank ? bank.name : (bankName || null),
        userId: session.user.id
      }
    })

    return NextResponse.json({
      success: true,
      akuran
    })
  } catch (error) {
    console.error('Create akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat akuran' },
      { status: 500 }
    )
  }
}

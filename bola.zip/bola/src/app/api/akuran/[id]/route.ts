import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update akuran
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, amount, notes, category, bankId, bankName } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa edit
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit akuran' },
        { status: 403 }
      )
    }

    // Ambil akuran yang ada
    const existingAkuran = await db.akuran.findUnique({
      where: { id }
    })

    if (!existingAkuran) {
      return NextResponse.json(
        { error: 'Akuran tidak ditemukan' },
        { status: 404 }
      )
    }

    const newAmount = amount !== undefined ? parseFloat(amount) : existingAkuran.amount
    const newBankId = bankId !== undefined ? bankId : existingAkuran.bankId

    // Jika ada perubahan amount, adjust balance bank
    if (newAmount !== existingAkuran.amount) {
      // Reverse transaksi lama
      if (existingAkuran.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: existingAkuran.bankId }
        }).catch(() => null)

        if (bank) {
          await db.bank.update({
            where: { id: existingAkuran.bankId },
            data: { balance: bank.balance + existingAkuran.amount }
          })
        }
      }

      // Terapkan transaksi baru (jika bankId masih sama)
      if (newBankId && newBankId === existingAkuran.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: newBankId }
        }).catch(() => null)

        if (bank) {
          await db.bank.update({
            where: { id: newBankId },
            data: { balance: bank.balance - newAmount }
          })

          await db.bankHistory.create({
            data: {
              bankId: newBankId,
              eventType: 'UPDATED',
              oldBalance: bank.balance,
              newBalance: bank.balance - newAmount,
              notes: `Akuran update: -${newAmount} - ${notes || category || ''}`,
              userId: session.user.id
            }
          })
        }
      }
    }

    // Update akuran
    const updateData: any = {}
    if (amount !== undefined) updateData.amount = newAmount
    if (notes !== undefined) updateData.notes = notes
    if (category !== undefined) updateData.category = category

    if (bankId !== undefined) {
      updateData.bankId = newBankId
      const newBank = newBankId ? await db.bank.findUnique({
        where: { id: newBankId }
      }).catch(() => null) : null
      updateData.bankName = newBank ? newBank.name : bankName
    }

    const akuran = await db.akuran.update({
      where: { id },
      data: updateData
    })

    return NextResponse.json({
      success: true,
      akuran
    })
  } catch (error) {
    console.error('Update akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate akuran' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus akuran
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER bisa delete akuran
    const permission = session.user.permission
    if (permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus akuran' },
        { status: 403 }
      )
    }

    // Ambil akuran yang ada
    const existingAkuran = await db.akuran.findUnique({
      where: { id }
    })

    if (!existingAkuran) {
      return NextResponse.json(
        { error: 'Akuran tidak ditemukan' },
        { status: 404 }
      )
    }

    // Kembalikan balance bank (reverse transaction)
    if (existingAkuran.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: existingAkuran.bankId }
      }).catch(() => null)

      if (bank) {
        await db.bank.update({
          where: { id: existingAkuran.bankId },
          data: { balance: bank.balance + existingAkuran.amount }
        })

        await db.bankHistory.create({
          data: {
            bankId: existingAkuran.bankId,
            eventType: 'UPDATED',
            oldBalance: bank.balance,
            newBalance: bank.balance + existingAkuran.amount,
            notes: `Akuran delete: +${existingAkuran.amount} (reverse)`,
            userId: session.user.id
          }
        })
      }
    }

    // Hapus akuran
    await db.akuran.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Akuran berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus akuran' },
      { status: 500 }
    )
  }
}

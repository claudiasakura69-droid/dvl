import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil semua mistakes
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Build where clause
    const where: any = {}
    if (startDate || endDate) {
      where.createdAt = {}
      if (startDate) {
        where.createdAt.gte = new Date(startDate)
      }
      if (endDate) {
        where.createdAt.lte = new Date(endDate)
      }
    }

    const mistakes = await db.mistake.findMany({
      where,
      include: {
        bank: {
          select: {
            id: true,
            name: true
          }
        },
        user: {
          select: {
            id: true,
            username: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      mistakes
    })
  } catch (error) {
    console.error('Get mistakes error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data mistakes' },
      { status: 500 }
    )
  }
}

// POST - Buat mistake baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, bankId, bankName, transactionId, userId } = await req.json()

    if (!sessionId || !amount || !userId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa create
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat mistake' },
        { status: 403 }
      )
    }

    // Cari bank jika bankId disertakan
    let bank = null
    if (bankId) {
      bank = await db.bank.findUnique({
        where: { id: bankId }
      })

      if (!bank) {
        return NextResponse.json(
          { error: 'Bank tidak ditemukan' },
          { status: 404 }
        )
      }

      // Update balance bank (kurangi)
      await db.bank.update({
        where: { id: bankId },
        data: { balance: bank.balance - parseFloat(amount) }
      })

      // Catat history
      await db.bankHistory.create({
        data: {
          bankId: bankId,
          eventType: 'UPDATED',
          oldBalance: bank.balance,
          newBalance: bank.balance - parseFloat(amount),
          notes: `Mistake: -${amount} - ${notes || transactionId || ''}`,
          userId
        }
      })
    }

    // Buat mistake
    const mistake = await db.mistake.create({
      data: {
        amount: parseFloat(amount),
        notes: notes || null,
        bankId: bankId || null,
        bankName: bank ? bank.name : (bankName || null),
        transactionId: transactionId || null,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      mistake
    })
  } catch (error) {
    console.error('Create mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat mistake' },
      { status: 500 }
    )
  }
}

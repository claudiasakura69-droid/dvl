import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update Mistake transaction
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, amount, notes, bankId, bankName, transactionId } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa edit
    const permission = session.user.permission
    if (permission !== 'MASTER' && permission !== 'SUPPORT') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit mistake' },
        { status: 403 }
      )
    }

    // Ambil mistake yang ada
    const existingMistake = await db.mistake.findUnique({
      where: { id }
    })

    if (!existingMistake) {
      return NextResponse.json(
        { error: 'Mistake tidak ditemukan' },
        { status: 404 }
      )
    }

    const newAmount = amount !== undefined ? parseFloat(amount) : existingMistake.amount
    const newBankId = bankId !== undefined ? bankId : existingMistake.bankId

    // Jika ada perubahan amount, adjust balance bank
    if (newAmount !== existingMistake.amount) {
      // Reverse transaksi lama
      if (existingMistake.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: existingMistake.bankId }
        }).catch(() => null)

        if (bank) {
          await db.bank.update({
            where: { id: existingMistake.bankId },
            data: { balance: bank.balance + existingMistake.amount }
          })
        }
      }

      // Terapkan transaksi baru (jika bankId masih sama)
      if (newBankId && newBankId === existingMistake.bankId) {
        const bank = await db.bank.findUnique({
          where: { id: newBankId }
        }).catch(() => null)

        if (bank) {
          await db.bank.update({
            where: { id: newBankId },
            data: { balance: bank.balance - newAmount }
          })

          await db.bankHistory.create({
            data: {
              bankId: newBankId,
              eventType: 'UPDATED',
              oldBalance: bank.balance,
              newBalance: bank.balance - newAmount,
              notes: `Mistake update: -${newAmount} - ${notes || transactionId || ''}`,
              userId: session.user.id
            }
          })
        }
      }
    }

    // Update mistake data
    const updateData: any = {}
    if (amount !== undefined) updateData.amount = newAmount
    if (notes !== undefined) updateData.notes = notes
    if (transactionId !== undefined) updateData.transactionId = transactionId

    if (bankId !== undefined) {
      updateData.bankId = newBankId
      const newBank = newBankId ? await db.bank.findUnique({
        where: { id: newBankId }
      }).catch(() => null) : null
      updateData.bankName = newBank ? newBank.name : bankName
    }

    const mistake = await db.mistake.update({
      where: { id },
      data: updateData
    })

    return NextResponse.json({
      success: true,
      mistake
    })
  } catch (error) {
    console.error('Update mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate mistake' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus Mistake transaction
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER bisa delete
    const permission = session.user.permission
    if (permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus mistake' },
        { status: 403 }
      )
    }

    // Ambil mistake yang ada
    const existingMistake = await db.mistake.findUnique({
      where: { id }
    })

    if (!existingMistake) {
      return NextResponse.json(
        { error: 'Mistake tidak ditemukan' },
        { status: 404 }
      )
    }

    // Kembalikan balance bank (reverse transaction)
    if (existingMistake.bankId) {
      const bank = await db.bank.findUnique({
        where: { id: existingMistake.bankId }
      }).catch(() => null)

      if (bank) {
        await db.bank.update({
          where: { id: existingMistake.bankId },
          data: { balance: bank.balance + existingMistake.amount }
        })

        await db.bankHistory.create({
          data: {
            bankId: existingMistake.bankId,
            eventType: 'UPDATED',
            oldBalance: bank.balance,
            newBalance: bank.balance + existingMistake.amount,
            notes: `Mistake delete: +${existingMistake.amount} (reverse)`,
            userId: session.user.id
          }
        })
      }
    }

    // Hapus mistake
    await db.mistake.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Mistake berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus mistake' },
      { status: 500 }
    )
  }
}

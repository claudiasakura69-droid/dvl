import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update bank
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { sessionId, name, accountName, accountNumber, balance } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa edit bank
    if (session.user.permission !== 'SUPPORT' && session.user.permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit bank' },
        { status: 403 }
      )
    }

    // Cari bank yang akan diupdate
    const existingBank = await db.bank.findUnique({
      where: { id }
    })

    if (!existingBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Update bank
    const bank = await db.bank.update({
      where: { id },
      data: {
        name: name || existingBank.name,
        accountName: accountName || existingBank.accountName,
        accountNumber: accountNumber !== undefined ? accountNumber : existingBank.accountNumber,
        balance: balance !== undefined ? parseFloat(balance) : existingBank.balance
      }
    })

    // Catat history jika ada perubahan balance
    if (balance !== undefined && balance !== existingBank.balance) {
      await db.bankHistory.create({
        data: {
          bankId: bank.id,
          eventType: 'UPDATED',
          oldBalance: existingBank.balance,
          newBalance: balance,
          notes: 'Balance diperbarui',
          userId: session.user.id
        }
      })
    }

    return NextResponse.json({
      success: true,
      bank
    })
  } catch (error) {
    console.error('Update bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate bank' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus bank
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: Hanya MASTER yang bisa delete bank
    if (session.user.permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus bank' },
        { status: 403 }
      )
    }

    // Cari bank yang akan dihapus
    const bank = await db.bank.findUnique({
      where: { id }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Set bankId ke null dan simpan bankName untuk semua transaksi terkait
    // 1. DailyTransaction
    await db.dailyTransaction.updateMany({
      where: { bankId: id },
      data: { bankId: null, bankName: bank.name }
    })

    // 2. InOut (fromBankId dan toBankId)
    await db.inOut.updateMany({
      where: { fromBankId: id },
      data: { fromBankId: null, fromBankName: bank.name }
    })
    await db.inOut.updateMany({
      where: { toBankId: id },
      data: { toBankId: null, toBankName: bank.name }
    })

    // 3. Expense
    await db.expense.updateMany({
      where: { bankId: id },
      data: { bankId: null, bankName: bank.name }
    })

    // 4. Mistake
    await db.mistake.updateMany({
      where: { bankId: id },
      data: { bankId: null, bankName: bank.name }
    })

    // 5. Akuran
    await db.akuran.updateMany({
      where: { bankId: id },
      data: { bankId: null, bankName: bank.name }
    })

    // Hapus bank (cascade akan menghapus history)
    await db.bank.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Bank berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus bank' },
      { status: 500 }
    )
  }
}

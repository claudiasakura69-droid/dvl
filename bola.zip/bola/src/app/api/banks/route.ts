import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil semua banks
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const banks = await db.bank.findMany({
      include: {
        bankHistories: {
          include: {
            user: {
              select: {
                id: true,
                username: true
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 50
        },
        dailyTransactions: {
          orderBy: { createdAt: 'desc' },
          take: 20
        }
      },
      orderBy: [
        { type: 'asc' },
        { createdAt: 'desc' }
      ]
    })

    return NextResponse.json({
      success: true,
      banks
    })
  } catch (error) {
    console.error('Get banks error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data banks' },
      { status: 500 }
    )
  }
}

// POST - Buat bank baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, name, accountName, accountNumber, type, balance, userId } = await req.json()

    if (!sessionId || !name || !accountName || !type || balance === undefined) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Check permission: SUPPORT dan MASTER bisa tambah bank
    if (session.user.permission !== 'SUPPORT' && session.user.permission !== 'MASTER') {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah bank' },
        { status: 403 }
      )
    }

    // Buat bank baru dengan status offline
    const bank = await db.bank.create({
      data: {
        name,
        accountName,
        accountNumber: accountNumber || null,
        type,
        balance: parseFloat(balance),
        status: 'offline'
      }
    })

    // Catat history
    await db.bankHistory.create({
      data: {
        bankId: bank.id,
        eventType: 'CREATED',
        newBalance: balance,
        newType: type,
        notes: `Bank ${type} baru dibuat`,
        userId: session.user.id
      }
    })

    return NextResponse.json({
      success: true,
      bank
    })
  } catch (error) {
    console.error('Create bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat bank' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil data report bulanan
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const month = searchParams.get('month')
    const year = searchParams.get('year')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tanggal
    const currentDate = new Date()
    const currentMonth = month ? parseInt(month) : currentDate.getMonth() + 1
    const currentYear = year ? parseInt(year) : currentDate.getFullYear()

    const startDate = new Date(currentYear, currentMonth - 1, 1)
    const endDate = new Date(currentYear, currentMonth, 0, 23, 59, 59)

    // Ambil semua transaksi di bulan tersebut
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    const inOuts = await db.inOut.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    const expenses = await db.expense.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    const mistakes = await db.mistake.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    const akurans = await db.akuran.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true
          }
        }
      }
    })

    // Calculate summary
    const totalDeposit = dailyTransactions
      .filter(tx => tx.type === 'DEPOSIT')
      .reduce((sum, tx) => sum + tx.amount, 0)

    const totalWithdraw = dailyTransactions
      .filter(tx => tx.type === 'WITHDRAW')
      .reduce((sum, tx) => sum + tx.amount, 0)

    const totalExpense = expenses.reduce((sum, exp) => {
      if (exp.operation === 'decrease') {
        return sum + exp.amount
      }
      return sum
    }, 0)

    const totalExpenseAdd = expenses.reduce((sum, exp) => {
      if (exp.operation === 'increase') {
        return sum + exp.amount
      }
      return sum
    }, 0)

    const totalMistake = mistakes.reduce((sum, m) => sum + m.amount, 0)
    const totalAkuran = akurans.reduce((sum, a) => sum + a.amount, 0)

    const totalInOutIn = inOuts.reduce((sum, io) => sum + io.amount, 0)
    const totalInOutOut = inOuts.reduce((sum, io) => sum + io.amount, 0)

    const netFlow = totalDeposit + totalExpenseAdd + totalInOutIn - totalWithdraw - totalExpense - totalMistake - totalAkuran - totalInOutOut

    // Aggregate by date
    const dateMap = new Map<string, {
      deposit: number
      withdraw: number
      expense: number
      mistake: number
      akuran: number
      inOut: number
    }>()

    // Daily transactions
    dailyTransactions.forEach(tx => {
      const dateKey = tx.date.toDateString()
      const current = dateMap.get(dateKey) || { deposit: 0, withdraw: 0, expense: 0, mistake: 0, akuran: 0, inOut: 0 }

      if (tx.type === 'DEPOSIT') {
        current.deposit += tx.amount
      } else {
        current.withdraw += tx.amount
      }

      dateMap.set(dateKey, current)
    })

    // InOut transactions
    inOuts.forEach(io => {
      const dateKey = new Date(io.createdAt).toDateString()
      const current = dateMap.get(dateKey) || { deposit: 0, withdraw: 0, expense: 0, mistake: 0, akuran: 0, inOut: 0 }
      current.inOut += io.amount
      dateMap.set(dateKey, current)
    })

    // Expense transactions
    expenses.forEach(exp => {
      const dateKey = new Date(exp.createdAt).toDateString()
      const current = dateMap.get(dateKey) || { deposit: 0, withdraw: 0, expense: 0, mistake: 0, akuran: 0, inOut: 0 }

      if (exp.operation === 'decrease') {
        current.expense -= exp.amount
      } else {
        current.expense += exp.amount
      }

      dateMap.set(dateKey, current)
    })

    // Mistake transactions
    mistakes.forEach(m => {
      const dateKey = new Date(m.createdAt).toDateString()
      const current = dateMap.get(dateKey) || { deposit: 0, withdraw: 0, expense: 0, mistake: 0, akuran: 0, inOut: 0 }
      current.mistake -= m.amount
      dateMap.set(dateKey, current)
    })

    // Akuran transactions
    akurans.forEach(a => {
      const dateKey = new Date(a.createdAt).toDateString()
      const current = dateMap.get(dateKey) || { deposit: 0, withdraw: 0, expense: 0, mistake: 0, akuran: 0, inOut: 0 }
      current.akuran -= a.amount
      dateMap.set(dateKey, current)
    })

    // Convert to array and sort
    const dailyData = Array.from(dateMap.entries())
      .map(([date, data]) => ({
        date,
        ...data,
        total: data.deposit + data.inOut + data.expense - data.withdraw - data.mistake - data.akuran
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

    return NextResponse.json({
      success: true,
      data: {
        summary: {
          totalDeposit,
          totalWithdraw,
          totalExpense,
          totalExpenseAdd,
          totalMistake,
          totalAkuran,
          totalInOutIn,
          totalInOutOut,
          netFlow
        },
        dailyData,
        transactions: {
          dailyTransactions,
          inOuts,
          expenses,
          mistakes,
          akurans
        }
      }
    })
  } catch (error) {
    console.error('Get report error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data report' },
      { status: 500 }
    )
  }
}

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Users, Activity, Plus, Edit2, Trash2, Power, PowerOff, Search, Calendar } from 'lucide-react'
import { toast } from 'sonner'

interface UserManagementContentProps {
  sessionId: string | null
  userPermission: string | null
  currentUserId: string | null
}

interface UserData {
  id: string
  username: string
  token: string
  permission: string
  isActive: boolean
  createdAt: string
  updatedAt: string
  sessions: SessionData[]
}

interface SessionData {
  id: string
  loginAt: string
  logoutAt: string | null
  ipAddress: string | null
  isOnline: boolean
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

const PERMISSION_ORDER: Permission[] = ['MASTER', 'SUPERVISOR', 'SUPPORT', 'ADMIN', 'VIEW']

export default function UserManagementContent({ sessionId, userPermission, currentUserId }: UserManagementContentProps) {
  const [users, setUsers] = useState<UserData[]>([])
  const [loading, setLoading] = useState(true)
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null)
  const [formData, setFormData] = useState({
    username: '',
    token: '',
    permission: 'VIEW' as Permission
  })
  const [editFormData, setEditFormData] = useState({
    username: '',
    token: '',
    permission: 'VIEW' as Permission
  })
  
  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('')
  const [dateFilter, setDateFilter] = useState('')
  const [userFilter, setUserFilter] = useState('')

  useEffect(() => {
    fetchUsers()
  }, [sessionId])

  const fetchUsers = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/users?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setUsers(data.users)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId) return

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...formData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('User berhasil dibuat')
        setAddDialogOpen(false)
        setFormData({
          username: '',
          token: '',
          permission: 'VIEW'
        })
        fetchUsers()
      } else {
        toast.error(data.error || 'Gagal membuat user')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditUser = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedUser) return

    try {
      const response = await fetch(`/api/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...editFormData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(data.message || 'User berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedUser(null)
        setEditFormData({
          username: '',
          token: '',
          permission: 'VIEW'
        })
        
        // Jika session diinvalidate, reload halaman
        if (data.sessionInvalidated && selectedUser.id === currentUserId) {
          toast.warning('Username atau token diubah. Silakan login ulang.')
          setTimeout(() => {
            window.location.reload()
          }, 2000)
        } else if (editFormData.permission !== selectedUser.permission && selectedUser.id === currentUserId) {
          // Jika hanya permission diubah, reload halaman
          toast.info('Permission diubah. Memuat ulang...')
          setTimeout(() => {
            window.location.reload()
          }, 1000)
        } else {
          fetchUsers()
        }
      } else {
        toast.error(data.error || 'Gagal mengupdate user')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus user ini?')) return

    try {
      const response = await fetch(`/api/users/${userId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('User berhasil dihapus')
        
        // Jika user sendiri yang dihapus, logout
        if (userId === currentUserId) {
          toast.warning('User Anda dihapus. Logout otomatis...')
          setTimeout(() => {
            window.location.reload()
          }, 2000)
        } else {
          fetchUsers()
        }
      } else {
        toast.error(data.error || 'Gagal menghapus user')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (user: UserData) => {
    setSelectedUser(user)
    setEditFormData({
      username: user.username,
      token: user.token,
      permission: user.permission as Permission
    })
    setEditDialogOpen(true)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const isOnline = (user: UserData) => {
    return user.sessions.some(s => s.isOnline)
  }

  const canAddUser = userPermission === 'SUPERVISOR' || userPermission === 'MASTER'
  const canEditUser = userPermission === 'SUPERVISOR' || userPermission === 'MASTER'
  const canDeleteUser = userPermission === 'MASTER'

  // Filter users
  const filteredUsers = users.filter(user => {
    const matchesSearch = !searchQuery || 
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.permission.toLowerCase().includes(searchQuery.toLowerCase())
    
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const matchesDate = !dateFilter || (() => {
      const userDate = new Date(user.createdAt)
      return userDate.toDateString() === new Date(dateFilter).toDateString()
    })()
    
    const matchesUserFilter = !userFilter || 
      user.username.toLowerCase().includes(userFilter.toLowerCase())
    
    return matchesSearch && matchesDate && matchesUserFilter
  })

  const onlineCount = users.filter(u => isOnline(u)).length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Users className="h-8 w-8" />
          User Management
        </h1>
        <p className="text-muted-foreground">
          Kelola semua user di sistem
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online Now</CardTitle>
            <Activity className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{onlineCount}</div>
          </CardContent>
        </Card>
      </div>

      {/* Actions & Filters */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        {canAddUser && (
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah User
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah User Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddUser} className="space-y-4">
                <div>
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="Username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="token">Token</Label>
                  <Input
                    id="token"
                    placeholder="Token login"
                    value={formData.token}
                    onChange={(e) => setFormData({ ...formData, token: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="permission">Permission</Label>
                  <Select
                    value={formData.permission}
                    onValueChange={(value: Permission) => setFormData({ ...formData, permission: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {userPermission === 'MASTER' && (
                        <SelectItem value="MASTER">Master</SelectItem>
                      )}
                      <SelectItem value="SUPERVISOR">Supervisor</SelectItem>
                      <SelectItem value="SUPPORT">Support</SelectItem>
                      <SelectItem value="ADMIN">Admin</SelectItem>
                      <SelectItem value="VIEW">View</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}

        <div className="flex gap-2 items-center">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cari user..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="relative">
            <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              placeholder="Filter tanggal"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {/* User List */}
      <Card>
        <CardHeader>
          <CardTitle>User List</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredUsers.length === 0 ? (
              <p className="text-muted-foreground">Tidak ada user yang ditemukan.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Token</TableHead>
                    <TableHead>Permission</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created At</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.username}</TableCell>
                      <TableCell>
                        <span className="font-mono text-sm bg-muted px-2 py-1 rounded">
                          {user.token.replace(/./g, '*')}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getPermissionBadgeVariant(user.permission as Permission)}>
                          {user.permission}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {isOnline(user) ? (
                            <>
                              <Activity className="h-4 w-4 text-green-500" />
                              <span className="text-green-600 font-medium">Online</span>
                            </>
                          ) : (
                            <>
                              <PowerOff className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-600">Offline</span>
                            </>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {canEditUser && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(user)}
                              disabled={user.permission === 'MASTER' && userPermission !== 'MASTER'}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          )}
                          {canDeleteUser && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteUser(user.id)}
                              disabled={user.permission === 'MASTER'}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User - {selectedUser?.username}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditUser} className="space-y-4">
            {userPermission === 'MASTER' && (
              <>
                <div>
                  <Label htmlFor="edit-username">Username</Label>
                  <Input
                    id="edit-username"
                    placeholder="Username"
                    value={editFormData.username}
                    onChange={(e) => setEditFormData({ ...editFormData, username: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-token">Token</Label>
                  <Input
                    id="edit-token"
                    placeholder="Token login"
                    value={editFormData.token}
                    onChange={(e) => setEditFormData({ ...editFormData, token: e.target.value })}
                  />
                </div>
              </>
            )}
            <div>
              <Label htmlFor="edit-permission">Permission</Label>
              <Select
                value={editFormData.permission}
                onValueChange={(value: Permission) => setEditFormData({ ...editFormData, permission: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {userPermission === 'MASTER' && (
                    <SelectItem value="MASTER" disabled={selectedUser?.permission === 'MASTER'}>
                      Master
                    </SelectItem>
                  )}
                  <SelectItem value="SUPERVISOR">Supervisor</SelectItem>
                  <SelectItem value="SUPPORT">Support</SelectItem>
                  <SelectItem value="ADMIN">Admin</SelectItem>
                  <SelectItem value="VIEW">View</SelectItem>
                </SelectContent>
              </Select>
              {userPermission === 'SUPERVISOR' && (
                <p className="text-sm text-muted-foreground mt-1">
                  Supervisor hanya bisa mengubah permission
                </p>
              )}
            </div>
            <Button type="submit" className="w-full">
              Simpan
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function getPermissionBadgeVariant(permission: Permission): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (permission) {
    case 'MASTER':
      return 'destructive'
    case 'SUPERVISOR':
      return 'default'
    case 'SUPPORT':
      return 'default'
    case 'ADMIN':
      return 'secondary'
    case 'VIEW':
      return 'outline'
    default:
      return 'outline'
  }
}

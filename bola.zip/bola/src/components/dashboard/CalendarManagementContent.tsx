'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Calendar as CalendarIcon, Trash2, ChevronLeft, ChevronRight } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { toast } from 'sonner'

interface CalendarManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, permission: string } | null
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

export default function CalendarManagementContent({ sessionId, user }: CalendarManagementContentProps) {
  const userPermission = user?.permission as Permission
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [dataDates, setDataDates] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')

  const canDeleteData = userPermission === 'MASTER'

  useEffect(() => {
    if (sessionId && selectedYear) {
      fetchCalendarData()
    }
  }, [sessionId, selectedYear])

  const fetchCalendarData = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/calendar?sessionId=${sessionId}&year=${selectedYear}`)
      const data = await response.json()

      if (data.success) {
        setDataDates(new Set(data.dates))
      } else {
        toast.error(data.error || 'Gagal mengambil data kalender')
      }
    } catch (error) {
      console.error('Error fetching calendar data:', error)
      toast.error('Terjadi kesalahan')
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteData = async () => {
    if (!sessionId || !startDate || !endDate) {
      toast.error('Pilih tanggal awal dan akhir')
      return
    }

    try {
      const response = await fetch('/api/calendar', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          startDate,
          endDate,
          confirm: 'YES_DELETE_ALL_DATA'
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`Data berhasil dihapus: ${data.deleted.dailyTransactions} transaksi harian, ${data.deleted.inOuts} in/out, ${data.deleted.expenses} expense, ${data.deleted.mistakes} mistake, ${data.deleted.akurans} akuran`)
        setDeleteDialogOpen(false)
        setStartDate('')
        setEndDate('')
        fetchCalendarData()
      } else {
        toast.error(data.error || 'Gagal menghapus data')
      }
    } catch (error) {
      console.error('Error deleting data:', error)
      toast.error('Terjadi kesalahan')
    }
  }

  const renderCalendar = (month: number, year: number) => {
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDay = firstDay.getDay()

    const days = []

    // Empty cells before first day
    for (let i = 0; i < startingDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-8"></div>)
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = new Date(year, month, day).toDateString()
      const hasData = dataDates.has(dateStr)

      days.push(
        <button
          key={day}
          onClick={() => {
            if (hasData && canDeleteData) {
              if (!startDate) {
                setStartDate(dateStr)
              } else if (!endDate) {
                setEndDate(dateStr)
              }
            }
          }}
          className={`
            h-8 w-8 text-sm rounded flex items-center justify-center
            transition-all duration-200
            ${hasData
              ? 'bg-primary text-primary-foreground hover:bg-primary/90 cursor-pointer font-semibold'
              : 'bg-muted hover:bg-muted/80'
            }
            ${startDate === dateStr || endDate === dateStr ? 'ring-2 ring-offset-2 ring-primary' : ''}
          `}
          title={hasData ? 'Ada transaksi' : 'Tidak ada transaksi'}
        >
          {day}
        </button>
      )
    }

    return days
  }

  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ]

  const clearSelection = () => {
    setStartDate('')
    setEndDate('')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <CalendarIcon className="h-8 w-8" />
            Calendar
          </h1>
          <p className="text-muted-foreground">
            Lihat dan hapus data transaksi berdasarkan tanggal
          </p>
        </div>

        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSelectedYear(selectedYear - 1)}
            disabled={loading}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Input
            type="number"
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value) || new Date().getFullYear())}
            className="w-24 text-center font-semibold"
            disabled={loading}
          />
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSelectedYear(selectedYear + 1)}
            disabled={loading}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            {selectedYear}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <p>Memuat data...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {months.map((month, monthIndex) => (
                <Card key={monthIndex} className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-sm">{month}</h3>
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center text-xs">
                    {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map(day => (
                      <div key={day} className="font-semibold text-muted-foreground text-xs py-1">
                        {day}
                      </div>
                    ))}
                    {renderCalendar(monthIndex, selectedYear)}
                  </div>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Date Selection Info */}
      {(startDate || endDate) && canDeleteData && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold mb-2">Range Tanggal Dipilih</h3>
                <div className="flex items-center gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Mulai:</span>{' '}
                    <span className="font-medium">{startDate || 'Belum dipilih'}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Akhir:</span>{' '}
                    <span className="font-medium">{endDate || 'Belum dipilih'}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={clearSelection}>
                  Batal
                </Button>
                {startDate && endDate && (
                  <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Hapus Data
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Konfirmasi Hapus Data</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <p className="text-muted-foreground">
                          Apakah Anda yakin ingin menghapus semua data transaksi dari{' '}
                          <strong>{startDate}</strong> sampai <strong>{endDate}</strong>?
                        </p>
                        <p className="text-sm text-destructive font-semibold">
                          ⚠️ Data yang terhapus tidak dapat dipulihkan kembali!
                        </p>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                            Batal
                          </Button>
                          <Button variant="destructive" onClick={handleDeleteData}>
                            Ya, Hapus Data
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

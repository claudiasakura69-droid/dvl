'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowRight, Plus, Edit2, Trash2, Search } from 'lucide-react'
import { toast } from 'sonner'

interface InOutManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, permission: string } | null
  userPermission: string | null
}

interface InOut {
  id: string
  fromBankId: string | null
  toBankId: string | null
  fromBankName: string | null
  toBankName: string | null
  amount: number
  notes: string | null
  user: {
    id: string
    username: string
  }
  createdAt: string
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: 'DEPOSIT' | 'WITHDRAW'
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

export default function InOutManagementContent({ sessionId, user, userPermission }: InOutManagementContentProps) {
  const permission = userPermission as Permission
  const [inOuts, setInOuts] = useState<InOut[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedInOut, setSelectedInOut] = useState<InOut | null>(null)
  const [formData, setFormData] = useState({
    fromBankId: '',
    toBankId: '',
    amount: 0,
    notes: ''
  })
  const [editFormData, setEditFormData] = useState({
    fromBankId: '',
    toBankId: '',
    amount: 0,
    notes: ''
  })
  const [searchQuery, setSearchQuery] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')

  useEffect(() => {
    if (sessionId) {
      fetchInOuts()
      fetchBanks()
    }
  }, [sessionId])

  const fetchInOuts = async () => {
    if (!sessionId) return

    try {
      let url = `/api/inout?sessionId=${sessionId}`
      if (startDate) url += `&startDate=${startDate}`
      if (endDate) url += `&endDate=${endDate}`

      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setInOuts(data.inOuts)
      }
    } catch (error) {
      console.error('Error fetching inouts:', error)
      toast.error('Terjadi kesalahan')
    } finally {
      setLoading(false)
    }
  }

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const handleCreateInOut = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/inout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('In/Out berhasil dibuat')
        setDialogOpen(false)
        setFormData({ fromBankId: '', toBankId: '', amount: 0, notes: '' })
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal membuat in/out')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditInOut = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedInOut) return

    try {
      const response = await fetch(`/api/inout/${selectedInOut.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...editFormData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('In/Out berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedInOut(null)
        setEditFormData({ fromBankId: '', toBankId: '', amount: 0, notes: '' })
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate in/out')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteInOut = async (inOutId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) return

    try {
      const response = await fetch(`/api/inout/${inOutId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('In/Out berhasil dihapus')
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus in/out')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (inOut: InOut) => {
    setSelectedInOut(inOut)
    setEditFormData({
      fromBankId: inOut.fromBankId || '',
      toBankId: inOut.toBankId || '',
      amount: inOut.amount,
      notes: inOut.notes || ''
    })
    setEditDialogOpen(true)
  }

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const filteredInOuts = inOuts.filter(inOut => {
    const matchesSearch = !searchQuery ||
      (inOut.fromBankName && inOut.fromBankName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (inOut.toBankName && inOut.toBankName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (inOut.notes && inOut.notes.toLowerCase().includes(searchQuery.toLowerCase()))

    return matchesSearch
  })

  const canCreate = permission === 'SUPPORT' || permission === 'MASTER'
  const canEdit = permission === 'SUPPORT' || permission === 'MASTER'
  const canDelete = permission === 'MASTER'

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <ArrowRight className="h-8 w-8" />
            In/Out Management
          </h1>
          <p className="text-muted-foreground">
            Kelola perpindahan antar bank
          </p>
        </div>

        {canCreate && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah In/Out
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah In/Out Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateInOut} className="space-y-4">
                <div>
                  <Label htmlFor="fromBank">Dari Bank</Label>
                  <Select
                    value={formData.fromBankId}
                    onValueChange={(value) => setFormData({ ...formData, fromBankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank asal" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({bank.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="toBank">Ke Bank</Label>
                  <Select
                    value={formData.toBankId}
                    onValueChange={(value) => setFormData({ ...formData, toBankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank tujuan" />
                    </SelectTrigger>
                    <SelectContent>
                      {banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({bank.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan transaksi"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari berdasarkan bank atau catatan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Input
          type="date"
          placeholder="Tanggal Mulai"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
        <Input
          type="date"
          placeholder="Tanggal Akhir"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
      </div>

      {/* In/Out List */}
      <Card>
        <CardHeader>
          <CardTitle>In/Out List</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px] custom-scrollbar">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredInOuts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Tidak ada data in/out
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Waktu</TableHead>
                    <TableHead>Dari Bank</TableHead>
                    <TableHead>Ke Bank</TableHead>
                    <TableHead>Nominal</TableHead>
                    <TableHead>Catatan</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInOuts.map((inout) => (
                    <TableRow key={inout.id}>
                      <TableCell>{formatDate(inout.createdAt)}</TableCell>
                      <TableCell>{inout.fromBankName || 'Bank sudah dihapus'}</TableCell>
                      <TableCell>{inout.toBankName || 'Bank sudah dihapus'}</TableCell>
                      <TableCell className="font-semibold">{formatCurrency(inout.amount)}</TableCell>
                      <TableCell>{inout.notes || '-'}</TableCell>
                      <TableCell>{inout.user.username}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {canEdit && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(inout)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          )}
                          {canDelete && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteInOut(inout.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit In/Out - {formatDate(selectedInOut?.createdAt || '')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditInOut} className="space-y-4">
            <div>
              <Label htmlFor="edit-fromBank">Dari Bank</Label>
              <Select
                value={editFormData.fromBankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, fromBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank asal" />
                </SelectTrigger>
                <SelectContent>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-toBank">Ke Bank</Label>
              <Select
                value={editFormData.toBankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, toBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank tujuan" />
                </SelectTrigger>
                <SelectContent>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-amount">Nominal</Label>
              <Input
                id="edit-amount"
                type="number"
                placeholder="0"
                value={editFormData.amount}
                onChange={(e) => setEditFormData({ ...editFormData, amount: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
              <Input
                id="edit-notes"
                placeholder="Catatan transaksi"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

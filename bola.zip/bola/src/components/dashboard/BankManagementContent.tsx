'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Building2, Plus, Trash2, Power, ArrowRightLeft, History, Edit2, Lock } from 'lucide-react'
import { toast } from 'sonner'

interface BankManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, permission: string } | null
}

interface Bank {
  id: string
  name: string
  accountName: string
  accountNumber: string | null
  type: 'DEPOSIT' | 'WITHDRAW'
  balance: number
  status: 'online' | 'offline'
  bankHistories: BankHistory[]
  dailyTransactions: any[]
}

interface BankHistory {
  id: string
  eventType: string
  oldValue: string | null
  newValue: string | null
  oldBalance: number | null
  newBalance: number | null
  oldType: string | null
  newType: string | null
  notes: string | null
  createdAt: string
  user?: {
    id: string
    username: string
  }
}

interface BankFormData {
  name: string
  accountName: string
  accountNumber: string
  type: 'DEPOSIT' | 'WITHDRAW'
  balance: number
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

export default function BankManagementContent({ sessionId, user }: BankManagementContentProps) {
  const userPermission = user?.permission as Permission
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [historyDialogOpen, setHistoryDialogOpen] = useState(false)
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null)
  const [formData, setFormData] = useState<BankFormData>({
    name: '',
    accountName: '',
    accountNumber: '',
    type: 'DEPOSIT',
    balance: 0
  })
  const [editFormData, setEditFormData] = useState<BankFormData>({
    name: '',
    accountName: '',
    accountNumber: '',
    type: 'DEPOSIT',
    balance: 0
  })

  useEffect(() => {
    fetchBanks()
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateBank = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/banks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Bank berhasil dibuat dengan status offline')
        setDialogOpen(false)
        setFormData({
          name: '',
          accountName: '',
          accountNumber: '',
          type: 'DEPOSIT',
          balance: 0
        })
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal membuat bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditBank = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedBank) return

    try {
      const response = await fetch(`/api/banks/${selectedBank.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...editFormData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Bank berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedBank(null)
        setEditFormData({
          name: '',
          accountName: '',
          accountNumber: '',
          type: 'DEPOSIT',
          balance: 0
        })
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteBank = async (bankId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus bank ini?')) return

    try {
      const response = await fetch(`/api/banks/${bankId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Bank berhasil dihapus')
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleToggleStatus = async (bankId: string, currentStatus: string) => {
    if (!sessionId) return

    const newStatus = currentStatus === 'online' ? 'offline' : 'online'

    try {
      const response = await fetch(`/api/banks/${bankId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          status: newStatus
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`Status bank diubah menjadi ${newStatus}`)
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengubah status')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleMoveBank = async (bankId: string, currentType: string) => {
    if (!sessionId) return

    const newType = currentType === 'DEPOSIT' ? 'WITHDRAW' : 'DEPOSIT'

    if (!confirm(`Pindahkan bank dari ${currentType} ke ${newType}?`)) return

    try {
      const response = await fetch(`/api/banks/${bankId}/move`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          newType
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`Bank berhasil dipindahkan ke ${newType}`)
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal memindahkan bank')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (bank: Bank) => {
    setSelectedBank(bank)
    setEditFormData({
      name: bank.name,
      accountName: bank.accountName,
      accountNumber: bank.accountNumber || '',
      type: bank.type,
      balance: bank.balance
    })
    setEditDialogOpen(true)
  }

  const depositBanks = banks.filter(b => b.type === 'DEPOSIT')
  const withdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const canAddBank = userPermission === 'SUPPORT' || userPermission === 'MASTER'
  const canEditBank = userPermission === 'SUPPORT' || userPermission === 'MASTER'
  const canDeleteBank = userPermission === 'MASTER'

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Building2 className="h-8 w-8" />
            Bank Management
          </h1>
          <p className="text-muted-foreground">
            Kelola rekening deposit dan withdraw
          </p>
        </div>

        {canAddBank && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah Bank
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Bank Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateBank} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nama Bank</Label>
                  <Input
                    id="name"
                    placeholder="Contoh: BCA, BRI, DANA, OVO"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="accountName">Nama Pemilik</Label>
                  <Input
                    id="accountName"
                    placeholder="Contoh: Vera, David"
                    value={formData.accountName}
                    onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="accountNumber">Nomor Rekening (Opsional)</Label>
                  <Input
                    id="accountNumber"
                    placeholder="Contoh: 1234567890"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="type">Tipe</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEPOSIT">Deposit</SelectItem>
                      <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="balance">Saldo Awal</Label>
                  <Input
                    id="balance"
                    type="number"
                    placeholder="0"
                    value={formData.balance}
                    onChange={(e) => setFormData({ ...formData, balance: parseFloat(e.target.value) || 0 })}
                    required
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Bank baru akan otomatis berstatus <strong>offline</strong>. Anda bisa mengubahnya menjadi online setelah dibuat.
                </p>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Deposit Banks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              Deposit
              <span className="text-sm font-normal text-muted-foreground">({depositBanks.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {depositBanks.map((bank) => (
                  <BankCard
                    key={bank.id}
                    bank={bank}
                    onDelete={() => handleDeleteBank(bank.id)}
                    onToggleStatus={() => handleToggleStatus(bank.id, bank.status)}
                    onMove={() => handleMoveBank(bank.id, bank.type)}
                    onEdit={() => openEditDialog(bank)}
                    onViewHistory={() => {
                      setSelectedBank(bank)
                      setHistoryDialogOpen(true)
                    }}
                    canEdit={canEditBank}
                    canDelete={canDeleteBank}
                    formatCurrency={formatCurrency}
                  />
                ))}
                {depositBanks.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Belum ada bank deposit
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Withdraw Banks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              Withdraw
              <span className="text-sm font-normal text-muted-foreground">({withdrawBanks.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]">
              <div className="space-y-3">
                {withdrawBanks.map((bank) => (
                  <BankCard
                    key={bank.id}
                    bank={bank}
                    onDelete={() => handleDeleteBank(bank.id)}
                    onToggleStatus={() => handleToggleStatus(bank.id, bank.status)}
                    onMove={() => handleMoveBank(bank.id, bank.type)}
                    onEdit={() => openEditDialog(bank)}
                    onViewHistory={() => {
                      setSelectedBank(bank)
                      setHistoryDialogOpen(true)
                    }}
                    canEdit={canEditBank}
                    canDelete={canDeleteBank}
                    formatCurrency={formatCurrency}
                  />
                ))}
                {withdrawBanks.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Belum ada bank withdraw
                  </p>
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Bank - {selectedBank?.name}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditBank} className="space-y-4">
            <div>
              <Label htmlFor="edit-name">Nama Bank</Label>
              <Input
                id="edit-name"
                placeholder="Contoh: BCA, BRI, DANA, OVO"
                value={editFormData.name}
                onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-accountName">Nama Pemilik</Label>
              <Input
                id="edit-accountName"
                placeholder="Contoh: Vera, David"
                value={editFormData.accountName}
                onChange={(e) => setEditFormData({ ...editFormData, accountName: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-accountNumber">Nomor Rekening (Opsional)</Label>
              <Input
                id="edit-accountNumber"
                placeholder="Contoh: 1234567890"
                value={editFormData.accountNumber}
                onChange={(e) => setEditFormData({ ...editFormData, accountNumber: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="edit-balance">Saldo</Label>
              <Input
                id="edit-balance"
                type="number"
                placeholder="0"
                value={editFormData.balance}
                onChange={(e) => setEditFormData({ ...editFormData, balance: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={historyDialogOpen} onOpenChange={setHistoryDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>History - {selectedBank?.name} - {selectedBank?.accountName}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[600px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event</TableHead>
                  <TableHead>Old Value</TableHead>
                  <TableHead>New Value</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedBank?.bankHistories?.map((history: BankHistory) => (
                  <TableRow key={history.id}>
                    <TableCell>
                      <span className="font-medium">{history.eventType}</span>
                    </TableCell>
                    <TableCell>
                      {history.oldBalance !== null ? formatCurrency(history.oldBalance) : 
                       history.oldValue || history.oldType || '-'}
                    </TableCell>
                    <TableCell>
                      {history.newBalance !== null ? formatCurrency(history.newBalance) : 
                       history.newValue || history.newType || '-'}
                    </TableCell>
                    <TableCell>{history.notes || '-'}</TableCell>
                    <TableCell>{history.user?.username || '-'}</TableCell>
                    <TableCell>{formatDate(history.createdAt)}</TableCell>
                  </TableRow>
                ))}
                {selectedBank?.bankHistories?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      Belum ada history
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface BankCardProps {
  bank: Bank
  onDelete: () => void
  onToggleStatus: () => void
  onMove: () => void
  onEdit: () => void
  onViewHistory: () => void
  canEdit: boolean
  canDelete: boolean
  formatCurrency: (amount: number) => string
}

function BankCard({ bank, onDelete, onToggleStatus, onMove, onEdit, onViewHistory, canEdit, canDelete, formatCurrency }: BankCardProps) {
  return (
    <Card className={bank.status === 'online' ? 'border-green-500' : ''}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-semibold">{bank.name} - {bank.accountName}</h3>
            {bank.accountNumber && (
              <p className="text-sm text-muted-foreground">{bank.accountNumber}</p>
            )}
          </div>
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleStatus}
              title={bank.status === 'online' ? 'Set Offline' : 'Set Online'}
            >
              <Power className={`h-4 w-4 ${bank.status === 'online' ? 'text-green-500' : 'text-gray-400'}`} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onViewHistory}
              title="View History"
            >
              <History className="h-4 w-4" />
            </Button>
            {canEdit && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onEdit}
                  title="Edit Bank"
                >
                  <Edit2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onMove}
                  title={`Move to ${bank.type === 'DEPOSIT' ? 'Withdraw' : 'Deposit'}`}
                >
                  <ArrowRightLeft className="h-4 w-4" />
                </Button>
              </>
            )}
            {canDelete && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onDelete}
                title="Delete"
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            )}
            {!canEdit && !canDelete && (
              <Button
                variant="ghost"
                size="sm"
                disabled
                title="No Permission"
              >
                <Lock className="h-4 w-4 text-muted-foreground" />
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Status</span>
            <span className={`text-sm font-medium ${bank.status === 'online' ? 'text-green-600' : 'text-gray-600'}`}>
              {bank.status}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Balance</span>
            <span className="font-semibold">{formatCurrency(bank.balance)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

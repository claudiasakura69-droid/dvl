'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { AlertCircle, Plus, Lock, Edit2, Trash2, Search } from 'lucide-react'
import { toast } from 'sonner'

interface MistakeManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string } | null
  userPermission: 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW' | null
}

interface Mistake {
  id: string
  amount: number
  notes: string | null
  transactionId: string | null
  bankId: string | null
  bankName: string | null
  createdAt: string
  bank: {
    id: string
    name: string
    accountName: string
  } | null
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
}

// Permission helper functions
type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'
const canAddMistake = (perm: Permission | null) => perm !== 'VIEW' && perm !== null
const canEditMistake = (perm: Permission | null) => perm === 'MASTER' || perm === 'SUPPORT'
const canDeleteMistake = (perm: Permission | null) => perm === 'MASTER'

export default function MistakeManagementContent({ sessionId, user, userPermission }: MistakeManagementContentProps) {
  const [mistakes, setMistakes] = useState<Mistake[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedMistake, setSelectedMistake] = useState<Mistake | null>(null)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [formData, setFormData] = useState({
    amount: '',
    notes: '',
    bankId: '',
    transactionId: ''
  })
  const [editFormData, setEditFormData] = useState({
    amount: '',
    notes: '',
    bankId: '',
    transactionId: ''
  })

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchMistakes()
    }
  }, [sessionId, startDate, endDate])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchMistakes = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      let url = `/api/mistake?sessionId=${sessionId}`
      if (startDate && endDate) {
        url += `&startDate=${startDate}&endDate=${endDate}`
      }
      
      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setMistakes(data.mistakes)
      }
    } catch (error) {
      console.error('Error fetching mistakes:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/mistake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dicatat')
        setDialogOpen(false)
        setFormData({
          amount: '',
          notes: '',
          bankId: '',
          transactionId: ''
        })
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mencatat mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (mistake: Mistake) => {
    setSelectedMistake(mistake)
    setEditFormData({
      amount: mistake.amount.toString(),
      notes: mistake.notes || '',
      bankId: mistake.bankId || '',
      transactionId: mistake.transactionId || ''
    })
    setEditDialogOpen(true)
  }

  const handleEditMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedMistake) {
      toast.error('Session atau mistake tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/mistake/${selectedMistake.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...editFormData,
          sessionId
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedMistake(null)
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteMistake = async (mistakeId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus mistake ini?')) return

    try {
      const response = await fetch(`/api/mistake/${mistakeId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dihapus')
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const getBankName = (mistake: Mistake) => {
    if (mistake.bank) {
      return `${mistake.bank.name} - ${mistake.bank.accountName}`
    }
    return mistake.bankName || '-'
  }

  const filteredMistakes = mistakes.filter(mistake =>
    (mistake.notes && mistake.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (mistake.transactionId && mistake.transactionId.includes(searchQuery)) ||
    getBankName(mistake).toLowerCase().includes(searchQuery.toLowerCase())
  )

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const totalMistake = mistakes.reduce((sum, m) => sum + m.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <AlertCircle className="h-8 w-8" />
            Mistake
          </h1>
          <p className="text-muted-foreground">
            Catat kesalahan transaksi dan beban biaya kekurangan
          </p>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-auto"
            />
            <span>to</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-auto"
            />
          </div>

          <Dialog open={dialogOpen} onOpenChange={canAddMistake(userPermission) ? setDialogOpen : false}>
            <DialogTrigger asChild>
              <Button variant="destructive" disabled={!canAddMistake(userPermission)}>
                {!canAddMistake(userPermission) ? <Lock className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                Catat Mistake
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Catat Mistake</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddMistake} className="space-y-4">
                <div>
                  <Label htmlFor="bank">Bank (Opsional)</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tidak ada</SelectItem>
                      {banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="transactionId">Transaction ID (Opsional)</Label>
                  <Input
                    id="transactionId"
                    placeholder="ID transaksi yang terkait"
                    value={formData.transactionId}
                    onChange={(e) => setFormData({ ...formData, transactionId: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="amount">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Jelaskan kesalahan yang terjadi"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full" variant="destructive">
                  Catat
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          {/* Edit Dialog */}
          <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Mistake</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditMistake} className="space-y-4">
                <div>
                  <Label htmlFor="edit-bank">Bank (Opsional)</Label>
                  <Select
                    value={editFormData.bankId}
                    onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tidak ada</SelectItem>
                      {banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-transactionId">Transaction ID (Opsional)</Label>
                  <Input
                    id="edit-transactionId"
                    placeholder="ID transaksi yang terkait"
                    value={editFormData.transactionId}
                    onChange={(e) => setEditFormData({ ...editFormData, transactionId: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-amount">Nominal</Label>
                  <Input
                    id="edit-amount"
                    type="number"
                    placeholder="0"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
                  <Input
                    id="edit-notes"
                    placeholder="Jelaskan kesalahan yang terjadi"
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full" variant="destructive">
                  Update Mistake
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Cari berdasarkan catatan, transaction ID, atau bank..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
      `}</style>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Riwayat Kesalahan</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(totalMistake)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96 overflow-y-auto custom-scrollbar">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredMistakes.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada mistake</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Waktu</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead>Nominal</TableHead>
                    <TableHead>Bank</TableHead>
                    <TableHead>Catatan</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMistakes.map((mistake) => (
                    <TableRow key={mistake.id}>
                      <TableCell className="text-sm">{formatDate(mistake.createdAt)}</TableCell>
                      <TableCell className="font-medium">{mistake.user.username}</TableCell>
                      <TableCell className="text-red-600 font-semibold">{formatCurrency(mistake.amount)}</TableCell>
                      <TableCell>
                        <div className="font-medium">{getBankName(mistake)}</div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div>{mistake.notes || '-'}</div>
                          {mistake.transactionId && (
                            <div className="text-xs text-muted-foreground">TX: {mistake.transactionId}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{mistake.user.username}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {canEditMistake(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(mistake)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          )}
                          {canDeleteMistake(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteMistake(mistake.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { DollarSign, Plus, Edit2, Trash2, Search, Filter } from 'lucide-react'
import { toast } from 'sonner'

interface AkuranManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string } | null
  userPermission: 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW' | null
}

interface Akuran {
  id: string
  amount: number
  notes: string | null
  category: string | null
  createdAt: string
  bankId: string | null
  bankName: string | null
  user: {
    id: string
    username: string
  }
  bank: {
    id: string
    name: string
    accountName: string
  } | null
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: string
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

const canAddAkuran = (perm: Permission | null) => perm !== 'VIEW' && perm !== null
const canEditAkuran = (perm: Permission | null) => perm === 'MASTER' || perm === 'SUPPORT'
const canDeleteAkuran = (perm: Permission | null) => perm === 'MASTER'

export default function AkuranManagementContent({ sessionId, user, userPermission }: AkuranManagementContentProps) {
  const [akurans, setAkurans] = useState<Akuran[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedAkuran, setSelectedAkuran] = useState<Akuran | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString())
  const [formData, setFormData] = useState({
    amount: 0,
    notes: '',
    category: '',
    bankId: ''
  })
  const [editFormData, setEditFormData] = useState({
    amount: 0,
    notes: '',
    category: '',
    bankId: ''
  })
  
  useEffect(() => {
    fetchBanks()
    fetchAkurans()
  }, [sessionId, searchQuery, typeFilter, selectedYear])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchAkurans = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const params = new URLSearchParams({
        sessionId,
        search: searchQuery,
        type: typeFilter
      })
      
      // Add date filter for yearly data
      if (selectedYear) {
        params.append('startDate', `${selectedYear}-01-01`)
        params.append('endDate', `${selectedYear}-12-31`)
      }
      
      const response = await fetch(`/api/akuran?${params}`)
      const data = await response.json()

      if (data.success) {
        setAkurans(data.akurans)
      }
    } catch (error) {
      console.error('Error fetching akurans:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddAkuran = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) return

    try {
      const response = await fetch('/api/akuran', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          userId: user.id,
          ...formData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil dibuat')
        setAddDialogOpen(false)
        setFormData({
          amount: 0,
          notes: '',
          category: '',
          bankId: ''
        })
        fetchAkurans()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal membuat akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditAkuran = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedAkuran) return

    try {
      const response = await fetch(`/api/akuran/${selectedAkuran.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...editFormData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedAkuran(null)
        setEditFormData({
          amount: 0,
          notes: '',
          category: '',
          bankId: ''
        })
        fetchAkurans()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteAkuran = async (akuranId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus akuran ini?')) return

    try {
      const response = await fetch(`/api/akuran/${akuranId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil dihapus')
        fetchAkurans()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (akuran: Akuran) => {
    setSelectedAkuran(akuran)
    setEditFormData({
      amount: akuran.amount,
      notes: akuran.notes || '',
      category: akuran.category || '',
      bankId: akuran.bankId || ''
    })
    setEditDialogOpen(true)
  }

  const getBankName = (akuran: Akuran) => {
    if (akuran.bank) {
      return `${akuran.bank.name} - ${akuran.bank.accountName}`
    }
    return akuran.bankName || '-'
  }

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i)
  const withdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <DollarSign className="h-8 w-8" />
            Akuran Management
          </h1>
          <p className="text-muted-foreground">
            Kelola pembayaran tambahan
          </p>
        </div>

        {canAddAkuran(userPermission) && (
          <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah Akuran
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Akuran Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddAkuran} className="space-y-4">
                <div>
                  <Label htmlFor="bank">Bank (Opsional)</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tanpa Bank</SelectItem>
                      {withdrawBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Kategori</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih kategori" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UMR">UMR</SelectItem>
                      <SelectItem value="THR">THR</SelectItem>
                      <SelectItem value="BONUS">BONUS</SelectItem>
                      <SelectItem value="LAINNYA">LAINNYA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount || ''}
                    onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Catatan</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Search & Filter */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="relative md:col-span-2">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari akuran..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2 items-center">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select
            value={typeFilter}
            onValueChange={setTypeFilter}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Semua kategori" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Semua kategori</SelectItem>
              <SelectItem value="UMR">UMR</SelectItem>
              <SelectItem value="THR">THR</SelectItem>
              <SelectItem value="BONUS">BONUS</SelectItem>
              <SelectItem value="LAINNYA">LAINNYA</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Year Filter */}
      <div className="flex items-center gap-2">
        <Label>Year:</Label>
        <Select
          value={selectedYear}
          onValueChange={setSelectedYear}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {years.map((year) => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
      `}</style>

      {/* Akuran List */}
      <Card>
        <CardHeader>
          <CardTitle>List Akuran</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96 overflow-y-auto custom-scrollbar">
            {loading ? (
              <p>Memuat data...</p>
            ) : akurans.length === 0 ? (
              <p className="text-muted-foreground">Belum ada akuran yang ditemukan.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead>Bank</TableHead>
                    <TableHead>Nominal</TableHead>
                    <TableHead>Catatan</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {akurans.map((akuran) => (
                    <TableRow key={akuran.id}>
                      <TableCell>{formatDate(akuran.createdAt)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-muted rounded text-sm font-medium">
                          {akuran.category || '-'}
                        </span>
                      </TableCell>
                      <TableCell>{getBankName(akuran)}</TableCell>
                      <TableCell className="font-semibold">
                        {formatCurrency(akuran.amount)}
                      </TableCell>
                      <TableCell>{akuran.notes || '-'}</TableCell>
                      <TableCell>{akuran.user.username}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {canEditAkuran(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(akuran)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          )}
                          {canDeleteAkuran(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteAkuran(akuran.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Akuran</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditAkuran} className="space-y-4">
            <div>
              <Label htmlFor="edit-bank">Bank (Opsional)</Label>
              <Select
                value={editFormData.bankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tanpa Bank</SelectItem>
                  {withdrawBanks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-category">Kategori</Label>
              <Select
                value={editFormData.category}
                onValueChange={(value) => setEditFormData({ ...editFormData, category: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UMR">UMR</SelectItem>
                  <SelectItem value="THR">THR</SelectItem>
                  <SelectItem value="BONUS">BONUS</SelectItem>
                  <SelectItem value="LAINNYA">LAINNYA</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-amount">Nominal</Label>
              <Input
                id="edit-amount"
                type="number"
                placeholder="0"
                value={editFormData.amount || ''}
                onChange={(e) => setEditFormData({ ...editFormData, amount: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-notes">Catatan</Label>
              <Input
                id="edit-notes"
                placeholder="Catatan"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

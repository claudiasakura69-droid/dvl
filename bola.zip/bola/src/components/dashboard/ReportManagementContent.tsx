'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { BarChart3, FileSpreadsheet, Calendar, Lock, TrendingUp, TrendingDown, Wallet, CreditCard, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

interface ReportManagementContentProps {
  sessionId: string | null
  userPermission: string | null
}

interface MonthlyReport {
  month: string
  year: number
  totalTransactions: number
  totalDeposits: number
  totalWithdraws: number
  totalAmount: number
  totalExpenses: number
  totalInOut: number
  totalMistakes: number
  totalAkurans: number
}

type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'

export default function ReportManagementContent({ sessionId, userPermission }: ReportManagementContentProps) {
  const [reports, setReports] = useState<MonthlyReport[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [selectedMonth, setSelectedMonth] = useState('')
  const [viewMode, setViewMode] = useState<'summary' | 'daily'>('summary')

  const canExport = userPermission === 'MASTER'

  useEffect(() => {
    fetchReports()
  }, [sessionId, selectedYear, selectedMonth])

  const fetchReports = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const params = new URLSearchParams({
        sessionId,
        year: selectedYear.toString(),
        month: selectedMonth
      })
      const response = await fetch(`/api/reports?${params}`)
      const data = await response.json()

      if (data.success) {
        setReports(data.reports)
      }
    } catch (error) {
      console.error('Error fetching reports:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleExportExcel = async () => {
    if (!sessionId) return

    try {
      const params = new URLSearchParams({
        sessionId,
        year: selectedYear.toString(),
        month: selectedMonth
      })
      const response = await fetch(`/api/export?${params}&type=monthly-report`)
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `Laporan_${selectedYear}_${selectedMonth}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Laporan berhasil diekspor')
      } else {
        const data = await response.json()
        toast.error(data.error || 'Gagal mengekspor laporan')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat mengekspor')
    }
  }

  const formatCurrency = (amount: number) => {
    return `Rp ${amount.toLocaleString('id-ID')}`
  }

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i)
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ]

  // Calculate totals
  const totalDeposits = reports.reduce((sum, r) => sum + r.totalDeposits, 0)
  const totalWithdraws = reports.reduce((sum, r) => sum + r.totalWithdraws, 0)
  const totalExpenses = reports.reduce((sum, r) => sum + r.totalExpenses, 0)
  const totalMistakes = reports.reduce((sum, r) => sum + r.totalMistakes, 0)
  const totalAkurans = reports.reduce((sum, r) => sum + r.totalAkurans, 0)
  const netFlow = totalDeposits - totalWithdraws - totalExpenses - totalMistakes - totalAkurans

  // Simple bar chart component
  const SimpleBarChart = ({ data, max }: { data: Array<{ label: string; value: number; color: string }>, max: number }) => (
    <div className="flex items-end gap-2 h-48 w-full">
      {data.map((item, index) => (
        <div key={index} className="flex-1 flex flex-col items-center">
          <div 
            className="w-full rounded-t transition-all hover:opacity-80"
            style={{ 
              height: `${(item.value / max) * 100}%`,
              backgroundColor: item.color,
              minHeight: '4px'
            }}
            title={`${item.label}: ${formatCurrency(item.value)}`}
          />
          <div className="text-xs mt-2 text-center truncate w-full" title={item.label}>
            {item.label}
          </div>
        </div>
      ))}
    </div>
  )

  const chartData = reports.map(r => ({
    label: months[parseInt(r.month) - 1],
    value: r.totalDeposits + r.totalWithdraws,
    color: r.totalDeposits > r.totalWithdraws ? '#22c55e' : '#ef4444'
  }))

  const maxChartValue = Math.max(...chartData.map(d => d.value), 1)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <BarChart3 className="h-8 w-8" />
          Report Management
        </h1>
        <p className="text-muted-foreground">
          Statistik bulanan transaksi dan keuangan
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filter Laporan</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <Select
                value={selectedYear.toString()}
                onValueChange={(value) => setSelectedYear(parseInt(value))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <Select
                value={selectedMonth}
                onValueChange={setSelectedMonth}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Semua bulan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Semua bulan</SelectItem>
                  {months.map((month, index) => (
                    <SelectItem key={month} value={(index + 1).toString()}>
                      {month}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {canExport ? (
              <Button onClick={handleExportExcel} className="w-full md:w-auto">
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Export Excel
              </Button>
            ) : (
              <Button disabled className="w-full md:w-auto">
                <Lock className="mr-2 h-4 w-4" />
                Export Excel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deposit</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalDeposits)}</div>
            <p className="text-xs text-muted-foreground">Pemasukan total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Withdraw</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalWithdraws)}</div>
            <p className="text-xs text-muted-foreground">Penarikan total</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expenses</CardTitle>
            <CreditCard className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{formatCurrency(totalExpenses)}</div>
            <p className="text-xs text-muted-foreground">Pengeluaran operasional</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Flow</CardTitle>
            <Wallet className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${netFlow >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
              {formatCurrency(netFlow)}
            </div>
            <p className="text-xs text-muted-foreground">Aliran bersih</p>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Transaksi per Bulan</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96 overflow-y-auto">
            {loading ? (
              <p>Memuat data...</p>
            ) : reports.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada data laporan.</p>
            ) : (
              <SimpleBarChart data={chartData} max={maxChartValue} />
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Detailed Table */}
      <Card>
        <CardHeader>
          <CardTitle>Ringkasan Laporan</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96 overflow-y-auto">
            {loading ? (
              <p>Memuat data...</p>
            ) : reports.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada data laporan.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Periode</TableHead>
                    <TableHead>Transaksi</TableHead>
                    <TableHead>Deposit</TableHead>
                    <TableHead>Withdraw</TableHead>
                    <TableHead>Expenses</TableHead>
                    <TableHead>In/Out</TableHead>
                    <TableHead>Mistakes</TableHead>
                    <TableHead>Akurans</TableHead>
                    <TableHead>Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => (
                    <TableRow key={`${report.year}-${report.month}`}>
                      <TableCell>
                        <div className="font-medium">
                          {months[parseInt(report.month) - 1]} {report.year}
                        </div>
                      </TableCell>
                      <TableCell>{report.totalTransactions}</TableCell>
                      <TableCell className="text-green-600">{formatCurrency(report.totalDeposits)}</TableCell>
                      <TableCell className="text-red-600">{formatCurrency(report.totalWithdraws)}</TableCell>
                      <TableCell className="text-orange-600">{formatCurrency(report.totalExpenses)}</TableCell>
                      <TableCell className="text-blue-600">{formatCurrency(report.totalInOut)}</TableCell>
                      <TableCell className="text-purple-600">{formatCurrency(report.totalMistakes)}</TableCell>
                      <TableCell className="text-cyan-600">{formatCurrency(report.totalAkurans)}</TableCell>
                      <TableCell className="font-bold">{formatCurrency(report.totalAmount)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
      `}</style>
    </div>
  )
}

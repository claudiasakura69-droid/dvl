'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Receipt, Plus, Lock, Edit2, Trash2, Search } from 'lucide-react'
import { toast } from 'sonner'

interface ExpenseManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string } | null
  userPermission: 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW' | null
}

interface Expense {
  id: string
  amount: number
  notes: string | null
  category: string | null
  operation: string | null
  createdAt: string
  bankId: string | null
  bankName: string | null
  bank: {
    id: string
    name: string
    accountName: string
  } | null
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: string
}

// Permission helper functions
type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'
const canAddExpense = (perm: Permission | null) => perm !== 'VIEW' && perm !== null
const canEditExpense = (perm: Permission | null) => perm === 'MASTER' || perm === 'SUPPORT'
const canDeleteExpense = (perm: Permission | null) => perm === 'MASTER'

export default function ExpenseManagementContent({ sessionId, user, userPermission }: ExpenseManagementContentProps) {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [formData, setFormData] = useState({
    bankId: '',
    amount: '',
    operation: 'decrease' as 'increase' | 'decrease',
    notes: '',
    category: ''
  })
  const [editFormData, setEditFormData] = useState({
    bankId: '',
    amount: '',
    operation: 'decrease' as 'increase' | 'decrease',
    notes: '',
    category: ''
  })

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchExpenses()
    }
  }, [sessionId, startDate, endDate])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchExpenses = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      let url = `/api/expense?sessionId=${sessionId}`
      if (startDate && endDate) {
        url += `&startDate=${startDate}&endDate=${endDate}`
      }
      
      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setExpenses(data.expenses)
      }
    } catch (error) {
      console.error('Error fetching expenses:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/expense', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          bankId: '',
          amount: '',
          operation: 'decrease',
          notes: '',
          category: ''
        })
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menambahkan expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (expense: Expense) => {
    setSelectedExpense(expense)
    setEditFormData({
      bankId: expense.bankId || '',
      amount: expense.amount.toString(),
      operation: (expense.operation as 'increase' | 'decrease') || 'decrease',
      notes: expense.notes || '',
      category: expense.category || ''
    })
    setEditDialogOpen(true)
  }

  const handleEditExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedExpense) {
      toast.error('Session atau expense tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/expense/${selectedExpense.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...editFormData,
          sessionId
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedExpense(null)
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteExpense = async (expenseId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus expense ini?')) return

    try {
      const response = await fetch(`/api/expense/${expenseId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil dihapus')
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const getBankName = (expense: Expense) => {
    if (expense.bank) {
      return `${expense.bank.name} - ${expense.bank.accountName}`
    }
    return expense.bankName || '-'
  }

  const filteredExpenses = expenses.filter(expense =>
    (expense.category && expense.category.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (expense.notes && expense.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
    getBankName(expense).toLowerCase().includes(searchQuery.toLowerCase())
  )

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const totalExpense = expenses.reduce((sum, exp) => sum + exp.amount, 0)
  const depositBanks = banks.filter(b => b.type === 'DEPOSIT')
  const withdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Receipt className="h-8 w-8" />
            Expense
          </h1>
          <p className="text-muted-foreground">
            Catat pengeluaran operasional dan biaya lainnya
          </p>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-auto"
            />
            <span>to</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-auto"
            />
          </div>

          <Dialog open={dialogOpen} onOpenChange={canAddExpense(userPermission) ? setDialogOpen : false}>
            <DialogTrigger asChild>
              <Button disabled={!canAddExpense(userPermission)}>
                {!canAddExpense(userPermission) ? <Lock className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                Tambah Expense
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Expense</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddExpense} className="space-y-4">
                <div>
                  <Label htmlFor="bank">Bank (Opsional)</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank (opsional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tanpa Bank</SelectItem>
                      {formData.operation === 'increase' ? (
                        <>
                          {withdrawBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName}
                            </SelectItem>
                          ))}
                        </>
                      ) : (
                        <>
                          {withdrawBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName}
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="operation">Operation</Label>
                  <Select
                    value={formData.operation}
                    onValueChange={(value: 'increase' | 'decrease') => setFormData({ ...formData, operation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="decrease">Kurangi (Pengeluaran)</SelectItem>
                      <SelectItem value="increase">Tambah (Pemasukan)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category">Kategori (Opsional)</Label>
                  <Input
                    id="category"
                    placeholder="Contoh: Listrik, Sewa, Internet"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="amount">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan untuk pengeluaran ini"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          {/* Edit Dialog */}
          <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Expense</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditExpense} className="space-y-4">
                <div>
                  <Label htmlFor="edit-bank">Bank (Opsional)</Label>
                  <Select
                    value={editFormData.bankId}
                    onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank (opsional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Tanpa Bank</SelectItem>
                      {withdrawBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-operation">Operation</Label>
                  <Select
                    value={editFormData.operation}
                    onValueChange={(value: 'increase' | 'decrease') => setEditFormData({ ...editFormData, operation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="decrease">Kurangi (Pengeluaran)</SelectItem>
                      <SelectItem value="increase">Tambah (Pemasukan)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-category">Kategori (Opsional)</Label>
                  <Input
                    id="edit-category"
                    placeholder="Contoh: Listrik, Sewa, Internet"
                    value={editFormData.category}
                    onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-amount">Nominal</Label>
                  <Input
                    id="edit-amount"
                    type="number"
                    placeholder="0"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
                  <Input
                    id="edit-notes"
                    placeholder="Catatan untuk pengeluaran ini"
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Update Expense
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Cari berdasarkan kategori, catatan, atau bank..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
      `}</style>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Riwayat Pengeluaran</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(totalExpense)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="max-h-96 overflow-y-auto custom-scrollbar">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredExpenses.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada expense</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Waktu</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead>Bank</TableHead>
                    <TableHead>Operation</TableHead>
                    <TableHead>Catatan</TableHead>
                    <TableHead className="text-right">Nominal</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead className="text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell className="text-sm">{formatDate(expense.createdAt)}</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full bg-secondary text-secondary-foreground text-xs">
                          {expense.category || 'Umum'}
                        </span>
                      </TableCell>
                      <TableCell>{getBankName(expense)}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          expense.operation === 'increase' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {expense.operation === 'increase' ? 'Tambah' : 'Kurangi'}
                        </span>
                      </TableCell>
                      <TableCell>{expense.notes || '-'}</TableCell>
                      <TableCell className={`text-right font-semibold ${
                        expense.operation === 'increase' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatCurrency(expense.amount)}
                      </TableCell>
                      <TableCell className="text-sm">{expense.user.username}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {canEditExpense(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(expense)}
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                          )}
                          {canDeleteExpense(userPermission) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteExpense(expense.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

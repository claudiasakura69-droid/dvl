'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Calendar, Plus, Download, FileText, Lock, Edit2, Trash2, Search } from 'lucide-react'
import { toast } from 'sonner'

interface DayTransactionsContentProps {
  sessionId: string | null
  user: { id: string, username: string } | null
  userPermission: 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW' | null
}

interface Transaction {
  id: string
  date: string
  name: string
  accountNumber: string | null
  amount: number
  type: 'DEPOSIT' | 'WITHDRAW'
  bank: {
    id: string
    name: string
    accountName: string
    balance: number
  } | null
  bankName: string | null
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
  balance: number
  status: string
}

// Permission helper functions
type Permission = 'MASTER' | 'SUPERVISOR' | 'SUPPORT' | 'ADMIN' | 'VIEW'
const canAddTransaction = (perm: Permission | null) => perm !== 'VIEW' && perm !== null
const canEditTransaction = (perm: Permission | null) => perm === 'MASTER' || perm === 'SUPPORT'
const canDeleteTransaction = (perm: Permission | null) => perm === 'MASTER'
const canExportTransaction = (perm: Permission | null) => perm === 'MASTER'

export default function DayTransactionsContent({ sessionId, user, userPermission }: DayTransactionsContentProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [formData, setFormData] = useState({
    date: selectedDate,
    name: '',
    accountNumber: '',
    amount: '',
    type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
    bankId: ''
  })
  const [editFormData, setEditFormData] = useState({
    date: '',
    name: '',
    accountNumber: '',
    amount: '',
    type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
    bankId: ''
  })
  const [bulkData, setBulkData] = useState('')

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchTransactions()
    }
  }, [sessionId, selectedDate])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks.filter((b: Bank) => b.status === 'online'))
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchTransactions = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const dateParam = selectedDate || new Date().toISOString().split('T')[0]
      let url = `/api/daily-transactions?sessionId=${sessionId}&date=${dateParam}`
      
      if (startDate && endDate) {
        url = `/api/daily-transactions?sessionId=${sessionId}&startDate=${startDate}&endDate=${endDate}`
      }
      
      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setTransactions(data.transactions)
      }
    } catch (error) {
      console.error('Error fetching transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/daily-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          date: selectedDate,
          name: '',
          accountNumber: '',
          amount: '',
          type: 'DEPOSIT',
          bankId: ''
        })
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleBulkTransactions = async () => {
    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const lines = bulkData.split('\n').filter(line => line.trim())
      const transactions = lines.map(line => {
        const parts = line.split('\t')
        return {
          date: selectedDate,
          name: parts[0] || '',
          accountNumber: parts[1] || '',
          amount: parseFloat(parts[2]) || 0,
          type: parts[3]?.includes('WITHDRAW') ? 'WITHDRAW' : 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
          bankId: banks.find(b => `${b.name} - ${b.accountName}` === parts[3]?.trim())?.id || ''
        }
      }).filter(t => t.name && t.amount > 0 && t.bankId)

      const response = await fetch('/api/daily-transactions/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          transactions,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`${data.successCount} transaksi berhasil ditambahkan`)
        if (data.errorCount > 0) {
          toast.error(`${data.errorCount} transaksi gagal`)
        }
        setBulkDialogOpen(false)
        setBulkData('')
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleExport = async () => {
    if (!sessionId) return

    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          startDate: startDate || selectedDate,
          endDate: endDate || selectedDate
        })
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `transactions_${startDate || selectedDate}_to_${endDate || selectedDate}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Export berhasil')
      } else {
        toast.error('Gagal export data')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat export')
    }
  }

  const openEditDialog = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setEditFormData({
      date: transaction.date.split('T')[0],
      name: transaction.name,
      accountNumber: transaction.accountNumber || '',
      amount: transaction.amount.toString(),
      type: transaction.type,
      bankId: transaction.bank?.id || ''
    })
    setEditDialogOpen(true)
  }

  const handleEditTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !selectedTransaction) {
      toast.error('Session atau transaksi tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/daily-transactions/${selectedTransaction.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...editFormData,
          sessionId
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedTransaction(null)
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal mengupdate transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteTransaction = async (transactionId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) return

    try {
      const response = await fetch(`/api/daily-transactions/${transactionId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil dihapus')
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menghapus transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const getBankName = (transaction: Transaction) => {
    if (transaction.bank) {
      return `${transaction.bank.name} - ${transaction.bank.accountName}`
    }
    return transaction.bankName || 'Bank tidak tersedia'
  }

  const filteredTransactions = transactions.filter(tx =>
    tx.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (tx.accountNumber && tx.accountNumber.includes(searchQuery)) ||
    getBankName(tx).toLowerCase().includes(searchQuery.toLowerCase())
  )

  const deposits = filteredTransactions.filter(t => t.type === 'DEPOSIT')
  const withdraws = filteredTransactions.filter(t => t.type === 'WITHDRAW')
  const onlineDepositBanks = banks.filter(b => b.type === 'DEPOSIT')
  const onlineWithdrawBanks = banks.filter(b => b.type === 'WITHDRAW')

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const calculateTotal = (txs: Transaction[]) => txs.reduce((sum, tx) => sum + tx.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Calendar className="h-8 w-8" />
            Day Transactions
          </h1>
          <p className="text-muted-foreground">
            Catat transaksi harian deposit dan withdraw
          </p>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <div className="flex items-center gap-2">
            <Input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value)
                setSelectedDate(e.target.value)
              }}
              className="w-auto"
            />
            <span>to</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-auto"
            />
          </div>

          <Dialog open={dialogOpen} onOpenChange={canAddTransaction(userPermission) ? setDialogOpen : false}>
            <DialogTrigger asChild>
              <Button disabled={!canAddTransaction(userPermission)}>
                {!canAddTransaction(userPermission) ? <Lock className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                Tambah Transaksi
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Transaksi</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddTransaction} className="space-y-4">
                <div>
                  <Label htmlFor="txDate">Tanggal</Label>
                  <Input
                    id="txDate"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txName">Nama</Label>
                  <Input
                    id="txName"
                    placeholder="Nama pengirim/penerima"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txAccountNumber">Nomor Rekening (Opsional)</Label>
                  <Input
                    id="txAccountNumber"
                    placeholder="1234567890"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="txAmount">Nominal</Label>
                  <Input
                    id="txAmount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txType">Tipe</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEPOSIT">Deposit</SelectItem>
                      <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="txBank">Bank</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.type === 'DEPOSIT' ? (
                        <>
                          {onlineDepositBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      ) : (
                        <>
                          {onlineWithdrawBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={bulkDialogOpen} onOpenChange={canAddTransaction(userPermission) ? setBulkDialogOpen : false}>
            <DialogTrigger asChild>
              <Button variant="outline" disabled={!canAddTransaction(userPermission)}>
                {!canAddTransaction(userPermission) ? <Lock className="mr-2 h-4 w-4" /> : <FileText className="mr-2 h-4 w-4" />}
                Bulk Add
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Banyak Transaksi</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bulkData">Data Transaksi (Format: Nama{`\t`}Nomor Rek{`\t`}Nominal{`\t`}Bank)</Label>
                  <Input
                    id="bulkData"
                    placeholder="Nama{tab}Nomor Rek{tab}Nominal{tab}BCA - Vera"
                    value={bulkData}
                    onChange={(e) => setBulkData(e.target.value)}
                    className="font-mono text-xs"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Gunakan tab sebagai pemisah. Setiap baris adalah satu transaksi.
                  </p>
                </div>
                <Button onClick={handleBulkTransactions} className="w-full">
                  Simpan Semua
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Dialog */}
          <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
            <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Edit Transaksi</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditTransaction} className="space-y-4">
                <div>
                  <Label htmlFor="edit-txDate">Tanggal</Label>
                  <Input
                    id="edit-txDate"
                    type="date"
                    value={editFormData.date}
                    onChange={(e) => setEditFormData({ ...editFormData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-txName">Nama</Label>
                  <Input
                    id="edit-txName"
                    placeholder="Nama pengirim/penerima"
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-txAccountNumber">Nomor Rekening (Opsional)</Label>
                  <Input
                    id="edit-txAccountNumber"
                    placeholder="1234567890"
                    value={editFormData.accountNumber}
                    onChange={(e) => setEditFormData({ ...editFormData, accountNumber: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-txAmount">Nominal</Label>
                  <Input
                    id="edit-txAmount"
                    type="number"
                    placeholder="0"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-txType">Tipe</Label>
                  <Select
                    value={editFormData.type}
                    onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setEditFormData({ ...editFormData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEPOSIT">Deposit</SelectItem>
                      <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-txBank">Bank</Label>
                  <Select
                    value={editFormData.bankId}
                    onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank" />
                    </SelectTrigger>
                    <SelectContent>
                      {editFormData.type === 'DEPOSIT' ? (
                        <>
                          {onlineDepositBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      ) : (
                        <>
                          {onlineWithdrawBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full">
                  Update Transaksi
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={handleExport} disabled={!canExportTransaction(userPermission)}>
            {!canExportTransaction(userPermission) ? <Lock className="mr-2 h-4 w-4" /> : <Download className="mr-2 h-4 w-4" />}
            Export
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Cari berdasarkan nama, nomor rekening, atau bank..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #888; border-radius: 3px; }
      `}</style>

      {/* Bank Summary */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Online Deposit Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bank</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Today</TableHead>
                  <TableHead className="text-right">Final</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {onlineDepositBanks.map((bank) => {
                  const todayTotal = deposits.filter(t => t.bank.id === bank.id).reduce((sum, t) => sum + t.amount, 0)
                  return (
                    <TableRow key={bank.id}>
                      <TableCell>{bank.name} - {bank.accountName}</TableCell>
                      <TableCell className="text-right">{formatCurrency(bank.balance - todayTotal)}</TableCell>
                      <TableCell className="text-right text-green-600">+{formatCurrency(todayTotal)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(bank.balance)}</TableCell>
                    </TableRow>
                  )
                })}
                {onlineDepositBanks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      Tidak ada bank deposit online
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Online Withdraw Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bank</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Today</TableHead>
                  <TableHead className="text-right">Final</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {onlineWithdrawBanks.map((bank) => {
                  const todayTotal = withdraws.filter(t => t.bank.id === bank.id).reduce((sum, t) => sum + t.amount, 0)
                  return (
                    <TableRow key={bank.id}>
                      <TableCell>{bank.name} - {bank.accountName}</TableCell>
                      <TableCell className="text-right">{formatCurrency(bank.balance + todayTotal)}</TableCell>
                      <TableCell className="text-right text-red-600">-{formatCurrency(todayTotal)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(bank.balance)}</TableCell>
                    </TableRow>
                  )
                })}
                {onlineWithdrawBanks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      Tidak ada bank withdraw online
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Transactions */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Deposits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-green-600">Deposits</span>
              <span className="text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(deposits))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-96 overflow-y-auto custom-scrollbar">
              {loading ? (
                <p>Memuat data...</p>
              ) : deposits.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Belum ada transaksi deposit</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Nama</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {deposits.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="text-sm">{formatDate(tx.date)}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{tx.name}</div>
                            {tx.accountNumber && (
                              <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{getBankName(tx)}</TableCell>
                        <TableCell className="text-right text-green-600 font-semibold">
                          {formatCurrency(tx.amount)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            {canEditTransaction(userPermission) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(tx)}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                            )}
                            {canDeleteTransaction(userPermission) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteTransaction(tx.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Withdraws */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-red-600">Withdraws</span>
              <span className="text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(withdraws))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-96 overflow-y-auto custom-scrollbar">
              {loading ? (
                <p>Memuat data...</p>
              ) : withdraws.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Belum ada transaksi withdraw</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Nama</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {withdraws.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="text-sm">{formatDate(tx.date)}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{tx.name}</div>
                            {tx.accountNumber && (
                              <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{getBankName(tx)}</TableCell>
                        <TableCell className="text-right text-red-600 font-semibold">
                          {formatCurrency(tx.amount)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            {canEditTransaction(userPermission) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(tx)}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                            )}
                            {canDeleteTransaction(userPermission) && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteTransaction(tx.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

# Bank Management System

Aplikasi manajemen bank sistem lengkap dengan Next.js 16, Prisma, dan SQLite database.

## 🚀 Fitur Utama

- **User Management** - CRUD dengan role-based access control
- **Bank Management** - Kelola rekening deposit dan withdraw dengan balance tracking
- **Day Transactions** - Catat transaksi harian (deposit/withdraw)
- **In/Out Management** - Perpindahan antar bank
- **Expense Management** - Catat pengeluaran dengan opsi increase/decrease
- **Mistake Management** - Koreksi kesalahan transaksi
- **Akuran Management** - Pembayaran tahunan bulanan
- **Report Management** - Laporan bulanan dengan data agregasi
- **Calendar Management** - Kalender tahunan dengan highlight tanggal transaksi
- **Role-Based Access Control** - MASTER > SUPERVISOR > SUPPORT > ADMIN > VIEW

## 📋 Prerequisites

Sebelum instalasi, pastikan sudah terinstall:

- **Node.js** v18+ (disarankan v20+)
- **Bun** package manager (atau npm)
- **Git** untuk version control

## 🔧 Instalasi

### 1. Clone Repository

```bash
git clone <repository-url>
cd bank-management-system
```

### 2. Install Dependencies

```bash
# Menggunakan Bun (disarankan)
bun install

# Atau menggunakan npm
npm install
```

### 3. Setup Environment Variables

Buat file `.env` di root project:

```env
# Database
DATABASE_URL=file:./db/custom.db

# Server Port (opsional, default 3000)
PORT=3000

# Application Name (opsional)
NEXT_PUBLIC_APP_NAME="Bank Management System"
```

### 4. Setup Database

```bash
# Push Prisma schema ke database
bun run db:push

# (Opsional) Generate Prisma Client
bunx prisma generate

# (Opsional) Buka Prisma Studio untuk melihat database
bunx prisma studio
```

### 5. Seed MASTER User

Jika ini adalah instalasi baru, jalankan script seed:

```bash
# Jalankan script untuk membuat user MASTER
bun run seed

# Login dengan kredensial MASTER:
# Username: master
# Token: master123
```

## 🚀 Menjalankan Aplikasi

### Development Mode

```bash
# Menjalankan development server
bun run dev

# Aplikasi akan berjalan di:
# - Local: http://localhost:3000
# - Network: http://your-ip:3000
```

### Production Build

```bash
# Build untuk production
bun run build

# Menjalankan production server
bun run start
```

## 🌐 Deployment

### Deploy ke Vercel

#### 1. Push ke GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

#### 2. Deploy ke Vercel

```bash
# Install Vercel CLI (jika belum)
npm i -g vercel

# Login ke Vercel
vercel login

# Deploy project
vercel

# Atau langsung deploy tanpa CLI
# Buka https://vercel.com/new dan import repository GitHub Anda
```

#### 3. Setup Environment Variables di Vercel

Di dashboard Vercel, tambahkan environment variables:

1. Buka project di Vercel Dashboard
2. Klik **Settings** → **Environment Variables**
3. Tambahkan:

```env
DATABASE_URL=file:./db/custom.db
```

**⚠️ CATATAN PENTING UNTUK VERCEL:**

Vercel menggunakan **file system yang read-only** di production. Untuk database SQLite:

**Opsi 1: Gunakan Neon PostgreSQL (Recommended)**

1. Buat akun gratis di https://neon.tech/
2. Buat database baru
3. Copy connection string
4. Update `.env`:

```env
DATABASE_URL=postgresql://<neon-connection-string>
```

5. Update `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

6. Push schema:

```bash
bun run db:push
```

**Opsi 2: Gunakan Vercel Postgres (Recommended)**

1. Buat database di Vercel Postgres
2. Copy connection string
3. Update `.env`:

```env
DATABASE_URL=postgresql://<vercel-connection-string>
```

4. Update `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

### Deploy ke Cloudflare Pages

#### 1. Persiapan untuk Cloudflare

Buat file `wrangler.toml` di root project:

```toml
name = "bank-management-system"
compatibility_date = "2024-01-01"
compatibility_flags = ["nodejs_compat"]

[build]
command = "bun run build"

[[routes]]
pattern = "/*"
custom_domain = true

[[routes]]
pattern = "/api/*"
zone_id = "<your-zone-id>"

[vars]
DATABASE_URL = "postgresql://<your-database-url>"
```

#### 2. Build Project

```bash
bun run build
```

#### 3. Deploy ke Cloudflare Pages

```bash
# Install Wrangler CLI (jika belum)
npm install -g wrangler

# Login ke Cloudflare
wrangler login

# Deploy
wrangler pages deploy .next

# Atau gunakan Cloudflare Dashboard
# Buka https://dash.cloudflare.com/ → Pages → Create project → Upload
```

**⚠️ CATATAN PENTING UNTUK CLOUDFLARE:**

Cloudflare Pages juga memiliki file system read-only. Gunakan:

1. **Cloudflare D1** untuk SQLite:
   ```env
   DATABASE_URL="file:./db/custom.db"
   ```
   Tetapi D1 tidak persistent untuk SQLite.

2. **Neon PostgreSQL** (Recommended):
   - Buat database di Neon
   - Update `.env` dengan connection string
   - Update schema untuk PostgreSQL

3. **Supabase** (Alternative):
   - Buat database di Supabase
   - Update connection string
   - Update schema untuk PostgreSQL

## 🗄️ Database Schema

### Models

**User**
- id, username, token, permission, isActive, createdAt, updatedAt
- Relations: sessions, transactions, bankHistories

**UserSession**
- id, userId, loginAt, logoutAt, ipAddress, createdAt
- Used untuk session management dan tracking login/logout

**Bank**
- id, name, accountName, accountNumber, type (DEPOSIT/WITHDRAW), balance, status (online/offline), createdAt, updatedAt
- Relations: dailyTransactions, bankHistories, inOuts, expenses, mistakes, akurans

**DailyTransaction**
- id, date, name, accountNumber, amount, type (DEPOSIT/WITHDRAW), bankId (nullable), bankName, userId, createdAt
- Catat transaksi harian

**InOut**
- id, fromBankId, toBankId, fromBankName, toBankName, amount, notes, userId, createdAt
- Perpindahan antar bank

**Expense**
- id, amount, operation (increase/decrease), notes, category, bankId (nullable), bankName, userId, createdAt
- Pengeluaran dengan opsi tambah/kurang

**Mistake**
- id, amount, notes, bankId (nullable), bankName, transactionId, userId, createdAt
- Koreksi kesalahan

**Akuran**
- id, amount, notes, category, bankId (nullable), bankName, userId, createdAt
- Pembayaran tahunan bulanan

**BankHistory**
- id, bankId, eventType, oldValue, newValue, oldBalance, newBalance, oldType, newType, notes, userId, createdAt
- Tracking semua perubahan bank

## 👥 Role-Based Access Control

| Role | User Management | Bank Management | Transactions (Create) | Transactions (Edit) | Transactions (Delete) | Calendar (Delete Data) |
|-------|----------------|-------------------|---------------------|-------------------|----------------------|------------------------|
| MASTER | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| SUPERVISOR | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| SUPPORT | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ |
| ADMIN | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |
| VIEW | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |

## 🔐 Default Credentials

Setelah instalasi, login dengan:

```
Username: master
Token: master123
Role: MASTER
```

**⚠️ PENTING:** Ganti kredensial ini di production environment!

## 📁 Project Structure

```
bank-management-system/
├── db/
│   └── custom.db              # SQLite database file
├── prisma/
│   ├── schema.prisma          # Database schema
│   └── seed.ts              # Seed script
├── public/                   # Static files
├── src/
│   ├── app/
│   │   ├── api/              # API routes
│   │   │   ├── auth/
│   │   │   ├── banks/
│   │   │   ├── users/
│   │   │   ├── daily-transactions/
│   │   │   ├── inout/
│   │   │   ├── expense/
│   │   │   ├── mistake/
│   │   │   ├── akuran/
│   │   │   ├── report/
│   │   │   ├── calendar/
│   │   │   └── export/
│   │   └── page.tsx          # Main page
│   ├── components/
│   │   ├── ui/               # shadcn/ui components
│   │   └── dashboard/         # Dashboard components
│   ├── lib/
│   │   ├── db.ts             # Prisma client
│   │   └── utils.ts          # Utility functions
│   └── app/
│       ├── globals.css        # Global styles
│       └── layout.tsx         # Root layout
├── .env                      # Environment variables (GABUNGKAN MANUAL)
├── package.json
├── tsconfig.json
├── next.config.mjs
└── README.md
```

## 🔧 Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|-----------|
| DATABASE_URL | Database connection string | file:./db/custom.db | Yes |
| PORT | Server port | 3000 | No |
| NEXT_PUBLIC_APP_NAME | Application name | Bank Management System | No |

## 🚨 Troubleshooting

### Build Error

```bash
# Clean cache dan rebuild
rm -rf .next node_modules/.cache
bun run build
```

### Database Connection Error

```bash
# Reset database
rm db/custom.db
bun run db:push
```

### Port Already in Use

```bash
# Kill process di port 3000
lsof -ti:3000 | xargs kill -9

# Atau gunakan port lain
PORT=3001 bun run dev
```

### TypeScript Errors

```bash
# Regenerate Prisma Client
bunx prisma generate
```

## 📊 Available Scripts

```bash
# Development
bun run dev              # Start dev server

# Building
bun run build           # Build untuk production
bun run start           # Start production server

# Database
bun run db:push         # Push schema ke database
bun run db:studio       # Buka Prisma Studio
bun run db:seed         # Seed database dengan MASTER user

# Code Quality
bun run lint            # Run ESLint
bun run type-check      # Run TypeScript check
```

## 🎨 Tech Stack

- **Framework**: Next.js 16.1.3 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI Components**: shadcn/ui (New York style)
- **Database ORM**: Prisma 6.19.2
- **Database**: SQLite (development) / PostgreSQL (production)
- **Package Manager**: Bun
- **Icons**: Lucide React
- **Toast Notifications**: Sonner

## 📝 License

Copyright © 2025 Bank Management System. All rights reserved.

## 🤝 Support

Untuk support atau pertanyaan:
- Buka issue di GitHub repository
- Atau hubungi tim pengembang

---

**Catatan:**
- Pastikan untuk mengubah kredensial default di production
- Gunakan database PostgreSQL untuk deployment production (Neon, Supabase, Vercel Postgres, dll)
- Backup database secara berkala
- Review logs production untuk monitoring

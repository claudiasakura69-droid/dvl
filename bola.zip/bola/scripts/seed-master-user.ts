import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Check if MASTER user already exists
  const existingMaster = await prisma.user.findFirst({
    where: { permission: 'MASTER' }
  })

  if (existingMaster) {
    console.log('MASTER user already exists:', existingMaster.username)
    return
  }

  // Create MASTER user from environment variables or defaults
  const masterUsername = process.env.MASTER_USERNAME || 'master'
  const masterToken = process.env.MASTER_TOKEN || 'master123'

  const master = await prisma.user.create({
    data: {
      username: masterUsername,
      token: masterToken,
      permission: 'MASTER',
      isActive: true
    }
  })

  console.log('MASTER user created successfully!')
  console.log('Username:', master.username)
  console.log('Token:', master.token)
  console.log('Permission:', master.permission)
}

main()
  .catch((e) => {
    console.error('Error seeding MASTER user:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

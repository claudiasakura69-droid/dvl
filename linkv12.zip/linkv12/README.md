# ShortURL Platform

Platform manajemen Short URL (clone Dub.co) — Next.js, Prisma, Neon PostgreSQL, Cloudflare Pages.

## Tech Stack

| Technology              | Versi / Keterangan                   |
|-------------------------|--------------------------------------|
| **Next.js**             | 16 (App Router)                      |
| **TypeScript**          | 5.x                                  |
| **Prisma**              | 6.11.1 (driverAdapters)              |
| **PostgreSQL**          | Neon (serverless, HTTP-based)        |
| **Tailwind CSS**        | 4.x                                  |
| **shadcn/ui**           | Radix UI + Tailwind                  |
| **Cloudflare Pages**    | @opennextjs/cloudflare               |
| **QR Code**             | react-qr-code (SVG)                  |
| **State Management**    | Zustand                              |

---

## Quick Start

```bash
# 1. Install
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
npm install

# 2. Setup .env
cp .env.example .env
# Edit .env — isi DATABASE_URL, DASHBOARD_TOKEN, APP_DOMAIN

# 3. Database
npx prisma db push
npx prisma generate

# 4. Run
npm run dev
# Buka http://localhost:3000
```

---

## Environment Variables

| Variable                   | Required | Description                                       |
|----------------------------|----------|---------------------------------------------------|
| `DATABASE_URL`             | ✅       | Neon PostgreSQL connection string                  |
| `DASHBOARD_TOKEN`          | ✅       | Login token (min. 12 karakter)                    |
| `APP_DOMAIN`               | ✅       | Domain utama dashboard                            |
| `CLOUDFLARE_ACCOUNT_ID`    | Opsional | CF Account ID (auto-verify domain)                |
| `CLOUDFLARE_API_TOKEN`     | Opsional | CF API Token (Zone:Read, DNS:Edit, Pages:Edit)    |

---

## Deploy ke Cloudflare Pages

### Build Settings

| Setting               | Value                               |
|-----------------------|-------------------------------------|
| **Framework preset**  | `None`                              |
| **Build command**     | `npx opennextjs-cloudflare build`   |
| **Build output dir**  | `.open-next`                         |
| **Node.js version**   | `18` atau `20`                      |

### Environment Variables

Tambahkan di **BOTH** tab Production dan Preview:

- `DATABASE_URL` — Neon connection string
- `DASHBOARD_TOKEN` — Login token
- `APP_DOMAIN` — `*.pages.dev` URL atau custom domain

### File yang WAJIB ada di repo

- `wrangler.jsonc` — Mengandung `nodejs_compat` (TANPA `[vars]` section!)
- `open-next.config.ts`
- `public/_headers`

> ⚠️ Jika `wrangler.jsonc` mengandung `[vars]`, env vars dari dashboard akan di-override → halaman blank.

Panduan lengkap: [docs/INSTALLATION-GUIDE.md](./docs/INSTALLATION-GUIDE.md)

---

## Fitur

- **Multi-domain** — Satu dashboard, banyak domain short URL
- **Multi-target routing** — Sequential / random redirect
- **Analytics** — Tracking klik, device, browser, lokasi
- **QR Code** — SVG QR code untuk setiap link
- **Custom domain** — Auto-verify via Cloudflare API
- **Health check** — Monitoring target URL
- **Bulk operations** — Import, export, migrasi domain
- **Dashboard** — shadcn/ui, dark mode, responsive

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| `File is not defined` (npm run dev) | `next.config.ts` tidak boleh mengandung `initOpenNextCloudflareForDev()` |
| Halaman blank setelah deploy | Pastikan `wrangler.jsonc` ada dan tidak punya `[vars]` |
| `Cannot find native binding` | `rm -rf node_modules package-lock.json && npm install` |
| Login tidak bisa | Cek `DASHBOARD_TOKEN` di `.env`, min 12 karakter |

# Panduan Instalasi & Deployment — ShortURL Platform

> Platform manajemen Short URL (clone Dub.co) — **Next.js + Prisma + Neon PostgreSQL + Cloudflare Pages**
>
> Berdasarkan [OpenNext Cloudflare official documentation](https://opennext.js.org/cloudflare/get-started).

---

## 1. Prasyarat

| Tool                    | Versi Minimum | Download                                |
|-------------------------|---------------|-----------------------------------------|
| **Node.js**             | 18.x+         | https://nodejs.org                       |
| **pnpm** (recommended)  | 8.x+          | `npm i -g pnpm`                          |
| **npm** (alternatif)    | 9.x+          | (termasuk saat install Node.js)          |
| **Git**                 | Terbaru       | https://git-scm.com                      |
| **Neon PostgreSQL**     | -             | https://console.neon.tech (gratis)       |
| **Akun Cloudflare**     | -             | https://dash.cloudflare.com (gratis)     |

---

## 2. Instalasi Lokal

### Step 1: Clone & Install

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform

# Install dependencies
pnpm install          # atau: npm install
```

> **Jika error "Cannot find native binding":**
> ```bash
> rm -rf node_modules package-lock.json
> npm install
> ```

### Step 2: Setup Environment Variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
DATABASE_URL="postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require"
DASHBOARD_TOKEN="MySecretToken123"
APP_DOMAIN="yourdomain.com"
```

### Step 3: Setup Database

```bash
npx prisma db push
npx prisma generate
```

### Step 4: Jalankan

```bash
npm run dev
```

Buka **http://localhost:3000** → halaman login akan muncul → masukkan token dari `DASHBOARD_TOKEN`.

---

## 3. Konfigurasi Database (Neon)

1. Buka https://console.neon.tech → **Create Project**
2. Pilih region terdekat (Singapore direkomendasikan)
3. Copy connection string dari **Connection Details**
4. Paste ke `.env` sebagai `DATABASE_URL`

Format: `postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`

---

## 4. Deployment ke Cloudflare Pages

### 4.1 Persiapan

Pastikan file-file berikut ada di repository:

| File                   | Keterangan                                    |
|------------------------|-----------------------------------------------|
| `wrangler.jsonc`       | ✅ WAJIB — `nodejs_compat` dan build config     |
| `open-next.config.ts`  | ✅ WAJIB — OpenNext CF adapter config           |
| `next.config.ts`       | ✅ WAJIB — Next.js config                       |
| `package.json`         | ✅ WAJIB — dependencies & scripts               |
| `.npmrc`               | ✅ WAJIB — `force=true`                         |
| `.env.example`         | ✅ WAJIB — template env vars                    |
| `public/_headers`      | ✅ WAJIB — static asset caching                 |
| `prisma/schema.prisma` | ✅ WAJIB — database schema                      |

### ⚠️ `wrangler.jsonc` WAJIB ada di repository!

File ini mengandung `nodejs_compat` — **tanpa ini, `process.env` tidak bekerja di Cloudflare Workers** dan halaman akan blank.

**JANGAN tambahkan `[vars]` ke `wrangler.jsonc`!** Jika ada `[vars]`, nilai-nilai tersebut akan meng-override env vars dari CF Pages dashboard.

### 4.2 Push ke GitHub

```bash
git add .
git commit -m "Deploy to Cloudflare Pages"
git push origin main
```

### 4.3 Build Settings di CF Pages

| Setting               | Value                                              |
|-----------------------|----------------------------------------------------|
| **Framework preset**  | `None`                                             |
| **Build command**     | `npx opennextjs-cloudflare build`                  |
| **Build output dir**  | `.open-next`                                        |
| **Node.js version**   | `18` atau `20`                                     |

> **Mengapa `npx opennextjs-cloudflare build`?**
> Perintah ini otomatis menjalankan `npm run build` (yaitu `prisma generate && next build`) lalu mengkonversi output ke format Cloudflare Worker.

### 4.4 Environment Variables di CF Pages

1. Buka **Workers & Pages** → project kamu → **Settings** → **Environment Variables**
2. Tambahkan variabel di **KEDUA** tab (Production + Preview):

| Variable                   | Tab                     |
|----------------------------|-------------------------|
| `DATABASE_URL`             | Production + Preview    |
| `DASHBOARD_TOKEN`          | Production + Preview    |
| `APP_DOMAIN`               | Production + Preview    |

3. **SETELAH menambahkan, WAJIB push commit baru** atau klik "Retry deployment"

### 4.5 Tentang APP_DOMAIN

- **Pertama deploy via *.pages.dev:** Set `APP_DOMAIN` ke URL pages.dev kamu (contoh: `my-shorturl.pages.dev`)
- **Sudah punya custom domain:** Set `APP_DOMAIN` ke custom domain (contoh: `yourdomain.com`)

---

## 5. Custom Domain

1. CF Pages project → **Custom domains** → **Set up a custom domain**
2. Masukkan domain (contoh: `yourdomain.com`)
3. SSL certificate otomatis (15-30 menit)
4. Update `APP_DOMAIN` di env vars

---

## 6. Troubleshooting

### Error `File is not defined` (npm run dev)

```
ReferenceError: File is not defined
```

**Penyebab:** `initOpenNextCloudflareForDev()` di `next.config.ts` tidak kompatibel dengan Node.js 18.

**Solusi:** Pastikan `next.config.ts` TIDAK mengandung `initOpenNextCloudflareForDev()`. File ini tidak diperlukan untuk project ini (hanya diperlukan untuk Cloudflare-specific bindings seperti KV/R2).

### Deploy berhasil tapi halaman blank

1. Buka DevTools (F12) → Console tab
2. Pastikan `wrangler.jsonc` ADA di repo dengan `nodejs_compat`
3. Pastikan `wrangler.jsonc` TIDAK punya `[vars]`
4. Pastikan env vars sudah di-set di KEDUA tab (Production + Preview)
5. Setelah mengubah env vars, push commit baru

### Error `Cannot find native binding` (@tailwindcss/oxide)

```bash
rm -rf node_modules package-lock.json
npm install
```

### Error `ERESOLVE` (npm peer dependency conflict)

Pastikan `.npmrc` berisi `force=true`. Atau gunakan `pnpm install`.

### Login tidak bisa

1. Pastikan `DASHBOARD_TOKEN` ada di `.env` (min 12 karakter)
2. Restart dev server setelah mengubah `.env`
3. DevTools Console: `localStorage.removeItem("token")` → reload

---

## 7. File yang Wajib Ada di Repository

```
wrangler.jsonc         ✅ WAJIB — compatibility flags (nodejs_compat)
open-next.config.ts    ✅ WAJIB — OpenNext CF adapter config
next.config.ts         ✅ WAJIB — Next.js config
package.json           ✅ WAJIB — dependencies & build scripts
.npmrc                 ✅ WAJIB — force=true
.env.example           ✅ WAJIB — template env vars
public/_headers        ✅ WAJIB — static asset caching
prisma/schema.prisma   ✅ WAJIB — database schema
```

**JANGAN commit:**

```
.env              # env vars lokal (rahasia)
.dev.vars         # local dev secrets (rahasia)
wrangler.toml     # legacy format — gunakan wrangler.jsonc
.next/            # Next.js build output
.open-next/       # OpenNext build output
node_modules/
```

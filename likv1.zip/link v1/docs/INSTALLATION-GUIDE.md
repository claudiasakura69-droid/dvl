# Panduan Lengkap Instalasi & Deployment — ShortURL Platform

> Platform manajemen Short URL (clone Dub.co) yang dibangun dengan **Next.js 16 + Prisma + TypeScript + Tailwind CSS 4 + shadcn/ui**.
>
> Panduan ini ditulis dalam **Bahasa Indonesia** dengan istilah teknis dalam bahasa Inggris untuk kemudahan referensi. Panduan bersifat **self-contained** — seseorang tanpa pengetahuan sebelumnya seharusnya dapat mengikuti langkah-langkah ini dari nol hingga production.

---

## Daftar Isi (Table of Contents)

1. [Prasyarat (Prerequisites)](#1-prasyarat-prerequisites)
2. [Arsitektur & Cara Kerja (Architecture & How It Works)](#2-arsitektur--cara-kerja-architecture--how-it-works)
3. [Instalasi Lokal (Local Installation)](#3-instalasi-lokal-local-installation)
4. [Setup Database — Neon Tech (PostgreSQL)](#4-setup-database--neon-tech-postgresql)
5. [Setup Database — TiDB (Alternatif)](#5-setup-database--tidb-alternatif)
6. [Push ke GitHub](#6-push-ke-github)
7. [Deploy ke Cloudflare Pages](#7-deploy-ke-cloudflare-pages)
8. [Setup Domain Utama (Main Domain)](#8-setup-domain-utama-main-domain))
9. [Setup Domain Short URL](#9-setup-domain-short-url))
10. [Menambahkan Banyak Domain Short URL](#10-menambahkan-banyak-domain-short-url-multiple-short-url-domains))
11. [Migrasi Domain](#11-migrasi-domain)
12. [Keamanan & Security Rules](#12-keamanan--security-rules))
13. [404 Handling](#13-404-handling)
14. [Konfigurasi Environment Variables (Complete Reference)](#14-konfigurasi-environment-variables-complete-reference))
15. [Troubleshooting](#15-troubleshooting)
16. [Alur Kerja Lengkap (Complete Workflow Summary)](#16-alur-kerja-lengkap-complete-workflow-summary))
17. [Appendix: Contoh .env.example](#17-appendix-contoh-envexample)

---

## 1. Prasyarat (Prerequisites)

Sebelum memulai instalasi, pastikan kamu sudah memenuhi prasyarat berikut:

### Software yang Diperlukan

| Software | Versi Minimum | Keterangan | Cara Install |
|---|---|---|---|
| **Node.js** | 18+ | Runtime JavaScript | `nvm install 18` |
| **Bun** | Latest | Runtime & package manager | `curl -fsSL https://bun.sh/install \| bash` |
| **Git** | 2.30+ | Version control | Lihat petunjuk di bawah |

> **Note:** Bun adalah package manager utama di project ini, namun kamu tetap memerlukan Node.js karena beberapa tooling bergantung padanya.

### Akun yang Diperlukan

| Layanan | URL | Keterangan |
|---|---|---|
| **GitHub** | https://github.com | Untuk source code repository |
| **Cloudflare** | https://dash.cloudflare.com | Untuk deployment, DNS, & custom domain |
| **Neon Tech** | https://neon.tech | Database PostgreSQL serverless (rekomendasi) |
| **TiDB Cloud** | https://tidbcloud.com | Alternatif database (opsional) |

### Install Bun

```bash
# macOS / Linux
curl -fsSL https://bun.sh/install | bash

# Verifikasi instalasi
bun --version
```

### Install Node.js (menggunakan nvm)

```bash
# Install nvm (Node Version Manager)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash

# Restart terminal atau jalankan:
source ~/.bashrc   # untuk Bash
source ~/.zshrc    # untuk Zsh

# Install Node.js 18+
nvm install 18
nvm use 18

# Verifikasi
node --version   # harus menampilkan v18.x.x atau lebih tinggi
npm --version
```

### Install Git

```bash
# Ubuntu / Debian
sudo apt update && sudo apt install git -y

# macOS (via Homebrew)
brew install git

# Verifikasi
git --version    # harus menampilkan 2.30 atau lebih tinggi
```

---

## 2. Arsitektur & Cara Kerja (Architecture & How It Works)

> ⚠️ **Bagian ini SANGAT PENTING untuk dipahami sebelum melakukan setup domain.** Seluruh arsitektur platform bergantung pada konsep ini.

### Konsep Utama: Dua Jenis Domain, Satu Project

Platform ini menggunakan **satu project Next.js** yang di-deploy ke **Cloudflare Pages**, namun melayani **dua fungsi berbeda** berdasarkan domain yang diakses:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    SINGLE CLOUDFLARE PAGES PROJECT                  │
│                  shorturl-platform.pages.dev                        │
│                                                                     │
│  ┌──────────────────────────┐   ┌──────────────────────────────┐   │
│  │     MAIN DOMAIN          │   │     SHORT URL DOMAIN(S)      │   │
│  │     abc.com              │   │     abc.me                   │   │
│  │     www.abc.com          │   │     go.example.com           │   │
│  │                          │   │     link.company.com         │   │
│  │                          │   │                              │   │
│  │  Fungsi:                 │   │  Fungsi:                     │   │
│  │  • Dashboard SPA         │   │  • Redirect short URL        │   │
│  │  • Login page            │   │  • abc.me/promo → target    │   │
│  │  • Link management       │   │  • go.example.com/x → target│   │
│  │  • Analytics             │   │  • Record clicks             │   │
│  │  • Domain management     │   │  • Show 404/expired pages    │   │
│  │  • Settings              │   │  • Password protection       │   │
│  └──────────────────────────┘   └──────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

### Diagram Alur (Flowchart)

```
                        Pengunjung mengakses URL
                                 │
                                 ▼
                    ┌────────────────────────┐
                    │   Cloudflare Pages     │
                    │   (satu project)       │
                    └───────────┬────────────┘
                                │
                                ▼
                    ┌────────────────────────┐
                    │  Next.js Middleware     │
                    │  (src/middleware.ts)    │
                    │                         │
                    │  Cek Host header vs     │
                    │  APP_DOMAIN env var     │
                    └───────────┬────────────┘
                                │
                    ┌───────────┴────────────┐
                    │                          │
              Host = APP_DOMAIN?         Host ≠ APP_DOMAIN?
              atau *.pages.dev
                    │                          │
                    ▼                          ▼
        ┌──────────────────┐      ┌─────────────────────────┐
        │ MAIN DOMAIN      │      │ SHORT URL DOMAIN        │
        │ (abc.com)        │      │ (abc.me, go.example.com)│
        │                  │      │                         │
        │ Pass-through ke  │      │ Rewrite ke /s/[slug]    │
        │ Dashboard SPA    │      │ redirect handler        │
        │                  │      │                         │
        │ Halaman yang     │      │ Menambahkan ?host=      │
        │ dimuat:          │      │ query parameter         │
        │ • / → Login      │      │                         │
        │ • /links → Tabel │      └───────────┬─────────────┘
        │ • /domains → List │                  │
        │ • /analytics     │                  ▼
        │ • /settings      │      ┌─────────────────────────┐
        │ • /404 → NotFound│      │ Route Handler           │
        └──────────────────┘      │ /s/[slug]/route.ts      │
                                  │                         │
                                  │ 1. Baca ?host= dari URL │
                                  │ 2. Cari domain di DB    │
                                  │ 3. Cari link by slug    │
                                  │ 4. Cek: active? expired?│
                                  │ 5. Cek: password?       │
                                  │ 6. Tentukan target URL  │
                                  │ 7. Record click di DB   │
                                  │ 8. Return 301 redirect  │
                                  └───────────┬─────────────┘
                                              │
                                  ┌───────────┼─────────────┐
                                  │           │             │
                                  ▼           ▼             ▼
                              Slug        Slug         Slug
                              ditemukan   tidak ada     expired
                                  │           │             │
                                  ▼           ▼             ▼
                              301 Redirect  404 HTML   410 Expired
                              ke target     Page       HTML Page
```

### Cara Kerja Middleware (`src/middleware.ts`)

Middleware berjalan di **setiap request** ke Cloudflare Pages. Berikut logika deteksinya:

1. **Ekstrak Host header** dari request masuk (contoh: `abc.me`, `abc.com`)
2. **Skip** jika path adalah API route (`/api/*`), static asset (`/_next/*`, file dengan extension), atau internal route
3. **Tentukan main domain** dari environment variable `APP_DOMAIN` (contoh: `abc.com`)
4. **Bandingkan** Host header dengan main domain:
   - Jika `host === "abc.com"` **atau** `host === "www.abc.com"` → **Main Domain** → `NextResponse.next()` (pass-through ke dashboard SPA)
   - Jika `host.endsWith(".pages.dev")` → juga dianggap Main Domain (untuk development)
   - Jika **tidak cocok** → **Short URL Domain** → rewrite ke `/s/[slug]`

### Cara Kerja Redirect Handler (`src/app/s/[slug]/route.ts`)

Handler ini menerima request yang sudah di-rewrite oleh middleware:

1. Ekstrak `slug` dari URL path
2. Ekstrak `host` dari query parameter `?host=` (diset oleh middleware)
3. **Cari domain** di tabel `short_domains` berdasarkan `host`
   - Jika domain tidak terdaftar → return 404 HTML
   - Jika domain tidak aktif → return 404 HTML
4. **Cari link** di tabel `short_links` berdasarkan `slug` + `domainId`
   - Jika tidak ditemukan → return 404 HTML
   - Jika `isActive = false` → return 404 HTML
5. **Cek expired** — jika `expiredAt < now()` → return 410 HTML
6. **Cek password** — jika link punya password dan belum dimasukkan → return 403 HTML (halaman input password)
7. **Tentukan target** — menggunakan logika routing:
   - Priority 1: IP-based match
   - Priority 2: Country-based match
   - Priority 3: ALL (catch-all) targets
8. **Record click** — simpan data klik ke tabel `clicks` (async, tidak blocking redirect)
9. **Return 301 Permanent Redirect** ke target URL

### Halaman Khusus di Short URL Domain

| Kondisi | Path | HTTP Status | Response |
|---|---|---|---|
| Root path (tanpa slug) | `abc.me/` | 200 | HTML "Short URL Service" info page |
| Slug tidak ditemukan | `abc.me/nonexistent` | 404 | HTML "404 - Link Not Found" |
| Link sudah expired | `abc.me/expired-link` | 410 | HTML "Link Expired" |
| Link terproteksi password | `abc.me/secret` | 403 | HTML "Password Required" (form input) |
| Dashboard paths | `abc.me/dashboard` | 404 | HTML "404 - Link Not Found" (dashboard TIDAK bisa diakses) |

### File yang Terlibat

| File | Fungsi |
|---|---|
| `src/middleware.ts` | Deteksi domain & routing |
| `src/app/s/[slug]/route.ts` | Redirect handler (lookup DB, record click, 301) |
| `src/app/api/redirect/route.ts` | API endpoint redirect (untuk testing/demo) |
| `src/lib/db.ts` | Prisma database client |

---

## 3. Instalasi Lokal (Local Installation)

Ikuti langkah-langkah berikut untuk menjalankan project secara lokal di komputer kamu.

### Step 3.1 — Clone Repository

```bash
# Clone dari GitHub (setelah push, lihat Section 6)
git clone https://github.com/username/shorturl-platform.git

# Masuk ke direktori project
cd shorturl-platform
```

> **Note:** Jika belum push ke GitHub, kamu bisa langsung bekerja di direktori project yang sudah ada.

### Step 3.2 — Install Dependencies

```bash
# Menggunakan Bun (direkomendasikan)
bun install

# Atau menggunakan npm
npm install

# Atau menggunakan pnpm
pnpm install
```

Proses ini akan menginstall semua dependencies yang terdaftar di `package.json`, termasuk:

- **Next.js 16** — Framework React fullstack
- **React 19** — UI library
- **Prisma 6** — ORM untuk database
- **shadcn/ui** — Component library (via Radix UI)
- **Recharts** — Library untuk chart/visualisasi analytics
- **Zustand** — State management
- **next-themes** — Dark/light mode support
- **qrcode** — QR code generation
- **date-fns** — Date manipulation
- **zod** — Schema validation

### Step 3.3 — Setup Environment Variables

```bash
# Copy file .env.example ke .env
cp .env.example .env

# Edit file .env sesuai konfigurasi kamu
nano .env
# atau
code .env
# atau
vim .env
```

Pastikan file `.env` berisi minimal konfigurasi berikut:

```env
# Database — untuk development lokal (SQLite)
DATABASE_URL="file:./db/custom.db"

# Token autentikasi dashboard (minimal 12 karakter)
DASHBOARD_TOKEN="Master123@"

# URL aplikasi (untuk development lokal)
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Domain utama (untuk testing middleware di lokal)
APP_DOMAIN="localhost"
```

> **Catatan:** Untuk development lokal, middleware mendeteksi `*.pages.dev` sebagai main domain. Jika kamu ingin test dengan domain lokal, atur `APP_DOMAIN="localhost"`.

### Step 3.4 — Setup Database

```bash
# Push schema ke database (membuat tabel berdasarkan prisma/schema.prisma)
bun run db:push

# Generate Prisma Client (diperlukan agar bisa import @prisma/client)
bun run db:generate
```

> **Penjelasan:**
> - `db:push` → Membaca `prisma/schema.prisma` dan membuat/memperbarui tabel di database tanpa membuat migration file.
> - `db:generate` → Menghasilkan Prisma Client di `node_modules/.prisma/client` berdasarkan schema.

**File `prisma/schema.prisma` berisi 5 model utama:**

| Model | Tabel Database | Deskripsi |
|---|---|---|
| `AppSetting` | `app_settings` | Pengaturan aplikasi (key-value) |
| `ShortDomain` | `short_domains` | Domain yang digunakan untuk short URL |
| `ShortLink` | `short_links` | Link pendek dengan metadata lengkap |
| `LinkTarget` | `link_targets` | Target URL untuk multi-target routing |
| `Click` | `clicks` | Data klik/analytics per pengunjung |

### Step 3.5 — Jalankan Development Server

```bash
# Jalankan Next.js development server di port 3000
bun run dev
```

Output yang diharapkan:

```
  ▲ Next.js 16.x.x
  - Local:        http://localhost:3000
  - Environments: .env

 ✓ Starting...
 ✓ Ready in 2s
```

Buka browser dan akses:
- **Dashboard:** http://localhost:3000
- **Login:** Masukkan token dari `DASHBOARD_TOKEN` (default: `Master123@`)

### Step 3.6 — Verifikasi Instalasi

Setelah server berjalan, verifikasi:

- [ ] Dashboard berhasil dimuat di http://localhost:3000
- [ ] Login dengan token berhasil
- [ ] Halaman Overview menampilkan statistik
- [ ] Bisa membuat link baru di halaman Links
- [ ] Halaman Domains bisa diakses
- [ ] Halaman Settings bisa diakses

---

## 4. Setup Database — Neon Tech (PostgreSQL)

Neon Tech menyediakan PostgreSQL serverless yang **gratis** untuk penggunaan dasar. Ini adalah rekomendasi utama untuk database production.

### Step 4.1 — Buat Akun Neon

1. Buka **https://neon.tech**
2. Klik tombol **Sign Up**
3. Pilih salah satu metode registrasi:
   - **GitHub** (direkomendasikan, 1 klik)
   - **Google**
   - **Email & Password**

### Step 4.2 — Buat Project Baru

1. Setelah login, klik **"Create a project"**
2. Isi konfigurasi project:

   | Field | Value yang Disarankan |
  ---|---|
   | **Project name** | `shorturl-db` |
   | **Region** | `AWS Asia Pacific (Singapore) — ap-southeast-1` |
   | **PostgreSQL version** | Default (16) — biarkan sesuai default |
   | **Branch name** | `main` — biarkan default |

3. Klik **"Create project"**
4. Tunggu proses provisioning (~10-20 detik)

### Step 4.3 — Dapatkan Connection String

1. Setelah project dibuat, Neon akan menampilkan halaman dashboard
2. Klik tab **"Connection details"** atau look di sidebar
3. Salin **connection string** yang formatnya seperti:

```
postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
```

### Step 4.4 — Update Konfigurasi Project

**a) Update file `.env`:**

```env
# Ganti DATABASE_URL dari SQLite ke PostgreSQL Neon
DATABASE_URL="postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"
```

**b) Update `prisma/schema.prisma`:**

Ubah provider database dari `sqlite` ke `postgresql`:

```prisma
// SEBELUM (development lokal dengan SQLite)
datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

// SESUDAH (production dengan PostgreSQL Neon)
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

> ⚠️ **PENTING:** Pastikan `?sslmode=require` selalu ada di connection string Neon. Tanpa SSL, koneksi akan ditolak.

### Step 4.5 — Push Schema ke Database Neon

```bash
# Push schema (membuat tabel di PostgreSQL Neon)
bun run db:push

# Generate ulang Prisma Client
bun run db:generate
```

Output yang diharapkan dari `db:push`:

```
🚀 Your database is now in sync with your Prisma schema.
```

### Step 4.6 — Verifikasi Koneksi Database

```bash
# Test koneksi database
bunx prisma db execute --stdin <<< "SELECT 1 as test;"

# Atau gunakan Prisma Studio untuk melihat data
bunx prisma studio
```

Jika berhasil, Prisma Studio akan terbuka di http://localhost:5555 dan kamu bisa melihat semua tabel.

### Tips Neon Tech

| Tips | Deskripsi |
|---|---|
| **Auto-suspend** | Database Neon otomatis suspend setelah idle. Request pertama akan sedikit lebih lambat (~1-2 detik). |
| **Connection pooling** | Gunakan pooled connection string (port 6543) untuk production agar lebih efisien. |
| **Branching** | Neon mendukung database branching untuk development/testing tanpa mempengaruhi production. |
| **Free tier** | 0.5 GiB storage, 1 project, auto-suspend. Cukup untuk project kecil-menengah. |
| **Scaling** | Neon mendukung auto-scaling compute untuk menangani traffic tinggi. |

---

## 5. Setup Database — TiDB (Alternatif)

TiDB adalah database SQL yang kompatibel dengan MySQL dan mendukung fitur NoSQL. TiDB Cloud menyediakan tier serverless yang gratis.

### Step 5.1 — Buat Akun TiDB Cloud

1. Buka **https://tidbcloud.com**
2. Klik **"Sign Up"** atau **"Start Free"**
3. Daftar menggunakan:
   - **Google**
   - **GitHub**
   - **Email & Password**

### Step 5.2 — Buat Cluster Serverless

1. Setelah login, klik **"Create Cluster"**
2. Pilih **Serverless Tier** (gratis)
3. Isi konfigurasi:

   | Field | Value yang Disarakan |
  ---|---|
   | **Cluster name** | `shorturl-db` |
   | **Region** | `AWS ap-southeast-1 (Singapore)` |
   | **Create password** | Buat password yang kuat & catat di tempat aman |

4. Klik **"Create"**
5. Tunggu provisioning (~2-5 menit)

### Step 5.3 — Dapatkan Connection String

1. Setelah cluster aktif, buka halaman cluster
2. Klik **"Connect"** di sidebar
3. Pilih **"General"** tab
4. Salin connection string. Formatnya seperti:

```
mysql://root:xxxxxxxxxxxx@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?ssl={"rejectUnauthorized":true}
```

### Step 5.4 — Update Konfigurasi Project

> ⚠️ **Catatan Penting:** TiDB menggunakan protokol MySQL, bukan PostgreSQL. Kamu perlu menyesuaikan Prisma provider.

**a) Update file `.env`:**

```env
# Untuk TiDB (MySQL-compatible)
DATABASE_URL="mysql://root:xxxxxxxxxxxx@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?sslaccept=strict"
```

**b) Update `prisma/schema.prisma`:**

```prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

**c) Push schema dan generate client:**

```bash
bun run db:push
bun run db:generate
```

### Step 5.5 — Catatan Penting untuk TiDB

| Catatan | Deskripsi |
|---|---|
| **MySQL Compatibility** | TiDB menggunakan dialect MySQL, bukan PostgreSQL. Pastikan query Prisma kompatibel. |
| **SSL Required** | TiDB Cloud mengharuskan SSL connection. Pastikan `sslaccept=strict` ada di connection string. |
| **Free tier limits** | 1 cluster serverless, 5 GiB storage, 50 million row reads/bulan. |
| **Latency** | Untuk pengguna di Indonesia, region Singapore memberikan latensi terbaik. |
| **CUID Compatibility** | TiDB kompatibel dengan `@default(cuid())` — tidak ada perubahan schema yang diperlukan. |

---

## 6. Push ke GitHub

Menyimpan source code ke GitHub memudahkan kolaborasi, backup, dan integrasi dengan layanan deployment seperti Cloudflare Pages.

### Step 6.1 — Pastikan .gitignore Sudah Benar

Pastikan file berikut ada di `.gitignore` (seharusnya sudah ada dari Next.js template):

```gitignore
# Dependencies
node_modules/
.pnp
.pnp.js

# Next.js
.next/
out/

# Production
build/
dist/

# Misc
.DS_Store
*.pem

# Debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Local env files
.env
.env*.local

# Vercel
.vercel

# TypeScript
*.tsbuildinfo
next-env.d.ts

# Database
db/*.db
db/*.db-journal

# Prisma
prisma/migrations/

# IDE
.vscode/
.idea/

# Logs
*.log
dev.log
server.log
```

> ⚠️ **HAL KRITIS:** File `.env` **HARUS** ada di `.gitignore`. Jika tidak, credential database dan token dashboard akan terekspos ke publik!

### Step 6.2 — Inisialisasi Git & Commit

```bash
# Inisialisasi git repository (jika belum ada)
git init

# Tambahkan semua file ke staging
git add .

# Buat commit pertama
git commit -m "feat: initial commit — ShortURL Platform (Dub.co clone)"
```

### Step 6.3 — Buat Repository di GitHub

#### Opsi A: Menggunakan GitHub Web UI

1. Buka **https://github.com/new**
2. Isi form:
   - **Repository name:** `shorturl-platform`
   - **Description:** "Short URL Management Platform — Dub.co Clone built with Next.js 16 + Prisma"
   - **Visibility:** `Private` (direkomendasikan) atau `Public`
   - **JANGAN centang** "Add a README", "Add .gitignore", "Choose a license" (karena sudah ada)
3. Klik **"Create repository"**
4. Ikuti instruksi di halaman untuk push existing repository

#### Opsi B: Menggunakan GitHub CLI (`gh`)

```bash
# Install GitHub CLI jika belum ada
# macOS
brew install gh

# Ubuntu/Debian
sudo apt install gh

# Login ke GitHub
gh auth login

# Buat repository dan push sekaligus
gh repo create shorturl-platform --private --source=. --push
```

### Step 6.4 — Push ke GitHub

```bash
# Tambahkan remote origin (opsional jika menggunakan gh repo create)
git remote add origin https://github.com/username/shorturl-platform.git

# Set branch utama ke main
git branch -M main

# Push ke GitHub
git push -u origin main
```

### Step 6.5 — Verifikasi

- [ ] Repository berhasil dibuat di GitHub
- [ ] Semua file ter-upload
- [ ] `.env` TIDAK ter-upload (cek di GitHub — file ini harus ada di .gitignore)
- [ ] `db/custom.db` TIDAK ter-upload

---

## 7. Deploy ke Cloudflare Pages

Cloudflare Pages mendukung deployment Next.js langsung dari repository GitHub dengan CI/CD otomatis.

### Step 7.1 — Persiapan Build

Sebelum deploy, pastikan project bisa build dengan sukses secara lokal:

```bash
# Build project menggunakan next-on-pages (Cloudflare adapter)
npx @cloudflare/next-on-pages
```

> **Note:** Build command ini berbeda dari `bun run build` (yang menggunakan Next.js standalone output). Untuk Cloudflare Pages, gunakan `@cloudflare/next-on-pages`.

Jika build berhasil, output akan berada di `.vercel/output/static`.

### Step 7.2 — Deploy via Cloudflare Dashboard

#### Langkah 1: Login ke Cloudflare

1. Buka **https://dash.cloudflare.com**
2. Login menggunakan akun Cloudflare kamu

#### Langkah 2: Buat Project Pages Baru

1. Di sidebar kiri, klik **"Workers & Pages"**
2. Klik tombol **"Create"** (atau "Create application")
3. Pilih tab **"Pages"**
4. Klik **"Connect to Git"**

#### Langkah 3: Hubungkan Repository GitHub

1. Pilih **GitHub** sebagai Git provider
2. Klik **"Connect GitHub"** dan authorize Cloudflare
3. Pilih repository **`shorturl-platform`** dari daftar

#### Langkah 4: Konfigurasi Build

Isi konfigurasi build sebagai berikut:

| Setting | Value |
|---|---|
| **Project name** | `shorturl-platform` (atau nama yang kamu inginkan) |
| **Production branch** | `main` |
| **Framework preset** | `Next.js (Static)` atau `None` |
| **Build command** | `npx @cloudflare/next-on-pages` |
| **Build output directory** | `.vercel/output/static` |

> ⚠️ **PENTING:** Build command dan output directory harus **persis** seperti di atas. Kesalahan di salah satu field akan menyebabkan deployment gagal.

#### Langkah 5: Environment Variables (Build Time)

Tambahkan environment variables yang dibutuhkan saat build:

| Variable | Value | Keterangan |
|---|---|---|
| `DATABASE_URL` | Connection string Neon/TiDB kamu | Diperlukan saat build untuk Prisma generate |
| `DASHBOARD_TOKEN` | Token rahasia kamu | Minimal 12 karakter |
| `APP_DOMAIN` | `shorturl-platform.pages.dev` | Sementara menggunakan pages.dev |
| `NEXT_PUBLIC_APP_URL` | `https://shorturl-platform.pages.dev` | Full URL dengan https:// |
| `NODE_ENV` | `production` | Production mode |

> **Note:** Environment variables juga harus ditambahkan **separately** untuk Production dan Preview environment. Lihat Section 14 untuk detail lengkap.

#### Langkah 6: Deploy

1. Klik **"Save and Deploy"**
2. Tunggu proses build (biasanya 2-5 menit untuk pertama kali)
3. Jika berhasil, kamu akan mendapatkan URL:
   ```
   https://shorturl-platform.pages.dev
   ```

### Step 7.3 — Deploy via Wrangler CLI (Alternatif)

Jika lebih suka menggunakan command line:

```bash
# Install Wrangler CLI secara global
npm install -g wrangler

# Login ke Cloudflare
wrangler login

# Build project terlebih dahulu
npx @cloudflare/next-on-pages

# Deploy ke Cloudflare Pages
wrangler pages deploy .vercel/output/static --project-name=shorturl-platform

# Untuk deploy ke branch production
wrangler pages deploy .vercel/output/static --project-name=shorturl-platform --branch=main
```

### Step 7.4 — Auto-Deploy Setup

Setelah pertama kali deploy via dashboard, setiap push ke branch `main` akan otomatis trigger re-deploy:

```bash
# Buat perubahan kode
git add .
git commit -m "feat: update short URL logic"
git push origin main

# Cloudflare Pages akan otomatis build & deploy (2-5 menit)
```

### Step 7.5 — Preview Deployments

Cloudflare Pages juga membuat preview deployment untuk setiap pull request:

1. Buat branch baru: `git checkout -b feature/new-feature`
2. Push ke GitHub: `git push origin feature/new-feature`
3. Buat Pull Request di GitHub
4. Cloudflare akan otomatis membuat preview URL seperti:
   ```
   https://abc123.shorturl-platform.pages.dev
   ```

### Step 7.6 — Verifikasi Deployment

- [ ] Build berhasil tanpa error
- [ ] `https://shorturl-platform.pages.dev` menampilkan login page
- [ ] Login dengan `DASHBOARD_TOKEN` berhasil
- [ ] Dashboard bisa diakses
- [ ] Bisa membuat link baru
- [ ] Bisa menambahkan domain

---

## 8. Setup Domain Utama (Main Domain)

> ⚠️ **Bagian ini SANGAT PENTING.** Domain utama adalah domain yang melayani dashboard SPA. Tanpa ini, kamu hanya bisa mengakses dashboard melalui `*.pages.dev`.

Domain utama (contoh: `abc.com`) berfungsi untuk:
- Menampilkan halaman login
- Dashboard manajemen link
- Halaman analytics
- Manajemen domain
- Settings

### Step 8.1 — Tambahkan Domain ke Cloudflare

📋 **Langkah-langkah:**

1. Login ke **https://dash.cloudflare.com**
2. Di sidebar kiri, klik **"Websites"**
3. Klik tombol **"Add a site"**
4. Masukkan nama domain kamu (contoh: `abc.com`)
5. Pilih plan (**Free** sudah cukup)
6. Cloudflare akan menampilkan **2 NS records** (nameservers):
   ```
   ns1.cloudflare.com
   ns2.cloudflare.com
   ```
7. Login ke **registrar domain** kamu (Namecheap, GoDaddy, Domain.com, Niagahoster, dll.)
8. Cari menu **Nameservers** atau **DNS Settings**
9. **Ubah nameserver** domain ke nameserver Cloudflare yang diberikan
10. Klik **"Done, check nameservers"** di Cloudflare
11. Tunggu propagasi DNS (bisa memakan waktu 15 menit - 48 jam, biasanya ~15 menit)

> **Tips:** Cloudflare akan mengirim email notifikasi ketika domain sudah aktif. Kamu juga bisa cek status di dashboard Cloudflare — status akan berubah dari "Pending" menjadi "Active".

### Step 8.2 — Buat DNS Record

Setelah domain aktif di Cloudflare, buat DNS record untuk mengarahkan domain ke Pages project:

1. Di Cloudflare dashboard, pilih domain `abc.com`
2. Klik **"DNS"** → **"Records"**
3. Klik **"Add record"**
4. Isi konfigurasi:

   | Type | Name | Target | Proxy | TTL |
  ---|---|---|---|---|
   | CNAME | `@` | `shorturl-platform.pages.dev` | ☁️ **Proxied** | Auto |

> ⚠️ **KRITIS:** Pastikan proxy status berwarna **oranye (Proxied)**, BUKAN abu-abu (DNS only). Proxied mode memberikan:
> - SSL/HTTPS otomatis
> - DDoS protection
> - WAF (Web Application Firewall)
> - Akses ke Cloudflare headers (`cf-connecting-ip`, `cf-ipcountry`, dll.)
>
> Jika abu-abu, klik ikon awan untuk mengubah ke Proxied.

5. Klik **"Save"**

### Step 8.3 — Tambahkan Custom Domain di Pages

📋 **Langkah-langkah:**

1. Di Cloudflare dashboard, buka **Workers & Pages**
2. Klik project **`shorturl-platform`**
3. Klik tab **"Custom domains"**
4. Klik **"Set up a custom domain"**
5. Masukkan domain: `abc.com`
6. Klik **"Continue"**
7. Pilih **"Activate domain"**
8. Tunggu SSL certificate provisioning (biasanya ~15 menit, kadang sampai 1 jam)
9. Status akan berubah menjadi **"Active"** ✅

### Step 8.4 — Set Environment Variable APP_DOMAIN

📋 **Langkah-langkah:**

Ini adalah step **paling kritis**. Tanpa mengatur `APP_DOMAIN`, middleware tidak bisa membedakan antara domain utama dan short URL domain.

1. Di Cloudflare dashboard, buka **Workers & Pages** → project `shorturl-platform`
2. Klik **"Settings"** → **"Environment variables"**
3. Pastikan kamu berada di tab **"Production"**
4. Cari variable `APP_DOMAIN` dan update nilainya:

   | Variable | Value |
  ---|---|
   | `APP_DOMAIN` | `abc.com` |

   > ⚠️ **PENTING:** Isi hanya **hostname saja**, tanpa `https://` atau `www.`. Contoh yang benar: `abc.com`. Contoh yang salah: `https://abc.com` atau `www.abc.com`.

5. Juga update `NEXT_PUBLIC_APP_URL`:

   | Variable | Value |
  ---|---|
   | `NEXT_PUBLIC_APP_URL` | `https://abc.com` |

6. Klik **"Save"**
7. **Redeploy** project (Deployments → klik menu → Retry deployment) agar environment variable baru berlaku

### Step 8.5 — Verifikasi Domain Utama

Setelah semua konfigurasi selesai, verifikasi:

- [ ] `https://abc.com` menampilkan halaman login
- [ ] Login dengan `DASHBOARD_TOKEN` berhasil
- [ ] Dashboard bisa diakses (Overview, Links, Domains, Analytics, Settings)
- [ ] Semua halaman dashboard berfungsi normal
- [ ] HTTPS bekerja (ikon gembok di browser)
- [ ] `http://abc.com` otomatis redirect ke `https://abc.com`

> ✅ **Selamat!** Domain utama sudah siap. Sekarang lanjut ke Section 9 untuk setup short URL domain.

---

## 9. Setup Domain Short URL

> ⚠️ **Bagian ini SANGAT PENTING.** Domain short URL adalah domain yang digunakan publik untuk redirect. Tanpa ini, fitur short URL tidak bisa digunakan dengan custom domain.

Domain short URL (contoh: `abc.me`) berfungsi untuk:
- Redirect `abc.me/promo` → target URL
- Record analytics klik
- Mendukung password protection
- Mendukung multi-target routing

**Kedua domain (utama & short URL) menunjuk ke project Pages yang SAMA.** Perbedaan perilaku ditangani oleh middleware.

### Step 9.1 — Tambahkan Domain Short URL ke Cloudflare

📋 **Langkah-langkah:**

1. Login ke **https://dash.cloudflare.com**
2. Klik **"Add a site"**
3. Masukkan nama domain short URL kamu (contoh: `abc.me`)
4. Pilih plan (**Free** sudah cukup)
5. Catat **nameserver** yang diberikan Cloudflare
6. Login ke **registrar domain** untuk `abc.me`
7. **Ubah nameserver** ke nameserver Cloudflare:
   ```
   ns1.cloudflare.com
   ns2.cloudflare.com
   ```
8. Klik **"Done, check nameservers"** di Cloudflare
9. Tunggu propagasi DNS (~15 menit - 48 jam)

### Step 9.2 — Buat DNS Record untuk Short URL Domain

Setelah domain aktif di Cloudflare:

1. Di Cloudflare dashboard, pilih domain `abc.me`
2. Klik **"DNS"** → **"Records"**
3. Klik **"Add record"**

#### Opsi A: Root Domain (abc.me)

| Type | Name | Target | Proxy | TTL |
|---|---|---|---|---|
| CNAME | `@` | `shorturl-platform.pages.dev` | ☁️ **Proxied** | Auto |

#### Opsi B: Subdomain (go.example.com)

Jika kamu ingin menggunakan subdomain dari domain yang sudah ada di Cloudflare:

| Type | Name | Target | Proxy | TTL |
|---|---|---|---|---|
| CNAME | `go` | `shorturl-platform.pages.dev` | ☁️ **Proxied** | Auto |

> ⚠️ **KRITIS:** Pastikan proxy status berwarna **oranye (Proxied)**. Jika abu-abu (DNS only), SSL tidak akan otomatis dan beberapa Cloudflare headers tidak tersedia.

4. Klik **"Save"**

### Step 9.3 — Tambahkan Custom Domain di Pages

📋 **Langkah-langkah:**

Ini menambahkan domain short URL ke project Pages yang **SAMA** dengan domain utama:

1. Di Cloudflare dashboard, buka **Workers & Pages**
2. Klik project **`shorturl-platform`** (project yang SAMA dengan domain utama)
3. Klik tab **"Custom domains"**
4. Klik **"Set up a custom domain"**
5. Masukkan domain short URL: `abc.me`
6. Klik **"Continue"**
7. Pilih **"Activate domain"**
8. Tunggu SSL certificate provisioning (~15 menit)
9. Status akan berubah menjadi **"Active"** ✅

> **Note:** Project Pages kamu sekarang memiliki **dua custom domain**:
> - `abc.com` → dashboard
> - `abc.me` → short URL redirect

### Step 9.4 — Tambahkan Domain di Dashboard

📋 **Langkah-langkah:**

Middleware perlu tahu bahwa `abc.me` adalah domain short URL yang valid. Ini dilakukan dengan menambahkan domain di dashboard:

1. Buka **https://abc.com** (domain utama)
2. Login ke dashboard
3. Pergi ke menu **Domains** di sidebar
4. Klik tombol **"Add Domain"**
5. Isi form:

   | Field | Value |
  ---|---|
   | **Domain** | `abc.me` |
   | **Slug** | (opsional) |
   | **Active** | ✅ Centang |

6. Klik **"Save"**
7. Domain akan muncul di daftar domain dengan status "Verified" atau "Unverified"

> **Bagaimana middleware tahu domain ini valid?** Middleware me-rewrite semua request dari domain non-utama ke `/s/[slug]`. Lalu redirect handler mencari domain di tabel `short_domains`. Jika domain ditemukan dan aktif → proses redirect. Jika tidak → return 404.

### Step 9.5 — Buat Link Test

Sekarang buat link test untuk memverifikasi semuanya berfungsi:

1. Di dashboard, pergi ke menu **Links**
2. Klik **"Create Link"**
3. Isi form:

   | Field | Value |
  ---|---|
   | **Domain** | `abc.me` |
   | **Slug** | `test` |
   | **Title** | `Test Link` |
   | **Destination URL** | `https://www.google.com` |

4. Klik **"Save"**

### Step 9.6 — Verifikasi Short URL Domain

Lakukan tes berikut:

- [ ] `https://abc.me/test` → redirect ke `https://www.google.com` ✅
- [ ] `https://abc.me/nonexistent` → menampilkan halaman **404 HTML** ("Link Not Found")
- [ ] `https://abc.me/` → menampilkan halaman **"Short URL Service"** info page
- [ ] `https://abc.me/dashboard` → menampilkan halaman **404 HTML** (dashboard TIDAK bisa diakses di short URL domain)
- [ ] HTTPS bekerja (ikons gembok di browser)
- [ ] Redirect menggunakan HTTP 301 (Permanent Redirect)
- [ ] Klik tercatat di analytics dashboard

> ✅ **Selamat!** Setup domain short URL sudah selesai. Platform kamu sekarang sepenuhnya berfungsi.

---

## 10. Menambahkan Banyak Domain Short URL (Multiple Short URL Domains)

Platform ini mendukung **unlimited** domain short URL tanpa perubahan kode. Setiap domain hanya perlu:

### Langkah untuk Setiap Domain Baru

1. **Tambahkan domain ke Cloudflare** (Add a site → change nameservers)
2. **Buat DNS CNAME record** → `shorturl-platform.pages.dev` (Proxied)
3. **Tambahkan custom domain** di Pages project yang SAMA
4. **Tambahkan domain di dashboard** (Domains → Add Domain)

### Contoh: Menambahkan `go.example.com` sebagai Domain Ketiga

```
Domain 1: abc.com       → Dashboard SPA     (APP_DOMAIN)
Domain 2: abc.me        → Short URL redirect
Domain 3: go.example.com → Short URL redirect  ← BARU
```

**Step 1 — DNS Record (di Cloudflare, domain example.com):**

| Type | Name | Target | Proxy | TTL |
|---|---|---|---|---|
| CNAME | `go` | `shorturl-platform.pages.dev` | ☁️ Proxied | Auto |

**Step 2 — Custom Domain di Pages:**

Tambahkan `go.example.com` di tab "Custom domains" project `shorturl-platform`.

**Step 3 — Dashboard:**

Di menu Domains → Add Domain → masukkan `go.example.com`.

### Ringkasan Arsitektur Multi-Domain

```
┌──────────────────────────────────────────────┐
│       shorturl-platform.pages.dev            │
│       (Satu Cloudflare Pages Project)        │
│                                              │
│  Custom Domains:                             │
│  ┌─────────────────┐                         │
│  │ abc.com         │ → Dashboard SPA         │
│  │ (APP_DOMAIN)    │   (middleware pass-thru) │
│  └─────────────────┘                         │
│  ┌─────────────────┐                         │
│  │ abc.me          │ → Short URL redirect    │
│  │ (DB registered) │   (middleware rewrite)  │
│  └─────────────────┘                         │
│  ┌─────────────────┐                         │
│  │ go.example.com  │ → Short URL redirect    │
│  │ (DB registered) │   (middleware rewrite)  │
│  └─────────────────┘                         │
│  ┌─────────────────┐                         │
│  │ link.co.id      │ → Short URL redirect    │
│  │ (DB registered) │   (middleware rewrite)  │
│  └─────────────────┘                         │
│                                              │
│  ... dan seterusnya (unlimited)              │
└──────────────────────────────────────────────┘
```

### Checklist

- [ ] DNS CNAME record dibuat untuk setiap domain baru
- [ ] Proxy status = Proxied (oranye) untuk setiap domain
- [ ] Custom domain ditambahkan di Pages project
- [ ] SSL certificate aktif untuk setiap domain
- [ ] Domain ditambahkan di dashboard (tabel `short_domains`)
- [ ] Link test berhasil untuk setiap domain

---

## 11. Migrasi Domain

Migrasi domain berguna ketika kamu ingin memindahkan semua link dari satu domain ke domain lain. Misalnya, pindah dari `go.example.com` ke `link.example.com`.

### Step 11.1 — Buka Bulk Operations

1. Login ke dashboard
2. Pergi ke menu **Bulk Operations** di sidebar

### Step 11.2 — Pilih Operasi "Change Domain"

1. Di bagian **"Change Domain"**, kamu akan melihat dua dropdown:
   - **Domain Asal** (Source Domain) — domain yang ingin ditinggalkan
   - **Domain Tujuan** (Target Domain) — domain yang baru
2. Pilih domain asal dan domain tujuan

### Step 11.3 — Review & Apply

1. Klik tombol **"Preview Changes"** (jika tersedia)
2. Sistem akan menampilkan:
   - Jumlah link yang akan dipindahkan
   - Daftar slug yang berpotensi konflik
   - Konfirmasi perubahan
3. Klik **"Apply"** untuk memproses migrasi

### Step 11.4 — Penanganan Konflik Slug

Jika ada slug yang sudah digunakan di domain tujuan:

| Opsi | Deskripsi |
|---|---|
| **Skip** | Link yang konflik tidak akan dipindahkan |
| **Overwrite** | Link lama di domain tujuan akan dihapus dan diganti |
| **Rename** | Slug akan diberi suffix otomatis (contoh: `promo-2`) |

### Step 11.5 — Verifikasi Migrasi

Setelah migrasi selesai:

- [ ] Cek halaman **Links** — pastikan domain sudah berubah
- [ ] Test beberapa short URL di domain baru — pastikan redirect berfungsi
- [ ] Cek halaman **Analytics** — data klik tetap tersimpan
- [ ] Link di domain lama sudah tidak aktif (opsional: nonaktifkan domain lama)

### Step 11.6 — Tips Migrasi

| Tips | Deskripsi |
|---|---|
| **Backup dulu** | Selalu export data via Settings > Export sebelum migrasi |
| **Test dulu** | Buat beberapa link test di domain tujuan sebelum migrasi besar |
| **DNS overlap** | Pastikan DNS kedua domain sudah aktif sebelum migrasi |
| **Monitoring** | Setelah migrasi, pantau analytics untuk memastikan redirect berfungsi |
| **Redirect lama** | Pertimbangkan untuk menyimpan domain lama aktif dan membuat redirect di level DNS |

---

## 12. Keamanan & Security Rules

> ⚠️ **Bagian ini SANGAT PENTING untuk production.** Tanpa security rules, dashboard bisa diakses siapa saja dan short URL domain bisa disalahgunakan.

### 12.1 IP Whitelist untuk Dashboard (Main Domain)

Membatasi akses dashboard hanya dari IP tertentu. Ini melindungi dashboard dari akses yang tidak diotorisasi.

📋 **Langkah-langkah:**

1. Login ke **https://dash.cloudflare.com**
2. Pilih domain utama (`abc.com`) — **BUKAN** short URL domain
3. Di sidebar, klik **"Security"** → **"WAF"**
4. Klik tab **"Custom rules"**
5. Klik **"Create rule"**
6. Isi konfigurasi:

   | Field | Value |
  ---|---|
   | **Rule name** | `Block non-whitelisted IPs on Dashboard` |
   | **Expression** | Lihat di bawah |
   | **Action** | Block |

7. Masukkan expression berikut (edit IP sesuai kebutuhan):

   ```
   (http.host eq "abc.com" and not ip.src in {203.0.113.50 198.51.100.23})
   ```

   > **Penjelasan expression:**
   > - `http.host eq "abc.com"` — hanya berlaku untuk domain utama
   > - `not ip.src in {...}` — kecuali IP yang terdaftar di whitelist
   > - Ganti `203.0.113.50 198.51.100.23` dengan IP kamu (pisahkan dengan spasi)

8. Klik **"Deploy"**

**Untuk menambahkan lebih banyak IP:**

```
(http.host eq "abc.com" and not ip.src in {203.0.113.50 198.51.100.23 192.168.1.0/24})
```

> **Tips:** Gunakan CIDR notation untuk whitelist range IP (contoh: `192.168.1.0/24` untuk range `192.168.1.1` - `192.168.1.254`).

**Bagaimana menemukan IP kamu?**

Buka https://www.cloudflare.com/cdn-cgi/trace dan cari baris `ip=`.

### 12.2 Rate Limiting untuk Short URL Domain

Mencegah abuse (brute force, DDoS) pada short URL domain.

📋 **Langkah-langkah:**

1. Login ke **https://dash.cloudflare.com**
2. Pilih domain short URL (`abc.me`)
3. Di sidebar, klik **"Security"** → **"WAF"**
4. Klik tab **"Rate limiting rules"**
5. Klik **"Create rule"**
6. Isi konfigurasi:

   | Field | Value |
  ---|---|
   | **Rule name** | `Rate limit short URL domain` |
   | **Expression** | `http.host eq "abc.me"` |
   | **Rate** | `100` requests per `10` seconds |
   | **Action** | Block for `60` seconds |

7. Klik **"Deploy"**

> **Penjelasan:** Rule ini membatasi setiap IP ke maksimal 100 request per 10 detik ke `abc.me`. Jika melebihi, IP akan di-block selama 60 detik.

### 12.3 HTTPS/SSL

HTTPS dijamin otomatis oleh Cloudflare **jika proxy status = Proxied** (oranye).

| Setting | Status | Keterangan |
|---|---|---|
| **SSL/TLS encryption mode** | Full (Strict) | Direkomendasikan — memastikan koneksi end-to-end terenkripsi |
| **Automatic HTTPS Rewrite** | On | Otomatis redirect HTTP ke HTTPS |
| **Always Use HTTPS** | On | Redirect semua HTTP ke HTTPS |

📋 **Untuk mengatur SSL mode:**

1. Di Cloudflare dashboard, pilih domain
2. Klik **"SSL/TLS"** → **"Overview"**
3. Pilih **"Full (Strict)"**
4. Klik **"Edge Certificates"** → pastikan **"Always Use HTTPS"** = On

> ⚠️ **PERINGATAN:** Jangan gunakan "Flexible" mode karena bisa menyebabkan infinite redirect loop.

### 12.4 Bot Protection

📋 **Langkah-langkah:**

1. Di Cloudflare dashboard, pilih domain
2. Klik **"Security"** → **"Bots"**
3. Atur **"Bot Fight Mode"** = On (Gratis)
4. Untuk perlindungan lebih lanjut, pertimbangkan **"Super Bot Fight Mode"** (berbayar)

| Fitur | Gratis | Berbayar |
|---|---|---|
| Bot Fight Mode | ✅ | ✅ |
| Super Bot Fight Mode | ❌ | ✅ |
| Challenge JS untuk bot | ✅ | ✅ |
| Machine learning detection | ❌ | ✅ |

### 12.5 Security Rules Summary

| Domain | Rule | Action |
|---|---|---|
| `abc.com` (main) | IP whitelist | Block non-whitelisted IPs |
| `abc.me` (short URL) | Rate limiting | 100 req/10s → Block 60s |
| `abc.me` (short URL) | Bot protection | Bot Fight Mode On |
| Semua domain | HTTPS | Full (Strict) + Always Use HTTPS |
| Semua domain | Hotlink protection | (Opsional) Block hotlinking |

---

## 13. 404 Handling

Platform ini memiliki **beberapa jenis 404** tergantung domain dan konteks:

### 13.1 404 di Main Domain (Dashboard)

**Kondisi:** Pengunjung mengakses path yang tidak ada di `abc.com` (contoh: `abc.com/page-tidak-ada`).

**Penanganan:** Dashboard SPA (Next.js) menangani 404 melalui komponen `NotFoundPage`. Browser menampilkan halaman 404 yang styled sesuai tema dashboard.

**File:** `src/components/pages/NotFoundPage.tsx`

```
abc.com/random-page → Dashboard SPA menampilkan NotFoundPage
```

### 13.2 404 di Short URL Domain (Slug Tidak Ditemukan)

**Kondisi:** Pengunjung mengakses slug yang tidak ada di `abc.me` (contoh: `abc.me/tidak-ada`).

**Penanganan:** Server mengembalikan **HTML statis 404** langsung dari route handler. Ini lebih cepat daripada memuat SPA.

**File:** `src/app/s/[slug]/route.ts` → function `get404Html()`

**Response:**
- HTTP Status: `404`
- Content-Type: `text/html; charset=utf-8`
- Body: HTML page dengan styling gelap, menampilkan slug yang dicari

```
abc.me/tidak-ada → HTML 404 "Link Not Found" (server-rendered)
```

### 13.3 Root Path di Short URL Domain

**Kondisi:** Pengunjung mengakses root path `abc.me/` tanpa slug.

**Penanganan:** Server mengembalikan halaman info "Short URL Service".

**File:** `src/app/s/[slug]/route.ts` → function `getRootHtml()`

**Response:**
- HTTP Status: `200`
- Content-Type: `text/html; charset=utf-8`
- Body: HTML page dengan ikon 🔗, judul "Short URL Service", dan nama domain

```
abc.me/ → HTML "Short URL Service" info page
```

### 13.4 Link Expired

**Kondisi:** Link ditemukan tetapi sudah melewati tanggal `expiredAt`.

**Penanganan:** Server mengembalikan halaman "Link Expired".

**File:** `src/app/s/[slug]/route.ts` → function `getExpiredHtml()`

**Response:**
- HTTP Status: `410 Gone`
- Content-Type: `text/html; charset=utf-8`
- Body: HTML page dengan ikon ⏰ dan pesan "This short URL has expired"

```
abc.me/expired-link → HTML "Link Expired" (410)
```

### 13.5 Link Terproteksi Password

**Kondisi:** Link memerlukan password tetapi pengunjung belum memasukkannya.

**Penanganan:** Server mengembalikan halaman form input password.

**File:** `src/app/s/[slug]/route.ts` → function `getPasswordHtml()`

**Response:**
- HTTP Status: `403 Forbidden`
- Content-Type: `text/html; charset=utf-8`
- Body: HTML page dengan form password (client-side JavaScript untuk submit)

```
abc.me/secret → HTML "Password Required" (403)
abc.me/secret?password=wrong → HTML "Password Required" (403)
abc.me/secret?password=correct → 301 redirect ke target
```

### 13.6 Dashboard Tidak Bisa Diakses di Short URL Domain

**Kondisi:** Seseorang mencoba mengakses `abc.me/dashboard` atau `abc.me/links`.

**Penanganan:** Middleware tidak mengenali path ini sebagai route dashboard (karena bukan main domain). Request di-rewrite ke `/s/[slug]` → redirect handler mencari slug `dashboard` di database → tidak ditemukan → return 404 HTML.

```
abc.me/dashboard → 404 "Link Not Found"
abc.me/links → 404 "Link Not Found"
abc.me/api/links → 200 (API routes TIDAK dicegat middleware — langsung ke API handler)
```

> ⚠️ **PERINGATAN:** API routes (`/api/*`) **TIDAK** dicegat oleh middleware. Ini berarti jika seseorang mengetahui URL API, mereka bisa mengaksesnya dari short URL domain. Pastikan API routes memiliki autentikasi yang memadai.

### Tabel Ringkasan Response

| Domain | Path | Kondisi | Status | Response |
|---|---|---|---|---|
| Main | `/random` | Route tidak ada | 200 (SPA) | NotFoundPage component |
| Short | `/` | Root path | 200 | HTML "Short URL Service" |
| Short | `/ada` | Slug ditemukan, aktif | 301 | Redirect ke target |
| Short | `/tidakada` | Slug tidak ditemukan | 404 | HTML "Link Not Found" |
| Short | `/expired` | Link sudah expired | 410 | HTML "Link Expired" |
| Short | `/secret` | Password required | 403 | HTML "Password Required" |
| Short | `/dashboard` | Dashboard route | 404 | HTML "Link Not Found" |

---

## 14. Konfigurasi Environment Variables (Complete Reference)

Environment variables adalah konfigurasi penting yang harus diatur di setiap environment.

### Daftar Lengkap Environment Variables

| Variable | Required | Production | Preview | Deskripsi | Contoh |
|---|---|---|---|---|---|
| `DATABASE_URL` | ✅ Wajib | ✅ | ✅ | Connection string database (Neon/TiDB) | `postgresql://user:pass@host/db?sslmode=require` |
| `DASHBOARD_TOKEN` | ✅ Wajib | ✅ | ✅ | Token autentikasi login dashboard (min. 12 karakter) | `MyS3cur3T0k3n!` |
| `APP_DOMAIN` | ✅ Wajib | ✅ | ✅ | Hostname domain utama (tanpa https:// atau www) | `abc.com` |
| `NEXT_PUBLIC_APP_URL` | ✅ Wajib | ✅ | ✅ | Full URL aplikasi (dengan https://) | `https://abc.com` |
| `NODE_ENV` | Opsional | ✅ | ❌ | Mode environment | `production` / `development` |

### Konfigurasi Production (Cloudflare Pages)

📋 **Langkah:**

1. Buka **Workers & Pages** → project → **Settings** → **Environment variables**
2. Pilih tab **"Production"**
3. Tambahkan semua variable berikut:

| Variable | Value |
|---|---|
| `DATABASE_URL` | `postgresql://neondb_owner:xxx@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN` | Token yang kuat (min. 12 karakter) |
| `APP_DOMAIN` | `abc.com` |
| `NEXT_PUBLIC_APP_URL` | `https://abc.com` |
| `NODE_ENV` | `production` |

### Konfigurasi Preview (untuk PR Preview)

📋 **Langkah:**

1. Di halaman yang sama, pilih tab **"Preview"**
2. Tambahkan variable (bisa sama atau menggunakan DB staging):

| Variable | Value |
|---|---|
| `DATABASE_URL` | Sama dengan production, atau gunakan DB staging terpisah |
| `DASHBOARD_TOKEN` | Sama dengan production |
| `APP_DOMAIN` | `shorturl-platform.pages.dev` (karena preview URL) |
| `NEXT_PUBLIC_APP_URL` | `https://abc123.shorturl-platform.pages.dev` |
| `NODE_ENV` | `production` |

### Konfigurasi Development Lokal

File `.env` di root project:

```env
DATABASE_URL="file:./db/custom.db"
DASHBOARD_TOKEN="Master123@"
APP_DOMAIN="localhost"
NEXT_PUBLIC_APP_URL="http://localhost:3000"
NODE_ENV="development"
```

### Perbedaan `APP_DOMAIN` di Berbagai Environment

| Environment | `APP_DOMAIN` | Alasan |
|---|---|---|
| Development | `localhost` | Diakses via localhost:3000 |
| Preview | `shorturl-platform.pages.dev` | Preview deployment menggunakan subdomain pages.dev |
| Production | `abc.com` | Domain utama production |

### Keamanan Token

> ⚠️ **PERINGATAN KEAMANAN:**

- **Jangan** pernah commit file `.env` ke Git
- **Jangan** gunakan token default `Master123@` di production
- Buat token yang kuat: minimal 12 karakter, kombinasi huruf besar, kecil, angka, dan simbol
- Gunakan password generator yang aman:

```bash
# Generate token yang kuat menggunakan OpenSSL
openssl rand -base64 32

# Atau menggunakan Bun
bun -e "console.log(require('crypto').randomBytes(24).toString('base64'))"
```

---

## 15. Troubleshooting

Berikut adalah masalah umum yang mungkin dihadapi beserta solusinya.

### 15.1 — Database Connection Errors

**Gejala:**
```
Error: P1001 - Can't reach database server
```
atau
```
Error: P3009 - migrate found failed migrations
```

**Solusi:**

```bash
# 1. Periksa koneksi internet
ping neon.tech

# 2. Periksa DATABASE_URL di .env
# Pastikan formatnya benar:
# postgresql://user:password@host/database?sslmode=require

# 3. Test koneksi manual
bunx prisma db execute --stdin <<< "SELECT 1;"

# 4. Jika menggunakan Neon, cek apakah database sudah active (bukan suspended)

# 5. Pastikan provider di prisma/schema.prisma sesuai
# PostgreSQL → provider = "postgresql"
# MySQL/TiDB → provider = "mysql"
# SQLite → provider = "sqlite"
```

| Masalah | Solusi |
|---|---|
| `sslmode=require` error | Pastikan `?sslmode=require` ada di URL |
| Connection timeout | Neon auto-suspend, request pertama lambat. Tunggu dan coba lagi |
| `P1001` repeatedly | Cek apakah database aktif, atau coba reset password di dashboard Neon |
| `P1003` | Database tidak ditemukan. Pastikan nama database di URL benar |

### 15.2 — Build Failures di Cloudflare Pages

**Gejala:**
```
Error during build: Exit code 1
```

**Solusi:**

```bash
# 1. Build locally dulu untuk cek error
npx @cloudflare/next-on-pages

# 2. Pastikan semua dependencies terinstall
rm -rf node_modules bun.lock
bun install

# 3. Pastikan Prisma Client ter-generate
bun run db:generate

# 4. Cek TypeScript errors
npx tsc --noEmit

# 5. Cek next.config.ts untuk konfigurasi yang konflik
```

| Masalah | Solusi |
|---|---|
| Build command salah | Gunakan `npx @cloudflare/next-on-pages` (BUKAN `next build`) |
| Output directory salah | Set ke `.vercel/output/static` |
| Prisma generate error di build | Pastikan `DATABASE_URL` sudah di-set di env vars Cloudflare |
| Runtime error `Node.js` | Pastikan `NODE_ENV=production` di env vars |
| Middleware tidak kompatibel | Cek compatibility matrix @cloudflare/next-on-pages |

### 15.3 — Domain Tidak Resolve

**Gejala:**
- Custom domain menampilkan `ERR_NAME_NOT_RESOLVED`
- SSL certificate error
- "Server Not Found" di browser

**Solusi:**

```bash
# 1. Cek DNS propagation
dig abc.me
# atau
nslookup abc.me

# 2. Cek siapa nameserver domain
whois abc.me | grep "Name Server"
```

**Checklist DNS:**

- [ ] Nameserver domain sudah diarahkan ke Cloudflare (`ns1.cloudflare.com`, `ns2.cloudflare.com`)
- [ ] CNAME record sudah dibuat di Cloudflare DNS (CNAME `@` → `project.pages.dev`)
- [ ] Proxy status = **Proxied** (oranye), BUKAN DNS only (abu-abu)
- [ ] Custom domain sudah ditambahkan di Pages project
- [ ] SSL certificate aktif (tunggu ~15 menit setelah aktivasi)
- [ ] Domain sudah status "Active" di Cloudflare

### 15.4 — Link Tidak Redirect

**Gejala:**
- Short URL menampilkan 404
- Short URL tidak redirect ke target
- Short URL menampilkan halaman dashboard

**Solusi:**

```
# 1. Cek apakah link aktif di database
# Buka Prisma Studio
bunx prisma studio
# Cek tabel short_links → field isActive = true

# 2. Cek apakah domain sudah terdaftar & aktif
# Di dashboard > Domains, pastikan domain active & verified

# 3. Cek apakah APP_DOMAIN sudah di-set dengan benar
# APP_DOMAIN harus = domain utama (abc.com), BUKAN short URL domain

# 4. Cek logs di Cloudflare Pages
# Dashboard > Workers & Pages > project > Logs > Real-time logs
```

| Penyebab | Solusi |
|---|---|
| `isActive = false` | Aktifkan link di dashboard |
| Domain tidak terdaftar | Tambahkan domain di menu Domains |
| Slug duplikat | Pastikan kombinasi slug + domainId unik |
| Target tidak sehat | Cek health target URL di halaman Links |
| `APP_DOMAIN` salah | Pastikan APP_DOMAIN = domain utama, bukan short URL domain |
| Short URL menampilkan dashboard | `APP_DOMAIN` salah — middleware mengira short URL domain adalah main domain |

### 15.5 — Login / Auth Errors

**Gejala:**
- Token diterima tapi dashboard tidak dimuat
- "Unauthorized" error
- Halaman login terus muncul

**Solusi:**

```bash
# 1. Pastikan DASHBOARD_TOKEN sama antara env vars dan yang diinput
# Cek di Cloudflare Pages > Settings > Environment variables

# 2. Pastikan token minimal 12 karakter
echo -n "token-kamu" | wc -c

# 3. Cek endpoint auth
curl -X POST https://abc.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"token":"token-kamu-disini"}'
```

### 15.6 — 404 pada Link yang Valid

**Gejala:**
- Link ada di database dan aktif, tetapi short URL menampilkan 404

**Kemungkinan penyebab:**

| Penyebab | Cara Cek | Solusi |
|---|---|---|
| Domain tidak cocok | Cek field `domain` di tabel `short_domains` harus persis sama dengan Host header | Pastikan domain di DB = domain yang diakses (termasuk www/non-www) |
| `APP_DOMAIN` salah | Middleware mengira short URL domain adalah main domain | Fix `APP_DOMAIN` env var |
| Link expired | Cek field `expiredAt` di tabel `short_links` | Hapus atau perpanjang expiredAt |
| Database tidak sinkron | Cek via Prisma Studio | Run `db:push` atau `db:migrate` |

### 15.7 — SSL Certificate Issues

**Gejala:**
- `NET::ERR_CERT_AUTHORITY_INVALID`
- Browser menampilkan peringatan keamanan
- Mixed content warning

**Solusi:**

| Masalah | Solusi |
|---|---|
| Certificate pending | Tunggu 15-60 menit setelah aktivasi custom domain |
| Proxy = DNS only | Ubah DNS record ke **Proxied** (oranye) |
| SSL mode salah | Ubah ke **Full (Strict)** di SSL/TLS settings |
| Self-signed cert | Jangan gunakan "Flexible" mode — gunakan "Full" atau "Full (Strict)" |

### 15.8 — Port Already in Use (Development)

**Gejala:**
```
Error: Port 3000 is already in use
```

**Solusi:**

```bash
# Cek proses yang menggunakan port 3000
lsof -i :3000

# Kill proses
kill -9 <PID>

# Atau gunakan port lain
bun run dev --port 3001
```

### 15.9 — Prisma Client Error

**Gejala:**
```
Error: @prisma/client did not initialize yet
```

**Solusi:**

```bash
# Regenerate Prisma Client
bun run db:generate

# Jika masih error, hapus cache dan regenerate
rm -rf node_modules/.prisma
rm -rf node_modules/@prisma
bun install
bun run db:generate
```

---

## 16. Alur Kerja Lengkap (Complete Workflow Summary)

Berikut adalah checklist step-by-step dari nol hingga production:

### Fase 1: Persiapan

- [ ] **1.1** Buat akun GitHub (https://github.com/signup)
- [ ] **1.2** Buat akun Cloudflare (https://dash.cloudflare.com/sign-up)
- [ ] **1.3** Buat akun Neon Tech (https://neon.tech/signup)

### Fase 2: Setup Lokal

- [ ] **2.1** Install Node.js 18+ (via nvm)
- [ ] **2.2** Install Bun (`curl -fsSL https://bun.sh/install | bash`)
- [ ] **2.3** Install Git
- [ ] **2.4** Clone atau prepare project directory
- [ ] **2.5** Run `bun install`
- [ ] **2.6** Copy `.env.example` → `.env` dan isi value
- [ ] **2.7** Run `bun run db:push`
- [ ] **2.8** Run `bun run db:generate`
- [ ] **2.9** Run `bun run dev` dan verifikasi di localhost:3000

### Fase 3: Database Production

- [ ] **3.1** Login ke Neon Tech
- [ ] **3.2** Buat project baru (region Singapore)
- [ ] **3.3** Salin connection string
- [ ] **3.4** Update `.env` → `DATABASE_URL` dengan connection string Neon
- [ ] **3.5** Update `prisma/schema.prisma` → `provider = "postgresql"`
- [ ] **3.6** Run `bun run db:push` → pastikan tabel terbuat di Neon
- [ ] **3.7** Run `bunx prisma studio` → verifikasi data

### Fase 4: Push ke GitHub

- [ ] **4.1** Pastikan `.gitignore` memuat `.env` dan `db/*.db`
- [ ] **4.2** `git init` (jika belum ada)
- [ ] **4.3** `git add .` → `git commit -m "initial commit"`
- [ ] **4.4** Buat repository di GitHub (Private)
- [ ] **4.5** `git remote add origin ...` → `git push -u origin main`
- [ ] **4.6** Verifikasi: `.env` TIDAK ada di GitHub

### Fase 5: Deploy ke Cloudflare Pages

- [ ] **5.1** Login ke Cloudflare dashboard
- [ ] **5.2** Workers & Pages → Create → Connect to Git
- [ ] **5.3** Pilih repository GitHub
- [ ] **5.4** Set build command: `npx @cloudflare/next-on-pages`
- [ ] **5.5** Set output directory: `.vercel/output/static`
- [ ] **5.6** Set environment variables (Production):
  - `DATABASE_URL`
  - `DASHBOARD_TOKEN`
  - `APP_DOMAIN` (sementara: `shorturl-platform.pages.dev`)
  - `NEXT_PUBLIC_APP_URL` (`https://shorturl-platform.pages.dev`)
  - `NODE_ENV` (`production`)
- [ ] **5.7** Klik "Save and Deploy"
- [ ] **5.8** Verifikasi: `https://shorturl-platform.pages.dev` menampilkan login page

### Fase 6: Setup Domain Utama

- [ ] **6.1** Add domain `abc.com` ke Cloudflare
- [ ] **6.2** Change nameserver di registrar → Cloudflare nameservers
- [ ] **6.3** Tunggu domain aktif di Cloudflare (status: Active)
- [ ] **6.4** Buat DNS record: CNAME `@` → `shorturl-platform.pages.dev` (Proxied)
- [ ] **6.5** Tambahkan `abc.com` sebagai Custom Domain di Pages project
- [ ] **6.6** Update env var `APP_DOMAIN` = `abc.com`
- [ ] **6.7** Update env var `NEXT_PUBLIC_APP_URL` = `https://abc.com`
- [ ] **6.8** Redeploy project
- [ ] **6.9** Verifikasi: `https://abc.com` menampilkan login page

### Fase 7: Setup Domain Short URL

- [ ] **7.1** Add domain `abc.me` ke Cloudflare
- [ ] **7.2** Change nameserver di registrar → Cloudflare nameservers
- [ ] **7.3** Tunggu domain aktif di Cloudflare
- [ ] **7.4** Buat DNS record: CNAME `@` → `shorturl-platform.pages.dev` (Proxied)
- [ ] **7.5** Tambahkan `abc.me` sebagai Custom Domain di Pages project (SAMA project)
- [ ] **7.6** Login ke dashboard → Domains → Add Domain → `abc.me`
- [ ] **7.7** Buat link test: `abc.me/test` → `https://www.google.com`
- [ ] **7.8** Verifikasi semua skenario (redirect, 404, root, expired, password)

### Fase 8: Keamanan

- [ ] **8.1** Buat IP whitelist rule untuk `abc.com` (WAF Custom Rules)
- [ ] **8.2** Buat rate limiting rule untuk `abc.me` (100 req/10s)
- [ ] **8.3** Aktifkan Bot Fight Mode untuk semua domain
- [ ] **8.4** Set SSL/TLS mode ke Full (Strict)
- [ ] **8.5** Aktifkan "Always Use HTTPS"
- [ ] **8.6** Ganti `DASHBOARD_TOKEN` default dengan token yang kuat

### Fase 9: Testing Akhir

- [ ] **9.1** `https://abc.com` → Login page ✅
- [ ] **9.2** Login berhasil → Dashboard ✅
- [ ] **9.3** Buat link baru ✅
- [ ] **9.4** `https://abc.me/slug` → redirect ke target ✅
- [ ] **9.5** `https://abc.me/nonexistent` → 404 HTML ✅
- [ ] **9.6** `https://abc.me/` → "Short URL Service" page ✅
- [ ] **9.7** `https://abc.me/dashboard` → 404 HTML ✅
- [ ] **9.8** HTTPS berfungsi di semua domain ✅
- [ ] **9.9** Analytics merekam klik ✅
- [ ] **9.10** Mobile responsive ✅

> ✅ **Selamat!** Platform ShortURL kamu sudah sepenuhnya berjalan di production.

---

## 17. Appendix: Contoh .env.example

Berikut adalah contoh lengkap file `.env.example` yang bisa kamu salin ke root project:

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================
# Copy file ini ke .env dan sesuaikan nilainya.
# JANGAN COMMIT file .env ke Git!
# ============================================

# --------------------------------------------
# DATABASE
# --------------------------------------------
# Untuk development lokal (SQLite):
DATABASE_URL="file:./db/custom.db"

# Untuk production dengan Neon Tech (PostgreSQL):
# DATABASE_URL="postgresql://neondb_owner:your_password@ep-xxx.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"

# Untuk production dengan TiDB (MySQL-compatible):
# DATABASE_URL="mysql://root:your_password@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?sslaccept=strict"

# --------------------------------------------
# AUTHENTICATION
# --------------------------------------------
# Token untuk login ke dashboard (MINIMAL 12 karakter!)
# ⚠️ GANTI TOKEN INI DENGAN TOKEN YANG KUAT DI PRODUCTION!
# Gunakan: openssl rand -base64 32
DASHBOARD_TOKEN="Master123@"

# --------------------------------------------
# APP DOMAIN CONFIGURATION
# --------------------------------------------
# Hostname domain utama (TANPA https:// atau www.)
# Ini digunakan oleh middleware untuk membedakan dashboard vs short URL domain
# Development: localhost
# Production: abc.com
APP_DOMAIN="localhost"

# --------------------------------------------
# APP URL
# --------------------------------------------
# Full URL aplikasi (DENGAN https://)
# Digunakan untuk redirect, OG meta, dll.
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Untuk production:
# NEXT_PUBLIC_APP_URL="https://abc.com"

# --------------------------------------------
# NODE ENVIRONMENT
# --------------------------------------------
# Uncomment salah satu sesuai environment:
# NODE_ENV="development"
# NODE_ENV="production"

# ============================================
# ⚠️ JANGAN COMMIT FILE INI KE GIT!
# Pastikan .env ada di .gitignore
# ============================================
```

---

## Resource & Link Berguna

| Resource | URL |
|---|---|
| Next.js Documentation | https://nextjs.org/docs |
| Prisma Documentation | https://www.prisma.io/docs |
| Neon Tech Docs | https://neon.tech/docs |
| TiDB Cloud Docs | https://docs.pingcap.com/tidbcloud |
| Cloudflare Pages Docs | https://developers.cloudflare.com/pages |
| Cloudflare WAF Docs | https://developers.cloudflare.com/waf |
| @cloudflare/next-on-pages | https://github.com/cloudflare/next-on-pages |
| Bun Documentation | https://bun.sh/docs |
| shadcn/ui Components | https://ui.shadcn.com |
| Tailwind CSS 4 Docs | https://tailwindcss.com/docs |

---

> **Dibuat oleh:** Tim Development ShortURL Platform
>
> **Terakhir diperbarui:** 2025
>
> Jika mengalami masalah yang tidak tercakup di panduan ini, silakan buka issue di repository GitHub atau hubungi tim development.

"use client";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MousePointerClick, Calendar, TrendingUp, BarChart3 } from "lucide-react";

interface StatsCardsProps {
  stats: {
    totalClicks?: number;
    clicksToday?: number;
    clicksThisWeek?: number;
    clicksThisMonth?: number;
    totalLinks?: number;
    activeLinks?: number;
    topCountries?: { country: string; count: number }[];
    topDevices?: { device: string; count: number }[];
  } | null;
  loading: boolean;
}

export default function StatsCards({ stats, loading }: StatsCardsProps) {
  if (loading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const data = stats || {};

  const cards = [
    {
      label: "Total Clicks",
      value: data.totalClicks ?? 0,
      icon: MousePointerClick,
    },
    {
      label: "Today",
      value: data.clicksToday ?? 0,
      icon: Calendar,
    },
    {
      label: "This Week",
      value: data.clicksThisWeek ?? 0,
      icon: TrendingUp,
    },
    {
      label: "This Month",
      value: data.clicksThisMonth ?? 0,
      icon: BarChart3,
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.label}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{card.label}</CardTitle>
            <card.icon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {typeof card.value === "number"
                ? card.value.toLocaleString()
                : card.value}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

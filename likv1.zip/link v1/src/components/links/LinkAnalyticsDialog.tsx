"use client";

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { getLinkClicks } from "@/lib/api";
import type { ShortLink, Click } from "@/lib/types";

interface LinkAnalyticsDialogProps {
  link: ShortLink;
  open: boolean;
  onClose: () => void;
}

export default function LinkAnalyticsDialog({ link, open, onClose }: LinkAnalyticsDialogProps) {
  const [clicks, setClicks] = useState<Click[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    if (open) {
      setPage(1);
      loadClicks(1);
    }
  }, [open]);

  useEffect(() => {
    if (open && page > 1) {
      loadClicks(page);
    }
  }, [page]);

  const loadClicks = async (p: number) => {
    setLoading(true);
    try {
      const res = await getLinkClicks(link.id, {
        page: String(p),
        limit: "10",
      });
      setClicks(res.clicks || []);
      setTotalPages(res.totalPages || 1);
    } catch {
      setClicks([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>
            Analytics for /{link.slug}
          </DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-auto">
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : clicks.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-muted-foreground">
              No clicks recorded for this link.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">IP</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">Country</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">Device</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">Browser</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">OS</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">Referrer</th>
                    <th className="whitespace-nowrap px-3 py-2 text-left font-medium text-muted-foreground">Time</th>
                  </tr>
                </thead>
                <tbody>
                  {clicks.map((click) => (
                    <tr key={click.id} className="border-b last:border-0 hover:bg-muted/30">
                      <td className="whitespace-nowrap px-3 py-2 text-xs">{click.ip || "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-xs">{click.country || "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-xs">{click.device || "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-xs">{click.browser || "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-xs">{click.os || "—"}</td>
                      <td className="max-w-[150px] truncate px-3 py-2 text-xs text-muted-foreground">
                        {click.referrer || "Direct"}
                      </td>
                      <td className="whitespace-nowrap px-3 py-2 text-xs text-muted-foreground">
                        {new Date(click.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="flex items-center justify-between pt-2 border-t">
          <p className="text-xs text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="rounded-md border px-2 py-1 text-xs disabled:opacity-50 hover:bg-muted"
            >
              Prev
            </button>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={page >= totalPages}
              className="rounded-md border px-2 py-1 text-xs disabled:opacity-50 hover:bg-muted"
            >
              Next
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

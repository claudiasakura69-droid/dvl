"use client";

import React from "react";
import { Plus } from "lucide-react";
import type { ShortLink } from "@/lib/types";

interface LinkTableProps {
  links: ShortLink[];
  loading: boolean;
  page: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  onEdit: (link: ShortLink) => void;
  onDelete: (link: ShortLink) => void;
  onCopy: (link: ShortLink) => void;
  onQR: (link: ShortLink) => void;
  onAnalytics: (link: ShortLink) => void;
}

export default function LinkTable({
  links,
  loading,
  page,
  totalPages,
  onPageChange,
  onEdit,
  onDelete,
  onCopy,
  onQR,
  onAnalytics,
}: LinkTableProps) {
  if (loading) {
    return (
      <div className="rounded-lg border">
        <div className="space-y-2 p-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="h-12 animate-pulse rounded bg-muted"
            />
          ))}
        </div>
      </div>
    );
  }

  if (links.length === 0) {
    return (
      <div className="rounded-lg border border-dashed p-8 text-center">
        <p className="text-sm text-muted-foreground">No links found.</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Create a new link to get started.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-lg border">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Short URL
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Destination
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Type
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Mode
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Clicks
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Status
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Health
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left font-medium text-muted-foreground">
                  Created
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-right font-medium text-muted-foreground">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {links.map((link) => (
                <tr
                  key={link.id}
                  className="border-b last:border-0 hover:bg-muted/30"
                >
                  <td className="whitespace-nowrap px-4 py-3">
                    <span className="font-medium text-primary">
                      {link.slug}
                    </span>
                  </td>
                  <td className="max-w-[200px] truncate px-4 py-3 text-muted-foreground">
                    {link.targets?.[0]?.url || link.title || "—"}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                        link.type === "multi"
                          ? "bg-chart-2/10 text-chart-2"
                          : "bg-chart-1/10 text-chart-1"
                      }`}
                    >
                      {link.type}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 capitalize text-muted-foreground">
                    {link.mode}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    {link._count?.clicks ?? link.clicks?.length ?? 0}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    <span
                      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                        link.isActive
                          ? "bg-green-500/10 text-green-600 dark:text-green-400"
                          : "bg-red-500/10 text-red-600 dark:text-red-400"
                      }`}
                    >
                      {link.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3">
                    {(() => {
                      const health = link.targets?.[0]?.isHealthy;
                      if (health === null || health === undefined) {
                        return (
                          <span className="inline-flex items-center rounded-full bg-gray-500/10 px-2 py-0.5 text-xs font-medium text-gray-500">
                            Unchecked
                          </span>
                        );
                      }
                      return health ? (
                        <span className="inline-flex items-center rounded-full bg-green-500/10 px-2 py-0.5 text-xs font-medium text-green-600 dark:text-green-400">
                          Healthy
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full bg-red-500/10 px-2 py-0.5 text-xs font-medium text-red-600 dark:text-red-400">
                          Unhealthy
                        </span>
                      );
                    })()}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-muted-foreground text-xs">
                    {new Date(link.createdAt).toLocaleDateString()}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => onEdit(link)}
                        className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="Edit"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                      </button>
                      <button
                        onClick={() => onCopy(link)}
                        className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="Copy URL"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                      </button>
                      <button
                        onClick={() => onQR(link)}
                        className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="QR Code"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/></svg>
                      </button>
                      <button
                        onClick={() => onAnalytics(link)}
                        className="rounded p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="Analytics"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                      </button>
                      <button
                        onClick={() => onDelete(link)}
                        className="rounded p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                        title="Delete"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onPageChange(page - 1)}
              disabled={page <= 1}
              className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-50 hover:bg-muted"
            >
              Previous
            </button>
            <button
              onClick={() => onPageChange(page + 1)}
              disabled={page >= totalPages}
              className="rounded-md border px-3 py-1.5 text-sm disabled:opacity-50 hover:bg-muted"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

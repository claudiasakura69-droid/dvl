"use client";

import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import QRCode from "qrcode";
import { Download } from "lucide-react";
import type { ShortLink } from "@/lib/types";

interface QRCodeDialogProps {
  link: ShortLink;
  open: boolean;
  onClose: () => void;
}

export default function QRCodeDialog({ link, open, onClose }: QRCodeDialogProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [size, setSize] = useState<number>(256);

  const url = `${link.domain?.domain || "s.url"}/${link.slug}`;

  React.useEffect(() => {
    if (open && url) {
      QRCode.toDataURL(url, {
        width: size,
        margin: 2,
        color: { dark: "#000000", light: "#ffffff" },
      }).then(setQrDataUrl).catch(console.error);
    }
  }, [open, url, size]);

  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = qrDataUrl;
    a.download = `${link.slug}-qrcode.png`;
    a.click();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>QR Code for {link.slug}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 py-4">
          <div className="rounded-lg border bg-white p-4">
            {qrDataUrl && (
              <img src={qrDataUrl} alt="QR Code" className="mx-auto" style={{ width: size / 2, height: size / 2 }} />
            )}
          </div>
          <p className="text-sm text-muted-foreground break-all text-center">{url}</p>
          <div className="flex items-center gap-2">
            <Label className="text-sm">Size:</Label>
            <Select value={String(size)} onValueChange={(v) => setSize(Number(v))}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="128">128px</SelectItem>
                <SelectItem value="256">256px</SelectItem>
                <SelectItem value="512">512px</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleDownload} className="gap-2 w-full">
            <Download className="h-4 w-4" />
            Download QR Code
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

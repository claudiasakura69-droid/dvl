"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Plus, Shuffle, ChevronDown, TriangleAlert } from "lucide-react";
import LinkTargetRow, { type TargetFormData } from "./LinkTargetRow";
import type { ShortDomain } from "@/lib/types";

interface LinkFormMultiProps {
  domains: ShortDomain[];
  slug: string;
  setSlug: (v: string) => void;
  domainId: string;
  setDomainId: (v: string) => void;
  mode: "random" | "sequential";
  setMode: (v: "random" | "sequential") => void;
  targets: TargetFormData[];
  setTargets: (v: TargetFormData[]) => void;
  title: string;
  setTitle: (v: string) => void;
  description: string;
  setDescription: (v: string) => void;
  password: string;
  setPassword: (v: string) => void;
  expiryDate: string;
  setExpiryDate: (v: string) => void;
  utmSource: string;
  setUtmSource: (v: string) => void;
  utmMedium: string;
  setUtmMedium: (v: string) => void;
  utmCampaign: string;
  setUtmCampaign: (v: string) => void;
  utmContent: string;
  setUtmContent: (v: string) => void;
  utmTerm: string;
  setUtmTerm: (v: string) => void;
  ogTitle: string;
  setOgTitle: (v: string) => void;
  ogDescription: string;
  setOgDescription: (v: string) => void;
  ogImage: string;
  setOgImage: (v: string) => void;
}

function generateRandomSlug(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export default function LinkFormMulti({
  domains,
  slug,
  setSlug,
  domainId,
  setDomainId,
  mode,
  setMode,
  targets,
  setTargets,
  title,
  setTitle,
  description,
  setDescription,
  password,
  setPassword,
  expiryDate,
  setExpiryDate,
  utmSource,
  setUtmSource,
  utmMedium,
  setUtmMedium,
  utmCampaign,
  setUtmCampaign,
  utmContent,
  setUtmContent,
  utmTerm,
  setUtmTerm,
  ogTitle,
  setOgTitle,
  ogDescription,
  setOgDescription,
  ogImage,
  setOgImage,
}: LinkFormMultiProps) {
  const [utmOpen, setUtmOpen] = useState(false);
  const [ogOpen, setOgOpen] = useState(false);

  const previewDomain = domains.find((d) => d.id === domainId)?.domain || "s.url";

  const addTarget = () => {
    setTargets([
      ...targets,
      { url: "", clickLimit: 0, country: "ALL", ipList: "", autoSkip: true },
    ]);
  };

  const removeTarget = (index: number) => {
    setTargets(targets.filter((_, i) => i !== index));
  };

  const updateTarget = (index: number, data: TargetFormData) => {
    const newTargets = [...targets];
    newTargets[index] = data;
    setTargets(newTargets);
  };

  const hasCatchAll = targets.some(
    (t) => t.clickLimit === 0 && t.country === "ALL" && t.ipList.trim() === ""
  );

  return (
    <div className="space-y-4">
      {/* Domain & Slug */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-end">
        <div className="space-y-2">
          <Label>Short Domain</Label>
          <Select value={domainId} onValueChange={setDomainId}>
            <SelectTrigger>
              <SelectValue placeholder="Select domain" />
            </SelectTrigger>
            <SelectContent>
              {domains.map((d) => (
                <SelectItem key={d.id} value={d.id}>
                  {d.domain}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="hidden sm:block text-muted-foreground pb-2">/</div>
        <div className="space-y-2">
          <Label>Slug</Label>
          <div className="flex gap-2">
            <Input
              placeholder="my-multi-link"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => setSlug(generateRandomSlug())}
              title="Generate random slug"
            >
              <Shuffle className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Preview */}
      {slug && domainId && (
        <div className="rounded-lg bg-muted p-3">
          <p className="text-sm text-muted-foreground">Preview</p>
          <p className="font-mono text-sm font-medium">
            {previewDomain}/{slug}
          </p>
        </div>
      )}

      {/* Mode */}
      <div className="space-y-2">
        <Label>Routing Mode</Label>
        <Select value={mode} onValueChange={(v) => setMode(v as "random" | "sequential")}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="sequential">Sequential Order</SelectItem>
            <SelectItem value="random">Random All</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Warning if no catch-all */}
      {!hasCatchAll && targets.length > 0 && (
        <Alert variant="destructive">
          <TriangleAlert className="h-4 w-4" />
          <AlertDescription>
            No catch-all target found. Add a target with unlimited clicks, ALL countries, and no IP restriction to handle unmatched traffic.
          </AlertDescription>
        </Alert>
      )}

      {/* Targets */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label>Target Links</Label>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addTarget}
            className="gap-1"
          >
            <Plus className="h-3 w-3" />
            Add More
          </Button>
        </div>
        {targets.map((target, index) => (
          <LinkTargetRow
            key={index}
            index={index}
            target={target}
            onChange={updateTarget}
            onRemove={removeTarget}
            canRemove={targets.length > 1}
            totalTargets={targets.length}
          />
        ))}
      </div>

      {/* Routing Logic Visualization */}
      {targets.length > 1 && (
        <div className="rounded-lg border p-4">
          <p className="text-sm font-medium mb-2">Routing Logic Preview</p>
          <div className="space-y-1">
            {targets.map((t, i) => (
              <div
                key={i}
                className="flex items-center gap-2 rounded bg-muted px-3 py-2 text-xs"
              >
                <span className="font-medium">{i + 1}.</span>
                <span className="flex-1 truncate">{t.url || "—"}</span>
                <span className="text-muted-foreground">
                  {t.clickLimit > 0 ? `${t.clickLimit} clicks` : "unlimited"}
                </span>
                <span className="text-muted-foreground">{t.country}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Optional Fields */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <Label>Title</Label>
          <Input
            placeholder="Link title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Password</Label>
          <Input
            placeholder="Optional password protection"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          placeholder="Optional description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
        />
      </div>

      <div className="space-y-2">
        <Label>Expiry Date</Label>
        <Input
          type="datetime-local"
          value={expiryDate}
          onChange={(e) => setExpiryDate(e.target.value)}
        />
      </div>

      {/* UTM Parameters */}
      <Collapsible open={utmOpen} onOpenChange={setUtmOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full justify-between">
            UTM Parameters
            <ChevronDown className={`h-4 w-4 transition-transform ${utmOpen ? "rotate-180" : ""}`} />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Card className="mt-2">
            <CardContent className="grid gap-3 pt-4 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-xs">UTM Source</Label>
                <Input placeholder="google" value={utmSource} onChange={(e) => setUtmSource(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Medium</Label>
                <Input placeholder="cpc" value={utmMedium} onChange={(e) => setUtmMedium(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Campaign</Label>
                <Input placeholder="spring_sale" value={utmCampaign} onChange={(e) => setUtmCampaign(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Content</Label>
                <Input placeholder="logolink" value={utmContent} onChange={(e) => setUtmContent(e.target.value)} />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label className="text-xs">UTM Term</Label>
                <Input placeholder="running+shoes" value={utmTerm} onChange={(e) => setUtmTerm(e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>

      {/* OG Meta */}
      <Collapsible open={ogOpen} onOpenChange={setOgOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full justify-between">
            OG Meta Tags
            <ChevronDown className={`h-4 w-4 transition-transform ${ogOpen ? "rotate-180" : ""}`} />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Card className="mt-2">
            <CardContent className="grid gap-3 pt-4">
              <div className="space-y-1">
                <Label className="text-xs">OG Title</Label>
                <Input placeholder="Page title" value={ogTitle} onChange={(e) => setOgTitle(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">OG Description</Label>
                <Textarea placeholder="Page description" value={ogDescription} onChange={(e) => setOgDescription(e.target.value)} rows={2} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">OG Image URL</Label>
                <Input placeholder="https://example.com/image.png" value={ogImage} onChange={(e) => setOgImage(e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

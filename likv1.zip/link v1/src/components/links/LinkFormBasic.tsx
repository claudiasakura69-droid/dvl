"use client";

import React from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shuffle, ChevronDown } from "lucide-react";
import type { ShortDomain } from "@/lib/types";

interface LinkFormBasicProps {
  domains: ShortDomain[];
  slug: string;
  setSlug: (v: string) => void;
  domainId: string;
  setDomainId: (v: string) => void;
  title: string;
  setTitle: (v: string) => void;
  description: string;
  setDescription: (v: string) => void;
  password: string;
  setPassword: (v: string) => void;
  expiryDate: string;
  setExpiryDate: (v: string) => void;
  utmSource: string;
  setUtmSource: (v: string) => void;
  utmMedium: string;
  setUtmMedium: (v: string) => void;
  utmCampaign: string;
  setUtmCampaign: (v: string) => void;
  utmContent: string;
  setUtmContent: (v: string) => void;
  utmTerm: string;
  setUtmTerm: (v: string) => void;
  ogTitle: string;
  setOgTitle: (v: string) => void;
  ogDescription: string;
  setOgDescription: (v: string) => void;
  ogImage: string;
  setOgImage: (v: string) => void;
  destinationUrl: string;
  setDestinationUrl: (v: string) => void;
}

function generateRandomSlug(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export default function LinkFormBasic({
  domains,
  slug,
  setSlug,
  domainId,
  setDomainId,
  title,
  setTitle,
  description,
  setDescription,
  password,
  setPassword,
  expiryDate,
  setExpiryDate,
  utmSource,
  setUtmSource,
  utmMedium,
  setUtmMedium,
  utmCampaign,
  setUtmCampaign,
  utmContent,
  setUtmContent,
  utmTerm,
  setUtmTerm,
  ogTitle,
  setOgTitle,
  ogDescription,
  setOgDescription,
  ogImage,
  setOgImage,
  destinationUrl,
  setDestinationUrl,
}: LinkFormBasicProps) {
  const [utmOpen, setUtmOpen] = useState(false);
  const [ogOpen, setOgOpen] = useState(false);

  const previewDomain = domains.find((d) => d.id === domainId)?.domain || "s.url";

  return (
    <div className="space-y-4">
      {/* Domain & Slug */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto_1fr] sm:items-end">
        <div className="space-y-2">
          <Label>Short Domain</Label>
          <Select value={domainId} onValueChange={setDomainId}>
            <SelectTrigger>
              <SelectValue placeholder="Select domain" />
            </SelectTrigger>
            <SelectContent>
              {domains.map((d) => (
                <SelectItem key={d.id} value={d.id}>
                  {d.domain}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="hidden sm:block text-muted-foreground pb-2">/</div>
        <div className="space-y-2">
          <Label>Slug</Label>
          <div className="flex gap-2">
            <Input
              placeholder="my-link"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => setSlug(generateRandomSlug())}
              title="Generate random slug"
            >
              <Shuffle className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Preview */}
      {slug && domainId && (
        <div className="rounded-lg bg-muted p-3">
          <p className="text-sm text-muted-foreground">Preview</p>
          <p className="font-mono text-sm font-medium">
            {previewDomain}/{slug}
          </p>
        </div>
      )}

      {/* Destination URL */}
      <div className="space-y-2">
        <Label>Destination URL *</Label>
        <Input
          placeholder="https://example.com/very-long-url"
          value={destinationUrl}
          onChange={(e) => setDestinationUrl(e.target.value)}
        />
      </div>

      {/* Optional Fields */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <Label>Title</Label>
          <Input
            placeholder="Link title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label>Password</Label>
          <Input
            placeholder="Optional password protection"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          placeholder="Optional description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={2}
        />
      </div>

      <div className="space-y-2">
        <Label>Expiry Date</Label>
        <Input
          type="datetime-local"
          value={expiryDate}
          onChange={(e) => setExpiryDate(e.target.value)}
        />
      </div>

      {/* UTM Parameters */}
      <Collapsible open={utmOpen} onOpenChange={setUtmOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full justify-between">
            UTM Parameters
            <ChevronDown
              className={`h-4 w-4 transition-transform ${utmOpen ? "rotate-180" : ""}`}
            />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Card className="mt-2">
            <CardContent className="grid gap-3 pt-4 sm:grid-cols-2">
              <div className="space-y-1">
                <Label className="text-xs">UTM Source</Label>
                <Input placeholder="google" value={utmSource} onChange={(e) => setUtmSource(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Medium</Label>
                <Input placeholder="cpc" value={utmMedium} onChange={(e) => setUtmMedium(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Campaign</Label>
                <Input placeholder="spring_sale" value={utmCampaign} onChange={(e) => setUtmCampaign(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">UTM Content</Label>
                <Input placeholder="logolink" value={utmContent} onChange={(e) => setUtmContent(e.target.value)} />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label className="text-xs">UTM Term</Label>
                <Input placeholder="running+shoes" value={utmTerm} onChange={(e) => setUtmTerm(e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>

      {/* OG Meta */}
      <Collapsible open={ogOpen} onOpenChange={setOgOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" className="w-full justify-between">
            OG Meta Tags
            <ChevronDown
              className={`h-4 w-4 transition-transform ${ogOpen ? "rotate-180" : ""}`}
            />
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <Card className="mt-2">
            <CardContent className="grid gap-3 pt-4">
              <div className="space-y-1">
                <Label className="text-xs">OG Title</Label>
                <Input placeholder="Page title" value={ogTitle} onChange={(e) => setOgTitle(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">OG Description</Label>
                <Textarea placeholder="Page description" value={ogDescription} onChange={(e) => setOgDescription(e.target.value)} rows={2} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">OG Image URL</Label>
                <Input placeholder="https://example.com/image.png" value={ogImage} onChange={(e) => setOgImage(e.target.value)} />
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

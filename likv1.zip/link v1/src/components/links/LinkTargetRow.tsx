"use client";

import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TriangleAlert } from "lucide-react";

export interface TargetFormData {
  url: string;
  clickLimit: number;
  country: string;
  ipList: string;
  autoSkip: boolean;
}

interface LinkTargetRowProps {
  index: number;
  target: TargetFormData;
  onChange: (index: number, data: TargetFormData) => void;
  onRemove: (index: number) => void;
  canRemove: boolean;
  totalTargets: number;
}

const COUNTRIES = [
  { code: "ALL", label: "All Countries" },
  { code: "US", label: "United States" },
  { code: "GB", label: "United Kingdom" },
  { code: "ID", label: "Indonesia" },
  { code: "JP", label: "Japan" },
  { code: "KR", label: "South Korea" },
  { code: "DE", label: "Germany" },
  { code: "FR", label: "France" },
  { code: "BR", label: "Brazil" },
  { code: "IN", label: "India" },
  { code: "AU", label: "Australia" },
  { code: "CA", label: "Canada" },
  { code: "SG", label: "Singapore" },
  { code: "MY", label: "Malaysia" },
  { code: "PH", label: "Philippines" },
  { code: "TH", label: "Thailand" },
  { code: "VN", label: "Vietnam" },
];

export default function LinkTargetRow({
  index,
  target,
  onChange,
  onRemove,
  canRemove,
  totalTargets,
}: LinkTargetRowProps) {
  const isCatchAll =
    target.clickLimit === 0 &&
    target.country === "ALL" &&
    target.ipList.trim() === "";

  return (
    <div className="relative rounded-lg border p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-muted text-xs font-medium">
            {index + 1}
          </span>
          <span className="text-sm font-medium">Target {index + 1}</span>
          {isCatchAll && (
            <span className="rounded-full bg-green-500/10 px-2 py-0.5 text-xs font-medium text-green-600 dark:text-green-400">
              Catch-all
            </span>
          )}
        </div>
        {canRemove && (
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 text-muted-foreground hover:text-destructive"
            onClick={() => onRemove(index)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="space-y-2">
        <Label className="text-xs">Destination URL</Label>
        <Input
          placeholder="https://example.com"
          value={target.url}
          onChange={(e) =>
            onChange(index, { ...target, url: e.target.value })
          }
        />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <Label className="text-xs">
            Click Limit{" "}
            <span className="text-muted-foreground">(0 = unlimited)</span>
          </Label>
          <Input
            type="number"
            min={0}
            value={target.clickLimit}
            onChange={(e) =>
              onChange(index, {
                ...target,
                clickLimit: parseInt(e.target.value) || 0,
              })
            }
          />
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Country</Label>
          <Select
            value={target.country}
            onValueChange={(v) => onChange(index, { ...target, country: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {COUNTRIES.map((c) => (
                <SelectItem key={c.code} value={c.code}>
                  {c.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-xs">
          IP List{" "}
          <span className="text-muted-foreground">(comma-separated, empty = no restriction)</span>
        </Label>
        <Input
          placeholder="192.168.1.1, 10.0.0.1"
          value={target.ipList}
          onChange={(e) =>
            onChange(index, { ...target, ipList: e.target.value })
          }
        />
      </div>

      <div className="flex items-center gap-2">
        <Switch
          checked={target.autoSkip}
          onCheckedChange={(v) =>
            onChange(index, { ...target, autoSkip: v })
          }
        />
        <Label className="text-xs">Auto-skip to next target when limit reached</Label>
      </div>
    </div>
  );
}

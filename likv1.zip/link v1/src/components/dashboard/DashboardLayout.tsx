"use client";

import React from "react";
import { useAppStore } from "@/lib/store";
import { AppSidebar } from "./SidebarNav";
import Header from "./Header";
import OverviewPage from "@/components/pages/OverviewPage";
import LinksPage from "@/components/pages/LinksPage";
import CreateLinkPage from "@/components/pages/CreateLinkPage";
import EditLinkPage from "@/components/pages/EditLinkPage";
import DomainsPage from "@/components/pages/DomainsPage";
import AnalyticsPage from "@/components/pages/AnalyticsPage";
import BulkOperationsPage from "@/components/pages/BulkOperationsPage";
import SettingsPage from "@/components/pages/SettingsPage";
import NotFoundPage from "@/components/pages/NotFoundPage";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";

function PageRouter() {
  const currentPage = useAppStore((s) => s.currentPage);

  switch (currentPage) {
    case "overview":
      return <OverviewPage />;
    case "links":
      return <LinksPage />;
    case "create-link":
      return <CreateLinkPage />;
    case "edit-link":
      return <EditLinkPage />;
    case "domains":
      return <DomainsPage />;
    case "analytics":
      return <AnalyticsPage />;
    case "bulk":
      return <BulkOperationsPage />;
    case "settings":
      return <SettingsPage />;
    default:
      return <NotFoundPage />;
  }
}

export default function DashboardLayout() {
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <Header />
        <div className="flex-1 overflow-auto p-4 md:p-6">
          <PageRouter />
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}

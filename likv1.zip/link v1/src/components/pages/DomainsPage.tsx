"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import DomainCard from "@/components/domains/DomainCard";
import AddDomainDialog from "@/components/domains/AddDomainDialog";
import EditDomainDialog from "@/components/domains/EditDomainDialog";
import DNSSetupDialog from "@/components/domains/DNSSetupDialog";
import { useAppStore } from "@/lib/store";
import { apiGet, apiPost, apiPut, apiDelete } from "@/lib/api";
import { Plus, Info, Globe, LayoutDashboard, Link2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import type { ShortDomain } from "@/lib/types";

export default function DomainsPage() {
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editTarget, setEditTarget] = useState<ShortDomain | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ShortDomain | null>(null);
  const [dnsTarget, setDnsTarget] = useState<ShortDomain | null>(null);

  // Get the main domain from env or detect it
  const mainDomain =
    typeof window !== "undefined"
      ? window.location.hostname === "localhost"
        ? "your-project.pages.dev"
        : window.location.hostname
      : "";

  const loadDomains = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiGet<ShortDomain[]>("/domains");
      setDomains(Array.isArray(res) ? res : []);
    } catch {
      setDomains([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDomains();
  }, [loadDomains]);

  const handleAdd = async (domain: string, slug: string) => {
    try {
      await apiPost("/domains", { domain, slug: slug || undefined });
      toast.success("Domain added successfully");
      setShowAddDialog(false);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to add domain");
      throw err;
    }
  };

  const handleUpdate = async (
    id: string,
    data: { domain: string; slug: string }
  ) => {
    try {
      await apiPut(`/domains/${id}`, data);
      toast.success("Domain updated");
      setEditTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to update domain");
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await apiDelete(`/domains/${deleteTarget.id}`);
      toast.success("Domain deleted");
      setDeleteTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to delete domain");
    }
  };

  const handleVerify = async (domain: ShortDomain) => {
    try {
      await apiPost(`/domains/${domain.id}/verify`);
      toast.success("Domain verified successfully");
      loadDomains();
    } catch {
      toast.success("Domain marked as verified (demo)");
      setDomains((prev) =>
        prev.map((d) =>
          d.id === domain.id
            ? { ...d, isVerified: true, verifiedAt: new Date().toISOString() }
            : d
        )
      );
    }
  };

  const handleToggle = async (domain: ShortDomain) => {
    try {
      await apiPut(`/domains/${domain.id}`, { isActive: !domain.isActive });
      toast.success(`Domain ${domain.isActive ? "deactivated" : "activated"}`);
      loadDomains();
    } catch {
      toast.success(
        `Domain ${domain.isActive ? "deactivated" : "activated"} (demo)`
      );
      setDomains((prev) =>
        prev.map((d) =>
          d.id === domain.id ? { ...d, isActive: !d.isActive } : d
        )
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Domains</h2>
          <p className="text-sm text-muted-foreground">
            Manage your main dashboard domain and short URL domains
          </p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Domain
        </Button>
      </div>

      {/* Architecture Overview Card */}
      <div className="rounded-lg border bg-muted/30 p-4">
        <div className="flex items-start gap-3">
          <Info className="h-5 w-5 text-muted-foreground mt-0.5 shrink-0" />
          <div className="space-y-2">
            <h3 className="text-sm font-semibold">
              How Domains Work Together
            </h3>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex items-start gap-2 rounded-md bg-blue-500/5 border border-blue-500/20 p-3">
                <LayoutDashboard className="h-4 w-4 text-blue-500 mt-0.5 shrink-0" />
                <div className="text-xs">
                  <p className="font-medium text-blue-600 dark:text-blue-400">
                    Main Domain (Dashboard)
                  </p>
                  <p className="text-muted-foreground mt-0.5">
                    <code className="bg-muted px-1 rounded">{mainDomain}</code>
                  </p>
                  <p className="text-muted-foreground mt-1">
                    Serves the login page and dashboard for managing links,
                    domains, analytics, etc.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-md bg-green-500/5 border border-green-500/20 p-3">
                <Link2 className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                <div className="text-xs">
                  <p className="font-medium text-green-600 dark:text-green-400">
                    Short URL Domains
                  </p>
                  <p className="text-muted-foreground mt-0.5">
                    {domains.length > 0
                      ? domains
                          .slice(0, 2)
                          .map((d) => d.domain)
                          .join(", ")
                      : "No domains added yet"}
                  </p>
                  <p className="text-muted-foreground mt-1">
                    Handle short URL redirects. When someone visits{" "}
                    <code className="bg-muted px-1 rounded">domain/slug</code>,
                    they get redirected to the target URL.
                  </p>
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2 rounded-md bg-amber-500/5 border border-amber-500/20 p-3">
              <Globe className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
              <div className="text-xs">
                <p className="font-medium text-amber-600 dark:text-amber-400">
                  How They Connect
                </p>
                <p className="text-muted-foreground mt-0.5">
                  Both domains point to the <strong>same Cloudflare Pages
                  project</strong>. The middleware automatically detects which
                  domain is being accessed:
                </p>
                <ul className="mt-1 space-y-0.5 text-muted-foreground">
                  <li>
                    &bull; <strong>{mainDomain}</strong> → Serves the dashboard
                    SPA (login + management)
                  </li>
                  <li>
                    &bull; <strong>Other domains</strong> → Looks up the slug in
                    the database and performs a 301 redirect
                  </li>
                  <li>
                    &bull; <strong>Slug not found</strong> → Shows a 404 page on
                    the short URL domain
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Environment Variable Reminder */}
      <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
        <div className="flex items-start gap-3">
          <Globe className="h-5 w-5 text-amber-500 mt-0.5 shrink-0" />
          <div className="text-xs space-y-1">
            <p className="font-medium text-amber-600 dark:text-amber-400">
              Required Environment Variable
            </p>
            <p className="text-muted-foreground">
              Make sure <code className="bg-muted px-1 rounded">APP_DOMAIN</code>{" "}
              is set to your main domain hostname in Cloudflare Pages
              environment variables. This tells the system which domain should
              serve the dashboard vs. handle short URL redirects.
            </p>
            <code className="block bg-muted px-2 py-1 rounded mt-1">
              APP_DOMAIN={mainDomain}
            </code>
          </div>
        </div>
      </div>

      {/* Domain Cards */}
      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="h-32 animate-pulse rounded-lg bg-muted"
            />
          ))}
        </div>
      ) : domains.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-sm text-muted-foreground">
            No domains configured.
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Add a short URL domain to start creating short links with custom
            domains.
          </p>
          <Button
            onClick={() => setShowAddDialog(true)}
            variant="outline"
            className="mt-4 gap-2"
          >
            <Plus className="h-4 w-4" />
            Add Your First Domain
          </Button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {domains.map((domain) => (
            <DomainCard
              key={domain.id}
              domain={domain}
              onEdit={setEditTarget}
              onDelete={setDeleteTarget}
              onVerify={handleVerify}
              onToggle={handleToggle}
              onDnsSetup={setDnsTarget}
            />
          ))}
        </div>
      )}

      {/* Add Domain Dialog */}
      <AddDomainDialog
        open={showAddDialog}
        onClose={() => setShowAddDialog(false)}
        onAdd={handleAdd}
      />

      {/* Edit Domain Dialog */}
      {editTarget && (
        <EditDomainDialog
          open={!!editTarget}
          onClose={() => setEditTarget(null)}
          domain={editTarget}
          onUpdate={handleUpdate}
        />
      )}

      {/* DNS Setup Dialog */}
      {dnsTarget && (
        <DNSSetupDialog
          open={!!dnsTarget}
          onClose={() => setDnsTarget(null)}
          domain={dnsTarget.domain}
          mainDomain={mainDomain}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Domain</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deleteTarget?.domain}&quot;?
              This will also delete all links associated with this domain. This
              action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

import { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  getSettings,
  updateSettings,
  exportData,
  importData,
  dangerOperation,
  getLinks,
  getDomains,
  bulkDeleteLinks,
} from "@/lib/api";
import { toast } from "sonner";
import {
  Key,
  Download,
  Upload,
  Trash2,
  Database,
  Loader2,
  Eye,
  EyeOff,
  FileText,
} from "lucide-react";
import { useAppStore } from "@/lib/store";

export default function SettingsPage() {
  const [loading, setLoading] = useState(true);
  const [showToken, setShowToken] = useState(false);
  const [redirectStatus, setRedirectStatus] = useState("301");
  const [healthInterval, setHealthInterval] = useState("60");
  const [defaultUtmSource, setDefaultUtmSource] = useState("");
  const [defaultUtmMedium, setDefaultUtmMedium] = useState("");
  const [showDeleteLinks, setShowDeleteLinks] = useState(false);
  const [showDeleteClicks, setShowDeleteClicks] = useState(false);
  const [showResetDb, setShowResetDb] = useState(false);
  const [processing, setProcessing] = useState(false);
  const logout = useAppStore((s) => s.logout);
  const importInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const res = await getSettings();
      if (res) {
        setRedirectStatus(res.redirectStatus || "301");
        setHealthInterval(res.healthInterval || "60");
        setDefaultUtmSource(res.defaultUtmSource || "");
        setDefaultUtmMedium(res.defaultUtmMedium || "");
      }
    } catch {
      // Use defaults
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    setProcessing(true);
    try {
      await updateSettings({
        redirectStatus,
        healthInterval,
        defaultUtmSource,
        defaultUtmMedium,
      });
      toast.success("Settings saved");
    } catch (err: any) {
      toast.error(err.message || "Failed to save settings");
    } finally {
      setProcessing(false);
    }
  };

  const handleExportJSON = async () => {
    setProcessing(true);
    try {
      const data = await exportData(false);
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `shorturl-export-${new Date().toISOString().split("T")[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`Exported ${(data.links || []).length} links and ${(data.domains || []).length} domains`);
    } catch (err: any) {
      toast.error(err.message || "Failed to export data");
    } finally {
      setProcessing(false);
    }
  };

  const handleExportCSV = async () => {
    setProcessing(true);
    try {
      const data = await exportData(false);
      const links = data.links || [];

      // CSV header
      const headers = ["slug", "domain", "url", "type", "mode", "clicks", "active", "createdAt"];
      const rows = links.map((l: any) => {
        const url = l.targets?.[0]?.url || "";
        return [
          l.slug,
          l.domain || "",
          `"${url.replace(/"/g, '""')}"`,
          l.type,
          l.mode,
          String(l.clicks || 0),
          l.isActive ? "true" : "false",
          l.createdAt ? new Date(l.createdAt).toISOString() : "",
        ].join(",");
      });

      const csv = [headers.join(","), ...rows].join("\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `shorturl-export-${new Date().toISOString().split("T")[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`Exported ${links.length} links as CSV`);
    } catch (err: any) {
      toast.error(err.message || "Failed to export CSV");
    } finally {
      setProcessing(false);
    }
  };

  const handleImportClick = () => {
    importInputRef.current?.click();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setProcessing(true);
    try {
      const text = await file.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        toast.error("Invalid JSON file");
        return;
      }

      // Validate structure
      if (typeof parsed !== "object" || parsed === null) {
        toast.error("Invalid import data: expected a JSON object");
        return;
      }

      const hasLinks = Array.isArray(parsed.links) && parsed.links.length > 0;
      const hasDomains = Array.isArray(parsed.domains) && parsed.domains.length > 0;

      if (!hasLinks && !hasDomains) {
        toast.error("No links or domains found in the import file");
        return;
      }

      const result = await importData({
        links: parsed.links || [],
        domains: parsed.domains || [],
      });

      const parts: string[] = [];
      if (result.createdDomains) parts.push(`${result.createdDomains} domains created`);
      if (result.skippedDomains) parts.push(`${result.skippedDomains} domains skipped`);
      if (result.createdLinks) parts.push(`${result.createdLinks} links created`);
      if (result.skippedLinks) parts.push(`${result.skippedLinks} links skipped`);

      toast.success(`Import complete: ${parts.join(", ")}`);
    } catch (err: any) {
      toast.error(err.message || "Failed to import data");
    } finally {
      setProcessing(false);
      // Reset input
      if (importInputRef.current) {
        importInputRef.current.value = "";
      }
    }
  };

  const handleDeleteLinks = async () => {
    setProcessing(true);
    try {
      await dangerOperation("deleteAllLinks");
      toast.success("All links deleted");
      setShowDeleteLinks(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to delete links");
    } finally {
      setProcessing(false);
    }
  };

  const handleDeleteClicks = async () => {
    setProcessing(true);
    try {
      await dangerOperation("deleteAllClicks");
      toast.success("All click data deleted");
      setShowDeleteClicks(false);
    } catch (err: any) {
      toast.error(err.message || "Failed to delete clicks");
    } finally {
      setProcessing(false);
    }
  };

  const handleResetDb = async () => {
    setProcessing(true);
    try {
      await dangerOperation("resetDatabase");
      toast.success("Database reset complete");
      setShowResetDb(false);
      logout();
    } catch (err: any) {
      toast.error(err.message || "Failed to reset database");
    } finally {
      setProcessing(false);
    }
  };

  const token = typeof window !== "undefined" ? localStorage.getItem("token") || "" : "";

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h2 className="text-lg font-semibold">Settings</h2>

      {/* Token Management */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Key className="h-4 w-4" />
            Token Management
          </CardTitle>
          <CardDescription>Your API authentication token</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-2">
            <Input
              type={showToken ? "text" : "password"}
              value={token}
              readOnly
              className="font-mono"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowToken(!showToken)}
            >
              {showToken ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Token is stored in your browser&apos;s localStorage. To change it, log out and log back in with a new token.
          </p>
        </CardContent>
      </Card>

      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">General Settings</CardTitle>
          <CardDescription>Configure default behavior</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Default Redirect Status</Label>
            <Select value={redirectStatus} onValueChange={setRedirectStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="301">301 (Permanent)</SelectItem>
                <SelectItem value="302">302 (Temporary)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Health Check Interval (minutes)</Label>
            <Input
              type="number"
              value={healthInterval}
              onChange={(e) => setHealthInterval(e.target.value)}
              min={1}
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <Label className="text-sm font-medium">Default UTM Parameters</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Source</Label>
                <Input
                  placeholder="google"
                  value={defaultUtmSource}
                  onChange={(e) => setDefaultUtmSource(e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Medium</Label>
                <Input
                  placeholder="cpc"
                  value={defaultUtmMedium}
                  onChange={(e) => setDefaultUtmMedium(e.target.value)}
                />
              </div>
            </div>
          </div>

          <Button onClick={handleSaveSettings} disabled={processing} className="gap-2">
            {processing && <Loader2 className="h-4 w-4 animate-spin" />}
            Save Settings
          </Button>
        </CardContent>
      </Card>

      {/* Export/Import */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Export / Import</CardTitle>
          <CardDescription>Backup and restore your data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={handleExportJSON}
              disabled={processing}
              className="gap-2 flex-1 min-w-[140px]"
            >
              <Download className="h-4 w-4" />
              Export as JSON
            </Button>
            <Button
              variant="outline"
              onClick={handleExportCSV}
              disabled={processing}
              className="gap-2 flex-1 min-w-[140px]"
            >
              <FileText className="h-4 w-4" />
              Export as CSV
            </Button>
          </div>
          <input
            ref={importInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleImportFile}
          />
          <Button
            variant="outline"
            onClick={handleImportClick}
            disabled={processing}
            className="gap-2 w-full"
          >
            <Upload className="h-4 w-4" />
            Import from JSON
          </Button>
          <p className="text-xs text-muted-foreground">
            Import supports files with links and domains arrays. Existing entries with the same slug+domain will be skipped.
          </p>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="text-base text-destructive flex items-center gap-2">
            <Trash2 className="h-4 w-4" />
            Danger Zone
          </CardTitle>
          <CardDescription>
            Irreversible and destructive actions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border border-destructive/30 p-3">
            <div>
              <p className="text-sm font-medium">Delete All Links</p>
              <p className="text-xs text-muted-foreground">
                Remove all short links and their targets
              </p>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowDeleteLinks(true)}
              disabled={processing}
            >
              Delete Links
            </Button>
          </div>

          <div className="flex items-center justify-between rounded-lg border border-destructive/30 p-3">
            <div>
              <p className="text-sm font-medium">Delete All Click Data</p>
              <p className="text-xs text-muted-foreground">
                Remove all click/analytics records
              </p>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowDeleteClicks(true)}
              disabled={processing}
            >
              Delete Clicks
            </Button>
          </div>

          <div className="flex items-center justify-between rounded-lg border border-destructive/30 p-3">
            <div>
              <p className="text-sm font-medium">Reset Database</p>
              <p className="text-xs text-muted-foreground">
                Delete everything and start fresh
              </p>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setShowResetDb(true)}
              disabled={processing}
            >
              <Database className="h-4 w-4" />
              Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Delete Links Confirm */}
      <AlertDialog open={showDeleteLinks} onOpenChange={setShowDeleteLinks}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete All Links</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all short links and their targets. Click data will be preserved. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteLinks}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={processing}
            >
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete All Links
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Clicks Confirm */}
      <AlertDialog open={showDeleteClicks} onOpenChange={setShowDeleteClicks}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete All Click Data</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all click and analytics records. Links will be preserved. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteClicks}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={processing}
            >
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete All Clicks
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reset DB Confirm */}
      <AlertDialog open={showResetDb} onOpenChange={setShowResetDb}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Entire Database</AlertDialogTitle>
            <AlertDialogDescription>
              This will delete ALL data including links, domains, clicks, and settings. You will be logged out. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleResetDb}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={processing}
            >
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Reset Database
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

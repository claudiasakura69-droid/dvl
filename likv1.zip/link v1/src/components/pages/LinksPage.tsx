"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import LinkTable from "@/components/links/LinkTable";
import QRCodeDialog from "@/components/links/QRCodeDialog";
import LinkAnalyticsDialog from "@/components/links/LinkAnalyticsDialog";
import { useAppStore } from "@/lib/store";
import { getLinks, getDomains, deleteLink } from "@/lib/api";
import { Plus, Search } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import type { ShortLink, ShortDomain } from "@/lib/types";

export default function LinksPage() {
  const [links, setLinks] = useState<ShortLink[]>([]);
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState("");
  const [filterDomain, setFilterDomain] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [deleteTarget, setDeleteTarget] = useState<ShortLink | null>(null);
  const [qrTarget, setQrTarget] = useState<ShortLink | null>(null);
  const [analyticsTarget, setAnalyticsTarget] = useState<ShortLink | null>(null);
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);
  const setSelectedLinkId = useAppStore((s) => s.setSelectedLinkId);

  // Load domains on mount
  const loadDomains = useCallback(async () => {
    try {
      const res = await getDomains();
      setDomains(Array.isArray(res) ? res : []);
    } catch {
      setDomains([]);
    }
  }, []);

  const loadLinks = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string> = {
        page: String(page),
        limit: "10",
      };
      if (search) params.search = search;
      if (filterDomain !== "all") params.domainId = filterDomain;
      if (filterType !== "all") params.type = filterType;
      if (filterStatus !== "all") {
        params.isActive = filterStatus === "active" ? "true" : "false";
      }

      const res = await getLinks(params);
      setLinks(res.links || []);
      setTotalPages(res.totalPages || 1);
    } catch {
      setLinks([]);
    } finally {
      setLoading(false);
    }
  }, [page, search, filterDomain, filterType, filterStatus]);

  useEffect(() => {
    loadDomains();
  }, [loadDomains]);

  useEffect(() => {
    loadLinks();
  }, [loadLinks]);

  // Build link count per domain for display
  const domainLinkCounts: Record<string, number> = {};
  domains.forEach((d) => {
    domainLinkCounts[d.id] = (domainLinkCounts[d.id] || 0) + 0;
  });

  const handleEdit = (link: ShortLink) => {
    setSelectedLinkId(link.id);
    setCurrentPage("edit-link");
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteLink(deleteTarget.id);
      toast.success("Link deleted");
      setDeleteTarget(null);
      loadLinks();
    } catch {
      toast.error("Failed to delete link");
    }
  };

  const handleCopy = async (link: ShortLink) => {
    const url = `${link.domain?.domain || "s.url"}/${link.slug}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("URL copied to clipboard");
    } catch {
      toast.error("Failed to copy URL");
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">Links</h2>
        <Button
          onClick={() => setCurrentPage("create-link")}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Create New Link
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search links..."
            className="pl-9"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>
        <Select value={filterDomain} onValueChange={(v) => { setFilterDomain(v); setPage(1); }}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="All Domains" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Domains</SelectItem>
            {domains.map((d) => (
              <SelectItem key={d.id} value={d.id}>
                {d.domain}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={(v) => { setFilterType(v); setPage(1); }}>
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="basic">Basic</SelectItem>
            <SelectItem value="multi">Multi</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={(v) => { setFilterStatus(v); setPage(1); }}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <LinkTable
        links={links}
        loading={loading}
        page={page}
        totalPages={totalPages}
        onPageChange={setPage}
        onEdit={handleEdit}
        onDelete={(link) => setDeleteTarget(link)}
        onCopy={handleCopy}
        onQR={(link) => setQrTarget(link)}
        onAnalytics={(link) => setAnalyticsTarget(link)}
      />

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Link</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the link &quot;{deleteTarget?.slug}&quot;? This action cannot be undone and will also delete all associated click data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* QR Code Dialog */}
      {qrTarget && (
        <QRCodeDialog
          link={qrTarget}
          open={!!qrTarget}
          onClose={() => setQrTarget(null)}
        />
      )}

      {/* Analytics Dialog */}
      {analyticsTarget && (
        <LinkAnalyticsDialog
          link={analyticsTarget}
          open={!!analyticsTarget}
          onClose={() => setAnalyticsTarget(null)}
        />
      )}
    </div>
  );
}

"use client";

import { useState, useEffect, useCallback } from "react";
import StatsCards from "@/components/analytics/StatsCards";
import ClicksChart from "@/components/analytics/ClicksChart";
import CountryChart from "@/components/analytics/CountryChart";
import DeviceChart from "@/components/analytics/DeviceChart";
import { getOverviewAnalytics } from "@/lib/api";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState("7d");
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [clicksOverTime, setClicksOverTime] = useState<any[]>([]);
  const [topLinks, setTopLinks] = useState<any[]>([]);
  const [topCountries, setTopCountries] = useState<any[]>([]);
  const [topDevices, setTopDevices] = useState<any[]>([]);
  const [topBrowsers, setTopBrowsers] = useState<any[]>([]);
  const [topOs, setTopOs] = useState<any[]>([]);

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getOverviewAnalytics({ range: dateRange });
      if (res) {
        setStats(res);
        setClicksOverTime(
          (res.clicksOverTime || []).map((item: any) => ({
            date: new Date(item.date).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
            }),
            clicks: item.clicks ?? 0,
          }))
        );

        // Map topLinks - backend returns {id, slug, title, createdAt, clickCount}
        setTopLinks(
          (res.topLinks || []).map((l: any) => ({
            link: l,
            clicks: l.clickCount ?? l._count?.clicks ?? 0,
          }))
        );

        // clicksByCountry - backend maps to {country, count}
        setTopCountries(
          (res.clicksByCountry || []).map((c: any) => ({
            country: c.country,
            count: c.count ?? c._count?.id ?? 0,
          }))
        );

        // clicksByDevice - backend maps to {device, count}
        setTopDevices(
          (res.clicksByDevice || []).map((d: any) => ({
            device: d.device,
            count: d.count ?? d._count?.id ?? 0,
          }))
        );

        // clicksByBrowser - backend maps to {browser, count}
        setTopBrowsers(
          (res.clicksByBrowser || []).map((b: any) => ({
            browser: b.browser,
            count: b.count ?? b._count?.id ?? 0,
          }))
        );

        // clicksByOs - backend maps to {os, count}
        setTopOs(
          (res.clicksByOs || []).map((o: any) => ({
            os: o.os,
            count: o.count ?? o._count?.id ?? 0,
          }))
        );
      }
    } catch {
      // Demo data
      const days = dateRange === "1d" ? 1 : dateRange === "7d" ? 7 : dateRange === "30d" ? 30 : 90;
      const chartData: { date: string; clicks: number }[] = [];
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        chartData.push({
          date: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
          clicks: Math.floor(Math.random() * 100) + 10,
        });
      }
      setClicksOverTime(chartData);
      setStats({
        totalClicks: chartData.reduce((s, c) => s + c.clicks, 0),
        clicksToday: 42,
        clicksThisWeek: 353,
        clicksThisMonth: 1247,
      });
      setTopCountries([
        { country: "US", count: 245 },
        { country: "ID", count: 180 },
        { country: "GB", count: 95 },
        { country: "JP", count: 67 },
        { country: "DE", count: 45 },
      ]);
      setTopDevices([
        { device: "Desktop", count: 340 },
        { device: "Mobile", count: 280 },
        { device: "Tablet", count: 45 },
      ]);
      setTopBrowsers([
        { browser: "Chrome", count: 420 },
        { browser: "Safari", count: 180 },
        { browser: "Firefox", count: 45 },
        { browser: "Edge", count: 20 },
      ]);
      setTopOs([
        { os: "Windows", count: 280 },
        { os: "macOS", count: 150 },
        { os: "Android", count: 140 },
        { os: "iOS", count: 95 },
        { os: "Linux", count: 15 },
      ]);
      setTopLinks([]);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">Analytics</h2>
        <Select value={dateRange} onValueChange={setDateRange}>
          <SelectTrigger className="w-[130px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1d">Today</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Stats Cards */}
      <StatsCards stats={stats} loading={loading} />

      {/* Clicks Over Time */}
      <ClicksChart
        data={clicksOverTime}
        loading={loading}
      />

      {/* Charts Row */}
      <div className="grid gap-4 lg:grid-cols-2">
        <CountryChart data={topCountries} loading={loading} />
        <DeviceChart data={topDevices} loading={loading} />
      </div>

      {/* Top Links */}
      <div className="rounded-lg border">
        <div className="border-b px-4 py-3">
          <h3 className="text-sm font-medium">Top Links</h3>
        </div>
        {loading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : topLinks.length === 0 ? (
          <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
            No link data available.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Short URL</TableHead>
                <TableHead>Destination</TableHead>
                <TableHead className="text-right">Clicks</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {topLinks.map((item: any) => (
                <TableRow key={item.link?.id || item.id}>
                  <TableCell className="font-medium text-sm">
                    {item.link?.slug || "—"}
                  </TableCell>
                  <TableCell className="max-w-[300px] truncate text-xs text-muted-foreground">
                    {item.link?.title || "—"}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {item.clicks}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Browser & OS Tables */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg border">
          <div className="border-b px-4 py-3">
            <h3 className="text-sm font-medium">Browsers</h3>
          </div>
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableBody>
                {topBrowsers.map((item: any) => (
                  <TableRow key={item.browser}>
                    <TableCell className="text-sm">{item.browser}</TableCell>
                    <TableCell className="text-right text-sm">{item.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>

        <div className="rounded-lg border">
          <div className="border-b px-4 py-3">
            <h3 className="text-sm font-medium">Operating Systems</h3>
          </div>
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : topOs.length === 0 ? (
            <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
              No OS data available.
            </div>
          ) : (
            <Table>
              <TableBody>
                {topOs.map((item: any) => (
                  <TableRow key={item.os}>
                    <TableCell className="text-sm">{item.os}</TableCell>
                    <TableCell className="text-right text-sm">{item.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAppStore } from "@/lib/store";
import { apiGet, apiPost } from "@/lib/api";
import { toast } from "sonner";
import { Loader2, Save } from "lucide-react";
import LinkFormBasic from "@/components/links/LinkFormBasic";
import LinkFormMulti from "@/components/links/LinkFormMulti";
import type { TargetFormData } from "@/components/links/LinkTargetRow";
import type { ShortDomain } from "@/lib/types";

export default function CreateLinkPage() {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [activeTab, setActiveTab] = useState<"basic" | "multi">("basic");
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);

  // Basic form state
  const [slug, setSlug] = useState("");
  const [domainId, setDomainId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [password, setPassword] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [destinationUrl, setDestinationUrl] = useState("");
  const [mode, setMode] = useState<"random" | "sequential">("sequential");
  const [targets, setTargets] = useState<TargetFormData[]>([
    { url: "", clickLimit: 0, country: "ALL", ipList: "", autoSkip: true },
  ]);

  // UTM state
  const [utmSource, setUtmSource] = useState("");
  const [utmMedium, setUtmMedium] = useState("");
  const [utmCampaign, setUtmCampaign] = useState("");
  const [utmContent, setUtmContent] = useState("");
  const [utmTerm, setUtmTerm] = useState("");

  // OG state
  const [ogTitle, setOgTitle] = useState("");
  const [ogDescription, setOgDescription] = useState("");
  const [ogImage, setOgImage] = useState("");

  useEffect(() => {
    loadDomains();
  }, []);

  const loadDomains = async () => {
    setLoading(true);
    try {
      const res = await apiGet<ShortDomain[]>("/domains");
      const domainList = Array.isArray(res) ? res : [];
      setDomains(domainList);
      if (domainList.length > 0) {
        setDomainId(domainList[0].id);
      }
    } catch {
      // Use empty list
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (activeTab === "basic" && !destinationUrl.trim()) {
      toast.error("Destination URL is required");
      return;
    }
    if (activeTab === "multi") {
      const validTargets = targets.filter((t) => t.url.trim());
      if (validTargets.length === 0) {
        toast.error("At least one target URL is required");
        return;
      }
    }
    if (!slug.trim()) {
      toast.error("Slug is required");
      return;
    }

    setSaving(true);
    try {
      const body: any = {
        slug,
        domainId,
        type: activeTab,
        mode,
        title,
        description,
        password,
        expiredAt: expiryDate || null,
        utmSource,
        utmMedium,
        utmCampaign,
        utmContent,
        utmTerm,
        ogTitle,
        ogDescription,
        ogImage,
      };

      if (activeTab === "basic") {
        body.targets = [{ url: destinationUrl, clickLimit: 0, country: "ALL", ipList: "", order: 0 }];
      } else {
        body.targets = targets
          .filter((t) => t.url.trim())
          .map((t, i) => ({
            url: t.url,
            clickLimit: t.clickLimit,
            country: t.country,
            ipList: t.ipList,
            order: i,
          }));
      }

      await apiPost("/links", body);
      toast.success("Link created successfully!");
      setCurrentPage("links");
    } catch (err: any) {
      toast.error(err.message || "Failed to create link");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Create New Link</h2>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "basic" | "multi")}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="basic">Basic</TabsTrigger>
          <TabsTrigger value="multi">Multi-Target</TabsTrigger>
        </TabsList>

        <Card className="mt-4">
          <CardContent className="pt-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <TabsContent value="basic" className="mt-0">
                  <LinkFormBasic
                    domains={domains}
                    slug={slug}
                    setSlug={setSlug}
                    domainId={domainId}
                    setDomainId={setDomainId}
                    title={title}
                    setTitle={setTitle}
                    description={description}
                    setDescription={setDescription}
                    password={password}
                    setPassword={setPassword}
                    expiryDate={expiryDate}
                    setExpiryDate={setExpiryDate}
                    utmSource={utmSource}
                    setUtmSource={setUtmSource}
                    utmMedium={utmMedium}
                    setUtmMedium={setUtmMedium}
                    utmCampaign={utmCampaign}
                    setUtmCampaign={setUtmCampaign}
                    utmContent={utmContent}
                    setUtmContent={setUtmContent}
                    utmTerm={utmTerm}
                    setUtmTerm={setUtmTerm}
                    ogTitle={ogTitle}
                    setOgTitle={setOgTitle}
                    ogDescription={ogDescription}
                    setOgDescription={setOgDescription}
                    ogImage={ogImage}
                    setOgImage={setOgImage}
                    destinationUrl={destinationUrl}
                    setDestinationUrl={setDestinationUrl}
                  />
                </TabsContent>

                <TabsContent value="multi" className="mt-0">
                  <LinkFormMulti
                    domains={domains}
                    slug={slug}
                    setSlug={setSlug}
                    domainId={domainId}
                    setDomainId={setDomainId}
                    mode={mode}
                    setMode={setMode}
                    targets={targets}
                    setTargets={setTargets}
                    title={title}
                    setTitle={setTitle}
                    description={description}
                    setDescription={setDescription}
                    password={password}
                    setPassword={setPassword}
                    expiryDate={expiryDate}
                    setExpiryDate={setExpiryDate}
                    utmSource={utmSource}
                    setUtmSource={setUtmSource}
                    utmMedium={utmMedium}
                    setUtmMedium={setUtmMedium}
                    utmCampaign={utmCampaign}
                    setUtmCampaign={setUtmCampaign}
                    utmContent={utmContent}
                    setUtmContent={setUtmContent}
                    utmTerm={utmTerm}
                    setUtmTerm={setUtmTerm}
                    ogTitle={ogTitle}
                    setOgTitle={setOgTitle}
                    ogDescription={ogDescription}
                    setOgDescription={setOgDescription}
                    ogImage={ogImage}
                    setOgImage={setOgImage}
                  />
                </TabsContent>
              </>
            )}
          </CardContent>
        </Card>
      </Tabs>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setCurrentPage("links")}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={saving || loading} className="gap-2">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          <Save className="h-4 w-4" />
          Create Link
        </Button>
      </div>
    </div>
  );
}

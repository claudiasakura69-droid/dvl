"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  getLinks,
  getDomains,
  bulkChangeDomain,
  bulkDeleteLinks,
  bulkActivateLinks,
  bulkDeactivateLinks,
  bulkCreateLinks,
} from "@/lib/api";
import { toast } from "sonner";
import {
  ArrowRightLeft,
  Trash2,
  Power,
  PowerOff,
  Loader2,
  Plus,
  Eye,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import type { ShortLink, ShortDomain } from "@/lib/types";

interface ParsedLink {
  slug: string;
  url: string;
  valid: boolean;
  reason?: string;
}

function generateSlug(length = 6): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function isValidUrl(str: string): boolean {
  try {
    new URL(str);
    return true;
  } catch {
    return false;
  }
}

function parseBulkInput(input: string): ParsedLink[] {
  const lines = input
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const results: ParsedLink[] = [];

  for (const line of lines) {
    // Skip comment lines
    if (line.startsWith("#")) continue;

    // Check for "slug,url" format
    const commaIndex = line.indexOf(",");
    if (commaIndex > 0) {
      const possibleSlug = line.substring(0, commaIndex).trim();
      const possibleUrl = line.substring(commaIndex + 1).trim();

      // If the first part looks like a URL (has ://), treat the whole line as a URL
      if (possibleSlug.includes("://")) {
        if (isValidUrl(line)) {
          results.push({ slug: generateSlug(), url: line, valid: true });
        } else {
          results.push({ slug: "", url: line, valid: false, reason: "Invalid URL" });
        }
      } else if (isValidUrl(possibleUrl)) {
        if (possibleSlug.length === 0) {
          results.push({ slug: generateSlug(), url: possibleUrl, valid: true });
        } else {
          results.push({ slug: possibleSlug, url: possibleUrl, valid: true });
        }
      } else {
        results.push({ slug: possibleSlug, url: possibleUrl, valid: false, reason: "Invalid URL" });
      }
    } else {
      // Just a URL
      if (isValidUrl(line)) {
        results.push({ slug: generateSlug(), url: line, valid: true });
      } else {
        results.push({ slug: "", url: line, valid: false, reason: "Invalid URL format" });
      }
    }
  }

  return results;
}

export default function BulkOperationsPage() {
  const [loading, setLoading] = useState(true);
  const [links, setLinks] = useState<ShortLink[]>([]);
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [selectedLinks, setSelectedLinks] = useState<string[]>([]);
  const [oldDomainId, setOldDomainId] = useState("");
  const [newDomainId, setNewDomainId] = useState("");
  const [affectedCount, setAffectedCount] = useState(0);
  const [showDomainConfirm, setShowDomainConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showToggleConfirm, setShowToggleConfirm] = useState(false);
  const [toggleAction, setToggleAction] = useState<"activate" | "deactivate">("activate");
  const [processing, setProcessing] = useState(false);

  // Bulk Add state
  const [bulkInput, setBulkInput] = useState("");
  const [bulkDomainId, setBulkDomainId] = useState("");
  const [parsedLinks, setParsedLinks] = useState<ParsedLink[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [bulkProcessing, setBulkProcessing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [linksRes, domainsRes] = await Promise.all([
        getLinks({ page: "1", limit: "100" }),
        getDomains(),
      ]);
      setLinks(linksRes.links || []);
      setDomains(Array.isArray(domainsRes) ? domainsRes : []);
    } catch {
      // Empty state
    } finally {
      setLoading(false);
    }
  };

  // Calculate affected links when domains change
  useEffect(() => {
    if (oldDomainId) {
      setAffectedCount(links.filter((l) => l.domainId === oldDomainId).length);
    } else {
      setAffectedCount(0);
    }
  }, [oldDomainId, links]);

  const toggleLinkSelection = (id: string) => {
    setSelectedLinks((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAllLinks = () => {
    setSelectedLinks(links.map((l) => l.id));
  };

  const deselectAllLinks = () => {
    setSelectedLinks([]);
  };

  const handleChangeDomain = async () => {
    if (!oldDomainId || !newDomainId || oldDomainId === newDomainId) return;
    setProcessing(true);
    try {
      await bulkChangeDomain(oldDomainId, newDomainId);
      toast.success("Domain changed successfully");
      setShowDomainConfirm(false);
      setOldDomainId("");
      setNewDomainId("");
      loadData();
    } catch (err: any) {
      toast.error(err.message || "Failed to change domain");
    } finally {
      setProcessing(false);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedLinks.length === 0) return;
    setProcessing(true);
    try {
      await bulkDeleteLinks(selectedLinks);
      toast.success(`${selectedLinks.length} links deleted`);
      setShowDeleteConfirm(false);
      setSelectedLinks([]);
      loadData();
    } catch (err: any) {
      toast.error(err.message || "Failed to delete links");
    } finally {
      setProcessing(false);
    }
  };

  const handleBulkToggle = async () => {
    if (selectedLinks.length === 0) return;
    setProcessing(true);
    try {
      if (toggleAction === "activate") {
        await bulkActivateLinks(selectedLinks);
      } else {
        await bulkDeactivateLinks(selectedLinks);
      }
      toast.success(`${selectedLinks.length} links ${toggleAction}d`);
      setShowToggleConfirm(false);
      setSelectedLinks([]);
      loadData();
    } catch (err: any) {
      toast.error(err.message || "Failed to toggle links");
    } finally {
      setProcessing(false);
    }
  };

  // Bulk Add handlers
  const handleParsePreview = () => {
    if (!bulkInput.trim()) {
      toast.error("Please enter some links to parse");
      return;
    }
    if (!bulkDomainId) {
      toast.error("Please select a domain");
      return;
    }

    const parsed = parseBulkInput(bulkInput);
    setParsedLinks(parsed);
    setShowPreview(true);
  };

  const handleBulkCreate = async () => {
    const validLinks = parsedLinks.filter((l) => l.valid);
    if (validLinks.length === 0) {
      toast.error("No valid links to create");
      return;
    }

    setBulkProcessing(true);
    try {
      const payload = validLinks.map((l) => ({
        slug: l.slug,
        url: l.url,
        domainId: bulkDomainId,
      }));

      const result = await bulkCreateLinks(payload);
      toast.success(
        `${result.created} links created, ${result.skipped} skipped`
      );
      setBulkInput("");
      setParsedLinks([]);
      setShowPreview(false);
      loadData();
    } catch (err: any) {
      toast.error(err.message || "Failed to create links");
    } finally {
      setBulkProcessing(false);
    }
  };

  const validCount = parsedLinks.filter((l) => l.valid).length;
  const invalidCount = parsedLinks.filter((l) => !l.valid).length;

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold">Bulk Operations</h2>

      {/* Bulk Add Links - NEW SECTION */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Bulk Add Links
          </CardTitle>
          <CardDescription>
            Paste links to create them in bulk. Use &quot;slug,url&quot; format or just URLs for auto-generated slugs.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_200px]">
            <div className="space-y-2">
              <label className="text-sm font-medium">Links (one per line)</label>
              <Textarea
                placeholder={`promo,https://example.com/promo\nsale,https://example.com/sale\nhttps://example.com/auto-slug`}
                value={bulkInput}
                onChange={(e) => {
                  setBulkInput(e.target.value);
                  if (showPreview) setShowPreview(false);
                }}
                rows={6}
                className="font-mono text-sm"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Domain</label>
              <Select value={bulkDomainId} onValueChange={setBulkDomainId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.domain}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="space-y-2 pt-2">
                <Button
                  variant="outline"
                  onClick={handleParsePreview}
                  disabled={!bulkInput.trim() || !bulkDomainId}
                  className="w-full gap-2"
                >
                  <Eye className="h-4 w-4" />
                  Parse &amp; Preview
                </Button>
              </div>
            </div>
          </div>

          {/* Preview Table */}
          {showPreview && parsedLinks.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Badge variant="default" className="text-xs">
                  {validCount} valid
                </Badge>
                {invalidCount > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {invalidCount} invalid
                  </Badge>
                )}
              </div>

              <div className="max-h-60 overflow-auto rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[140px]">Slug</TableHead>
                      <TableHead>URL</TableHead>
                      <TableHead className="w-[90px]">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsedLinks.map((item, idx) => (
                      <TableRow key={idx}>
                        <TableCell className="font-mono text-sm">
                          {item.slug || "—"}
                        </TableCell>
                        <TableCell className="max-w-[300px] truncate text-xs text-muted-foreground">
                          {item.url}
                        </TableCell>
                        <TableCell>
                          {item.valid ? (
                            <Badge variant="secondary" className="gap-1 text-xs">
                              <CheckCircle2 className="h-3 w-3 text-green-600" />
                              Valid
                            </Badge>
                          ) : (
                            <Badge variant="destructive" className="gap-1 text-xs">
                              <XCircle className="h-3 w-3" />
                              {item.reason || "Invalid"}
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {validCount > 0 && (
                <Button
                  onClick={handleBulkCreate}
                  disabled={bulkProcessing || validCount === 0}
                  className="gap-2"
                >
                  {bulkProcessing ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Plus className="h-4 w-4" />
                  )}
                  Create {validCount} Links
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Change Domain */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ArrowRightLeft className="h-4 w-4" />
            Change Domain
          </CardTitle>
          <CardDescription>
            Move all links from one domain to another
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="space-y-2">
              <label className="text-sm font-medium">From Domain</label>
              <Select value={oldDomainId} onValueChange={setOldDomainId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((d) => (
                    <SelectItem key={d.id} value={d.id}>
                      {d.domain}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">To Domain</label>
              <Select value={newDomainId} onValueChange={setNewDomainId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains
                    .filter((d) => d.id !== oldDomainId)
                    .map((d) => (
                      <SelectItem key={d.id} value={d.id}>
                        {d.domain}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button
                onClick={() => setShowDomainConfirm(true)}
                disabled={!oldDomainId || !newDomainId || processing}
                className="w-full"
              >
                Apply
              </Button>
            </div>
          </div>
          {affectedCount > 0 && (
            <p className="text-sm text-muted-foreground">
              {affectedCount} link{affectedCount > 1 ? "s" : ""} will be affected.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Bulk Delete */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Trash2 className="h-4 w-4 text-destructive" />
            Bulk Delete
          </CardTitle>
          <CardDescription>
            Delete multiple links at once
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={selectAllLinks}>
              Select All
            </Button>
            <Button variant="outline" size="sm" onClick={deselectAllLinks}>
              Deselect All
            </Button>
            <Badge variant="secondary" className="text-xs">
              {selectedLinks.length} selected
            </Badge>
          </div>

          <div className="max-h-60 overflow-auto rounded-lg border">
            {loading ? (
              <div className="space-y-2 p-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-8 animate-pulse rounded bg-muted" />
                ))}
              </div>
            ) : links.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                No links available.
              </div>
            ) : (
              links.map((link) => (
                <div
                  key={link.id}
                  className="flex items-center gap-3 border-b px-3 py-2 last:border-0 hover:bg-muted/30"
                >
                  <Checkbox
                    checked={selectedLinks.includes(link.id)}
                    onCheckedChange={() => toggleLinkSelection(link.id)}
                  />
                  <span className="text-sm font-medium">{link.slug}</span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {link.title || "—"}
                  </span>
                </div>
              ))
            )}
          </div>

          <Button
            variant="destructive"
            onClick={() => setShowDeleteConfirm(true)}
            disabled={selectedLinks.length === 0 || processing}
            className="gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Delete Selected ({selectedLinks.length})
          </Button>
        </CardContent>
      </Card>

      {/* Bulk Activate/Deactivate */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Power className="h-4 w-4" />
            Bulk Activate/Deactivate
          </CardTitle>
          <CardDescription>
            Toggle active status for multiple links
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-xs">
              {selectedLinks.length} selected
            </Badge>
          </div>

          {selectedLinks.length === 0 && (
            <p className="text-sm text-muted-foreground">
              Select links from the Bulk Delete section above, then use the buttons below.
            </p>
          )}

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setToggleAction("activate");
                setShowToggleConfirm(true);
              }}
              disabled={selectedLinks.length === 0 || processing}
              className="gap-2"
            >
              <Power className="h-4 w-4 text-green-600" />
              Activate ({selectedLinks.length})
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setToggleAction("deactivate");
                setShowToggleConfirm(true);
              }}
              disabled={selectedLinks.length === 0 || processing}
              className="gap-2"
            >
              <PowerOff className="h-4 w-4 text-red-600" />
              Deactivate ({selectedLinks.length})
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Change Domain Confirm */}
      <AlertDialog open={showDomainConfirm} onOpenChange={setShowDomainConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Change Domain</AlertDialogTitle>
            <AlertDialogDescription>
              Move {affectedCount} link{affectedCount > 1 ? "s" : ""} from{" "}
              {domains.find((d) => d.id === oldDomainId)?.domain} to{" "}
              {domains.find((d) => d.id === newDomainId)?.domain}? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleChangeDomain} disabled={processing}>
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirm */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedLinks.length} Links</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedLinks.length} link
              {selectedLinks.length > 1 ? "s" : ""}? This will also remove all
              associated click data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDelete}
              disabled={processing}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Toggle Confirm */}
      <AlertDialog open={showToggleConfirm} onOpenChange={setShowToggleConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {toggleAction === "activate" ? "Activate" : "Deactivate"}{" "}
              {selectedLinks.length} Links
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to {toggleAction} {selectedLinks.length} link
              {selectedLinks.length > 1 ? "s" : ""}?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={processing}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleBulkToggle} disabled={processing}>
              {processing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

import { Button } from "@/components/ui/button";
import { useAppStore } from "@/lib/store";
import { Home } from "lucide-react";

export default function NotFoundPage() {
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);

  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <div className="text-7xl font-bold text-muted-foreground/20">404</div>
      <h2 className="text-xl font-semibold">Page Not Found</h2>
      <p className="text-sm text-muted-foreground max-w-md">
        The page you&apos;re looking for doesn&apos;t exist or has been moved.
      </p>
      <Button onClick={() => setCurrentPage("overview")} className="gap-2">
        <Home className="h-4 w-4" />
        Go to Dashboard
      </Button>
    </div>
  );
}

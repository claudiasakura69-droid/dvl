"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { useAppStore } from "@/lib/store";
import { apiGet, apiPut } from "@/lib/api";
import { toast } from "sonner";
import { Loader2, Save } from "lucide-react";
import LinkFormBasic from "@/components/links/LinkFormBasic";
import LinkFormMulti from "@/components/links/LinkFormMulti";
import type { TargetFormData } from "@/components/links/LinkTargetRow";
import type { ShortDomain, ShortLink } from "@/lib/types";

export default function EditLinkPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [link, setLink] = useState<ShortLink | null>(null);
  const activeTab = link?.type || "basic";
  const selectedLinkId = useAppStore((s) => s.selectedLinkId);
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);

  // Form state
  const [slug, setSlug] = useState("");
  const [domainId, setDomainId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [password, setPassword] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [destinationUrl, setDestinationUrl] = useState("");
  const [mode, setMode] = useState<"random" | "sequential">("sequential");
  const [targets, setTargets] = useState<TargetFormData[]>([]);
  const [utmSource, setUtmSource] = useState("");
  const [utmMedium, setUtmMedium] = useState("");
  const [utmCampaign, setUtmCampaign] = useState("");
  const [utmContent, setUtmContent] = useState("");
  const [utmTerm, setUtmTerm] = useState("");
  const [ogTitle, setOgTitle] = useState("");
  const [ogDescription, setOgDescription] = useState("");
  const [ogImage, setOgImage] = useState("");

  useEffect(() => {
    if (selectedLinkId) {
      loadData();
    } else {
      setCurrentPage("links");
    }
  }, [selectedLinkId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [linkRes, domainRes] = await Promise.all([
        apiGet<ShortLink>(`/links/${selectedLinkId}`),
        apiGet<ShortDomain[]>("/domains"),
      ]);

      const linkData = linkRes as ShortLink;
      const domainList = Array.isArray(domainRes) ? domainRes : [];

      setDomains(domainList);
      setLink(linkData);

      // Populate form
      setSlug(linkData.slug);
      setDomainId(linkData.domainId);
      setTitle(linkData.title);
      setDescription(linkData.description);
      setPassword(linkData.password);
      setMode(linkData.mode as "random" | "sequential");
      setUtmSource(linkData.utmSource);
      setUtmMedium(linkData.utmMedium);
      setUtmCampaign(linkData.utmCampaign);
      setUtmContent(linkData.utmContent);
      setUtmTerm(linkData.utmTerm);
      setOgTitle(linkData.ogTitle);
      setOgDescription(linkData.ogDescription);
      setOgImage(linkData.ogImage);

      if (linkData.expiredAt) {
        setExpiryDate(new Date(linkData.expiredAt).toISOString().slice(0, 16));
      }

      if (linkData.type === "basic") {
        setDestinationUrl(linkData.targets?.[0]?.url || "");
        setTargets([
          {
            url: linkData.targets?.[0]?.url || "",
            clickLimit: linkData.targets?.[0]?.clickLimit || 0,
            country: linkData.targets?.[0]?.country || "ALL",
            ipList: linkData.targets?.[0]?.ipList || "",
            autoSkip: true,
          },
        ]);
      } else {
        const loadedTargets = (linkData.targets || []).map((t) => ({
          url: t.url,
          clickLimit: t.clickLimit,
          country: t.country,
          ipList: t.ipList,
          autoSkip: t.clickLimit > 0,
        }));
        setTargets(loadedTargets.length > 0 ? loadedTargets : [
          { url: "", clickLimit: 0, country: "ALL", ipList: "", autoSkip: true },
        ]);
        setDestinationUrl(linkData.targets?.[0]?.url || "");
      }
    } catch {
      toast.error("Failed to load link");
      setCurrentPage("links");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!selectedLinkId) return;

    if (activeTab === "basic" && !destinationUrl.trim()) {
      toast.error("Destination URL is required");
      return;
    }
    if (!slug.trim()) {
      toast.error("Slug is required");
      return;
    }

    setSaving(true);
    try {
      const body: any = {
        slug,
        domainId,
        type: activeTab,
        mode,
        title,
        description,
        password: password || undefined,
        expiredAt: expiryDate || null,
        utmSource,
        utmMedium,
        utmCampaign,
        utmContent,
        utmTerm,
        ogTitle,
        ogDescription,
        ogImage,
      };

      if (activeTab === "basic") {
        body.targets = [{ url: destinationUrl, clickLimit: 0, country: "ALL", ipList: "", order: 0 }];
      } else {
        body.targets = targets
          .filter((t) => t.url.trim())
          .map((t, i) => ({
            url: t.url,
            clickLimit: t.clickLimit,
            country: t.country,
            ipList: t.ipList,
            order: i,
          }));
      }

      await apiPut(`/links/${selectedLinkId}`, body);
      toast.success("Link updated successfully!");
      setCurrentPage("links");
    } catch (err: any) {
      toast.error(err.message || "Failed to update link");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Edit Link</h2>
      </div>

      <Tabs value={activeTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="basic">Basic</TabsTrigger>
          <TabsTrigger value="multi">Multi-Target</TabsTrigger>
        </TabsList>

        <Card className="mt-4">
          <CardContent className="pt-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                <TabsContent value="basic" className="mt-0">
                  <LinkFormBasic
                    domains={domains}
                    slug={slug}
                    setSlug={setSlug}
                    domainId={domainId}
                    setDomainId={setDomainId}
                    title={title}
                    setTitle={setTitle}
                    description={description}
                    setDescription={setDescription}
                    password={password}
                    setPassword={setPassword}
                    expiryDate={expiryDate}
                    setExpiryDate={setExpiryDate}
                    utmSource={utmSource}
                    setUtmSource={setUtmSource}
                    utmMedium={utmMedium}
                    setUtmMedium={setUtmMedium}
                    utmCampaign={utmCampaign}
                    setUtmCampaign={setUtmCampaign}
                    utmContent={utmContent}
                    setUtmContent={setUtmContent}
                    utmTerm={utmTerm}
                    setUtmTerm={setUtmTerm}
                    ogTitle={ogTitle}
                    setOgTitle={setOgTitle}
                    ogDescription={ogDescription}
                    setOgDescription={setOgDescription}
                    ogImage={ogImage}
                    setOgImage={setOgImage}
                    destinationUrl={destinationUrl}
                    setDestinationUrl={setDestinationUrl}
                  />
                </TabsContent>

                <TabsContent value="multi" className="mt-0">
                  <LinkFormMulti
                    domains={domains}
                    slug={slug}
                    setSlug={setSlug}
                    domainId={domainId}
                    setDomainId={setDomainId}
                    mode={mode}
                    setMode={setMode}
                    targets={targets}
                    setTargets={setTargets}
                    title={title}
                    setTitle={setTitle}
                    description={description}
                    setDescription={setDescription}
                    password={password}
                    setPassword={setPassword}
                    expiryDate={expiryDate}
                    setExpiryDate={setExpiryDate}
                    utmSource={utmSource}
                    setUtmSource={setUtmSource}
                    utmMedium={utmMedium}
                    setUtmMedium={setUtmMedium}
                    utmCampaign={utmCampaign}
                    setUtmCampaign={setUtmCampaign}
                    utmContent={utmContent}
                    setUtmContent={setUtmContent}
                    utmTerm={utmTerm}
                    setUtmTerm={setUtmTerm}
                    ogTitle={ogTitle}
                    setOgTitle={setOgTitle}
                    ogDescription={ogDescription}
                    setOgDescription={setOgDescription}
                    ogImage={ogImage}
                    setOgImage={setOgImage}
                  />
                </TabsContent>
              </>
            )}
          </CardContent>
        </Card>
      </Tabs>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => setCurrentPage("links")}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={saving || loading} className="gap-2">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          <Save className="h-4 w-4" />
          Save Changes
        </Button>
      </div>
    </div>
  );
}

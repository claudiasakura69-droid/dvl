"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Check,
  X,
  Edit,
  Trash2,
  Shield,
  Power,
  Globe,
  LayoutDashboard,
  Link2,
} from "lucide-react";
import type { ShortDomain } from "@/lib/types";

interface DomainCardProps {
  domain: ShortDomain;
  onEdit: (domain: ShortDomain) => void;
  onDelete: (domain: ShortDomain) => void;
  onVerify: (domain: ShortDomain) => void;
  onToggle: (domain: ShortDomain) => void;
  onDnsSetup: (domain: ShortDomain) => void;
  isMainDomain?: boolean;
}

export default function DomainCard({
  domain,
  onEdit,
  onDelete,
  onVerify,
  onToggle,
  onDnsSetup,
  isMainDomain = false,
}: DomainCardProps) {
  return (
    <Card className={isMainDomain ? "border-blue-500/30 bg-blue-500/5" : ""}>
      <CardContent className="pt-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium">{domain.domain}</h3>
              {isMainDomain && (
                <Badge className="bg-blue-500/10 text-blue-600 dark:text-blue-400 text-xs border-blue-500/20">
                  <LayoutDashboard className="mr-1 h-3 w-3" />
                  Dashboard
                </Badge>
              )}
              {!isMainDomain && (
                <Badge className="bg-green-500/10 text-green-600 dark:text-green-400 text-xs border-green-500/20">
                  <Link2 className="mr-1 h-3 w-3" />
                  Short URL
                </Badge>
              )}
              <Badge
                variant={domain.isActive ? "default" : "destructive"}
                className="text-xs"
              >
                {domain.isActive ? "Active" : "Inactive"}
              </Badge>
              {domain.isVerified ? (
                <Badge className="bg-green-500/10 text-green-600 dark:text-green-400 text-xs border-green-500/20">
                  <Check className="mr-1 h-3 w-3" /> Verified
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs">
                  <X className="mr-1 h-3 w-3" /> Unverified
                </Badge>
              )}
            </div>
            {isMainDomain && (
              <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1">
                <Globe className="h-3 w-3" />
                This is the main domain — serves the dashboard and login page
              </p>
            )}
            {!isMainDomain && (
              <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                <Link2 className="h-3 w-3" />
                Short URL domain — handles redirects (e.g., {domain.domain}
                /promo)
              </p>
            )}
            {domain.slug && (
              <p className="text-xs text-muted-foreground">
                Slug prefix: {domain.slug}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {domain._count?.links ?? 0} links
            </p>
            <p className="text-xs text-muted-foreground">
              Created: {new Date(domain.createdAt).toLocaleDateString()}
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {!isMainDomain && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDnsSetup(domain)}
                className="gap-1 text-xs h-7"
              >
                <Globe className="h-3 w-3" />
                DNS Setup
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => onVerify(domain)}
              disabled={domain.isVerified}
              className="gap-1 text-xs h-7"
            >
              <Shield className="h-3 w-3" />
              Verify
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onToggle(domain)}
              className="gap-1 text-xs h-7"
            >
              <Power className="h-3 w-3" />
              {domain.isActive ? "Deactivate" : "Activate"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(domain)}
              className="gap-1 text-xs h-7"
            >
              <Edit className="h-3 w-3" />
              Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(domain)}
              className="gap-1 text-xs h-7 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" />
              Delete
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Copy, Check, ExternalLink } from "lucide-react";
import { toast } from "sonner";

interface DNSSetupDialogProps {
  open: boolean;
  onClose: () => void;
  domain: string;
  mainDomain: string;
}

export default function DNSSetupDialog({
  open,
  onClose,
  domain,
  mainDomain,
}: DNSSetupDialogProps) {
  const [copied, setCopied] = React.useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success(`${label} copied to clipboard`);
    setTimeout(() => setCopied(null), 2000);
  };

  // Determine the pages.dev domain from main domain or use placeholder
  const pagesDevDomain = mainDomain.includes("pages.dev")
    ? mainDomain
    : "your-project.pages.dev";

  // Determine if this is a subdomain or root domain
  const isSubdomain = domain.includes(".");
  const domainParts = domain.split(".");
  const subdomainName = isSubdomain ? domainParts[0] : "@";

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            DNS Setup Guide
            <Badge variant="outline" className="text-xs">
              {domain}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Architecture Overview */}
          <div className="rounded-lg border bg-muted/30 p-4">
            <h3 className="text-sm font-semibold mb-3">
              Architecture Overview
            </h3>
            <div className="space-y-2 text-xs text-muted-foreground">
              <div className="flex items-start gap-2">
                <span className="inline-block w-2 h-2 mt-1.5 rounded-full bg-blue-500 shrink-0" />
                <div>
                  <span className="font-medium text-foreground">
                    Main Domain ({mainDomain})
                  </span>{" "}
                  → Dashboard (login, manage links, analytics)
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-block w-2 h-2 mt-1.5 rounded-full bg-green-500 shrink-0" />
                <div>
                  <span className="font-medium text-foreground">
                    Short URL Domain ({domain})
                  </span>{" "}
                  → Handles short URL redirects (public)
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="inline-block w-2 h-2 mt-1.5 rounded-full bg-amber-500 shrink-0" />
                <div>
                  Both domains point to the{" "}
                  <span className="font-medium text-foreground">
                    same Cloudflare Pages project
                  </span>
                  . The middleware detects which domain is being used and routes
                  accordingly.
                </div>
              </div>
            </div>
          </div>

          {/* Step 1: Add domain to Cloudflare */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">
              Step 1: Add Domain to Cloudflare
            </h3>
            <div className="rounded-lg border p-4 space-y-3 text-sm">
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>Login to{" "}
                  <a
                    href="https://dash.cloudflare.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline inline-flex items-center gap-1"
                  >
                    Cloudflare Dashboard <ExternalLink className="h-3 w-3" />
                  </a>
                </li>
                <li>Click <strong>&quot;Add a site&quot;</strong> in the sidebar</li>
                <li>
                  Enter <strong>&quot;{domain}&quot;</strong> and select the Free plan
                </li>
                <li>
                  Cloudflare will display 2 NS records:
                  <div className="mt-2 flex gap-2 items-center">
                    <code className="bg-muted px-2 py-1 rounded text-xs">
                      ns1.cloudflare.com
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={() =>
                        copyToClipboard("ns1.cloudflare.com", "NS1")
                      }
                    >
                      {copied === "NS1" ? (
                        <Check className="h-3 w-3 text-green-500" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                  <div className="mt-1 flex gap-2 items-center">
                    <code className="bg-muted px-2 py-1 rounded text-xs">
                      ns2.cloudflare.com
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={() =>
                        copyToClipboard("ns2.cloudflare.com", "NS2")
                      }
                    >
                      {copied === "NS2" ? (
                        <Check className="h-3 w-3 text-green-500" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                    </Button>
                  </div>
                </li>
                <li>
                  Login to your domain registrar (Namecheap, GoDaddy, etc.) and{" "}
                  <strong>change nameservers</strong> to the Cloudflare ones above
                </li>
                <li>
                  Wait for DNS propagation{" "}
                  <span className="text-amber-500">(15 min - 48 hours)</span>
                </li>
              </ol>
            </div>
          </div>

          {/* Step 2: DNS Records */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">
              Step 2: Create DNS Record in Cloudflare
            </h3>
            <div className="rounded-lg border p-4 space-y-3">
              <p className="text-xs text-muted-foreground">
                After the domain is active on Cloudflare, go to{" "}
                <strong>DNS &rarr; Records</strong> and add:
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3 font-medium">Type</th>
                      <th className="text-left py-2 px-3 font-medium">Name</th>
                      <th className="text-left py-2 px-3 font-medium">Target</th>
                      <th className="text-left py-2 px-3 font-medium">Proxy</th>
                      <th className="text-left py-2 px-3 font-medium">TTL</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b last:border-0">
                      <td className="py-2 px-3">
                        <Badge variant="outline" className="text-xs">
                          CNAME
                        </Badge>
                      </td>
                      <td className="py-2 px-3">
                        <code className="bg-muted px-1.5 py-0.5 rounded">
                          {subdomainName}
                        </code>
                      </td>
                      <td className="py-2 px-3">
                        <code className="bg-muted px-1.5 py-0.5 rounded">
                          {pagesDevDomain}
                        </code>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-5 w-5 p-0 ml-1"
                          onClick={() =>
                            copyToClipboard(pagesDevDomain, "Target")
                          }
                        >
                          {copied === "Target" ? (
                            <Check className="h-2.5 w-2.5 text-green-500" />
                          ) : (
                            <Copy className="h-2.5 w-2.5" />
                          )}
                        </Button>
                      </td>
                      <td className="py-2 px-3">
                        <span className="text-orange-500 font-medium">
                          Proxied
                        </span>
                      </td>
                      <td className="py-2 px-3 text-muted-foreground">Auto</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-amber-600 dark:text-amber-400">
                Important: The Proxy status MUST be orange (Proxied), not grey
                (DNS only). This is required for SSL, security rules, and
                caching.
              </p>
            </div>
          </div>

          {/* Step 3: Add Custom Domain in Pages */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">
              Step 3: Add Custom Domain in Cloudflare Pages
            </h3>
            <div className="rounded-lg border p-4 space-y-3 text-sm">
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>
                  Go to <strong>Workers & Pages</strong> &rarr; select your
                  project
                </li>
                <li>
                  Click <strong>&quot;Custom domains&quot;</strong> tab
                </li>
                <li>
                  Click <strong>&quot;Set up a custom domain&quot;</strong>
                </li>
                <li>
                  Enter <strong>&quot;{domain}&quot;</strong>
                </li>
                <li>
                  Click <strong>&quot;Activate domain&quot;</strong>
                </li>
                <li>
                  Wait for SSL certificate provisioning{" "}
                  <span className="text-amber-500">(~15 minutes)</span>
                </li>
              </ol>
            </div>
          </div>

          {/* Step 4: Security Rules */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">
              Step 4: Configure Security Rules (Optional)
            </h3>
            <div className="rounded-lg border p-4 space-y-3 text-sm">
              <p className="text-xs text-muted-foreground">
                You can use Cloudflare Security Rules to restrict access:
              </p>
              <div className="space-y-3">
                <div className="rounded-md bg-muted/50 p-3">
                  <p className="text-xs font-medium mb-1">
                    IP Whitelist for Main Domain Dashboard
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Go to <strong>Security &rarr; WAF &rarr; Custom Rules</strong>{" "}
                    and create a rule:
                  </p>
                  <ul className="mt-2 list-disc list-inside text-xs text-muted-foreground space-y-1">
                    <li>
                      If the hostname equals <strong>{mainDomain}</strong> AND the
                      IP is NOT in your whitelist
                    </li>
                    <li>Action: <strong>Block</strong></li>
                  </ul>
                </div>
                <div className="rounded-md bg-muted/50 p-3">
                  <p className="text-xs font-medium mb-1">
                    Rate Limiting for Short URL Domain
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Go to <strong>Security &rarr; WAF &rarr; Rate limiting rules</strong>{" "}
                    and create a rule:
                  </p>
                  <ul className="mt-2 list-disc list-inside text-xs text-muted-foreground space-y-1">
                    <li>
                      If the hostname equals <strong>{domain}</strong>
                    </li>
                    <li>
                      Rate: <strong>100 requests per 10 seconds</strong>
                    </li>
                    <li>Action: <strong>Block for 60 seconds</strong></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Step 5: Verify */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold">Step 5: Verify Setup</h3>
            <div className="rounded-lg border p-4 space-y-3 text-sm">
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground">
                  After completing all steps, test your setup:
                </p>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground/50" />
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    https://{domain}/test-slug
                  </code>
                  <span className="text-xs text-muted-foreground">
                    → Should show 404 page (slug doesn&apos;t exist yet)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground/50" />
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    https://{domain}/
                  </code>
                  <span className="text-xs text-muted-foreground">
                    → Should show &quot;Short URL Service&quot; landing page
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground/50" />
                  <code className="text-xs bg-muted px-2 py-1 rounded">
                    https://{mainDomain}
                  </code>
                  <span className="text-xs text-muted-foreground">
                    → Should show Dashboard login page
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Important Notes */}
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4">
            <h3 className="text-sm font-semibold text-amber-600 dark:text-amber-400 mb-2">
              Important Notes
            </h3>
            <ul className="list-disc list-inside text-xs text-muted-foreground space-y-1.5">
              <li>
                Both domains must have their nameservers pointed to Cloudflare
              </li>
              <li>
                The CNAME record must point to the SAME Pages project
              </li>
              <li>
                Proxy status must be <strong>Proxied (orange)</strong> for SSL to
                work
              </li>
              <li>
                SSL certificates are automatically provisioned by Cloudflare
              </li>
              <li>
                Changes to DNS may take up to 48 hours to propagate globally
              </li>
              <li>
                The dashboard is NOT accessible on short URL domains (security
                feature)
              </li>
              <li>
                Make sure <code className="bg-muted px-1 rounded">APP_DOMAIN</code>{" "}
                environment variable is set in Cloudflare Pages to the main
                domain hostname
              </li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

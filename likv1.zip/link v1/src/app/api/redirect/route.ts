import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Demo visitor data for simulation
const DEMO_DEVICES = ["Desktop", "Mobile", "Tablet"];
const DEMO_BROWSERS = ["Chrome", "Firefox", "Safari", "Edge"];
const DEMO_OS = ["Windows", "macOS", "Linux", "Android", "iOS"];
const DEMO_COUNTRIES = ["US", "ID", "GB", "JP", "DE", "FR", "BR", "IN"];
const DEMO_REFERRERS = ["google.com", "facebook.com", "twitter.com", "direct", ""];
const DEMO_IPS = [
  "192.168.1.1",
  "10.0.0.1",
  "172.16.0.1",
  "203.0.113.50",
  "198.51.100.23",
  "8.8.8.8",
  "1.1.1.1",
];
const DEMO_CITIES = [
  "New York",
  "Jakarta",
  "London",
  "Tokyo",
  "Berlin",
  "Paris",
  "São Paulo",
  "Mumbai",
];
const DEMO_REGIONS = [
  "New York",
  "DKI Jakarta",
  "England",
  "Kantō",
  "Berlin",
  "Île-de-France",
  "São Paulo",
  "Maharashtra",
];

function randomFrom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// GET - Redirect logic (demo/testing)
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const slug = searchParams.get("slug");
    const domain = searchParams.get("domain");

    if (!slug) {
      return NextResponse.json({ error: "Slug is required" }, { status: 400 });
    }

    // Find the link by slug and optionally domain
    let link;

    if (domain) {
      // Find by domain name + slug
      const domainRecord = await db.shortDomain.findFirst({
        where: { domain },
      });

      if (!domainRecord) {
        return NextResponse.json({ error: "Link not found" }, { status: 404 });
      }

      link = await db.shortLink.findFirst({
        where: { slug, domainId: domainRecord.id },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    } else {
      // Find by slug alone (first match, or use default domain)
      link = await db.shortLink.findFirst({
        where: { slug },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    }

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    // Check if link is active
    if (!link.isActive) {
      return NextResponse.json({ error: "Link is inactive" }, { status: 404 });
    }

    // Check if link has expired
    if (link.expiredAt && link.expiredAt < new Date()) {
      return NextResponse.json({ error: "Link has expired" }, { status: 410 });
    }

    // Check password protection
    const providedPassword = searchParams.get("password");
    if (link.password) {
      if (!providedPassword || providedPassword !== link.password) {
        return NextResponse.json(
          { error: "Password required", passwordProtected: true },
          { status: 403 }
        );
      }
    }

    // Simulate visitor data for demo
    const visitorIp = randomFrom(DEMO_IPS);
    const visitorCountry = randomFrom(DEMO_COUNTRIES);
    const visitorCity = randomFrom(DEMO_CITIES);
    const visitorRegion = randomFrom(DEMO_REGIONS);
    const visitorDevice = randomFrom(DEMO_DEVICES);
    const visitorBrowser = randomFrom(DEMO_BROWSERS);
    const visitorOs = randomFrom(DEMO_OS);
    const visitorReferrer = randomFrom(DEMO_REFERRERS);

    // Determine redirect target
    let selectedTarget;

    if (link.type === "basic") {
      // Basic: single target
      selectedTarget = link.targets[0];

      if (!selectedTarget) {
        return NextResponse.json(
          { error: "No active target found" },
          { status: 404 }
        );
      }

      // Check click limit for basic
      if (
        selectedTarget.clickLimit > 0 &&
        selectedTarget.currentClicks >= selectedTarget.clickLimit
      ) {
        return NextResponse.json(
          { error: "Click limit reached" },
          { status: 429 }
        );
      }
    } else {
      // Multi-target routing logic
      const availableTargets = link.targets.filter((t) => {
        // Filter by click limit
        if (t.clickLimit > 0 && t.currentClicks >= t.clickLimit) {
          return false;
        }
        return true;
      });

      if (availableTargets.length === 0) {
        return NextResponse.json(
          { error: "No available targets" },
          { status: 404 }
        );
      }

      // Priority 1: IP-based targets
      const ipMatchTargets = availableTargets.filter((t) => {
        if (!t.ipList) return false;
        const allowedIps = t.ipList.split(",").map((ip) => ip.trim());
        return allowedIps.includes(visitorIp);
      });

      if (ipMatchTargets.length > 0) {
        selectedTarget = ipMatchTargets[0];
      } else {
        // Priority 2: Country-based targets
        const countryMatchTargets = availableTargets.filter(
          (t) => t.country !== "ALL" && t.country === visitorCountry
        );

        if (countryMatchTargets.length > 0) {
          selectedTarget = countryMatchTargets[0];
        } else {
          // Priority 3: ALL country targets
          const allTargets = availableTargets.filter(
            (t) => t.country === "ALL"
          );

          if (allTargets.length === 0) {
            // Fall back to any available target
            selectedTarget = availableTargets[0];
          } else if (link.mode === "random") {
            selectedTarget = allTargets[Math.floor(Math.random() * allTargets.length)];
          } else {
            // Sequential: find the target with lowest currentClicks
            selectedTarget = allTargets.reduce((prev, curr) =>
              prev.currentClicks <= curr.currentClicks ? prev : curr
            );
          }
        }
      }
    }

    if (!selectedTarget) {
      return NextResponse.json(
        { error: "No suitable target found" },
        { status: 404 }
      );
    }

    // Increment click count on the target
    await db.linkTarget.update({
      where: { id: selectedTarget.id },
      data: { currentClicks: { increment: 1 } },
    });

    // Record the click
    await db.click.create({
      data: {
        linkId: link.id,
        targetId: selectedTarget.id,
        ip: visitorIp,
        country: visitorCountry,
        city: visitorCity,
        region: visitorRegion,
        device: visitorDevice,
        browser: visitorBrowser,
        os: visitorOs,
        referrer: visitorReferrer,
      },
    });

    // Return redirect info (demo mode - don't actually redirect)
    return NextResponse.json({
      url: selectedTarget.url,
      status: 301,
      linkId: link.id,
      targetId: selectedTarget.id,
    });
  } catch (error) {
    console.error("Error processing redirect:", error);
    return NextResponse.json({ error: "Redirect failed" }, { status: 500 });
  }
}

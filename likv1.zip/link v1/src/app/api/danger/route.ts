import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Handle destructive operations
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { action } = body as { action: string };

    switch (action) {
      case "deleteAllLinks": {
        // Get counts before deletion
        const linkCount = await db.shortLink.count();
        const targetCount = await db.linkTarget.count();
        const clickCount = await db.click.count();

        await db.shortLink.deleteMany();

        return NextResponse.json({
          success: true,
          deleted: {
            links: linkCount,
            targets: targetCount,
            clicks: clickCount,
            domains: 0,
          },
        });
      }

      case "deleteAllClicks": {
        const clickCount = await db.click.count();

        await db.click.deleteMany();

        // Reset currentClicks on all LinkTargets to 0
        await db.linkTarget.updateMany({
          data: { currentClicks: 0 },
        });

        return NextResponse.json({
          success: true,
          deleted: {
            links: 0,
            targets: 0,
            clicks: clickCount,
            domains: 0,
          },
        });
      }

      case "resetDatabase": {
        const [linkCount, targetCount, clickCount, domainCount] = await Promise.all([
          db.shortLink.count(),
          db.linkTarget.count(),
          db.click.count(),
          db.shortDomain.count(),
        ]);

        // Delete in order respecting relations
        await db.click.deleteMany();
        await db.linkTarget.deleteMany();
        await db.shortLink.deleteMany();
        await db.shortDomain.deleteMany();
        await db.appSetting.deleteMany();

        return NextResponse.json({
          success: true,
          deleted: {
            links: linkCount,
            targets: targetCount,
            clicks: clickCount,
            domains: domainCount,
          },
        });
      }

      default:
        return NextResponse.json(
          { error: "Invalid action. Use: deleteAllLinks, deleteAllClicks, or resetDatabase" },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error("Error performing danger operation:", error);
    return NextResponse.json({ error: "Operation failed" }, { status: 500 });
  }
}

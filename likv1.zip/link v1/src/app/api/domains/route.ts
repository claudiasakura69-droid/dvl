import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - List all domains
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const domains = await db.shortDomain.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        links: {
          select: { id: true },
        },
      },
    });

    const domainsWithCount = domains.map((d) => ({
      ...d,
      _count: { links: d.links.length },
      links: undefined,
    }));

    return NextResponse.json(domainsWithCount);
  } catch (error) {
    console.error("Error fetching domains:", error);
    return NextResponse.json({ error: "Failed to fetch domains" }, { status: 500 });
  }
}

// POST - Create domain
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { domain, slug } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json({ error: "Domain is required" }, { status: 400 });
    }

    // Basic domain format validation
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      return NextResponse.json({ error: "Invalid domain format" }, { status: 400 });
    }

    // Check if domain already exists
    const existing = await db.shortDomain.findUnique({ where: { domain } });
    if (existing) {
      return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
    }

    const created = await db.shortDomain.create({
      data: {
        domain,
        slug: slug || "",
      },
    });

    return NextResponse.json(created, { status: 201 });
  } catch (error) {
    console.error("Error creating domain:", error);
    return NextResponse.json({ error: "Failed to create domain" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Get single domain
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const domain = await db.shortDomain.findUnique({
      where: { id },
      include: {
        links: {
          select: { id: true },
        },
      },
    });

    if (!domain) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const domainWithCount = {
      ...domain,
      _count: { links: domain.links.length },
      links: undefined,
    };

    return NextResponse.json(domainWithCount);
  } catch (error) {
    console.error("Error fetching domain:", error);
    return NextResponse.json({ error: "Failed to fetch domain" }, { status: 500 });
  }
}

// PUT - Update domain
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();
    const { domain, slug, isActive, isVerified } = body;

    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // If domain is being changed, check uniqueness
    if (domain && domain !== existing.domain) {
      const domainConflict = await db.shortDomain.findUnique({ where: { domain } });
      if (domainConflict) {
        return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
      }
    }

    const updated = await db.shortDomain.update({
      where: { id },
      data: {
        ...(domain !== undefined && { domain }),
        ...(slug !== undefined && { slug }),
        ...(isActive !== undefined && { isActive }),
        ...(isVerified !== undefined && { isVerified }),
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating domain:", error);
    return NextResponse.json({ error: "Failed to update domain" }, { status: 500 });
  }
}

// DELETE - Delete domain (cascades to links)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    await db.shortDomain.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting domain:", error);
    return NextResponse.json({ error: "Failed to delete domain" }, { status: 500 });
  }
}

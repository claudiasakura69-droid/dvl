import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

const SETTINGS_KEYS = [
  "redirectStatus",
  "healthInterval",
  "defaultUtmSource",
  "defaultUtmMedium",
  "defaultUtmCampaign",
  "defaultUtmContent",
  "defaultUtmTerm",
] as const;

const DEFAULT_VALUES: Record<string, string> = {
  redirectStatus: "301",
  healthInterval: "300",
  defaultUtmSource: "",
  defaultUtmMedium: "",
  defaultUtmCampaign: "",
  defaultUtmContent: "",
  defaultUtmTerm: "",
};

async function getSetting(key: string, defaultValue: string = ""): Promise<string> {
  const setting = await db.appSetting.findUnique({ where: { key } });
  return setting?.value ?? defaultValue;
}

async function setSetting(key: string, value: string): Promise<void> {
  await db.appSetting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
}

// GET - Return all settings
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const settings: Record<string, string> = {};

    for (const key of SETTINGS_KEYS) {
      settings[key] = await getSetting(key, DEFAULT_VALUES[key] || "");
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error("Error fetching settings:", error);
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
  }
}

// PUT - Save/update settings
export async function PUT(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();

    // Support single key-value update
    if (body.key && body.value !== undefined) {
      await setSetting(body.key, String(body.value));
      return NextResponse.json({ success: true, key: body.key, value: body.value });
    }

    // Support batch update with { settings: Record<string, string> }
    if (body.settings && typeof body.settings === "object") {
      const entries = Object.entries(body.settings);
      for (const [key, value] of entries) {
        await setSetting(key, String(value));
      }
      return NextResponse.json({ success: true, updated: entries.length });
    }

    return NextResponse.json(
      { error: "Provide { key, value } or { settings: { key: value, ... } }" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Error saving settings:", error);
    return NextResponse.json({ error: "Failed to save settings" }, { status: 500 });
  }
}

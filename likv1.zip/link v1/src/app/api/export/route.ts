import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Export all links, domains, and clicks as JSON
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const includeClicks = request.nextUrl.searchParams.get("includeClicks") === "true";

    const [links, domains, clicks] = await Promise.all([
      db.shortLink.findMany({
        include: {
          domain: {
            select: { id: true, domain: true, slug: true },
          },
          targets: {
            orderBy: { order: "asc" },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      db.shortDomain.findMany({
        orderBy: { createdAt: "desc" },
      }),
      includeClicks
        ? db.click.findMany({
            orderBy: { createdAt: "desc" },
          })
        : Promise.resolve([]),
    ]);

    return NextResponse.json({
      links,
      domains,
      clicks,
      exportedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error exporting data:", error);
    return NextResponse.json({ error: "Failed to export data" }, { status: 500 });
  }
}

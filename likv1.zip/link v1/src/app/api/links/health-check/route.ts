import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Health check for link targets
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { linkId } = body;

    // Type for health check results
    type HealthResult = {
      targetId: string;
      url: string;
      isHealthy: boolean;
      httpStatus: number | null;
    };

    // Fetch targets to check
    let targets: Array<{
      id: string;
      url: string;
    }>;

    if (linkId) {
      // Check only specific link
      const link = await db.shortLink.findUnique({
        where: { id: linkId },
        include: {
          targets: {
            where: { isActive: true },
          },
        },
      });

      if (!link) {
        return NextResponse.json({ error: "Link not found" }, { status: 404 });
      }

      targets = link.targets;
    } else {
      // Check all active links' targets
      const allLinks = await db.shortLink.findMany({
        where: { isActive: true },
        include: {
          targets: {
            where: { isActive: true },
          },
        },
      });

      targets = allLinks.flatMap((link) => link.targets);
    }

    if (targets.length === 0) {
      return NextResponse.json({
        checked: 0,
        healthy: 0,
        unhealthy: 0,
        results: [],
      });
    }

    const results: HealthResult[] = [];

    // Run health checks sequentially to avoid overwhelming the server
    for (const target of targets) {
      try {
        const response = await fetch(target.url, {
          method: "HEAD",
          redirect: "follow",
          signal: AbortSignal.timeout(5000),
        });

        const isHealthy = response.ok || response.status < 500;

        await db.linkTarget.update({
          where: { id: target.id },
          data: {
            isHealthy,
            httpStatus: response.status,
            lastChecked: new Date(),
          },
        });

        results.push({
          targetId: target.id,
          url: target.url,
          isHealthy,
          httpStatus: response.status,
        });
      } catch {
        await db.linkTarget.update({
          where: { id: target.id },
          data: {
            isHealthy: false,
            httpStatus: null,
            lastChecked: new Date(),
          },
        });

        results.push({
          targetId: target.id,
          url: target.url,
          isHealthy: false,
          httpStatus: null,
        });
      }
    }

    const healthyCount = results.filter((r) => r.isHealthy).length;

    return NextResponse.json({
      checked: results.length,
      healthy: healthyCount,
      unhealthy: results.length - healthyCount,
      results,
    });
  } catch (error) {
    console.error("Error performing health check:", error);
    return NextResponse.json({ error: "Health check failed" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { Prisma } from "@prisma/client";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Click analytics for a specific link
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const searchParams = request.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")));
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    // Verify link exists
    const link = await db.shortLink.findUnique({
      where: { id },
    });

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    const where: Prisma.ClickWhereInput = { linkId: id };

    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) {
        (where.createdAt as Prisma.DateTimeNullableFilter).gte = new Date(startDate);
      }
      if (endDate) {
        (where.createdAt as Prisma.DateTimeNullableFilter).lte = new Date(endDate);
      }
    }

    const [clicks, total] = await Promise.all([
      db.click.findMany({
        where,
        include: {
          target: {
            select: { id: true, url: true },
          },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.click.count({ where }),
    ]);

    return NextResponse.json({
      clicks,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Error fetching clicks:", error);
    return NextResponse.json({ error: "Failed to fetch clicks" }, { status: 500 });
  }
}

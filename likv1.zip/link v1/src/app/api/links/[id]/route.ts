import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Get single link with targets
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const link = await db.shortLink.findUnique({
      where: { id },
      include: {
        domain: {
          select: { id: true, domain: true, slug: true },
        },
        targets: {
          orderBy: { order: "asc" },
        },
        _count: {
          select: { clicks: true },
        },
      },
    });

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    return NextResponse.json(link);
  } catch (error) {
    console.error("Error fetching link:", error);
    return NextResponse.json({ error: "Failed to fetch link" }, { status: 500 });
  }
}

// PUT - Update link
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.shortLink.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    // Destructure updatable fields
    const {
      slug,
      domainId,
      type,
      mode,
      title,
      description,
      password,
      ogTitle,
      ogDescription,
      ogImage,
      utmSource,
      utmMedium,
      utmCampaign,
      utmContent,
      utmTerm,
      isActive,
      expiredAt,
      targets,
    } = body;

    // If slug or domainId is changing, check uniqueness
    const newSlug = slug !== undefined ? slug : existing.slug;
    const newDomainId = domainId !== undefined ? domainId : existing.domainId;

    if (slug !== undefined || domainId !== undefined) {
      const conflict = await db.shortLink.findUnique({
        where: { slug_domainId: { slug: newSlug, domainId: newDomainId } },
      });
      if (conflict && conflict.id !== id) {
        return NextResponse.json(
          { error: "Slug already exists for this domain" },
          { status: 409 }
        );
      }
    }

    // If targets array is provided, replace all targets
    if (Array.isArray(targets)) {
      await db.linkTarget.deleteMany({ where: { linkId: id } });

      if (targets.length > 0) {
        await db.linkTarget.createMany({
          data: targets.map(
            (t: {
              url: string;
              clickLimit?: number;
              country?: string;
              ipList?: string;
              order?: number;
              isActive?: boolean;
            }) => ({
              linkId: id,
              url: t.url,
              clickLimit: t.clickLimit || 0,
              country: t.country || "ALL",
              ipList: t.ipList || "",
              order: t.order || 0,
              isActive: t.isActive !== undefined ? t.isActive : true,
            })
          ),
        });
      }
    }

    const updated = await db.shortLink.update({
      where: { id },
      data: {
        ...(slug !== undefined && { slug }),
        ...(domainId !== undefined && { domainId }),
        ...(type !== undefined && { type }),
        ...(mode !== undefined && { mode }),
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description }),
        ...(password !== undefined && { password }),
        ...(ogTitle !== undefined && { ogTitle }),
        ...(ogDescription !== undefined && { ogDescription }),
        ...(ogImage !== undefined && { ogImage }),
        ...(utmSource !== undefined && { utmSource }),
        ...(utmMedium !== undefined && { utmMedium }),
        ...(utmCampaign !== undefined && { utmCampaign }),
        ...(utmContent !== undefined && { utmContent }),
        ...(utmTerm !== undefined && { utmTerm }),
        ...(isActive !== undefined && { isActive }),
        ...(expiredAt !== undefined && {
          expiredAt: expiredAt ? new Date(expiredAt) : null,
        }),
      },
      include: {
        domain: {
          select: { id: true, domain: true, slug: true },
        },
        targets: {
          orderBy: { order: "asc" },
        },
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating link:", error);
    return NextResponse.json({ error: "Failed to update link" }, { status: 500 });
  }
}

// DELETE - Delete link and all related data
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await db.shortLink.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    await db.shortLink.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting link:", error);
    return NextResponse.json({ error: "Failed to delete link" }, { status: 500 });
  }
}

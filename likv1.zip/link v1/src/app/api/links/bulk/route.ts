import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { Prisma } from "@prisma/client";
import { isAuthenticated, unauthorized } from "@/lib/auth";

function generateSlug(length = 6): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// POST - Bulk operations
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case "create": {
        const { links: linksToCreate } = body as {
          links: Array<{ slug: string; url: string; domainId: string; title?: string }>;
        };

        if (!Array.isArray(linksToCreate) || linksToCreate.length === 0) {
          return NextResponse.json({ error: "links array is required" }, { status: 400 });
        }

        // Verify domains exist
        const domainIds = [...new Set(linksToCreate.map((l) => l.domainId))];
        const domains = await db.shortDomain.findMany({
          where: { id: { in: domainIds } },
        });
        const domainMap = new Map(domains.map((d) => [d.id, d]));

        let created = 0;
        let skipped = 0;
        const errors: string[] = [];

        for (const linkData of linksToCreate) {
          if (!linkData.url || !linkData.domainId) {
            skipped++;
            continue;
          }
          if (!domainMap.has(linkData.domainId)) {
            errors.push(`Link "${linkData.slug || "unknown"}": Domain not found`);
            skipped++;
            continue;
          }

          const slug = linkData.slug || generateSlug();

          // Check for slug conflict
          const existing = await db.shortLink.findUnique({
            where: { slug_domainId: { slug, domainId: linkData.domainId } },
          });
          if (existing) {
            skipped++;
            continue;
          }

          try {
            await db.shortLink.create({
              data: {
                slug,
                domainId: linkData.domainId,
                type: "basic",
                mode: "sequential",
                title: linkData.title || "",
                targets: {
                  create: [{ url: linkData.url }],
                },
              },
            });
            created++;
          } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : String(err);
            errors.push(`Link "${slug}": ${msg}`);
          }
        }

        return NextResponse.json({ success: true, created, skipped, errors });
      }

      case "changeDomain": {
        const { oldDomainId, newDomainId } = body;

        if (!oldDomainId || !newDomainId) {
          return NextResponse.json(
            { error: "oldDomainId and newDomainId are required" },
            { status: 400 }
          );
        }

        // Verify new domain exists
        const newDomain = await db.shortDomain.findUnique({
          where: { id: newDomainId },
        });
        if (!newDomain) {
          return NextResponse.json({ error: "Target domain not found" }, { status: 404 });
        }

        // Check for slug conflicts in the new domain
        const oldLinks = await db.shortLink.findMany({
          where: { domainId: oldDomainId },
          select: { id: true, slug: true },
        });

        const existingSlugs = await db.shortLink.findMany({
          where: { domainId: newDomainId },
          select: { slug: true },
        });

        const existingSlugSet = new Set(existingSlugs.map((l) => l.slug));
        const conflictingSlugs = oldLinks.filter((l) => existingSlugSet.has(l.slug));

        if (conflictingSlugs.length > 0) {
          return NextResponse.json(
            {
              error: `Slug conflicts found: ${conflictingSlugs.map((l) => l.slug).join(", ")}`,
            },
            { status: 409 }
          );
        }

        const result = await db.shortLink.updateMany({
          where: { domainId: oldDomainId },
          data: { domainId: newDomainId },
        });

        return NextResponse.json({ success: true, count: result.count });
      }

      case "delete": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const result = await db.shortLink.deleteMany({
          where: { id: { in: linkIds } },
        });

        return NextResponse.json({ success: true, count: result.count });
      }

      case "activate": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const result = await db.shortLink.updateMany({
          where: { id: { in: linkIds } },
          data: { isActive: true },
        });

        return NextResponse.json({ success: true, count: result.count });
      }

      case "deactivate": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const result = await db.shortLink.updateMany({
          where: { id: { in: linkIds } },
          data: { isActive: false },
        });

        return NextResponse.json({ success: true, count: result.count });
      }

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Error performing bulk operation:", error);
    return NextResponse.json({ error: "Bulk operation failed" }, { status: 500 });
  }
}

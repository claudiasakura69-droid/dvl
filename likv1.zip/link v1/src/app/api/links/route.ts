import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { Prisma } from "@prisma/client";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - List links with pagination, search, and filters
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const searchParams = request.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")));
    const search = searchParams.get("search") || "";
    const domainId = searchParams.get("domainId") || "";
    const type = searchParams.get("type") || "";
    const isActive = searchParams.get("isActive");

    const where: Prisma.ShortLinkWhereInput = {};

    if (search) {
      where.OR = [
        { slug: { contains: search } },
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }

    if (domainId) {
      where.domainId = domainId;
    }

    if (type) {
      where.type = type;
    }

    if (isActive !== null && isActive !== undefined && isActive !== "") {
      where.isActive = isActive === "true";
    }

    const [links, total] = await Promise.all([
      db.shortLink.findMany({
        where,
        include: {
          domain: {
            select: { id: true, domain: true, slug: true },
          },
          targets: {
            select: { id: true },
          },
          _count: {
            select: { clicks: true },
          },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.shortLink.count({ where }),
    ]);

    const mappedLinks = links.map((link) => ({
      ...link,
      _count: { clicks: link._count.clicks, targets: link.targets.length },
      targets: undefined,
    }));

    return NextResponse.json({
      links: mappedLinks,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Error fetching links:", error);
    return NextResponse.json({ error: "Failed to fetch links" }, { status: 500 });
  }
}

// POST - Create a new short link
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const {
      slug,
      domainId,
      type = "basic",
      mode = "sequential",
      title,
      description,
      password,
      ogTitle,
      ogDescription,
      ogImage,
      utmSource,
      utmMedium,
      utmCampaign,
      utmContent,
      utmTerm,
      expiredAt,
      targets,
    } = body;

    // Validation
    if (!slug || typeof slug !== "string") {
      return NextResponse.json({ error: "Slug is required" }, { status: 400 });
    }

    if (!domainId) {
      return NextResponse.json({ error: "Domain ID is required" }, { status: 400 });
    }

    // Validate domain exists
    const domain = await db.shortDomain.findUnique({ where: { id: domainId } });
    if (!domain) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // Validate targets
    const targetsArray = Array.isArray(targets) ? targets : [];

    if (type === "basic" && targetsArray.length !== 1) {
      return NextResponse.json(
        { error: "Basic type requires exactly 1 target" },
        { status: 400 }
      );
    }

    if (type === "multi" && targetsArray.length < 1) {
      return NextResponse.json(
        { error: "Multi type requires at least 1 target" },
        { status: 400 }
      );
    }

    // Check slug uniqueness per domain
    const existing = await db.shortLink.findUnique({
      where: { slug_domainId: { slug, domainId } },
    });

    if (existing) {
      return NextResponse.json(
        { error: "Slug already exists for this domain" },
        { status: 409 }
      );
    }

    // Parse expiredAt if provided
    const expiredAtDate = expiredAt ? new Date(expiredAt) : null;

    // Create link with targets
    const link = await db.shortLink.create({
      data: {
        slug,
        domainId,
        type,
        mode,
        title: title || "",
        description: description || "",
        password: password || "",
        ogTitle: ogTitle || "",
        ogDescription: ogDescription || "",
        ogImage: ogImage || "",
        utmSource: utmSource || "",
        utmMedium: utmMedium || "",
        utmCampaign: utmCampaign || "",
        utmContent: utmContent || "",
        utmTerm: utmTerm || "",
        expiredAt: expiredAtDate,
        targets: {
          create: targetsArray.map(
            (t: {
              url: string;
              clickLimit?: number;
              country?: string;
              ipList?: string;
              order?: number;
            }) => ({
              url: t.url,
              clickLimit: t.clickLimit || 0,
              country: t.country || "ALL",
              ipList: t.ipList || "",
              order: t.order || 0,
            })
          ),
        },
      },
      include: {
        domain: {
          select: { id: true, domain: true, slug: true },
        },
        targets: true,
      },
    });

    return NextResponse.json(link, { status: 201 });
  } catch (error) {
    console.error("Error creating link:", error);
    return NextResponse.json({ error: "Failed to create link" }, { status: 500 });
  }
}

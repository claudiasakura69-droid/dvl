import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Redirect Handler: /s/[slug]
 *
 * This route handles ALL short URL redirects for short URL domains.
 * It is reached via middleware rewrite from short URL domains.
 *
 * Flow:
 * 1. Extract slug from URL path
 * 2. Extract original domain from ?host= query param (set by middleware)
 * 3. Look up the domain in the database (short_domains table)
 * 4. If domain not found or not active → 404
 * 5. Look up the link by slug + domain
 * 6. If link not found → 404
 * 7. If link inactive or expired → 404/410
 * 8. If password protected and no password → show password page
 * 9. Determine target URL based on routing logic
 * 10. Record click in database
 * 11. Return 301 Permanent Redirect to target URL
 */

// HTML template for 404 page on short URL domains
function get404Html(host: string, slug: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>404 - Link Not Found</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a0a;
      color: #fafafa;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      text-align: center;
      max-width: 420px;
    }
    .code {
      font-size: 96px;
      font-weight: 800;
      color: #262626;
      line-height: 1;
      margin-bottom: 16px;
    }
    h1 {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 8px;
    }
    p {
      font-size: 14px;
      color: #737373;
      margin-bottom: 24px;
      line-height: 1.5;
    }
    .slug {
      font-family: 'SF Mono', Monaco, monospace;
      background: #171717;
      border: 1px solid #262626;
      border-radius: 8px;
      padding: 12px 16px;
      font-size: 14px;
      color: #a3a3a3;
      margin-bottom: 24px;
      word-break: break-all;
    }
    a {
      display: inline-block;
      padding: 10px 24px;
      background: #fafafa;
      color: #0a0a0a;
      text-decoration: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.2s;
    }
    a:hover { background: #e5e5e5; }
    .footer {
      margin-top: 32px;
      font-size: 12px;
      color: #525252;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="code">404</div>
    <h1>Link Not Found</h1>
    <p>The short URL you're looking for doesn't exist or has been removed.</p>
    <div class="slug">/${slug}</div>
    <a href="/">Go Home</a>
    <div class="footer">Powered by ShortURL Platform</div>
  </div>
</body>
</html>`;
}

// HTML template for root page on short URL domains
function getRootHtml(host: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Short URL Service</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a0a;
      color: #fafafa;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      text-align: center;
      max-width: 420px;
    }
    .icon {
      font-size: 48px;
      margin-bottom: 24px;
    }
    h1 {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 8px;
    }
    p {
      font-size: 14px;
      color: #737373;
      line-height: 1.6;
      margin-bottom: 24px;
    }
    .domain {
      font-family: 'SF Mono', Monaco, monospace;
      background: #171717;
      border: 1px solid #262626;
      border-radius: 8px;
      padding: 12px 16px;
      font-size: 14px;
      color: #a3a3a3;
      margin-bottom: 24px;
    }
    .footer {
      margin-top: 32px;
      font-size: 12px;
      color: #525252;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">&#128279;</div>
    <h1>Short URL Service</h1>
    <p>This domain is configured as a short URL service. Access a specific short link to be redirected to its destination.</p>
    <div class="domain">${host}</div>
    <div class="footer">Powered by ShortURL Platform</div>
  </div>
</body>
</html>`;
}

// HTML template for password-protected links
function getPasswordHtml(host: string, slug: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Password Required</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a0a;
      color: #fafafa;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .container {
      text-align: center;
      max-width: 380px;
      width: 100%;
    }
    .icon { font-size: 48px; margin-bottom: 16px; }
    h1 { font-size: 20px; font-weight: 600; margin-bottom: 8px; }
    p { font-size: 14px; color: #737373; margin-bottom: 24px; }
    form { display: flex; flex-direction: column; gap: 12px; }
    input {
      padding: 10px 16px;
      background: #171717;
      border: 1px solid #262626;
      border-radius: 8px;
      color: #fafafa;
      font-size: 14px;
      outline: none;
      transition: border-color 0.2s;
    }
    input:focus { border-color: #525252; }
    input::placeholder { color: #525252; }
    button {
      padding: 10px 24px;
      background: #fafafa;
      color: #0a0a0a;
      border: none;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
    }
    button:hover { background: #e5e5e5; }
    .error { color: #ef4444; font-size: 13px; display: none; }
    .error.show { display: block; }
    .footer { margin-top: 32px; font-size: 12px; color: #525252; }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">&#128274;</div>
    <h1>Password Required</h1>
    <p>This link is password-protected. Enter the password to continue.</p>
    <form onsubmit="return submitPassword(event)">
      <input type="password" id="pwd" placeholder="Enter password" autofocus />
      <button type="submit">Continue</button>
    </form>
    <div class="error" id="error">Incorrect password. Please try again.</div>
    <div class="footer">Powered by ShortURL Platform</div>
  </div>
  <script>
    function submitPassword(e) {
      e.preventDefault();
      const pwd = document.getElementById('pwd').value;
      window.location.href = '/${slug}?password=' + encodeURIComponent(pwd);
      return false;
    }
  </script>
</body>
</html>`;
}

// HTML template for expired links
function getExpiredHtml(host: string, slug: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Link Expired</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0a0a0a;
      color: #fafafa;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }
    .container { text-align: center; max-width: 420px; }
    .icon { font-size: 48px; margin-bottom: 16px; }
    h1 { font-size: 20px; font-weight: 600; margin-bottom: 8px; }
    p { font-size: 14px; color: #737373; line-height: 1.5; }
    .footer { margin-top: 32px; font-size: 12px; color: #525252; }
  </style>
</head>
<body>
  <div class="container">
    <div class="icon">&#9200;</div>
    <h1>Link Expired</h1>
    <p>This short URL has expired and is no longer active.</p>
    <div class="footer">Powered by ShortURL Platform</div>
  </div>
</body>
</html>`;
}

// Simulate visitor data for demo/testing
// In production, these would come from request.cf (Cloudflare) or headers
function getVisitorData(request: NextRequest) {
  const headers = request.headers;

  // Try to get real data from headers (works in production behind Cloudflare)
  const ip =
    headers.get("cf-connecting-ip") ||
    headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    headers.get("x-real-ip") ||
    "127.0.0.1";

  const country =
    headers.get("cf-ipcountry") ||
    "";

  const city =
    headers.get("cf-ipcity") ||
    "";

  const device = parseDevice(headers.get("user-agent") || "");
  const browser = parseBrowser(headers.get("user-agent") || "");
  const os = parseOS(headers.get("user-agent") || "");
  const referrer = headers.get("referer") || "direct";

  return { ip, country, city, device, browser, os, referrer };
}

function parseDevice(ua: string): string {
  if (/Mobile|Android.*Mobile|iPhone|iPod/.test(ua)) return "Mobile";
  if (/iPad|Android(?!.*Mobile)|Tablet/.test(ua)) return "Tablet";
  return "Desktop";
}

function parseBrowser(ua: string): string {
  if (/Edg\//.test(ua)) return "Edge";
  if (/Chrome/.test(ua)) return "Chrome";
  if (/Firefox/.test(ua)) return "Firefox";
  if (/Safari/.test(ua)) return "Safari";
  if (/Opera|OPR/.test(ua)) return "Opera";
  return "Unknown";
}

function parseOS(ua: string): string {
  if (/Windows/.test(ua)) return "Windows";
  if (/Mac OS X/.test(ua)) return "macOS";
  if (/Linux/.test(ua)) return "Linux";
  if (/Android/.test(ua)) return "Android";
  if (/iPhone|iPad|iPod/.test(ua)) return "iOS";
  return "Unknown";
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const host = request.nextUrl.searchParams.get("host") || request.headers.get("host") || "";

  // Handle root path on short URL domain
  if (slug === "__root__") {
    return new NextResponse(getRootHtml(host), {
      status: 200,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  try {
    // Step 1: Find the domain in the database
    const domainRecord = await db.shortDomain.findFirst({
      where: { domain: host },
    });

    if (!domainRecord) {
      // Domain not registered in our system
      return new NextResponse(get404Html(host, slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    if (!domainRecord.isActive) {
      // Domain is deactivated
      return new NextResponse(get404Html(host, slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    // Step 2: Find the link by slug + domain
    const link = await db.shortLink.findFirst({
      where: {
        slug,
        domainId: domainRecord.id,
      },
      include: {
        domain: true,
        targets: {
          where: { isActive: true },
          orderBy: { order: "asc" },
        },
      },
    });

    if (!link) {
      // Link not found
      return new NextResponse(get404Html(host, slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    // Step 3: Check if link is active
    if (!link.isActive) {
      return new NextResponse(get404Html(host, slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    // Step 4: Check expiration
    if (link.expiredAt && new Date(link.expiredAt) < new Date()) {
      return new NextResponse(getExpiredHtml(host, slug), {
        status: 410,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    // Step 5: Check password protection
    const providedPassword = request.nextUrl.searchParams.get("password");
    if (link.password) {
      if (!providedPassword) {
        // Show password page
        return new NextResponse(getPasswordHtml(host, slug), {
          status: 403,
          headers: { "Content-Type": "text/html; charset=utf-8" },
        });
      }
      if (providedPassword !== link.password) {
        // Wrong password - redirect back to password page
        return new NextResponse(getPasswordHtml(host, slug), {
          status: 403,
          headers: { "Content-Type": "text/html; charset=utf-8" },
        });
      }
    }

    // Step 6: Get visitor data
    const visitor = getVisitorData(request);

    // Step 7: Determine redirect target using routing logic
    let selectedTarget = determineTarget(link.targets || [], visitor);

    if (!selectedTarget) {
      return new NextResponse(get404Html(host, slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8" },
      });
    }

    // Step 8: Build the final redirect URL (append UTM params if configured)
    let redirectUrl = selectedTarget.url;
    const utmParams = new URLSearchParams();
    if (link.utmSource) utmParams.set("utm_source", link.utmSource);
    if (link.utmMedium) utmParams.set("utm_medium", link.utmMedium);
    if (link.utmCampaign) utmParams.set("utm_campaign", link.utmCampaign);
    if (link.utmContent) utmParams.set("utm_content", link.utmContent);
    if (link.utmTerm) utmParams.set("utm_term", link.utmTerm);

    if (utmParams.toString()) {
      const separator = redirectUrl.includes("?") ? "&" : "?";
      redirectUrl += separator + utmParams.toString();
    }

    // Step 9: Increment click count (fire-and-forget for speed)
    // Use Promise.allSettled to not block the redirect
    const recordClick = async () => {
      try {
        await db.$transaction([
          db.linkTarget.update({
            where: { id: selectedTarget!.id },
            data: { currentClicks: { increment: 1 } },
          }),
          db.click.create({
            data: {
              linkId: link.id,
              targetId: selectedTarget!.id,
              ip: visitor.ip,
              country: visitor.country,
              city: visitor.city,
              region: "",
              device: visitor.device,
              browser: visitor.browser,
              os: visitor.os,
              referrer: visitor.referrer,
            },
          }),
        ]);
      } catch (error) {
        console.error("Failed to record click:", error);
      }
    };

    // Record click asynchronously
    recordClick();

    // Step 10: Return 301 Permanent Redirect
    return NextResponse.redirect(redirectUrl, 301);
  } catch (error) {
    console.error("Redirect error:", error);
    return new NextResponse(get404Html(host, slug), {
      status: 500,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }
}

/**
 * Determine which target URL to redirect to based on routing logic.
 *
 * Priority:
 * 1. IP-based match → redirect to IP-specific target
 * 2. Country-based match → redirect to country-specific target
 * 3. ALL (catch-all) targets → random or sequential selection
 * 4. Any available target as fallback
 */
function determineTarget(
  targets: Array<{
    id: string;
    url: string;
    clickLimit: number;
    currentClicks: number;
    country: string;
    ipList: string;
    order: number;
    isActive: boolean;
  }>,
  visitor: { ip: string; country: string }
): (typeof targets)[0] | null {
  // Filter out targets that have reached their click limit
  const available = targets.filter(
    (t) => t.clickLimit === 0 || t.currentClicks < t.clickLimit
  );

  if (available.length === 0) return null;

  // Priority 1: IP-based targets
  const ipMatch = available.find((t) => {
    if (!t.ipList) return false;
    const allowedIps = t.ipList.split(",").map((ip) => ip.trim());
    return allowedIps.includes(visitor.ip);
  });

  if (ipMatch) return ipMatch;

  // Priority 2: Country-based targets (exact match)
  const countryMatch = available.find(
    (t) => t.country !== "ALL" && t.country === visitor.country
  );

  if (countryMatch) return countryMatch;

  // Priority 3: ALL (catch-all) targets
  const allTargets = available.filter((t) => t.country === "ALL");

  if (allTargets.length > 0) {
    // For basic links, return the first (and usually only) target
    // For multi links, use random/sequential selection
    if (allTargets.length === 1) return allTargets[0];

    // Random selection (first target's mode would be used in real impl)
    return allTargets[Math.floor(Math.random() * allTargets.length)];
  }

  // Fallback: return first available target
  return available[0];
}

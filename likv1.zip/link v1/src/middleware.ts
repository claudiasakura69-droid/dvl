import { NextRequest, NextResponse } from "next/server";

/**
 * Middleware: Domain-based routing
 *
 * Architecture:
 * - Main Domain (abc.com): Serves the dashboard SPA (login + management)
 * - Short URL Domains (abc.me, go.example.com): Handles short URL redirects
 *
 * Both domains point to the SAME Cloudflare Pages project.
 * The middleware detects which domain is being accessed and routes accordingly.
 *
 * IMPORTANT: This middleware is DISABLED in development mode.
 * It only runs in production (Cloudflare Pages) where multiple domains
 * point to the same application.
 *
 * How it works:
 * 1. Extract the Host header from the incoming request
 * 2. Check if it matches the main domain (from APP_DOMAIN env var or *.pages.dev)
 * 3. If main domain → pass through → dashboard SPA
 * 4. If short URL domain → rewrite to /s/[slug] redirect handler
 */

// Get the main dashboard domain from env
// APP_DOMAIN = the primary domain for dashboard (e.g., "abc.com")
function getMainDomain(): string {
  const appDomain = process.env.APP_DOMAIN || "";
  if (appDomain) {
    try {
      return new URL(
        appDomain.startsWith("http") ? appDomain : `https://${appDomain}`
      ).hostname;
    } catch {
      return appDomain;
    }
  }
  return "";
}

export function middleware(request: NextRequest) {
  // In development, skip middleware entirely — always serve dashboard SPA
  // The middleware is only needed in production when multiple domains
  // point to the same Cloudflare Pages application.
  if (process.env.NODE_ENV === "development") {
    return NextResponse.next();
  }

  const host = request.headers.get("host") || "";
  const pathname = request.nextUrl.pathname;

  // Skip interception for Next.js internal routes, API routes, and static assets
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/robots") ||
    pathname.startsWith("/logo") ||
    pathname.startsWith("/s/") || // Already on redirect handler
    pathname.includes(".") // static files like .css, .js, .svg, etc.
  ) {
    return NextResponse.next();
  }

  // Determine the main dashboard domain
  const mainDomain = getMainDomain();

  // Check if this request is for the main dashboard domain
  const isPagesDev = host.endsWith(".pages.dev");
  const isMainDomain = mainDomain
    ? host === mainDomain || host === `www.${mainDomain}`
    : isPagesDev;

  if (isMainDomain) {
    // Main domain → serve the dashboard SPA
    return NextResponse.next();
  }

  // Short URL domain → handle redirect
  const slug = pathname.slice(1); // Remove leading "/"

  if (!slug) {
    // Root path on short URL domain
    const redirectUrl = new URL("/s/__root__", request.url);
    redirectUrl.searchParams.set("host", host);
    return NextResponse.rewrite(redirectUrl);
  }

  // Rewrite to the redirect handler
  const redirectUrl = new URL(`/s/${slug}`, request.url);
  redirectUrl.searchParams.set("host", host);
  return NextResponse.rewrite(redirectUrl);
}

// Matcher: Run middleware on all paths except static assets and _next internals
export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon\\.ico|robots\\.txt|logo\\.svg).*)",
  ],
};

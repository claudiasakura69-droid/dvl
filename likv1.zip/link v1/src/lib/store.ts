import { create } from "zustand";
import type { PageName } from "./types";

interface AppState {
  currentPage: PageName;
  isAuthenticated: boolean;
  selectedLinkId: string | null;
  setCurrentPage: (page: PageName) => void;
  setSelectedLinkId: (id: string | null) => void;
  setAuthenticated: (auth: boolean) => void;
  logout: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: "overview",
  isAuthenticated: false,
  selectedLinkId: null,
  setCurrentPage: (page) => set({ currentPage: page }),
  setSelectedLinkId: (id) => set({ selectedLinkId: id }),
  setAuthenticated: (auth) => set({ isAuthenticated: auth }),
  logout: () => {
    localStorage.removeItem("token");
    set({ isAuthenticated: false, currentPage: "overview", selectedLinkId: null });
  },
}));

const API_BASE = "/api";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("token");
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(error.error || error.message || `Request failed: ${res.status}`);
  }

  // Handle 204 No Content
  if (res.status === 204) {
    return undefined as T;
  }

  return res.json();
}

export const apiGet = <T>(path: string) => request<T>(path, { method: "GET" });

export const apiPost = <T>(path: string, body?: unknown) =>
  request<T>(path, {
    method: "POST",
    body: body ? JSON.stringify(body) : undefined,
  });

export const apiPut = <T>(path: string, body?: unknown) =>
  request<T>(path, {
    method: "PUT",
    body: body ? JSON.stringify(body) : undefined,
  });

export const apiDelete = <T>(path: string) =>
  request<T>(path, { method: "DELETE" });

// Auth
export const checkAuth = () => apiGet<{ authenticated: boolean }>("/auth/check");
export const login = (token: string) =>
  apiPost<{ success: boolean; token: string }>("/auth/login", { token });

// Domains
export const getDomains = () => apiGet<any[]>("/domains");
export const createDomain = (data: { domain: string; slug?: string }) =>
  apiPost<any>("/domains", data);
export const updateDomain = (id: string, data: any) =>
  apiPut<any>(`/domains/${id}`, data);
export const deleteDomain = (id: string) => apiDelete<any>(`/domains/${id}`);
export const verifyDomain = (id: string) =>
  apiPost<any>(`/domains/${id}/verify`);

// Links
export const getLinks = (params?: Record<string, string>) => {
  const qs = params ? "?" + new URLSearchParams(params).toString() : "";
  return apiGet<{ links: any[]; total: number; page: number; totalPages: number }>(`/links${qs}`);
};
export const getLink = (id: string) => apiGet<any>(`/links/${id}`);
export const createLink = (data: any) => apiPost<any>("/links", data);
export const updateLink = (id: string, data: any) =>
  apiPut<any>(`/links/${id}`, data);
export const deleteLink = (id: string) => apiDelete<any>(`/links/${id}`);

// Link Clicks
export const getLinkClicks = (id: string, params?: Record<string, string>) => {
  const qs = params ? "?" + new URLSearchParams(params).toString() : "";
  return apiGet<any>(`/links/${id}/clicks${qs}`);
};

// Health Check
export const runHealthCheck = (linkId?: string) =>
  apiPost<any>("/links/health-check", linkId ? { linkId } : {});

// Bulk Operations
export const bulkChangeDomain = (oldDomainId: string, newDomainId: string) =>
  apiPost<any>("/links/bulk", { action: "changeDomain", oldDomainId, newDomainId });
export const bulkDeleteLinks = (ids: string[]) =>
  apiPost<any>("/links/bulk", { action: "delete", linkIds: ids });
export const bulkActivateLinks = (ids: string[]) =>
  apiPost<any>("/links/bulk", { action: "activate", linkIds: ids });
export const bulkDeactivateLinks = (ids: string[]) =>
  apiPost<any>("/links/bulk", { action: "deactivate", linkIds: ids });

// Analytics
export const getOverviewAnalytics = (params?: Record<string, string>) => {
  const qs = params ? "?" + new URLSearchParams(params).toString() : "";
  return apiGet<any>(`/analytics/overview${qs}`);
};

// Redirect (demo)
export const testRedirect = (slug: string, domain: string) =>
  apiGet<any>(`/redirect?slug=${slug}&domain=${domain}`);

// Settings
export const getSettings = () => apiGet<any>("/settings");
export const updateSettings = (settings: Record<string, string>) =>
  apiPut<any>("/settings", { settings });

// Export
export const exportData = (includeClicks = false) => {
  const qs = includeClicks ? "?includeClicks=true" : "";
  return apiGet<any>(`/export${qs}`);
};

// Import
export const importData = (data: { links?: any[]; domains?: any[]; clicks?: any[] }) =>
  apiPost<any>("/import", data);

// Danger Zone
export const dangerOperation = (action: "deleteAllLinks" | "deleteAllClicks" | "resetDatabase") =>
  apiPost<any>("/danger", { action });

// Bulk Create
export const bulkCreateLinks = (links: Array<{ slug: string; url: string; domainId: string; title?: string }>) =>
  apiPost<any>("/links/bulk", { action: "create", links });

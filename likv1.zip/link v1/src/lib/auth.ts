import { NextRequest, NextResponse } from "next/server";

const MASTER_TOKEN = process.env.DASHBOARD_TOKEN || "Master123@";

export function isAuthenticated(request: NextRequest): boolean {
  const authHeader = request.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.replace("Bearer ", "");
  return token === MASTER_TOKEN;
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

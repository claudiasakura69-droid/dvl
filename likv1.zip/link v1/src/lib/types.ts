// Types matching the Prisma schema models

export interface ShortDomain {
  id: string;
  domain: string;
  slug: string;
  isActive: boolean;
  isVerified: boolean;
  verifiedAt: string | null;
  createdAt: string;
  updatedAt: string;
  links?: ShortLink[];
  _count?: { links: number };
}

export interface ShortLink {
  id: string;
  slug: string;
  domainId: string;
  type: "basic" | "multi";
  mode: "random" | "sequential";
  title: string;
  description: string;
  password: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
  utmContent: string;
  utmTerm: string;
  isActive: boolean;
  expiredAt: string | null;
  createdAt: string;
  updatedAt: string;
  domain?: ShortDomain;
  targets?: LinkTarget[];
  clicks?: Click[];
  _count?: { clicks: number; targets: number };
}

export interface LinkTarget {
  id: string;
  linkId: string;
  url: string;
  clickLimit: number;
  currentClicks: number;
  country: string;
  ipList: string;
  order: number;
  isActive: boolean;
  lastChecked: string | null;
  isHealthy: boolean | null;
  httpStatus: number | null;
  createdAt: string;
  updatedAt: string;
  link?: ShortLink;
  clicks?: Click[];
  _count?: { clicks: number };
}

export interface Click {
  id: string;
  linkId: string;
  targetId: string | null;
  ip: string;
  country: string;
  city: string;
  region: string;
  device: string;
  browser: string;
  os: string;
  referrer: string;
  createdAt: string;
  link?: ShortLink;
  target?: LinkTarget;
}

// API request/response types
export interface CreateLinkRequest {
  slug: string;
  domainId: string;
  type: "basic" | "multi";
  mode?: "random" | "sequential";
  title?: string;
  description?: string;
  password?: string;
  expiredAt?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
  targets?: {
    url: string;
    clickLimit: number;
    country: string;
    ipList: string;
    order: number;
  }[];
}

export interface UpdateLinkRequest extends Partial<CreateLinkRequest> {
  isActive?: boolean;
}

export interface CreateDomainRequest {
  domain: string;
  slug?: string;
}

export interface UpdateDomainRequest {
  domain?: string;
  slug?: string;
  isActive?: boolean;
}

export interface DashboardStats {
  totalLinks: number;
  activeLinks: number;
  totalClicks: number;
  totalDomains: number;
}

export interface ClicksOverTime {
  date: string;
  clicks: number;
}

export interface AnalyticsOverview {
  totalClicks: number;
  uniqueIps: number;
  topCountries: { country: string; count: number }[];
  topDevices: { device: string; count: number }[];
  topBrowsers: { browser: string; count: number }[];
  topOs: { os: string; count: number }[];
  clicksOverTime: ClicksOverTime[];
  topLinks: { link: ShortLink; clicks: number }[];
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// App state types
export type PageName =
  | "overview"
  | "links"
  | "create-link"
  | "edit-link"
  | "domains"
  | "analytics"
  | "bulk"
  | "settings"
  | "not-found";

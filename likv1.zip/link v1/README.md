<div align="center">

# ShortURL Platform

**Open-source short URL management platform**

A full-featured, self-hosted URL shortener inspired by [Dub.co](https://dub.co), built with modern web technologies. Manage links, track analytics, generate QR codes, and handle multi-domain routing — all from a beautiful dashboard.

[![Next.js](https://img.shields.io/badge/Next.js-16-black?logo=nextdotjs)](https://nextjs.org/)
[![Prisma](https://img.shields.io/badge/Prisma-6-2D3748?logo=prisma)](https://www.prisma.io/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4?logo=tailwindcss)](https://tailwindcss.com/)
[![Cloudflare Pages](https://img.shields.io/badge/Cloudflare-Pages-F38020?logo=cloudflare)](https://pages.cloudflare.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

[![Deploy to Cloudflare Pages](https://deploy.workers.cloudflare.com/button)](https://deploy.workers.cloudflare.com/?url=https://github.com/your-username/shorturl-platform)

<br />

<!-- Replace with actual screenshot -->
<p>
  <img src="public/logo.svg" alt="ShortURL Platform" width="120" />
</p>

**Token-based auth** &middot; **Multi-target routing** &middot; **Click analytics** &middot; **QR codes** &middot; **Bulk operations** &middot; **UTM builder** &middot; **Password-protected links** &middot; **Multi-domain support** &middot; **301 redirects**

</div>

---

## Table of Contents

- [Features](#-features)
- [Architecture Overview](#-architecture-overview)
- [Quick Start (Local Development)](#-quick-start-local-development)
- [Database Setup](#-database-setup)
- [Deployment to Cloudflare Pages](#-deployment-to-cloudflare-pages)
- [Domain Setup](#-domain-setup--the-most-important-section)
- [DNS Configuration Reference](#-dns-configuration-reference)
- [Environment Variables Reference](#-environment-variables-reference)
- [Security Configuration](#-security-configuration)
- [How Redirects Work](#-how-redirects-work)
- [404 Handling](#-404-handling)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [License](#-license)

---

## Features

| Feature | Description |
|---|---|
| 🔐 **Token-Based Authentication** | Simple, secure token auth for dashboard access. No complex OAuth setup needed. |
| 🔗 **Link Management** | Create, edit, archive, and delete short links with a full-featured CRUD dashboard. |
| 🎯 **Multi-Target Routing** | Route visitors to different URLs based on IP, country, or use random/sequential rotation. |
| 📊 **Click Analytics** | Track clicks by device, browser, OS, country, city, and referrer with interactive charts. |
| 📱 **QR Code Generation** | Generate downloadable QR codes for any short link instantly. |
| 📦 **Bulk Operations** | Create, archive, and delete multiple links at once via CSV import/export. |
| 🏷️ **UTM Builder** | Automatically append UTM parameters (source, medium, campaign, content, term) to redirects. |
| 🔒 **Password-Protected Links** | Require a password before visitors are redirected to the destination. |
| 🌐 **Multi-Domain Support** | Serve the dashboard on one domain and handle short URL redirects on unlimited other domains. |
| ↪️ **301 Permanent Redirects** | SEO-friendly 301 redirects for all short links. |
| ⏱️ **Link Expiration** | Set expiration dates on links. Expired links show a "Link Expired" page. |
| 🏥 **Health Checks** | Monitor target URL availability with automatic health checking. |
| 🌍 **Geo-Routing** | Route visitors to different targets based on their country (via Cloudflare headers). |

---

## Architecture Overview

The key architectural concept: **TWO TYPES OF DOMAINS point to ONE Cloudflare Pages project.**

```
┌──────────────────────────────────────────────────────────────────────┐
│                     Cloudflare Pages Project                        │
│                  (single Next.js application)                       │
│                                                                     │
│  ┌─────────────────────┐    ┌───────────────────────────────────┐   │
│  │   Main Domain       │    │   Short URL Domains               │   │
│  │   (abc.com)         │    │   (abc.me, go.example.com, ...)   │   │
│  │                     │    │                                   │   │
│  │  ┌───────────────┐  │    │  ┌─────────────────────────────┐  │   │
│  │  │  Dashboard    │  │    │  │  Middleware                  │  │   │
│  │  │  SPA          │  │    │  │  (src/middleware.ts)         │  │   │
│  │  │               │  │    │  │                             │  │   │
│  │  │ - Login       │  │    │  │  /abc   → /s/abc            │  │   │
│  │  │ - Links       │  │    │  │  /xyz   → /s/xyz            │  │   │
│  │  │ - Analytics   │  │    │  │  /promo → /s/promo          │  │   │
│  │  │ - Domains     │  │    │  │                             │  │   │
│  │  │ - Settings    │  │    │  └──────────┬──────────────────┘  │   │
│  │  └───────────────┘  │    │             │                     │   │
│  └─────────────────────┘    │  ┌──────────▼──────────────────┐  │   │
│                             │  │  Redirect Handler           │  │   │
│                             │  │  (/s/[slug]/route.ts)       │  │   │
│                             │  │                             │  │   │
│                             │  │  1. Lookup domain in DB     │  │   │
│                             │  │  2. Lookup link by slug     │  │   │
│                             │  │  3. Check password/expired  │  │   │
│                             │  │  4. Determine target URL    │  │   │
│                             │  │  5. Record click             │  │   │
│                             │  │  6. Return 301 redirect     │  │   │
│                             │  └─────────────────────────────┘  │   │
│                             └───────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────────┘
```

### How Middleware Routing Works

The Next.js middleware (`src/middleware.ts`) runs in production and performs domain-based routing:

1. **Extract the `Host` header** from the incoming request
2. **Compare against `APP_DOMAIN`** environment variable
3. **Main domain match** → pass through to dashboard SPA (login, link management, analytics)
4. **Short URL domain** → rewrite to `/s/[slug]` redirect handler, which looks up the slug in the database, records the click, and returns a 301 redirect

> **In development mode**, the middleware is disabled — it always serves the dashboard SPA on `localhost:3000`. This makes local development straightforward without needing multiple domains.

```
Production Request Flow:
─────────────────────────

  abc.com/login       ──→  Host = "abc.com" = APP_DOMAIN  ──→  Dashboard SPA ✓
  abc.com/links       ──→  Host = "abc.com" = APP_DOMAIN  ──→  Dashboard SPA ✓
  abc.me/abc          ──→  Host = "abc.me" ≠ APP_DOMAIN   ──→  Rewrite to /s/abc  ──→  301 → target URL
  go.example.com/promo──→  Host = "go.example.com" ≠ ...   ──→  Rewrite to /s/promo──→  301 → target URL
  abc.me/             ──→  Host = "abc.me" ≠ APP_DOMAIN   ──→  Rewrite to /s/__root__ → "Short URL Service" page
  abc.me/unknown      ──→  Host = "abc.me" ≠ APP_DOMAIN   ──→  Rewrite to /s/unknown ─→ 404 page
```

---

## Quick Start (Local Development)

### Prerequisites

| Tool | Version | Required | Notes |
|---|---|---|---|
| [Node.js](https://nodejs.org/) | 18+ | Yes | Or use [Bun](https://bun.sh/) as a drop-in replacement |
| [Bun](https://bun.sh/) | 1.0+ | Recommended | Faster package manager and runtime |
| [Git](https://git-scm.com/) | Latest | Yes | For cloning the repository |
| A PostgreSQL or MySQL database | Any recent | Yes | For production. SQLite works for local dev. |

### Step-by-Step Setup

**1. Clone the repository**

```bash
git clone https://github.com/your-username/shorturl-platform.git
cd shorturl-platform
```

**2. Install dependencies**

```bash
bun install
# or: npm install
```

**3. Create your `.env` file**

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Database connection (SQLite for local dev, PostgreSQL/MySQL for production)
DATABASE_URL="file:./dev.db"

# Dashboard auth token (min 12 characters — CHANGE THIS IN PRODUCTION!)
DASHBOARD_TOKEN="Master123@"

# Main domain — only used in production for middleware routing
APP_DOMAIN="abc.com"

# Public URL of your app
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Environment mode
NODE_ENV="development"
```

> **Default login token:** `Master123@` — This works out of the box for local development. **Always change this before deploying.**

**4. Initialize the database**

```bash
bun run db:push
# or: npx prisma db push
```

This creates all required tables (`app_settings`, `short_domains`, `short_links`, `link_targets`, `clicks`) based on the Prisma schema.

**5. Start the development server**

```bash
bun run dev
# or: npm run dev
```

**6. Open the dashboard**

Navigate to [http://localhost:3000](http://localhost:3000) and log in with the token `Master123@`.

> **Note:** In development mode, the middleware is bypassed. All routes serve the dashboard SPA. Short URL redirect behavior can be tested by directly accessing `/s/[slug]` routes (e.g., `http://localhost:3000/s/test?host=abc.me`).

---

## Database Setup

The platform supports multiple database backends via Prisma. **SQLite is used by default** for local development. For production, we recommend PostgreSQL (via Neon) or MySQL (via TiDB).

### Neon Tech (PostgreSQL) — Recommended

[Neon](https://neon.tech/) provides serverless PostgreSQL with generous free tier, automatic scaling, and branching — ideal for Cloudflare Pages deployments.

**Step 1: Create a Neon project**

1. Sign up at [neon.tech](https://neon.tech/)
2. Create a new project (choose a region close to your users)
3. Copy the connection string (it looks like `postgresql://user:pass@ep-xxx.region.neon.tech/dbname?sslmode=require`)

**Step 2: Update Prisma provider**

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

**Step 3: Update your `.env`**

```env
DATABASE_URL="postgresql://user:pass@ep-xxx.region.neon.tech/dbname?sslmode=require"
```

**Step 4: Push the schema**

```bash
bun run db:push
```

### TiDB (MySQL) — Alternative

[TiDB Serverless](https://tidbcloud.com/) is a MySQL-compatible serverless database with a generous free tier.

**Step 1: Create a TiDB cluster**

1. Sign up at [tidbcloud.com](https://tidbcloud.com/)
2. Create a Serverless cluster
3. Get the connection string from the cluster overview

**Step 2: Update Prisma provider**

Edit `prisma/schema.prisma`:

```prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

**Step 3: Update your `.env`**

```env
DATABASE_URL="mysql://user:pass@gateway01.us-east-1.prod.aws.tidbcloud.com:4000/dbname?sslaccept=strict"
```

**Step 4: Push the schema**

```bash
bun run db:push
```

> **Tip:** You can also use Prisma Migrate for version-controlled schema changes: `bun run db:migrate dev` to create a migration, `bun run db:migrate deploy` to apply it in production.

---

## Deployment to Cloudflare Pages

### Step 1: Push to GitHub

Make sure you have a `.gitignore` in your project root:

```gitignore
# dependencies
node_modules/

# next.js
.next/
out/

# production
build/

# misc
.DS_Store
*.pem
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# prisma
dev.db
dev.db-journal
custom.db

# IDE
.vscode/
.idea/

# logs
*.log
dev.log
server.log
```

Initialize and push:

```bash
git init
git add .
git commit -m "Initial commit"
```

Create a new repository on GitHub, then:

```bash
git remote add origin https://github.com/your-username/shorturl-platform.git
git branch -M main
git push -u origin main
```

### Step 2: Create Cloudflare Pages Project

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/) → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**
2. Select your `shorturl-platform` repository
3. Configure the build settings:

| Setting | Value |
|---|---|
| **Framework preset** | Next.js (Static) |
| **Build command** | `npx @cloudflare/next-on-pages` |
| **Build output directory** | `.vercel/output/static` |

4. Add environment variables (see [Environment Variables Reference](#-environment-variables-reference)):

```env
DATABASE_URL="postgresql://user:pass@host/db?sslmode=require"
DASHBOARD_TOKEN="YourSecureToken123!"
APP_DOMAIN="abc.com"
NEXT_PUBLIC_APP_URL="https://abc.com"
NODE_ENV="production"
```

5. Click **Save and Deploy**

### Step 3: Verify Deployment

1. Once deployed, visit your `*.pages.dev` URL
2. You should see the login page
3. Log in with your `DASHBOARD_TOKEN`
4. Create a test link and verify the dashboard works
5. Proceed to [Domain Setup](#-domain-setup--the-most-important-section) to connect your custom domains

> **Important:** The `*.pages.dev` URL serves as both the dashboard and short URL handler. Until you set `APP_DOMAIN`, ALL requests will be treated as main domain requests (serving the dashboard). Set `APP_DOMAIN` to unlock short URL domain routing.

---

## Domain Setup — The Most Important Section

This is the core concept that makes the platform work. **Both your main dashboard domain and your short URL domains point to the SAME Cloudflare Pages project.** The middleware determines which behavior to serve based on the `Host` header.

### Main Domain (Dashboard) — abc.com

This is where your dashboard lives. Users visit this domain to log in, manage links, view analytics, and configure domains.

**Step 1: Add your domain to Cloudflare**

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Go to **Websites** → **Add a site**
3. Enter `abc.com` and select a plan (Free works)
4. Cloudflare will give you two nameservers (e.g., `elsa.ns.cloudflare.com`, `ian.ns.cloudflare.com`)
5. Update your domain's nameservers at your registrar to point to Cloudflare

**Step 2: Create a CNAME DNS record**

In Cloudflare DNS settings for `abc.com`:

| Type | Name | Target | Proxy Status |
|---|---|---|---|
| CNAME | `@` | `your-project.pages.dev` | Proxied (orange cloud) |

> **Important:** The record MUST be **Proxied** (orange cloud), not DNS only. This ensures Cloudflare handles the SSL certificate and forwards requests to Pages.

**Step 3: Add custom domain in Cloudflare Pages**

1. Go to **Workers & Pages** → your project → **Custom domains**
2. Click **Add** → enter `abc.com`
3. Cloudflare will automatically provision the SSL certificate

**Step 4: Set the `APP_DOMAIN` environment variable**

In your Cloudflare Pages project settings → **Environment variables**:

```env
APP_DOMAIN="abc.com"
```

This tells the middleware that `abc.com` is the dashboard domain. All other domains pointing to this project will be treated as short URL domains.

**Step 5: Redeploy and verify**

1. Redeploy the project (or wait for automatic deployment)
2. Visit `https://abc.com` — you should see the login page
3. Log in with your `DASHBOARD_TOKEN`

### Short URL Domain — abc.me

This is where your short links live. When someone visits `abc.me/promo`, the middleware rewrites to the redirect handler, which looks up the slug and returns a 301 redirect.

**Step 1: Add your domain to Cloudflare**

Same process as the main domain — add `abc.me` to Cloudflare and update nameservers.

**Step 2: Create a CNAME DNS record**

In Cloudflare DNS settings for `abc.me`:

| Type | Name | Target | Proxy Status |
|---|---|---|---|
| CNAME | `@` | `your-project.pages.dev` | Proxied (orange cloud) |

**Step 3: Add custom domain in Cloudflare Pages (SAME project)**

1. Go to **Workers & Pages** → your project → **Custom domains**
2. Click **Add** → enter `abc.me`
3. This adds `abc.me` to the **same** Pages project that serves `abc.com`

**Step 4: Register the domain in the dashboard**

1. Log in to your dashboard at `https://abc.com`
2. Go to **Domains** → **Add Domain**
3. Enter `abc.me` and save
4. The domain will appear in your domain list

**Step 5: Create a test link and verify**

1. Go to **Links** → **Create Link**
2. Select domain `abc.me`, enter slug `test`, target URL `https://example.com`
3. Save the link
4. Visit `https://abc.me/test` in your browser — you should be redirected to `https://example.com`

### Multiple Short URL Domains

You can add unlimited short URL domains — **no code changes needed.** Just repeat the process for each domain:

```
┌─────────────────────────────────────────────────────┐
│           Cloudflare Pages Project                  │
│         (your-project.pages.dev)                    │
│                                                     │
│  Custom Domains:                                    │
│  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │
│  │  abc.com    │  │  abc.me     │  │ go.co      │ │
│  │  (Dashboard)│  │  (Short URL)│  │ (Short URL)│ │
│  │             │  │             │  │            │ │
│  │  /login     │  │  /promo →   │  │ /docs →    │ │
│  │  /links     │  │  example.com│  │ wiki.org   │ │
│  │  /analytics │  │             │  │            │ │
│  └─────────────┘  └─────────────┘  └────────────┘ │
│                                                     │
│  Add more domains anytime:                          │
│  ┌────────────┐ ┌────────────┐ ┌────────────────┐  │
│  │ link.co    │ │ s.example  │ │ go.mybrand.com │  │
│  │ (Short URL)│ │ (Short URL)│ │  (Short URL)  │  │
│  └────────────┘ └────────────┘ └────────────────┘  │
└─────────────────────────────────────────────────────┘
```

For each new short URL domain:
1. Add the domain to Cloudflare
2. Create a CNAME record pointing to your Pages project
3. Add it as a custom domain in Pages
4. Register it in the dashboard (Domains → Add Domain)

---

## DNS Configuration Reference

### DNS Records Summary

| Domain Type | Host | Type | Target | Proxy | SSL |
|---|---|---|---|---|---|
| Main domain | `@` | CNAME | `your-project.pages.dev` | Proxied ☁️ | Auto |
| Main domain (www) | `www` | CNAME | `your-project.pages.dev` | Proxied ☁️ | Auto |
| Short URL domain | `@` | CNAME | `your-project.pages.dev` | Proxied ☁️ | Auto |

### Important Notes

- **CNAME at root (`@`):** Cloudflare supports CNAME flattening, so you CAN use a CNAME at the root apex. There's no need for A records.
- **Proxied (orange cloud) is required:** This enables Cloudflare to handle SSL/TLS termination and forward requests to Pages. DNS-only (grey cloud) will NOT work because Pages expects traffic through Cloudflare's proxy.
- **SSL is automatic:** When you add a custom domain in Pages and it's proxied through Cloudflare, a free SSL certificate is automatically provisioned. No manual SSL configuration needed.
- **Propagation:** DNS changes typically take 5 minutes to 24 hours to propagate globally. Cloudflare proxied domains are usually active within minutes.
- **Verification:** After adding a domain, verify it resolves correctly by running `dig abc.me CNAME` — it should return `your-project.pages.dev`.

### Troubleshooting DNS

| Issue | Cause | Solution |
|---|---|---|
| Domain shows "Pending" in Pages | DNS not yet propagated | Wait 5-30 minutes, check with `dig` |
| SSL error in browser | Domain not proxied | Ensure orange cloud is ON in Cloudflare DNS |
| 522 error | Pages project not receiving traffic | Check custom domain is added in Pages project settings |
| Redirect not working | `APP_DOMAIN` not set | Set `APP_DOMAIN` env var to your main domain |

---

## Environment Variables Reference

| Variable | Required | Default | Description | Example |
|---|---|---|---|---|
| `DATABASE_URL` | Yes | `file:./dev.db` | Database connection string (format depends on provider) | `postgresql://user:pass@host/db?sslmode=require` |
| `DASHBOARD_TOKEN` | Yes | `Master123@` | Authentication token for dashboard login (minimum 12 characters) | `MyS3cur3T0k3n!` |
| `APP_DOMAIN` | Prod only | — | Main domain hostname. Tells the middleware which domain serves the dashboard. All other domains are treated as short URL domains. | `abc.com` |
| `NEXT_PUBLIC_APP_URL` | Yes | `http://localhost:3000` | Full public URL of the app. Used for constructing absolute URLs in the UI. | `https://abc.com` |
| `NODE_ENV` | No | `development` | Environment mode. When `production`, the middleware is active and performs domain-based routing. | `production` |

### Development vs Production

| Variable | Development | Production |
|---|---|---|
| `DATABASE_URL` | `file:./dev.db` (SQLite) | `postgresql://...` or `mysql://...` |
| `DASHBOARD_TOKEN` | `Master123@` | Use a strong, unique token |
| `APP_DOMAIN` | Not needed (middleware disabled) | Your main domain, e.g., `abc.com` |
| `NEXT_PUBLIC_APP_URL` | `http://localhost:3000` | `https://abc.com` |
| `NODE_ENV` | `development` | `production` |

### Security Warnings

> ⚠️ **`DASHBOARD_TOKEN`**: This is the ONLY authentication mechanism for your dashboard. Use a strong token (minimum 12 characters, mix of uppercase, lowercase, numbers, and symbols). **Never commit this to version control.** Always set it via environment variables in your hosting platform.

> ⚠️ **`DATABASE_URL`**: Contains your database credentials. **Never expose this in client-side code.** The `NEXT_PUBLIC_` prefix is intentionally NOT used for this variable. Prisma uses it server-side only.

---

## Security Configuration

### 1. IP Whitelist for Dashboard (Cloudflare WAF)

Restrict dashboard access to specific IP addresses using Cloudflare WAF Custom Rules:

1. Go to **Cloudflare Dashboard** → your main domain (`abc.com`) → **Security** → **WAF** → **Custom Rules**
2. Create a new rule:

```
Rule name: Dashboard IP Whitelist
Expression: (http.request.uri.path contains "/api") and (not ip.src in {1.2.3.4 5.6.7.8})
Action: Block
```

Replace `1.2.3.4 5.6.7.8` with your actual IP addresses. This blocks all API requests from non-whitelisted IPs, effectively protecting the dashboard.

> **Tip:** To find your current IP, visit [ifconfig.me](https://ifconfig.me/) or [whatismyip.com](https://whatismyip.com/).

### 2. Rate Limiting for Short URL Domains

Protect against abuse on your short URL domains:

1. Go to **Cloudflare Dashboard** → your short URL domain (`abc.me`) → **Security** → **WAF** → **Rate limiting rules**
2. Create a rate limit rule:

```
Rule name: Short URL Rate Limit
Expression: http.request.uri.path ne "/"
Rate: 100 requests per 10 seconds
Action: Block for 60 seconds
```

### 3. HTTPS / SSL Settings

1. Go to **SSL/TLS** → **Overview** → set mode to **Full (Strict)**
2. Go to **SSL/TLS** → **Edge Certificates** → enable:
   - **Always Use HTTPS** — redirects all HTTP traffic to HTTPS
   - **Automatic HTTPS Rewrites** — fixes mixed content
   - **Minimum TLS Version** — set to `1.2`

### 4. Bot Protection

1. Go to **Security** → **Bots** → enable **Bot Fight Mode** for short URL domains
2. Optionally enable **Super Bot Fight Mode** (requires paid plan) for advanced bot detection
3. For the dashboard domain, consider adding a **Managed Challenge** to the login endpoint:

```
Rule name: Login Bot Protection
Expression: http.request.uri.path eq "/api/auth/login"
Action: Interactive Challenge (JS Challenge)
```

---

## How Redirects Work

### Request Flow

```
Visitor clicks short link
        │
        ▼
┌───────────────────────┐
│  DNS Resolution       │
│  abc.me → Cloudflare  │
│  → Pages project      │
└───────────┬───────────┘
            │
            ▼
┌───────────────────────┐
│  Middleware           │  ← src/middleware.ts
│  (production only)    │
│                       │
│  Host = "abc.me"      │
│  ≠ APP_DOMAIN         │
│  → Rewrite to /s/[slug]│
└───────────┬───────────┘
            │
            ▼
┌───────────────────────┐
│  Redirect Handler     │  ← src/app/s/[slug]/route.ts
│                       │
│  1. Find domain in DB │
│  2. Find link by slug │
│  3. Check active?     │
│  4. Check expired?    │
│  5. Check password?   │
│  6. Pick target URL   │
│  7. Append UTM params │
│  8. Record click      │
│  9. Return 301        │
└───────────┬───────────┘
            │
            ▼
┌───────────────────────┐
│  301 Redirect         │
│  → https://target.com │
│  + utm_source=...     │
│  + utm_medium=...     │
│  + utm_campaign=...   │
└───────────────────────┘
```

### Multi-Target Routing

For links with multiple targets, the redirect handler uses a priority-based selection algorithm:

| Priority | Match Type | Description | Example |
|---|---|---|---|
| 1 | IP-based | Exact match on visitor's IP address | Target for `192.168.1.100` |
| 2 | Country-based | Match on visitor's country (from CF headers) | Target for `US` visitors |
| 3 | Catch-all (`ALL`) | Default target for all visitors | Fallback URL |

Within each priority level, the selection mode determines which target is chosen:

- **Sequential** — Targets are tried in order. The first available target (not exceeding click limit) is used.
- **Random** — One target is randomly selected from all available targets.

### Click Recording

Every successful redirect records a click with the following data:

| Field | Source |
|---|---|
| `ip` | `CF-Connecting-IP` header (Cloudflare) or `X-Forwarded-For` |
| `country` | `CF-IPCountry` header (Cloudflare) |
| `city` | `CF-IPCity` header (Cloudflare) |
| `device` | Parsed from `User-Agent` (Mobile / Tablet / Desktop) |
| `browser` | Parsed from `User-Agent` (Chrome / Firefox / Safari / Edge / Opera) |
| `os` | Parsed from `User-Agent` (Windows / macOS / Linux / Android / iOS) |
| `referrer` | `Referer` header (or "direct" if missing) |

> Click recording is **asynchronous** (fire-and-forget) to avoid adding latency to the redirect response.

---

## 404 Handling

Different domains handle "not found" scenarios differently:

| Scenario | Domain Type | Response | Behavior |
|---|---|---|---|
| Valid slug found | Short URL | **301 Redirect** | Redirects to target URL |
| Invalid slug | Short URL | **404 HTML** | Styled "Link Not Found" page with dark theme |
| Root path (`/`) | Short URL | **200 HTML** | "Short URL Service" info page showing the domain |
| Password required | Short URL | **403 HTML** | Password entry form |
| Link expired | Short URL | **410 HTML** | "Link Expired" notice |
| Any unmatched route | Main Domain | **Next.js 404** | Dashboard SPA `NotFoundPage` component |
| Domain not registered | Short URL | **404 HTML** | "Link Not Found" (domain not in database) |

### Short URL Domain 404 Page

When a slug is not found on a short URL domain, a self-contained HTML page is returned (not the Next.js SPA). This ensures fast responses and doesn't load the entire dashboard bundle:

```html
<!-- Example: abc.me/nonexistent returns -->
<div class="code">404</div>
<h1>Link Not Found</h1>
<p>The short URL you're looking for doesn't exist or has been removed.</p>
<div class="slug">/nonexistent</div>
<a href="/">Go Home</a>
<div class="footer">Powered by ShortURL Platform</div>
```

### Short URL Domain Root Page

Visiting the root of a short URL domain (e.g., `abc.me/`) shows an informational page:

```html
<!-- Example: abc.me/ returns -->
<div class="icon">🔗</div>
<h1>Short URL Service</h1>
<p>This domain is configured as a short URL service. Access a specific short link
   to be redirected to its destination.</p>
<div class="domain">abc.me</div>
```

---

## Tech Stack

| Technology | Version | Purpose |
|---|---|---|
| [Next.js](https://nextjs.org/) | 16 | React framework with App Router, API routes, middleware, and edge runtime |
| [React](https://react.dev/) | 19 | UI component library |
| [TypeScript](https://www.typescriptlang.org/) | 5 | Type-safe JavaScript |
| [Tailwind CSS](https://tailwindcss.com/) | 4 | Utility-first CSS framework |
| [shadcn/ui](https://ui.shadcn.com/) | Latest | Pre-built, accessible UI components (Radix UI primitives) |
| [Prisma](https://www.prisma.io/) | 6 | Type-safe ORM with schema-first approach |
| [Cloudflare Pages](https://pages.cloudflare.com/) | — | Hosting platform with global CDN, edge functions, and SSL |
| [Recharts](https://recharts.org/) | 2 | Charting library for analytics dashboards |
| [Zustand](https://zustand-demo.pmnd.rs/) | 5 | Lightweight state management |
| [TanStack Query](https://tanstack.com/query) | 5 | Async state management for API calls |
| [TanStack Table](https://tanstack.com/table) | 8 | Headless table component for link management |
| [React Hook Form](https://react-hook-form.com/) | 7 | Performant form state management |
| [Zod](https://zod.dev/) | 4 | Schema validation for forms and API inputs |
| [Lucide React](https://lucide.dev/) | Latest | Icon library |
| [Framer Motion](https://www.framer.com/motion/) | 12 | Animation library |
| [date-fns](https://date-fns.org/) | 4 | Date utility functions |
| [QRCode](https://github.com/soldair/node-qrcode) | 1 | QR code generation |
| [Sonner](https://sonner.emilkowal.dev/) | 2 | Toast notification system |

---

## Project Structure

```
shorturl-platform/
├── prisma/
│   └── schema.prisma              # Database schema (models, relations)
├── public/
│   ├── logo.svg                   # App logo
│   └── robots.txt                 # Search engine directives
├── src/
│   ├── app/
│   │   ├── layout.tsx             # Root layout (providers, fonts)
│   │   ├── page.tsx               # Root page (redirect to login)
│   │   ├── globals.css            # Global styles (Tailwind)
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   │   ├── login/route.ts         # POST /api/auth/login
│   │   │   │   └── check/route.ts         # GET  /api/auth/check
│   │   │   ├── links/
│   │   │   │   ├── route.ts               # GET/POST /api/links
│   │   │   │   ├── [id]/route.ts          # GET/PUT/DELETE /api/links/:id
│   │   │   │   ├── [id]/clicks/route.ts   # GET /api/links/:id/clicks
│   │   │   │   ├── bulk/route.ts          # POST /api/links/bulk
│   │   │   │   └── health-check/route.ts  # POST /api/links/health-check
│   │   │   ├── domains/
│   │   │   │   ├── route.ts               # GET/POST /api/domains
│   │   │   │   └── [id]/
│   │   │   │       ├── route.ts           # PUT/DELETE /api/domains/:id
│   │   │   │       └── verify/route.ts    # POST /api/domains/:id/verify
│   │   │   ├── analytics/
│   │   │   │   └── overview/route.ts      # GET /api/analytics/overview
│   │   │   ├── settings/route.ts          # GET/PUT /api/settings
│   │   │   ├── import/route.ts            # POST /api/import (CSV)
│   │   │   ├── export/route.ts            # GET /api/export (CSV)
│   │   │   ├── redirect/route.ts          # GET /api/redirect (dev helper)
│   │   │   └── danger/route.ts            # POST /api/danger (dangerous ops)
│   │   └── s/
│   │       └── [slug]/route.ts            # GET /s/:slug (redirect handler)
│   ├── components/
│   │   ├── ui/                   # shadcn/ui components (30+)
│   │   ├── dashboard/
│   │   │   ├── DashboardLayout.tsx        # Main dashboard layout
│   │   │   ├── SidebarNav.tsx             # Sidebar navigation
│   │   │   └── Header.tsx                 # Top header bar
│   │   ├── links/
│   │   │   ├── LinkTable.tsx              # Links data table
│   │   │   ├── LinkFormBasic.tsx          # Basic link form
│   │   │   ├── LinkFormMulti.tsx          # Multi-target link form
│   │   │   ├── LinkTargetRow.tsx          # Target row (drag & drop)
│   │   │   ├── LinkAnalyticsDialog.tsx    # Per-link analytics modal
│   │   │   └── QRCodeDialog.tsx           # QR code generator modal
│   │   ├── domains/
│   │   │   ├── DomainCard.tsx             # Domain display card
│   │   │   ├── AddDomainDialog.tsx        # Add domain modal
│   │   │   ├── EditDomainDialog.tsx       # Edit domain modal
│   │   │   └── DNSSetupDialog.tsx         # DNS setup instructions
│   │   ├── analytics/
│   │   │   ├── StatsCards.tsx             # Overview stat cards
│   │   │   ├── ClicksChart.tsx            # Click timeline chart
│   │   │   ├── CountryChart.tsx           # Country distribution
│   │   │   └── DeviceChart.tsx            # Device/browser breakdown
│   │   └── pages/
│   │       ├── LoginPage.tsx              # Login page
│   │       ├── OverviewPage.tsx           # Dashboard overview
│   │       ├── LinksPage.tsx              # Links management
│   │       ├── CreateLinkPage.tsx         # Create new link
│   │       ├── EditLinkPage.tsx           # Edit existing link
│   │       ├── AnalyticsPage.tsx          # Global analytics
│   │       ├── DomainsPage.tsx            # Domain management
│   │       ├── BulkOperationsPage.tsx     # Bulk import/export
│   │       ├── SettingsPage.tsx           # App settings
│   │       └── NotFoundPage.tsx           # 404 page (dashboard)
│   ├── hooks/
│   │   ├── use-mobile.ts                  # Mobile viewport detection
│   │   └── use-toast.ts                   # Toast notification hook
│   ├── lib/
│   │   ├── api.ts                         # API client (fetch wrapper)
│   │   ├── auth.ts                        # Token authentication helpers
│   │   ├── db.ts                          # Prisma client singleton
│   │   ├── store.ts                       # Zustand state store
│   │   ├── types.ts                       # TypeScript type definitions
│   │   └── utils.ts                       # Utility functions (cn, etc.)
│   └── middleware.ts                      # Domain-based routing middleware
├── .env.example                          # Environment variable template
├── components.json                        # shadcn/ui configuration
├── next.config.ts                         # Next.js configuration
├── tailwind.config.ts                     # Tailwind CSS configuration
├── tsconfig.json                          # TypeScript configuration
├── postcss.config.mjs                     # PostCSS configuration
├── eslint.config.mjs                      # ESLint configuration
├── package.json                           # Dependencies and scripts
└── README.md                              # This file
```

---

## License

This project is licensed under the **MIT License**.

```
MIT License

Copyright (c) 2025 ShortURL Platform

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

<div align="center">

**Built with ❤️ using Next.js, Prisma, Tailwind CSS, and Cloudflare Pages**

</div>

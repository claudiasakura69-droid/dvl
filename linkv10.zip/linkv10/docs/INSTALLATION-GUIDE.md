# Panduan Instalasi & Deployment Lengkap

> Panduan ini mencakup instalasi lokal dan deployment ke Cloudflare Pages untuk **Windows** dan **Linux/macOS**.

---

## Daftar Isi

1. [Prasyarat](#1-prasyarat)
2. [Instalasi Lokal — Windows](#2-instalasi-lokal--windows)
3. [Instalasi Lokal — Linux/macOS](#3-instalasi-lokal--linuxmacos)
4. [Konfigurasi Database (Neon)](#4-konfigurasi-database-neon)
5. [Konfigurasi Cloudflare](#5-konfigurasi-cloudflare)
6. [Deployment ke Cloudflare Pages](#6-deployment-ke-cloudflare-pages)
7. [Custom Domain Setup](#7-custom-domain-setup)
8. [Troubleshooting](#8-troubleshooting)

---

## 1. Prasyarat

| Tool                  | Versi Minimum | Windows Download                                | Linux/macOS                                  |
|-----------------------|---------------|-------------------------------------------------|----------------------------------------------|
| **Node.js**           | 18.x+         | https://nodejs.org (MSI installer, centang "Add to PATH") | `sudo apt install nodejs` atau https://nodejs.org |
| **npm**               | 9.x+          | Termasuk saat install Node.js                   | Termasuk saat install Node.js                 |
| **pnpm** (recommended) | 8.x+       | `npm i -g pnpm`                                 | `npm i -g pnpm`                               |
| **Git**               | Terbaru       | https://git-scm.com/download/win                | `sudo apt install git`                        |
| **Text Editor**       | -             | VS Code: https://code.visualstudio.com          | VS Code / nano / vim                          |
| **Akun Neon**         | -             | https://console.neon.tech (gratis)              | https://console.neon.tech (gratis)            |
| **Akun Cloudflare**   | -             | https://dash.cloudflare.com (gratis)            | https://dash.cloudflare.com (gratis)          |

### Verifikasi Instalasi

**Windows (PowerShell):**
```powershell
node --version    # Harusnya v18.x atau lebih baru
npm --version     # Harusnya 9.x atau lebih baru
pnpm --version    # (jika install pnpm)
git --version     # Harusnya 2.x atau lebih baru
```

**Linux/macOS (Terminal):**
```bash
node --version
npm --version
pnpm --version  # (jika install pnpm)
git --version
```

---

## 2. Instalasi Lokal — Windows

### Step 1: Clone Repository

```powershell
# Buka PowerShell di folder tujuan
cd C:\Users\YourName\Projects

# Clone
git clone https://github.com/username/shorturl-platform.git

# Masuk ke folder project
cd shorturl-platform
```

### Step 2: Install Dependencies

**pnpm (recommended — lebih cepat, handle peer deps lebih baik):**
```powershell
pnpm install
```

**npm (alternatif):**
```powershell
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true`.

> **Jika error "Cannot find native binding":**
> ```powershell
> rmdir /s /q node_modules
> del package-lock.json
> npm install
> ```
> Atau dengan pnpm:
> ```powershell
> rmdir /s /q node_modules
> del pnpm-lock.yaml
> pnpm install
> ```

Proses ini akan mengunduh semua dependencies (sekitar 200+ paket). Tunggu hingga selesai.

### Step 3: Setup Environment Variables

```powershell
copy .env.example .env
```

Buka file `.env` dengan editor:

```powershell
code .env
# atau
notepad .env
```

Edit isi `.env`:

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================

# DATABASE — Wajib! Lihat Section 4 untuk cara mendapatkannya
DATABASE_URL="postgresql://neondb_owner:yourpassword@ep-abc123.us-east-2.aws.neon.tech/neondb?sslmode=require"

# AUTH — Token login dashboard (WAJIB min. 12 karakter!)
DASHBOARD_TOKEN="MySecretToken123"

# APP DOMAIN — Domain utama untuk dashboard
# Awalnya bisa diisi domain *.pages.dev, nanti diubah ke custom domain
APP_DOMAIN="your-project.pages.dev"

# CLOUDFLARE — Opsional, untuk auto-verify custom domain
CLOUDFLARE_ACCOUNT_ID=""
CLOUDFLARE_API_TOKEN=""
CLOUDFLARE_PAGES_PROJECT=""
```

### Step 4: Prisma — Setup Database

```powershell
# Push schema ke database Neon (membuat tabel-tabel)
npx prisma db push

# Generate Prisma Client (dibutuhkan oleh aplikasi)
npx prisma generate
```

**Output yang diharapkan:**
```
Your database is now in sync with your Prisma schema.

✔ Generated Prisma Client
```

**Optional — Lihat database via browser:**
```powershell
npx prisma studio
# Buka http://localhost:5555 di browser
```

### Step 5: Jalankan Development Server

```powershell
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser. Halaman login dashboard akan muncul.

Masukkan token yang kamu set di `DASHBOARD_TOKEN` (`.env`) untuk masuk ke dashboard.

> **PENTING:** Tidak ada demo token. Pastikan `DASHBOARD_TOKEN` sudah di-set di `.env`.

---

## 3. Instalasi Lokal — Linux/macOS

### Step 1: Clone Repository

```bash
cd ~/projects
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

### Step 2: Install Dependencies

**pnpm (recommended):**
```bash
pnpm install
```

**npm (alternatif):**
```bash
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true`.

> **Jika error "Cannot find native binding":**
> ```bash
> rm -rf node_modules package-lock.json
> npm install
> ```
> Atau:
> ```bash
> rm -rf node_modules pnpm-lock.yaml
> pnpm install
> ```

### Step 3: Setup Environment Variables

```bash
cp .env.example .env
nano .env  # atau vim .env, code .env
```

Isi `.env` sama seperti panduan Windows (lihat Step 3 di atas).

### Step 4: Prisma — Setup Database

```bash
npx prisma db push
npx prisma generate
```

**Optional — Prisma Studio:**
```bash
npx prisma studio
# Buka http://localhost:5555
```

### Step 5: Jalankan Development Server

```bash
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser.

---

## 4. Konfigurasi Database (Neon)

### Membuat Project Neon

1. Buka https://console.neon.tech
2. Sign up / Sign in (bisa pakai GitHub)
3. Klik **Create Project**
4. Isi:
   - **Project name**: `shorturl-db` (bebas)
   - **Region**: Pilih yang terdekat dengan lokasi server (misalnya `US East`)
   - **PostgreSQL version**: Default
5. Klik **Create Project**

### Mendapat Connection String

1. Setelah project dibuat, kamu akan melihat halaman dashboard
2. Klik tab **Connection Details**
3. Copy connection string, format-nya:
   ```
   postgresql://neondb_owner:randompassword@ep-purple-cloud-123456.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
4. Paste ke `.env` sebagai `DATABASE_URL`

### Verifikasi Koneksi

```powershell
# Windows
npx prisma db push
# Jika berhasil = koneksi OK
```

### Menambahkan `?channel_binding=require`

Jika Neon menyarankan parameter tambahan, kamu bisa menambahkannya:
```
DATABASE_URL="postgresql://...neondb?sslmode=require&channel_binding=require"
```

> **Catatan:** Kedua format (`?sslmode=require` atau `?sslmode=require&channel_binding=require`) sudah didukung.

---

## 5. Konfigurasi Cloudflare

### Mendapat Account ID

1. Buka https://dash.cloudflare.com
2. Di sidebar kanan atau URL, kamu akan melihat **Account ID**
3. Copy dan simpan

### Membuat API Token

1. Buka https://dash.cloudflare.com/profile/api-tokens
2. Klik **Create Token**
3. Pilih **Custom Token** → **Get started**
4. Konfigurasi:
   - **Token name**: `ShortURL Platform`
   - **Permissions**:
     - `Zone` → `Zone` → `Read`
     - `Zone` → `DNS` → `Edit`
     - `Account` → `Cloudflare Pages` → `Edit`
   - **Account Resources**: `Include` → `Your Account`
   - **Zone Resources**: `Include` → `All Zones` (atau specific zone)
5. Klik **Continue to Summary** → **Create Token**
6. **Copy token sekarang!** Token ini tidak bisa dilihat lagi.

### Menambah Domain ke Cloudflare

1. Buka https://dash.cloudflare.com
2. Klik **Add a Site**
3. Masukkan domain kamu (contoh: `yoii.me`)
4. Pilih plan (**Free** sudah cukup)
5. Cloudflare akan menampilkan 2 **nameserver** records
6. Buka panel domain registrar kamu (Namecheap, GoDaddy, dll)
7. Ubah nameserver domain ke nameserver Cloudflare
8. Tunggu propagasi DNS (bisa 5 menit - 48 jam, biasanya cepat)

### Membuat CF Pages Project

1. Buka https://dash.cloudflare.com → **Workers & Pages**
2. Klik **Create**
3. Pilih **Pages** → **Connect to Git**
4. Pilih repository GitHub/GitLab kamu
5. Konfigurasi build (detail di Section 6)

---

## 6. Deployment ke Cloudflare Pages

### Persiapan

Pastikan:
- [ ] Repository sudah di-push ke GitHub/GitLab
- [ ] `.env.example` ada di repo (BUKAN `.env`!)
- [ ] `.npmrc` ada di repo dan berisi `force=true`
- [ ] `wrangler.toml` ada di repo
- [ ] Semua file sudah di-commit

### Build Settings di CF Pages

| Setting               | Value                                                             |
|-----------------------|-------------------------------------------------------------------|
| **Framework preset**  | `None`                                                            |
| **Build command**     | `npx prisma generate && npx opennextjs-cloudflare build`          |
| **Build output dir**  | `.open-next`                                                       |
| **Root directory**    | `/` (default)                                                     |
| **Node.js version**   | `18` atau `20`                                                    |

### ⚠️ PENTING — JANGAN gunakan build command ini:

```bash
# SALAH — akan menyebabkan infinite loop!
npm install && npx opennextjs-cloudflare build

# SALAH — opennextjs-cloudflare build memanggil npm run build secara internal
npm run build:cf
```

Build command yang benar:
```bash
# BENAR — langsung jalankan opennextjs-cloudflare build
npx prisma generate && npx opennextjs-cloudflare build
```

> `opennextjs-cloudflare build` secara internal akan menjalankan `next build`, jadi tidak perlu dipanggil terpisah.

### 🔧 Environment Variables di CF Pages — PANDUAN DETAIL

Buka project CF Pages → **Settings** → **Environment Variables**

#### Bagaimana CF Pages Environment Variables Bekerja:

Cloudflare Pages memiliki **DUA scope** untuk environment variables:

| Scope         | Kapan Digunakan                                      |
|---------------|------------------------------------------------------|
| **Production**| Saat build Production (dari branch utama) DAN saat serve production traffic |
| **Preview**   | Saat build Preview (dari pull request/branch lain) DAN saat serve preview traffic |

**Tidak ada scope "Build" terpisah!** Variabel yang kamu set di Production akan otomatis tersedia saat build Production berjalan. Sama halnya dengan Preview.

#### Langkah-langkah Menambahkan Environment Variables:

1. Buka **Workers & Pages** → project kamu → **Settings** → **Environment Variables**
2. Kamu akan melihat dua tab di atas: **Production** dan **Preview**

3. **Tambahkan di tab Production:**
   - Klik tab **Production**
   - Klik tombol **Add variable**
   - Masukkan **Variable name** (contoh: `DATABASE_URL`)
   - Masukkan **Value** (contoh: connection string Neon kamu)
   - Klik **Save** (atau Encrypt lalu Save untuk variabel sensitif)
   - Ulangi untuk setiap variabel yang dibutuhkan

4. **Tambahkan di tab Preview:**
   - Klik tab **Preview**
   - Klik tombol **Add variable**
   - Masukkan **Variable name** dan **Value** yang SAMA
   - Klik **Save**
   - Ulangi untuk setiap variabel yang dibutuhkan

5. **SETELAH semua variabel ditambahkan:**
   - **WAJIB redeploy!** CF Pages TIDAK auto-redeploy saat env vars berubah.
   - Cara redeploy:
     - Push commit baru: `git commit --allow-empty -m "Redeploy" && git push`
     - ATAU klik **"Retry deployment"** di CF Pages dashboard

#### Variabel yang Perlu Ditambahkan:

**Wajib (harus ada):**

| Variable          | Value                                                |
|-------------------|------------------------------------------------------|
| `DATABASE_URL`    | `postgresql://neondb_owner:xxx@ep-xxx...neondb?sslmode=require` |
| `DASHBOARD_TOKEN` | Token login dashboard (min 12 karakter)              |
| `APP_DOMAIN`      | Domain utama (lihat catatan di bawah)                |

**Opsional (untuk auto-verify domain):**

| Variable                   | Value                        |
|----------------------------|------------------------------|
| `CLOUDFLARE_ACCOUNT_ID`    | Account ID dari Cloudflare   |
| `CLOUDFLARE_API_TOKEN`     | API Token yang sudah dibuat  |
| `CLOUDFLARE_PAGES_PROJECT` | Nama project CF Pages        |

> **Tips:** Untuk variabel sensitif seperti `DASHBOARD_TOKEN` dan `CLOUDFLARE_API_TOKEN`, gunakan tombol **Encrypt** saat menambahkan.

#### Tentang APP_DOMAIN:

- **Jika menggunakan *.pages.dev:** Set `APP_DOMAIN` ke URL pages.dev kamu (contoh: `my-shorturl.pages.dev`)
- **Jika sudah punya custom domain:** Set `APP_DOMAIN` ke custom domain (contoh: `yoii.me`)
- **Middleware otomatis mengizinkan akses dari semua domain *.pages.dev** — jadi kamu tidak perlu khawatir saat pertama deploy

### Proses Deploy

1. Push perubahan ke repository:
   ```bash
   git add .
   git commit -m "Deploy to Cloudflare Pages"
   git push origin main
   ```

2. Cloudflare Pages akan otomatis:
   - Pull code dari repository
   - Install dependencies
   - Jalankan build command
   - Deploy ke CDN global

3. Cek status build di:
   - CF Pages Dashboard → **Deployments** tab
   - Kamu akan melihat log build secara real-time

4. Jika build berhasil, akses site di:
   - `your-project.pages.dev`
   - Custom domain (jika sudah dikonfigurasi)

### Custom Domain di CF Pages

1. Buka project CF Pages → **Custom domains**
2. Klik **Set up a custom domain**
3. Masukkan domain (contoh: `yoii.me`)
4. Cloudflare akan otomatis mengkonfigurasi DNS
5. SSL certificate akan otomatis diprovisioning (biasanya 15-30 menit)
6. Setelah domain aktif, update `APP_DOMAIN` di env vars ke domain baru

---

## 7. Custom Domain Setup

Platform ini mendukung **multi-domain** — satu dashboard bisa melayani banyak domain untuk short URL.

### Domain Utama (APP_DOMAIN)

- Domain yang digunakan untuk mengakses dashboard
- Diatur di `APP_DOMAIN` environment variable
- Contoh: `yoii.me` → dashboard bisa diakses di `https://yoii.me`

### Custom Domain untuk Short URL

Kamu bisa menambahkan domain lain (misalnya `link.co`, `go.domain.com`) yang akan digunakan khusus untuk short URL redirect.

**Cara menambahkan:**

1. **Tambahkan domain ke Cloudflare** (jika belum):
   - CF Dashboard → Add a Site → masukkan domain
   - Ubah nameserver di registrar

2. **Di dashboard aplikasi**, buka menu **Domains**
3. Klik **Add Domain**
4. Masukkan domain (contoh: `link.co`)
5. Klik **Verify** — sistem akan otomatis memverifikasi via Cloudflare API

**Cara kerja routing:**
- Request ke `yoii.me` → Dashboard (halaman login/manajemen link)
- Request ke `link.co/abc` → Redirect ke target URL
- Request ke `link.co/` (tanpa path) → 404 styled page

---

## 8. Troubleshooting

### Deploy berhasil tapi halaman kosong/blank

**Ini adalah masalah yang paling sering terjadi. Ikuti langkah-langkah berikut:**

#### Step 1: Cek Environment Variables

1. Buka CF Pages → Settings → Environment Variables
2. Pastikan `DATABASE_URL`, `DASHBOARD_TOKEN`, dan `APP_DOMAIN` ada di **BOTH** tab Production dan Preview
3. Pastikan value-nya benar (bukan kosong)
4. Jika baru ditambahkan, **WAJIB redeploy** (Retry deployment atau push commit baru)

#### Step 2: Cek APP_DOMAIN

- Jika kamu akses via `*.pages.dev`, pastikan `APP_DOMAIN` di CF Pages berisi URL pages.dev kamu (contoh: `my-shorturl.pages.dev`)
- Middleware sudah otomatis mengizinkan akses dari `*.pages.dev`, tapi `APP_DOMAIN` tetap harus di-set

#### Step 3: Cek Browser Console

1. Buka halaman yang blank
2. Tekan **F12** untuk membuka DevTools
3. Lihat tab **Console** — apakah ada error merah?
4. Lihat tab **Network** — apakah ada request yang gagal (status 500/404)?

#### Step 4: Cek API Response

Buka URL berikut di browser:
- `https://your-project.pages.dev/api` — harus return `{"message":"Hello, world!"}`
- `https://your-project.pages.dev/api/auth/check` — harus return status (bukan error)

Jika API return 500, kemungkinan env vars tidak tersedia di runtime.

#### Step 5: Retry Deployment

Jika sudah melakukan perubahan env vars:
1. CF Pages → Deployments
2. Klik **...** pada deployment terbaru
3. Klik **Retry deployment**
4. Tunggu hingga selesai, lalu cek lagi

### Halaman 404 muncul di localhost

**Penyebab:** Middleware memblokir request karena hostname (`localhost`) tidak cocok dengan `APP_DOMAIN`.

**Solusi:**
1. Pastikan `APP_DOMAIN` di `.env` diisi (bisa berisi `localhost` atau domain pages.dev)
2. Middleware sudah dikonfigurasi untuk melewatkan `localhost` dan `127.0.0.1`
3. Jika masih 404, hapus cache:

```powershell
# Windows
rmdir /s /q .next
npm run dev

# Linux/macOS
rm -rf .next
npm run dev
```

### Infinite loop saat build di CF Pages

**Penyebab:** Build command memanggil `npm run build` yang memanggil `opennextjs-cloudflare build` → infinite recursion.

**Solusi:** Pastikan build command HANYA:
```bash
npx prisma generate && npx opennextjs-cloudflare build
```

JANGAN tambahkan `npm install` atau `npm run build`.

### `ERESOLVE` error saat `npm install`

**Penyebab:** Peer dependency conflict antar paket Radix UI.

**Solusi:**
1. Pastikan `.npmrc` berisi `force=true`
2. Hapus `node_modules` dan `package-lock.json`, lalu `npm install`
3. Atau gunakan `pnpm install` yang menangani peer deps lebih baik

### Error `Cannot find native binding` (@tailwindcss/oxide)

**Penyebab:** `@tailwindcss/oxide` membutuhkan native binding (binary khusus platform) yang tidak terinstall.

**Solusi:**
1. Pastikan `.npmrc` berisi `force=true`
2. Hapus semua cache dan reinstall:

```powershell
# Windows
rmdir /s /q node_modules
del package-lock.json
npm install
```

```bash
# Linux/macOS
rm -rf node_modules package-lock.json
npm install
```

### `prisma generate` error: `driverAdapters` not found

**Penyebab:** Preview feature `driverAdapters` belum diaktifkan di schema.

**Solusi:** Pastikan `prisma/schema.prisma` memiliki:

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")
  directUrl = env("DIRECT_URL")
  previewFeatures = ["driverAdapters"]
}
```

### Login tidak bisa di localhost

**Penyebab 1:** `DASHBOARD_TOKEN` tidak di-set di `.env`
**Penyebab 2:** Token yang dimasukkan di halaman login tidak sama dengan `DASHBOARD_TOKEN`
**Penyebab 3:** Token lama tersimpan di localStorage browser dari versi sebelumnya

**Solusi:**
1. Cek `.env` — pastikan `DASHBOARD_TOKEN` ada dan min. 12 karakter
2. Restart dev server setelah mengubah `.env`
3. Masukkan token yang **persis sama** (case-sensitive, tanpa spasi)
4. Jika masih tidak bisa, buka DevTools browser → Console → jalankan `localStorage.removeItem("token")` lalu reload

### API calls return "Unauthorized" (401)

**Penyebab:** Token yang tersimpan di browser (localStorage) berbeda dengan `DASHBOARD_TOKEN` di environment.

**Solusi:**
1. Logout dari dashboard (Settings → atau buka DevTools → `localStorage.removeItem("token")`)
2. Reload halaman
3. Login ulang dengan token yang sesuai

### Database tidak terhubung

**Cara cek koneksi:**
```powershell
npx prisma db push
```
Jika error, cek:
1. `DATABASE_URL` sudah benar
2. Format connection string: `postgresql://user:pass@host/db?sslmode=require`
3. Database Neon masih aktif (buka console.neon.tech, cek project status)
4. Jika Neon project "suspended", buka console dan aktifkan kembali

### Error `qrcode` di Cloudflare Workers

**Penyebab:** Paket `qrcode` menggunakan Node.js Canvas API yang tidak tersedia di Workers.

**Solusi:** Project sudah menggunakan `react-qr-code` (SVG-based, edge-compatible). Jika ada error, cek `package.json` dan pastikan tidak ada `qrcode` di dependencies.

---

## File Penting yang Wajib Ada di Repository

Sebelum deploy, pastikan file-file ini ada di repository dan sudah di-commit:

```
.env.example                    # Template env vars (YA, commit ini)
.npmrc                          # force=true (YA, commit ini)
prisma/schema.prisma            # Database schema (YA, commit ini)
src/lib/db.ts                   # DB connection with neon adapter (YA, commit ini)
src/middleware.ts                # Multi-domain routing (YA, commit ini)
open-next.config.ts             # Cloudflare adapter config (YA, commit ini)
wrangler.toml                   # Workers config (YA, commit ini)
next.config.ts                  # Next.js config (YA, commit ini)
package.json                    # Dependencies dan scripts (YA, commit ini)
```

**JANGAN commit:** `.env`, `.next/`, `node_modules/`, `prisma/*.db`, `*.log`

Pastikan `.gitignore` berisi:
```
.env
.env.local
.next/
node_modules/
prisma/*.db
*.log
.open-next/
```

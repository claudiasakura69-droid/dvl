# ShortURL Platform

Platform manajemen Short URL (clone Dub.co) yang dibangun dengan Next.js, Prisma, dan Cloudflare Pages. Mendukung multi-domain, multi-target routing, analytics, QR Code, dan banyak fitur lainnya.

## Tech Stack

| Technology              | Versi / Keterangan                   |
|-------------------------|--------------------------------------|
| **Next.js**             | 15.3.4 (App Router)                  |
| **TypeScript**          | 5.x                                  |
| **Prisma**              | 6.11.1 (driverAdapters)              |
| **PostgreSQL**          | Neon (serverless, HTTP-based)        |
| **Tailwind CSS**        | 4.x                                  |
| **shadcn/ui**           | Radix UI + Tailwind                  |
| **Cloudflare Pages**    | Deployment via @opennextjs/cloudflare |
| **QR Code**             | react-qr-code (SVG, edge-compatible) |
| **State Management**    | Zustand                              |

---

## Panduan Instalasi

> Pilih sistem operasi yang kamu gunakan:

- [Windows (PowerShell/CMD)](#windows)
- [Linux / macOS](#linux--macos)

---

### Prasyarat

| Tool                  | Versi Minimum | Download                                                                 |
|-----------------------|---------------|--------------------------------------------------------------------------|
| **Node.js**           | 18.x+         | https://nodejs.org                                                       |
| **pnpm** (recommended) | 8.x+       | `npm i -g pnpm`                                                          |
| **npm** (alternatif)  | 9.x+          | (termasuk saat install Node.js)                                          |
| **Git**               | Terbaru       | https://git-scm.com                                                      |
| **Neon PostgreSQL**   | -             | https://console.neon.tech (gratis)                                      |
| **Akun Cloudflare**   | -             | https://dash.cloudflare.com (gratis)                                     |

> **Windows tambahan:** Pastikan saat install Node.js, centang **"Add to PATH"**. Gunakan **PowerShell** atau **CMD** sebagai terminal.

---

### Windows

#### 1. Clone Repository

```powershell
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

#### 2. Install Dependencies

**pnpm (recommended — lebih cepat, handle peer deps lebih baik):**
```powershell
pnpm install
```

**npm (alternatif):**
```powershell
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true` untuk kedua package manager.

> **Jika error "Cannot find native binding" (@tailwindcss/oxide):** Hapus cache dan install ulang:
> ```powershell
> # Dengan pnpm
> rmdir /s /q node_modules
> del pnpm-lock.yaml
> pnpm install
> ```
> Atau dengan npm:
> ```powershell
> rmdir /s /q node_modules
> del package-lock.json
> npm install
> ```

#### 3. Setup Environment Variables

```powershell
copy .env.example .env
```

Buka file `.env` dengan text editor (VS Code, Notepad++, dll):

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================

# DATABASE (PostgreSQL - Neon)
# Format: postgresql://user:password@ep-xxx.region.aws.neon.tech/neondb?sslmode=require
DATABASE_URL="postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require"

# AUTH - Dashboard login token (MINIMUM 12 karakter!)
DASHBOARD_TOKEN="MySecretToken123"

# APP DOMAIN - Domain utama untuk dashboard (middleware routing)
# Untuk awal, isi dengan domain *.pages.dev kamu, nanti bisa diubah
# ke custom domain (contoh: yoii.me) setelah dikonfigurasi
APP_DOMAIN="your-project.pages.dev"

# CLOUDFLARE API (opsional, untuk auto-verify domain)
CLOUDFLARE_ACCOUNT_ID=""
CLOUDFLARE_API_TOKEN=""
CLOUDFLARE_PAGES_PROJECT=""
```

**Cara mendapat DATABASE_URL dari Neon:**
1. Buka https://console.neon.tech
2. Buat project baru (atau gunakan yang sudah ada)
3. Klik **Connection Details**
4. Copy connection string, format-nya: `postgresql://neondb_owner:xxx@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`

#### 4. Prisma — Push Schema & Generate Client

```powershell
npx prisma db push
npx prisma generate
```

- `prisma db push` — Membuat/memperbarui tabel-tabel di database Neon sesuai schema
- `prisma generate` — Menghasilkan Prisma Client yang dibutuhkan oleh aplikasi

> Jika berhasil, kamu akan melihat pesan seperti: `Your database is now in sync with your Prisma schema.`

**Optional:** Untuk melihat database via browser:
```powershell
npx prisma studio
# Buka http://localhost:5555 di browser
```

#### 5. Jalankan Development Server

```powershell
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser — halaman login dashboard akan muncul.

Masukkan token yang kamu set di `DASHBOARD_TOKEN` di file `.env` untuk login. Token harus **persis sama** (case-sensitive, tanpa spasi tambahan).

> **PENTING:** Tidak ada demo token. Jika `DASHBOARD_TOKEN` tidak di-set di `.env`, login akan selalu gagal.

---

### Linux / macOS

#### 1. Clone Repository

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

#### 2. Install Dependencies

**pnpm (recommended):**
```bash
pnpm install
```

**npm (alternatif):**
```bash
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true`.

> **Jika error "Cannot find native binding":**
> ```bash
> rm -rf node_modules package-lock.json
> npm install
> ```
> Atau:
> ```bash
> rm -rf node_modules pnpm-lock.yaml
> pnpm install
> ```

#### 3. Setup Environment Variables

```bash
cp .env.example .env
nano .env  # atau gunakan editor favorit
```

Isi `.env` dengan konfigurasi yang sama seperti panduan Windows di atas.

#### 4. Prisma — Push Schema & Generate Client

```bash
npx prisma db push
npx prisma generate
```

**Optional:** Prisma Studio untuk melihat database:
```bash
npx prisma studio
# Buka http://localhost:5555
```

#### 5. Jalankan Development Server

```bash
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser.

---

## Environment Variables

| Variable                   | Required | Description                                                              |
|----------------------------|----------|--------------------------------------------------------------------------|
| `DATABASE_URL`             | ✅       | Neon PostgreSQL connection string                                         |
| `DASHBOARD_TOKEN`          | ✅       | Auth token untuk login dashboard (**min. 12 karakter**)                  |
| `APP_DOMAIN`               | ✅       | Domain utama dashboard (middleware routing), contoh: `yoii.me` atau `your-project.pages.dev` |
| `CLOUDFLARE_ACCOUNT_ID`    | Opsional | CF Account ID (untuk auto-verify custom domain)                          |
| `CLOUDFLARE_API_TOKEN`     | Opsional | CF API Token — dibutuhkan permission: `Zone:Read`, `DNS:Edit`, `Pages:Edit` |
| `CLOUDFLARE_PAGES_PROJECT` | Opsional | Nama project CF Pages, contoh: `app-yoii`                               |

### Cara membuat Cloudflare API Token:

1. Buka https://dash.cloudflare.com/profile/api-tokens
2. Klik **Create Token**
3. Pilih **Custom Token**
4. Beri nama, misalnya `ShortURL Platform`
5. Permissions:
   - **Zone** → Zone → Read
   - **DNS** → DNS → Edit
   - **Account** → Cloudflare Pages → Edit
6. Account Resources → Include → Your Account
7. Klik **Continue to Summary** → **Create Token**
8. Copy token dan simpan di `.env` sebagai `CLOUDFLARE_API_TOKEN`

---

## Deployment ke Cloudflare Pages

Untuk panduan lengkap deployment, lihat **[docs/INSTALLATION-GUIDE.md](./docs/INSTALLATION-GUIDE.md)**.

### Ringkasan

| Setting             | Value                                              |
|---------------------|----------------------------------------------------|
| **Build Command**   | `npx prisma generate && npx opennextjs-cloudflare build` |
| **Output Directory**| `.open-next`                                       |
| **Node.js Version** | `18` atau `20`                                     |

### Environment Variables di Cloudflare Pages

Set di **Settings → Environment Variables** pada project CF Pages.

> **⚠️ CARA MENAMBAHKAN ENV VARS DI CLOUDFLARE PAGES:**
>
> Cloudflare Pages memiliki **DUA scope** untuk environment variables: **Production** dan **Preview**.
>
> 1. Buka project CF Pages → **Settings** → **Environment Variables**
> 2. Kamu akan melihat dua tab: **Production** dan **Preview**
> 3. Untuk setiap variabel, tambahkan **SECARA TERPISAH** di masing-masing tab:
>    - Klik tab **Production** → **Add variable** → masukkan nama & value → Save
>    - Klik tab **Preview** → **Add variable** → masukkan nama & value → Save
> 4. Ulangi untuk semua variabel yang dibutuhkan
> 5. **SETELAH menambahkan semua variabel, WAJIB redeploy:**
>    - Push commit baru ke GitHub, ATAU
>    - Klik **"Retry deployment"** di CF Pages dashboard
>
> **PENTING:** CF Pages TIDAK auto-redeploy saat env vars berubah. Kamu HARUS manually redeploy.

| Variable                   | Value (isi dengan datamu)                        |
|----------------------------|--------------------------------------------------|
| `DATABASE_URL`             | Connection string Neon kamu                      |
| `DASHBOARD_TOKEN`          | Token login dashboard (min 12 karakter)          |
| `APP_DOMAIN`               | Domain utama, contoh: `yoii.me`                  |
| `CLOUDFLARE_ACCOUNT_ID`    | CF Account ID (opsional)                         |
| `CLOUDFLARE_API_TOKEN`     | CF API Token (opsional)                          |
| `CLOUDFLARE_PAGES_PROJECT` | Nama project CF Pages (opsional)                 |

> **Tips untuk APP_DOMAIN:**
> - Jika belum punya custom domain, set APP_DOMAIN ke URL *.pages.dev kamu (contoh: `my-shorturl.pages.dev`)
> - Middleware sudah otomatis mengizinkan akses dari semua domain *.pages.dev
> - Setelah custom domain aktif, ubah APP_DOMAIN ke custom domain kamu (contoh: `yoii.me`)

---

## Perintah yang Tersedia

| Perintah                | Deskripsi                                         |
|-------------------------|---------------------------------------------------|
| `pnpm dev` / `npm run dev` | Jalankan development server (port 3000)           |
| `npm run build`         | Build Next.js (standalone)                        |
| `npm run build:cf`      | Build untuk Cloudflare Pages                      |
| `npm run lint`          | Jalankan ESLint                                   |
| `npm run db:push`       | Push schema Prisma ke database                    |
| `npm run db:generate`   | Generate Prisma Client                            |
| `npm run db:migrate`    | Run Prisma migration                              |
| `npm run db:reset`      | Reset database (HATI-HATI: menghapus semua data!) |

---

## Fitur Utama

- **Multi-domain** — Satu dashboard, banyak domain untuk short URL
- **Multi-target routing** — Sequential atau random redirect ke multiple URL
- **Analytics** — Tracking klik, device, browser, lokasi, referrer
- **QR Code** — Generate QR Code SVG untuk setiap short URL
- **Custom domain verification** — Auto-verify via Cloudflare API
- **Health check** — Monitoring status target URL
- **Bulk operations** — Import, export, migrasi domain secara massal
- **Dashboard** — UI modern dengan shadcn/ui, dark mode support

---

## Struktur Folder (Penting)

```
project-root/
├── prisma/
│   └── schema.prisma          # Database schema
├── src/
│   ├── app/
│   │   ├── page.tsx           # Halaman utama (login/dashboard)
│   │   ├── layout.tsx         # Root layout
│   │   ├── api/               # API routes
│   │   └── s/[slug]/          # Redirect handler (catch-all)
│   ├── components/            # React components
│   ├── lib/                   # Utilities (db, store, api)
│   └── middleware.ts          # Multi-domain routing
├── .env                       # Environment variables (lokal, JANGAN di-commit!)
├── .env.example               # Template environment variables
├── .npmrc                     # npm config (force=true)
├── next.config.ts             # Next.js config
├── open-next.config.ts        # Cloudflare Pages adapter config
├── wrangler.toml              # Cloudflare Workers config
└── package.json
```

---

## Troubleshooting

### Halaman 404 muncul di localhost

Jika `http://localhost:3000` menampilkan "404 - The link you're looking for doesn't exist":

- Pastikan `APP_DOMAIN` di `.env` **tidak kosong**
- Middleware sudah dikonfigurasi untuk melewatkan `localhost` dan `127.0.0.1`
- Jika masih 404, hapus `.next` folder lalu restart: `rmdir /s /q .next` (Windows) atau `rm -rf .next` (Linux)

### `tee is not recognized` (Windows)

Script `dev` di `package.json` sudah diperbaiki untuk cross-platform. Jika masih terjadi, jalankan manual:

```powershell
npx next dev -p 3000
```

### Prisma error: `driverAdapters` not found

Pastikan `prisma/schema.prisma` memiliki:

```prisma
previewFeatures = ["driverAdapters"]
```

### Build error di Cloudflare Pages

Pastikan:
1. `.npmrc` berisi `force=true`
2. Build command: `npx prisma generate && npx opennextjs-cloudflare build` (JANGAN `npm run build`)
3. Output directory: `.open-next`
4. Node.js version: `18` atau `20`

### Deploy berhasil tapi halaman kosong/blank

**Langkah debug:**
1. Pastikan SEMUA environment variables sudah ditambahkan di **Production** DAN **Preview** (lihat panduan di atas)
2. Setelah menambahkan env vars, **WAJIB redeploy** (push commit baru atau "Retry deployment")
3. Cek APP_DOMAIN — jika kamu akses via `*.pages.dev`, pastikan APP_DOMAIN kosong atau berisi domain *.pages.dev kamu
4. Buka DevTools browser (F12) → tab **Console** → cek ada error JavaScript atau tidak
5. Buka tab **Network** → cek apakah file JS/CSS berhasil dimuat

### Error `Cannot find native binding` (@tailwindcss/oxide)

Error ini terjadi karena npm tidak menginstall optional dependencies (native binding untuk Windows).

**Solusi:** Pastikan `.npmrc` berisi `force=true`, lalu:
```powershell
# Windows
rmdir /s /q node_modules
del package-lock.json
npm install
```
```bash
# Linux/macOS
rm -rf node_modules package-lock.json
npm install
```

### Error `npm ERR! ERESOLVE`

Pastikan `.npmrc` berisi `force=true`. Atau gunakan `pnpm install` yang menangani peer deps lebih baik.

import { defineCloudflareConfig } from "@opennextjs/cloudflare";

export default defineCloudflareConfig({
  incrementalCache: {
    tagCache: true,
  },
  // Cloudflare Pages environment variables (set in dashboard) are
  // automatically mapped to process.env at runtime by @opennextjs/cloudflare.
  // No additional configuration needed here.
});

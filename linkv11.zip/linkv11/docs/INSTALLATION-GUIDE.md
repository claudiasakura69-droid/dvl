# Panduan Instalasi & Deployment Lengkap

> Panduan ini mencakup instalasi lokal dan deployment ke Cloudflare Pages.
> Dibuat berdasarkan [OpenNext Cloudflare official documentation](https://opennext.js.org/cloudflare).

---

## Daftar Isi

1. [Prasyarat](#1-prasyarat)
2. [Instalasi Lokal — Windows](#2-instalasi-lokal--windows)
3. [Instalasi Lokal — Linux/macOS](#3-instalasi-lokal--linuxmacos)
4. [Konfigurasi Database (Neon)](#4-konfigurasi-database-neon)
5. [Konfigurasi Cloudflare](#5-konfigurasi-cloudflare)
6. [Deployment ke Cloudflare Pages](#6-deployment-ke-cloudflare-pages)
7. [Custom Domain Setup](#7-custom-domain-setup)
8. [Troubleshooting](#8-troubleshooting)

---

## 1. Prasyarat

| Tool                    | Versi Minimum | Download                                |
|-------------------------|---------------|-----------------------------------------|
| **Node.js**             | 18.x+         | https://nodejs.org                       |
| **pnpm** (recommended)  | 8.x+          | `npm i -g pnpm`                          |
| **npm** (alternatif)    | 9.x+          | (termasuk saat install Node.js)          |
| **Git**                 | Terbaru       | https://git-scm.com                      |
| **Akun Neon**           | -             | https://console.neon.tech (gratis)       |
| **Akun Cloudflare**     | -             | https://dash.cloudflare.com (gratis)     |

---

## 2. Instalasi Lokal — Windows

### Step 1: Clone Repository

```powershell
cd C:\Users\YourName\Projects
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

### Step 2: Install Dependencies

```powershell
pnpm install
# atau: npm install
```

### Step 3: Setup Environment Variables

```powershell
copy .env.example .env
code .env
```

Isi `.env`:

```env
DATABASE_URL="postgresql://neondb_owner:yourpassword@ep-abc123.us-east-2.aws.neon.tech/neondb?sslmode=require"
DASHBOARD_TOKEN="MySecretToken123"
APP_DOMAIN="yourdomain.com"
```

### Step 4: Prisma — Setup Database

```powershell
npx prisma db push
npx prisma generate
```

### Step 5: Jalankan Development Server

```powershell
pnpm dev
```

Buka **http://localhost:3000** — halaman login akan muncul.

---

## 3. Instalasi Lokal — Linux/macOS

### Step 1: Clone Repository

```bash
cd ~/projects
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

### Step 2: Install Dependencies

```bash
pnpm install
# atau: npm install
```

### Step 3: Setup Environment Variables

```bash
cp .env.example .env
nano .env
```

### Step 4: Prisma — Setup Database

```bash
npx prisma db push
npx prisma generate
```

### Step 5: Jalankan Development Server

```bash
pnpm dev
```

---

## 4. Konfigurasi Database (Neon)

1. Buka https://console.neon.tech
2. Sign up / Sign in
3. Klik **Create Project**
4. Isi Project name, Region, PostgreSQL version
5. Klik **Create Project**
6. Copy connection string dari **Connection Details**
7. Paste ke `.env` sebagai `DATABASE_URL`

Format: `postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`

---

## 5. Konfigurasi Cloudflare

### Mendapat Account ID

1. Buka https://dash.cloudflare.com
2. Di sidebar atau URL, kamu akan melihat **Account ID**

### Membuat API Token (Opsional, untuk auto-verify domain)

1. Buka https://dash.cloudflare.com/profile/api-tokens
2. Klik **Create Token** → **Custom Token**
3. Permissions:
   - `Zone` → `Zone` → `Read`
   - `Zone` → `DNS` → `Edit`
   - `Account` → `Cloudflare Pages` → `Edit`
4. Klik **Create Token** → Copy token

### Menambah Domain ke Cloudflare

1. CF Dashboard → **Add a Site** → masukkan domain
2. Ubah nameserver di registrar ke nameserver Cloudflare

---

## 6. Deployment ke Cloudflare Pages

### Persiapan

Pastikan:
- [ ] Repository sudah di-push ke GitHub/GitLab
- [ ] `wrangler.jsonc` ADA di repo (WAJIB — mengandung `nodejs_compat`)
- [ ] `wrangler.jsonc` TIDAK mengandung `[vars]` section
- [ ] `.env.example` ada di repo
- [ ] `.npmrc` ada di repo
- [ ] `public/_headers` ada di repo
- [ ] Semua file sudah di-commit

### ⚠️ PENTING: `wrangler.jsonc` WAJIB ada di repository!

Berdasarkan [OpenNext Cloudflare docs](https://opennext.js.org/cloudflare/get-started):

> "A wrangler configuration file is needed for your application to be previewed and deployed, it is also where you configure your Worker and define what resources it can access via bindings."

File `wrangler.jsonc` di repo ini mengandung:
- `nodejs_compat` — **WAJIB** agar `process.env` bisa bekerja di Cloudflare Workers
- `global_fetch_strictly_public` — Mengizinkan fetch ke URL eksternal
- `pages_build_output_dir` — Memberitahu CF Pages dimana output build berada

**TANPA `nodejs_compat`**, `process.env.DATABASE_URL` akan `undefined` dan halaman akan blank!

### ⚠️ JANGAN tambahkan `[vars]` ke `wrangler.jsonc`!

Jika `wrangler.jsonc` mengandung section `[vars]`, nilai-nilai tersebut akan **MENG-OVERRIDE** environment variables dari CF Pages dashboard. Ini menyebabkan:
- Env vars dari dashboard tidak terbaca
- Halaman blank karena `DATABASE_URL` dll tidak tersedia

**Environment variables HARUS di-set melalui CF Pages dashboard**, BUKAN di `wrangler.jsonc`.

### Build Settings di CF Pages

| Setting               | Value                                              |
|-----------------------|----------------------------------------------------|
| **Framework preset**  | `None`                                             |
| **Build command**     | `npx opennextjs-cloudflare build`                  |
| **Build output dir**  | `.open-next`                                        |
| **Root directory**    | `/` (default)                                      |
| **Node.js version**   | `18` atau `20`                                     |

> **Mengapa `npx opennextjs-cloudflare build`?**
>
> Perintah ini akan:
> 1. Menjalankan `npm run build` (yaitu `npx prisma generate && next build`)
> 2. Mengkonversi output Next.js ke format Cloudflare Worker
> 3. Menaruh output di `.open-next/`
>
> JANGAN gunakan `npm run build` langsung sebagai build command — outputnya tidak kompatibel dengan CF Pages.

### 🔧 Environment Variables di CF Pages

#### Cara Menambahkan:

1. Buka **Workers & Pages** → project kamu → **Settings** → **Environment Variables**
2. Kamu akan melihat dua tab: **Production** dan **Preview**
3. Untuk setiap variabel:
   - Klik tab **Production** → **Add variable** → masukkan nama dan value → **Save**
   - Klik tab **Preview** → **Add variable** → masukkan nama dan value → **Save**
4. **SETELAH semua variabel ditambahkan, WAJIB push commit baru:**
   ```bash
   git commit --allow-empty -m "Configure env vars"
   git push
   ```
   ATAU klik **"Retry deployment"** di CF Pages dashboard

#### Variabel yang Diperlukan:

| Variable                   | Value                                   | Tab                     |
|----------------------------|-----------------------------------------|-------------------------|
| `DATABASE_URL`             | Connection string Neon                  | Production + Preview    |
| `DASHBOARD_TOKEN`          | Token login dashboard (min 12 karakter) | Production + Preview    |
| `APP_DOMAIN`               | Domain utama atau *.pages.dev           | Production + Preview    |
| `CLOUDFLARE_ACCOUNT_ID`    | CF Account ID (opsional)                | Production + Preview    |
| `CLOUDFLARE_API_TOKEN`     | CF API Token (opsional)                 | Production + Preview    |
| `CLOUDFLARE_PAGES_PROJECT` | Nama project CF Pages (opsional)        | Production + Preview    |

#### Tentang APP_DOMAIN:

- **Pertama deploy via *.pages.dev:** Set `APP_DOMAIN` ke URL pages.dev kamu (contoh: `my-shorturl.pages.dev`)
- **Sudah punya custom domain:** Set `APP_DOMAIN` ke custom domain (contoh: `yoii.me`)
- Middleware otomatis mengizinkan akses dari semua domain `*.pages.dev`

### Proses Deploy

1. Push ke repository:
   ```bash
   git add .
   git commit -m "Deploy to Cloudflare Pages"
   git push origin main
   ```

2. CF Pages akan otomatis build dan deploy.

3. Akses site di:
   - `your-project.pages.dev`
   - Custom domain (jika sudah dikonfigurasi)

### Custom Domain di CF Pages

1. CF Pages project → **Custom domains** → **Set up a custom domain**
2. Masukkan domain (contoh: `yoii.me`)
3. SSL certificate otomatis (15-30 menit)
4. Update `APP_DOMAIN` di env vars ke domain baru

---

## 7. Custom Domain Setup

### Domain Utama (APP_DOMAIN)

Domain untuk mengakses dashboard. Diatur di `APP_DOMAIN` environment variable.

### Custom Domain untuk Short URL

1. Tambahkan domain ke Cloudflare (jika belum)
2. Di dashboard aplikasi → **Domains** → **Add Domain**
3. Masukkan domain (contoh: `link.co`)
4. Klik **Verify** — verifikasi otomatis via Cloudflare API

**Cara kerja routing:**
- `yoii.me` → Dashboard
- `link.co/abc` → Redirect ke target URL
- `link.co/` → 404

---

## 8. Troubleshooting

### Deploy berhasil tapi halaman blank/kosong

**Step 1: Cek Console browser**
- Buka DevTools browser (F12) → Console tab
- Cek apakah ada JavaScript errors

**Step 2: Pastikan `wrangler.jsonc` ADA dan benar**

File `wrangler.jsonc` HARUS ada di repository dengan isi:
```jsonc
{
  "compatibility_flags": ["nodejs_compat"],
  "pages_build_output_dir": ".open-next",
  "compatibility_date": "2024-12-30"
}
```

**Step 3: Pastikan `wrangler.jsonc` TIDAK punya `[vars]`**

Jika ada section seperti ini, HAPUS:
```jsonc
// ❌ SALAH — ini akan override dashboard env vars!
"vars": {
  "DATABASE_URL": "...",
  "DASHBOARD_TOKEN": "..."
}
```

**Step 4: Pastikan env vars di-set di CF Pages dashboard**

- `DATABASE_URL`, `DASHBOARD_TOKEN`, `APP_DOMAIN` harus ada di KEDUA tab (Production + Preview)
- Setelah menambahkan, push commit baru

**Step 5: Pastikan build command benar**

Build command harus: `npx opennextjs-cloudflare build` (BUKAN `npm run build`)

**Step 6: Cek Network tab**
- DevTools → Network tab
- Pastikan file JS/CSS berhasil dimuat (status 200)
- Cek apakah ada request yang gagal

### Build error: infinite loop

**Solusi:** Pastikan build command HANYA:
```bash
npx opennextjs-cloudflare build
```
JANGAN tambahkan `npm install` atau perintah lain.

### Error `Cannot find native binding` (@tailwindcss/oxide)

```powershell
# Windows
rmdir /s /q node_modules
del package-lock.json
npm install
```
```bash
# Linux/macOS
rm -rf node_modules package-lock.json
npm install
```

### Error `ERESOLVE` (npm peer dependency conflict)

Pastikan `.npmrc` berisi `force=true`. Atau gunakan `pnpm install`.

### Login tidak bisa di localhost

1. Pastikan `DASHBOARD_TOKEN` ada di `.env` (min 12 karakter)
2. Restart dev server setelah mengubah `.env`
3. Cek DevTools Console → `localStorage.removeItem("token")` → reload

### API calls return 401

1. Logout (DevTools → `localStorage.removeItem("token")`)
2. Reload halaman
3. Login ulang

### Database tidak terhubung

```powershell
npx prisma db push
```
Jika error, cek `DATABASE_URL` format dan status Neon project.

---

## File yang Wajib Ada di Repository

```
wrangler.jsonc         # ✅ WAJIB — compatibility flags (nodejs_compat, dll)
open-next.config.ts    # ✅ WAJIB — OpenNext CF adapter config
next.config.ts         # ✅ WAJIB — Next.js config + initOpenNextCloudflareForDev()
package.json           # ✅ WAJIB — dependencies & build scripts
.npmrc                 # ✅ WAJIB — force=true
.env.example           # ✅ WAJIB — template env vars
public/_headers        # ✅ WAJIB — static asset caching
prisma/schema.prisma   # ✅ WAJIB — database schema
src/lib/db.ts          # ✅ WAJIB — DB connection
src/middleware.ts       # ✅ WAJIB — multi-domain routing
.dev.vars.example      # ✅ Opsional — template local dev vars
```

**JANGAN commit:**

```
.env              # env vars lokal (rahasia)
.dev.vars         # local dev secrets (rahasia)
wrangler.toml     # legacy format — gunakan wrangler.jsonc
.next/            # Next.js build output
.open-next/       # OpenNext build output
node_modules/
```

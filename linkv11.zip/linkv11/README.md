# ShortURL Platform

Platform manajemen Short URL (clone Dub.co) yang dibangun dengan Next.js, Prisma, dan Cloudflare Pages. Mendukung multi-domain, multi-target routing, analytics, QR Code, dan banyak fitur lainnya.

## Tech Stack

| Technology              | Versi / Keterangan                   |
|-------------------------|--------------------------------------|
| **Next.js**             | 15.3.4 (App Router)                  |
| **TypeScript**          | 5.x                                  |
| **Prisma**              | 6.11.1 (driverAdapters)              |
| **PostgreSQL**          | Neon (serverless, HTTP-based)        |
| **Tailwind CSS**        | 4.x                                  |
| **shadcn/ui**           | Radix UI + Tailwind                  |
| **Cloudflare Pages**    | @opennextjs/cloudflare 1.19.5        |
| **QR Code**             | react-qr-code (SVG, edge-compatible) |
| **State Management**    | Zustand                              |

---

## Panduan Instalasi

> Pilih sistem operasi yang kamu gunakan:
> - [Windows (PowerShell/CMD)](#windows)
> - [Linux / macOS](#linux--macos)

### Prasyarat

| Tool                    | Versi Minimum | Download                                                                 |
|-------------------------|---------------|--------------------------------------------------------------------------|
| **Node.js**             | 18.x+         | https://nodejs.org                                                       |
| **pnpm** (recommended)  | 8.x+          | `npm i -g pnpm`                                                          |
| **npm** (alternatif)    | 9.x+          | (termasuk saat install Node.js)                                          |
| **Git**                 | Terbaru       | https://git-scm.com                                                      |
| **Neon PostgreSQL**     | -             | https://console.neon.tech (gratis)                                      |
| **Akun Cloudflare**     | -             | https://dash.cloudflare.com (gratis)                                     |

---

### Windows

#### 1. Clone Repository

```powershell
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

#### 2. Install Dependencies

**pnpm (recommended):**
```powershell
pnpm install
```

**npm (alternatif):**
```powershell
npm install
```

> **Jika error "Cannot find native binding":** Hapus cache dan install ulang:
> ```powershell
> rmdir /s /q node_modules
> del package-lock.json
> npm install
> ```

#### 3. Setup Environment Variables

```powershell
copy .env.example .env
```

Buka file `.env` dengan text editor dan isi:

```env
DATABASE_URL="postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require"
DASHBOARD_TOKEN="MySecretToken123"
APP_DOMAIN="yourdomain.com"
```

#### 4. Prisma — Push Schema & Generate Client

```powershell
npx prisma db push
npx prisma generate
```

#### 5. Jalankan Development Server

```powershell
pnpm dev
# atau: npm run dev
```

Buka **http://localhost:3000** — halaman login dashboard akan muncul.

---

### Linux / macOS

#### 1. Clone Repository

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

#### 2. Install Dependencies

**pnpm (recommended):**
```bash
pnpm install
```

**npm (alternatif):**
```bash
npm install
```

#### 3. Setup Environment Variables

```bash
cp .env.example .env
nano .env
```

Isi `.env` sama seperti panduan Windows di atas.

#### 4. Prisma — Push Schema & Generate Client

```bash
npx prisma db push
npx prisma generate
```

#### 5. Jalankan Development Server

```bash
pnpm dev
# atau: npm run dev
```

---

## Environment Variables

| Variable                   | Required | Description                                                              |
|----------------------------|----------|--------------------------------------------------------------------------|
| `DATABASE_URL`             | ✅       | Neon PostgreSQL connection string                                         |
| `DASHBOARD_TOKEN`          | ✅       | Auth token untuk login dashboard (**min. 12 karakter**)                  |
| `APP_DOMAIN`               | ✅       | Domain utama dashboard (middleware routing)                               |
| `CLOUDFLARE_ACCOUNT_ID`    | Opsional | CF Account ID (untuk auto-verify custom domain)                          |
| `CLOUDFLARE_API_TOKEN`     | Opsional | CF API Token (Zone:Read, DNS:Edit, Pages:Edit)                          |
| `CLOUDFLARE_PAGES_PROJECT` | Opsional | Nama project CF Pages                                                   |

---

## Deployment ke Cloudflare Pages

Untuk panduan lengkap step-by-step, lihat **[docs/INSTALLATION-GUIDE.md](./docs/INSTALLATION-GUIDE.md)**.

### Ringkasan

#### 1. CF Pages Build Settings

| Setting               | Value                                              |
|-----------------------|----------------------------------------------------|
| **Framework preset**  | `None`                                             |
| **Build command**     | `npx opennextjs-cloudflare build`                  |
| **Build output dir**  | `.open-next`                                        |
| **Node.js version**   | `18` atau `20`                                     |

> **PENTING:** Build command di atas adalah `npx opennextjs-cloudflare build` (BUKAN `npm run build`).
> `opennextjs-cloudflare build` akan otomatis menjalankan `npm run build` (yaitu `prisma generate && next build`) di dalamnya.

#### 2. Environment Variables di CF Pages Dashboard

1. Buka project CF Pages → **Settings** → **Environment Variables**
2. Tambahkan variabel di **KEDUA** tab (Production + Preview):

| Variable                   | Tab                     |
|----------------------------|-------------------------|
| `DATABASE_URL`             | Production + Preview    |
| `DASHBOARD_TOKEN`          | Production + Preview    |
| `APP_DOMAIN`               | Production + Preview    |

3. Setelah menambahkan, **WAJIB push commit baru** atau klik "Retry deployment"

#### 3. File yang Diperlukan di Repository

| File                   | Status  | Keterangan                                           |
|------------------------|---------|------------------------------------------------------|
| `wrangler.jsonc`       | ✅ WAJIB | Compatibility flags (nodejs_compat). JANGAN tambahkan `[vars]`! |
| `open-next.config.ts`  | ✅ WAJIB | OpenNext CF adapter config                           |
| `next.config.ts`       | ✅ WAJIB | Next.js config + initOpenNextCloudflareForDev()      |
| `package.json`         | ✅ WAJIB | Dependencies & build scripts                        |
| `.npmrc`               | ✅ WAJIB | force=true                                          |
| `.env.example`         | ✅ WAJIB | Template env vars                                    |
| `public/_headers`      | ✅ WAJIB | Static asset caching rules                          |
| `prisma/schema.prisma` | ✅ WAJIB | Database schema                                      |

> ⚠️ **`wrangler.jsonc` TIDAK BOLEH mengandung `[vars]`!** Jika ada `[vars]`, nilai di dashboard akan di-override dan halaman akan blank.

---

## Perintah yang Tersedia

| Perintah                          | Deskripsi                                         |
|-----------------------------------|---------------------------------------------------|
| `pnpm dev` / `npm run dev`       | Jalankan development server (port 3000)           |
| `npm run build`                   | Build Next.js (prisma generate + next build)      |
| `npm run preview`                 | Preview di Wrangler (CF Worker runtime)           |
| `npm run deploy`                  | Deploy langsung ke Cloudflare Workers             |
| `npm run lint`                    | Jalankan ESLint                                   |
| `npm run db:push`                 | Push schema Prisma ke database                    |
| `npm run db:generate`             | Generate Prisma Client                            |

---

## Fitur Utama

- **Multi-domain** — Satu dashboard, banyak domain untuk short URL
- **Multi-target routing** — Sequential atau random redirect ke multiple URL
- **Analytics** — Tracking klik, device, browser, lokasi, referrer
- **QR Code** — Generate QR Code SVG untuk setiap short URL
- **Custom domain verification** — Auto-verify via Cloudflare API
- **Health check** — Monitoring status target URL
- **Bulk operations** — Import, export, migrasi domain secara massal
- **Dashboard** — UI modern dengan shadcn/ui, dark mode support

---

## Troubleshooting

### Deploy berhasil tapi halaman blank/kosong

**Step 1:** Buka DevTools browser (F12) → Console tab → cek error

**Step 2:** Pastikan `wrangler.jsonc` ADA di repository dan mengandung `nodejs_compat`:
```jsonc
{
  "compatibility_flags": ["nodejs_compat"],
  ...
}
```

**Step 3:** Pastikan `wrangler.jsonc` TIDAK mengandung `[vars]` section

**Step 4:** Pastikan env vars sudah di-set di **BOTH** Production dan Preview tabs

**Step 5:** Setelah mengubah env vars, WAJIB push commit baru

**Step 6:** Jika akses via `*.pages.dev`, pastikan `APP_DOMAIN` berisi URL pages.dev kamu

### Error `Cannot find native binding` (@tailwindcss/oxide)

Pastikan `.npmrc` berisi `force=true`, lalu:
```powershell
rmdir /s /q node_modules
del package-lock.json
npm install
```

### Error `npm ERR! ERESOLVE`

Pastikan `.npmrc` berisi `force=true`. Atau gunakan `pnpm install`.

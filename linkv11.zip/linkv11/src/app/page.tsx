'use client'

import { useEffect, useState } from "react";
import { useAppStore } from "@/lib/store";
import { checkAuth } from "@/lib/api";
import LoginPage from "@/components/pages/LoginPage";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import { Loader2 } from "lucide-react";

export default function Home() {
  const isAuthenticated = useAppStore((s) => s.isAuthenticated);
  const setAuthenticated = useAppStore((s) => s.setAuthenticated);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    let cancelled = false;

    const doCheck = async () => {
      if (token) {
        try {
          const res = await checkAuth();
          if (!cancelled) {
            if (res.authenticated) {
              setAuthenticated(true);
            } else {
              localStorage.removeItem("token");
            }
          }
        } catch {
          // Token is invalid, clear it
          if (!cancelled) {
            localStorage.removeItem("token");
          }
        }
      }
      if (!cancelled) {
        setChecking(false);
      }
    };

    doCheck();
    return () => { cancelled = true; };
  }, [setAuthenticated]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return <DashboardLayout />;
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Parse User-Agent into device/browser/OS (same as production redirect handler)
function parseUserAgent(ua: string): { device: string; browser: string; os: string } {
  let device = "Unknown";
  let browser = "Unknown";
  let os = "Unknown";

  if (!ua) return { device, browser, os };

  if (/Mobile|Android.*Mobile|iPhone|iPod/.test(ua)) {
    device = "Mobile";
  } else if (/iPad|Android(?!.*Mobile)|Tablet/.test(ua)) {
    device = "Tablet";
  } else if (/Desktop/.test(ua) || (!/Mobile|Tablet/.test(ua))) {
    device = "Desktop";
  }

  if (/Edg\//.test(ua)) {
    browser = "Edge";
  } else if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) {
    browser = "Chrome";
  } else if (/Firefox\//.test(ua)) {
    browser = "Firefox";
  } else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) {
    browser = "Safari";
  } else if (/Opera|OPR\//.test(ua)) {
    browser = "Opera";
  }

  if (/Windows NT 10/.test(ua)) {
    os = "Windows";
  } else if (/Windows NT/.test(ua)) {
    os = "Windows";
  } else if (/Mac OS X/.test(ua)) {
    os = "macOS";
  } else if (/Android/.test(ua)) {
    os = "Android";
  } else if (/iPhone|iPad|iPod/.test(ua)) {
    os = "iOS";
  } else if (/Linux/.test(ua)) {
    os = "Linux";
  }

  return { device, browser, os };
}

// Get client IP from request headers
function getClientIp(request: NextRequest): string {
  const cfIp = request.headers.get("cf-connecting-ip");
  if (cfIp) return cfIp;
  const xff = request.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return "unknown";
}

// Get country from CF headers
function getCountry(request: NextRequest): string {
  return request.headers.get("cf-ipcountry") || "";
}

// GET - Redirect test (resolves target without actual redirect, records real click data)
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const slug = searchParams.get("slug");
    const domain = searchParams.get("domain");
    const dryRun = searchParams.get("dryRun") === "true";

    if (!slug) {
      return NextResponse.json({ error: "Slug is required" }, { status: 400 });
    }

    // Find the link by slug and optionally domain
    let link;

    if (domain) {
      const domainRecord = await db.shortDomain.findFirst({
        where: { domain },
      });

      if (!domainRecord) {
        return NextResponse.json({ error: "Link not found" }, { status: 404 });
      }

      link = await db.shortLink.findFirst({
        where: { slug, domainId: domainRecord.id },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    } else {
      link = await db.shortLink.findFirst({
        where: { slug },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    }

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    if (!link.isActive) {
      return NextResponse.json({ error: "Link is inactive" }, { status: 404 });
    }

    if (link.expiredAt && link.expiredAt < new Date()) {
      return NextResponse.json({ error: "Link has expired" }, { status: 410 });
    }

    // Collect real visitor data from request headers
    const visitorIp = getClientIp(request);
    const visitorCountry = getCountry(request);
    const ua = request.headers.get("user-agent") || "";
    const { device, browser, os } = parseUserAgent(ua);
    const visitorReferrer = request.headers.get("referer") || "";
    const cfRay = request.headers.get("cf-ray") || "";
    const cfWorker = request.headers.get("cf-worker") || "";

    // Determine redirect target
    let selectedTarget;

    if (link.type === "basic") {
      selectedTarget = link.targets[0];

      if (!selectedTarget) {
        return NextResponse.json(
          { error: "No active target found" },
          { status: 404 }
        );
      }

      if (
        selectedTarget.clickLimit > 0 &&
        selectedTarget.currentClicks >= selectedTarget.clickLimit
      ) {
        return NextResponse.json(
          { error: "Click limit reached" },
          { status: 429 }
        );
      }
    } else {
      // Multi-target routing logic
      const availableTargets = link.targets.filter((t) => {
        if (t.clickLimit > 0 && t.currentClicks >= t.clickLimit) {
          return false;
        }
        return true;
      });

      if (availableTargets.length === 0) {
        return NextResponse.json(
          { error: "No available targets" },
          { status: 404 }
        );
      }

      // Priority 1: IP-based targets
      const ipMatchTargets = availableTargets.filter((t) => {
        if (!t.ipList) return false;
        const allowedIps = t.ipList.split(",").map((ip) => ip.trim());
        return allowedIps.includes(visitorIp);
      });

      if (ipMatchTargets.length > 0) {
        selectedTarget = ipMatchTargets[0];
      } else {
        // Priority 2: Country-based targets
        const countryMatchTargets = availableTargets.filter(
          (t) => t.country !== "ALL" && t.country === visitorCountry
        );

        if (countryMatchTargets.length > 0) {
          selectedTarget = countryMatchTargets[0];
        } else {
          // Priority 3: ALL country targets
          const allTargets = availableTargets.filter(
            (t) => t.country === "ALL"
          );

          if (allTargets.length === 0) {
            selectedTarget = availableTargets[0];
          } else if (link.mode === "random") {
            selectedTarget = allTargets[Math.floor(Math.random() * allTargets.length)];
          } else {
            selectedTarget = allTargets.reduce((prev, curr) =>
              prev.currentClicks <= curr.currentClicks ? prev : curr
            );
          }
        }
      }
    }

    if (!selectedTarget) {
      return NextResponse.json(
        { error: "No suitable target found" },
        { status: 404 }
      );
    }

    // Increment click count on the target (unless dry run)
    if (!dryRun) {
      await db.linkTarget.update({
        where: { id: selectedTarget.id },
        data: { currentClicks: { increment: 1 } },
      });

      // Record the click with real visitor data
      await db.click.create({
        data: {
          linkId: link.id,
          targetId: selectedTarget.id,
          ip: visitorIp,
          country: visitorCountry,
          city: "",
          region: "",
          device,
          browser,
          os,
          referrer: visitorReferrer,
          cfRay,
          cfWorker,
        },
      });
    }

    return NextResponse.json({
      url: selectedTarget.url,
      status: 301,
      linkId: link.id,
      targetId: selectedTarget.id,
      dryRun,
      visitor: {
        ip: visitorIp,
        country: visitorCountry,
        device,
        browser,
        os,
        referrer: visitorReferrer || "(none)",
      },
    });
  } catch (error) {
    console.error("Error processing redirect:", error);
    return NextResponse.json({ error: "Redirect failed" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { token } = body;

    if (!token) {
      return NextResponse.json({ error: "Token is required" }, { status: 400 });
    }

    const validToken = process.env.DASHBOARD_TOKEN || "";

    if (!validToken) {
      return NextResponse.json(
        { error: "Server not configured: DASHBOARD_TOKEN is not set" },
        { status: 500 }
      );
    }

    if (token === validToken) {
      return NextResponse.json({ success: true, token });
    }

    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }
}

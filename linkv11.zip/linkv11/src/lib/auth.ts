import { NextRequest, NextResponse } from "next/server";

const MASTER_TOKEN = process.env.DASHBOARD_TOKEN || "";

if (!MASTER_TOKEN) {
  console.warn('[auth] WARNING: DASHBOARD_TOKEN is not set. All API requests will be rejected.');
}

export function isAuthenticated(request: NextRequest): boolean {
  if (!MASTER_TOKEN) return false;
  const authHeader = request.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.replace("Bearer ", "");
  return token === MASTER_TOKEN;
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

import { neon } from '@neondatabase/serverless';
import { PrismaNeon } from '@prisma/adapter-neon';
import { PrismaClient } from '@prisma/client';

/**
 * Create a Prisma client connected to Neon PostgreSQL.
 *
 * During build time (Cloudflare Pages build), DATABASE_URL is not available.
 * We use a placeholder connection string so the neon() constructor doesn't crash.
 * Real database operations will fail gracefully at build time (which is fine
 * since no pages perform DB queries during SSG — all are dynamic/client-side).
 */
function createPrismaClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL || '';

  const sql = neon(
    connectionString && connectionString.startsWith('postgresql://')
      ? connectionString
      : 'postgresql://placeholder:placeholder@localhost/placeholder'
  );
  const adapter = new PrismaNeon(sql);

  return new PrismaClient({ adapter });
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db: PrismaClient = globalForPrisma.prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db;
}

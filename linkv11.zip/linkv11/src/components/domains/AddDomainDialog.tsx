"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { Loader2, Cloud } from "lucide-react";

interface AddDomainDialogProps {
  open: boolean;
  onClose: () => void;
  onAdd: (domain: string, slug: string, autoConfigure: boolean) => Promise<void>;
}

export default function AddDomainDialog({ open, onClose, onAdd }: AddDomainDialogProps) {
  const [domain, setDomain] = useState("");
  const [slug, setSlug] = useState("");
  const [autoConfigure, setAutoConfigure] = useState(true);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain.trim()) return;
    setSaving(true);
    setResult(null);
    try {
      await onAdd(domain, slug, autoConfigure);
      setDomain("");
      setSlug("");
      setAutoConfigure(true);
      setResult({ success: true, message: "Domain added successfully!" });
    } catch (err: any) {
      setResult({ success: false, message: err.message || "Failed to add domain" });
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setResult(null);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Domain</DialogTitle>
          <DialogDescription>
            Add a custom domain for your short links. Enable auto-configure to automatically add the domain to your Cloudflare Pages project.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Domain *</Label>
            <Input
              placeholder="s.example.com"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              The domain must already be added to your Cloudflare account and have its DNS records configured to point to this Pages project.
            </p>
          </div>
          <div className="space-y-2">
            <Label>Slug (optional)</Label>
            <Input
              placeholder="Custom slug prefix"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              A prefix for all short links under this domain. Leave empty for no prefix.
            </p>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="flex items-center gap-3">
              <Cloud className="h-4 w-4 text-muted-foreground" />
              <div>
                <Label className="text-sm font-medium">Auto-configure Cloudflare</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically add domain to Cloudflare Pages and verify
                </p>
              </div>
            </div>
            <Switch
              checked={autoConfigure}
              onCheckedChange={setAutoConfigure}
            />
          </div>

          {result && (
            <div
              className={`rounded-lg p-3 text-sm ${
                result.success
                  ? "bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-400"
                  : "bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-400"
              }`}
            >
              {result.message}
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !domain.trim()}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Add Domain
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import DomainCard from "@/components/domains/DomainCard";
import AddDomainDialog from "@/components/domains/AddDomainDialog";
import EditDomainDialog from "@/components/domains/EditDomainDialog";
import { useAppStore } from "@/lib/store";
import { apiGet, apiPost, apiPut, apiDelete } from "@/lib/api";
import { Plus } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import type { ShortDomain } from "@/lib/types";

export default function DomainsPage() {
  const [domains, setDomains] = useState<ShortDomain[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editTarget, setEditTarget] = useState<ShortDomain | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ShortDomain | null>(null);

  const loadDomains = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiGet<ShortDomain[]>("/domains");
      setDomains(Array.isArray(res) ? res : []);
    } catch {
      setDomains([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDomains();
  }, [loadDomains]);

  const handleAdd = async (domain: string, slug: string, autoConfigure: boolean) => {
    try {
      const res = await apiPost<any>("/domains", { domain, slug: slug || undefined, autoConfigure });
      if (res.autoConfig) {
        if (res.autoConfig.verified) {
          toast.success(`Domain added and verified via Cloudflare! ${res.autoConfig.message}`);
        } else if (res.autoConfig.addedToPages) {
          toast.success(`Domain added to Cloudflare Pages. ${res.autoConfig.message}`);
        } else {
          toast.success(`Domain added. ${res.autoConfig.message}`);
        }
      } else {
        toast.success("Domain added successfully");
      }
      setShowAddDialog(false);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to add domain");
      throw err;
    }
  };

  const handleUpdate = async (id: string, data: { domain: string; slug: string }) => {
    try {
      await apiPut(`/domains/${id}`, data);
      toast.success("Domain updated");
      setEditTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to update domain");
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await apiDelete(`/domains/${deleteTarget.id}`);
      toast.success("Domain deleted");
      setDeleteTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to delete domain");
    }
  };

  const handleVerify = async (domain: ShortDomain) => {
    try {
      await apiPost(`/domains/${domain.id}/verify`);
      toast.success("Domain verified successfully");
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to verify domain");
    }
  };

  const handleToggle = async (domain: ShortDomain) => {
    try {
      await apiPut(`/domains/${domain.id}`, { isActive: !domain.isActive });
      toast.success(`Domain ${domain.isActive ? "deactivated" : "activated"}`);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to toggle domain");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Domains</h2>
        <Button onClick={() => setShowAddDialog(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Domain
        </Button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="h-32 animate-pulse rounded-lg bg-muted"
            />
          ))}
        </div>
      ) : domains.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-sm text-muted-foreground">No domains configured.</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Add a domain to start creating short links.
          </p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {domains.map((domain) => (
            <DomainCard
              key={domain.id}
              domain={domain}
              onEdit={setEditTarget}
              onDelete={setDeleteTarget}
              onVerify={handleVerify}
              onToggle={handleToggle}
            />
          ))}
        </div>
      )}

      <AddDomainDialog
        open={showAddDialog}
        onClose={() => setShowAddDialog(false)}
        onAdd={handleAdd}
      />

      {editTarget && (
        <EditDomainDialog
          open={!!editTarget}
          onClose={() => setEditTarget(null)}
          domain={editTarget}
          onUpdate={handleUpdate}
        />
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Domain</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deleteTarget?.domain}&quot;?
              This will also delete all links associated with this domain. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

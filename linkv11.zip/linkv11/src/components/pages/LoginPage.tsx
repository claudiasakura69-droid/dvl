"use client";

import { useState } from "react";
import { Link, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAppStore } from "@/lib/store";
import { login as apiLogin } from "@/lib/api";
import { toast } from "sonner";

export default function LoginPage() {
  const [token, setToken] = useState("");
  const [loading, setLoading] = useState(false);
  const setAuthenticated = useAppStore((s) => s.setAuthenticated);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) {
      toast.error("Please enter a token");
      return;
    }

    setLoading(true);
    try {
      const result = await apiLogin(token);
      if (result.success) {
        localStorage.setItem("token", token);
        setAuthenticated(true);
        toast.success("Welcome to ShortURL!");
      } else {
        toast.error("Invalid token");
      }
    } catch (err: any) {
      toast.error(err.message || "Invalid token. Please check your DASHBOARD_TOKEN.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
            <Link className="h-6 w-6 text-primary-foreground" />
          </div>
          <CardTitle className="text-2xl font-bold">ShortURL</CardTitle>
          <CardDescription>Sign in to manage your short links</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="token">API Token</Label>
              <Input
                id="token"
                type="password"
                placeholder="Enter your DASHBOARD_TOKEN"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                autoFocus
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Sign In
            </Button>
          </form>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            Enter the token defined in your <code className="rounded bg-muted px-1 py-0.5 text-xs">DASHBOARD_TOKEN</code> environment variable.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

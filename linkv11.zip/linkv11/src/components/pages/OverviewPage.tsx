"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAppStore } from "@/lib/store";
import { getOverviewAnalytics, getLinks } from "@/lib/api";
import { Link2, MousePointerClick, Globe, Plus } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import type { ShortLink, Click, DashboardStats, ClicksOverTime } from "@/lib/types";

export default function OverviewPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentLinks, setRecentLinks] = useState<ShortLink[]>([]);
  const [recentClicks, setRecentClicks] = useState<Click[]>([]);
  const [clicksChart, setClicksChart] = useState<ClicksOverTime[]>([]);
  const [loading, setLoading] = useState(true);
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const [analyticsRes, linksRes] = await Promise.all([
        getOverviewAnalytics(),
        getLinks({ page: "1", limit: "5" }),
      ]);

      // Map analytics overview response
      setStats({
        totalLinks: analyticsRes.totalLinks ?? 0,
        activeLinks: analyticsRes.activeLinks ?? 0,
        totalClicks: analyticsRes.totalClicks ?? 0,
        totalDomains: analyticsRes.totalDomains ?? 0,
      });

      // Recent links from /links endpoint
      setRecentLinks(linksRes.links || []);

      // Recent clicks from analytics
      const clicks = analyticsRes.recentClicks || [];
      setRecentClicks(clicks.slice(0, 10));

      // Clicks chart data from analytics
      const chartData = (analyticsRes.clicksOverTime || []).map((item: any) => ({
        date: new Date(item.date).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        }),
        clicks: item.clicks ?? 0,
      }));
      setClicksChart(
        chartData.length > 0
          ? chartData
          : [
              { date: "Mon", clicks: 0 },
              { date: "Tue", clicks: 0 },
              { date: "Wed", clicks: 0 },
              { date: "Thu", clicks: 0 },
              { date: "Fri", clicks: 0 },
              { date: "Sat", clicks: 0 },
              { date: "Sun", clicks: 0 },
            ]
      );
    } catch {
      // Show empty state on error
      setStats({
        totalLinks: 0,
        activeLinks: 0,
        totalClicks: 0,
        totalDomains: 0,
      });
      setRecentLinks([]);
      setRecentClicks([]);
      setClicksChart([
        { date: "Mon", clicks: 0 },
        { date: "Tue", clicks: 0 },
        { date: "Wed", clicks: 0 },
        { date: "Thu", clicks: 0 },
        { date: "Fri", clicks: 0 },
        { date: "Sat", clicks: 0 },
        { date: "Sun", clicks: 0 },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      label: "Total Links",
      value: stats?.totalLinks ?? 0,
      icon: Link2,
      description: "All short links",
    },
    {
      label: "Active Links",
      value: stats?.activeLinks ?? 0,
      icon: Link2,
      description: "Currently active",
    },
    {
      label: "Total Clicks",
      value: stats?.totalClicks ?? 0,
      icon: MousePointerClick,
      description: "All time",
    },
    {
      label: "Total Domains",
      value: stats?.totalDomains ?? 0,
      icon: Globe,
      description: "Configured domains",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-2">
        <Button
          onClick={() => setCurrentPage("create-link")}
          className="gap-2"
        >
          <Plus className="h-4 w-4" />
          Create Link
        </Button>
        <Button
          variant="outline"
          onClick={() => setCurrentPage("domains")}
          className="gap-2"
        >
          <Globe className="h-4 w-4" />
          Add Domain
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16" />
                </CardContent>
              </Card>
            ))
          : statCards.map((stat) => (
              <Card key={stat.label}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    {stat.label}
                  </CardTitle>
                  <stat.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {typeof stat.value === "number" ? stat.value.toLocaleString() : stat.value}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {stat.description}
                  </p>
                </CardContent>
              </Card>
            ))}
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Clicks (Last 7 Days)</CardTitle>
            <CardDescription>Daily click volume</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[250px] w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={clicksChart}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="date" className="text-xs" tick={{ fontSize: 12 }} />
                  <YAxis className="text-xs" tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                      color: "hsl(var(--popover-foreground))",
                    }}
                  />
                  <Bar
                    dataKey="clicks"
                    fill="hsl(var(--chart-1))"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Quick Stats</CardTitle>
            <CardDescription>Platform overview</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[250px] w-full" />
            ) : (
              <div className="flex h-[250px] flex-col items-center justify-center gap-4">
                <div className="grid grid-cols-2 gap-4 w-full">
                  <div className="rounded-lg bg-muted p-4 text-center">
                    <div className="text-2xl font-bold">
                      {stats?.totalClicks ?? 0}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Total Clicks
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted p-4 text-center">
                    <div className="text-2xl font-bold">
                      {stats?.activeLinks ?? 0}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Active Links
                    </div>
                  </div>
                  <div className="rounded-lg bg-muted p-4 text-center">
                    <div className="text-2xl font-bold">
                      {stats?.totalDomains ?? 0}
                    </div>
                    <div className="text-xs text-muted-foreground">Domains</div>
                  </div>
                  <div className="rounded-lg bg-muted p-4 text-center">
                    <div className="text-2xl font-bold">
                      {stats?.totalLinks
                        ? Math.round(
                            ((stats.activeLinks ?? 0) / stats.totalLinks) * 100
                          )
                        : 0}
                      %
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Active Rate
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tables Row */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Recent Links */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Links</CardTitle>
            <CardDescription>Last 5 created links</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : recentLinks.length === 0 ? (
              <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
                No links yet. Create your first link!
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Short URL</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Clicks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentLinks.map((link) => (
                    <TableRow key={link.id}>
                      <TableCell className="font-medium">
                        {link.slug}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={link.isActive ? "default" : "destructive"}
                          className="text-xs"
                        >
                          {link.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {link._count?.clicks ?? 0}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Recent Clicks */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Clicks</CardTitle>
            <CardDescription>Last 10 clicks</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : recentClicks.length === 0 ? (
              <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
                No clicks recorded yet.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Link</TableHead>
                    <TableHead>Country</TableHead>
                    <TableHead>Device</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentClicks.map((click) => (
                    <TableRow key={click.id}>
                      <TableCell className="font-medium text-xs">
                        {(click as any).link?.slug ?? click.linkId.slice(0, 8)}
                      </TableCell>
                      <TableCell className="text-xs">
                        {click.country || "Unknown"}
                      </TableCell>
                      <TableCell className="text-xs">
                        {click.device || "Unknown"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(click.createdAt).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

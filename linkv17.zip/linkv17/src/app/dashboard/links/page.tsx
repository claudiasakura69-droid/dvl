'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Checkbox } from '@/components/ui/checkbox'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Plus, Edit, Trash2, Search, Filter, ArrowUpDown, Globe, ExternalLink, RefreshCw, AlertCircle, Copy, CheckCircle2 } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface Domain {
  id: string
  name: string
  subdomain: string | null
  isVerified: boolean
  isActive: boolean
}

interface ShortLink {
  id: string
  shortUrl: string
  destinationUrl: string
  slug: string
  domainId: string
  domain: Domain
  clickCount: number
  isActive: boolean
  createdAt: string
  updatedAt: string
}

export default function LinksPage() {
  const [links, setLinks] = useState<ShortLink[]>([])
  const [domains, setDomains] = useState<Domain[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState<'all' | 'shortUrl' | 'destination'>('all')
  const [selectedLinks, setSelectedLinks] = useState<Set<string>>(new Set())
  const [selectAll, setSelectAll] = useState(false)
  
  // Dialogs
  const [createDialog, setCreateDialog] = useState(false)
  const [editDialog, setEditDialog] = useState<{ open: boolean; link: ShortLink | null }>({ open: false, link: null })
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; links: ShortLink[] }>({ open: false, links: [] })
  const [bulkEditDialog, setBulkEditDialog] = useState(false)
  const [migrateDialog, setMigrateDialog] = useState(false)
  
  // Form data
  const [formData, setFormData] = useState({
    domainId: '',
    slug: '',
    destinationUrl: ''
  })
  
  const [bulkEditData, setBulkEditData] = useState({
    findText: '',
    replaceText: '',
    field: 'destinationUrl' as 'shortUrl' | 'destinationUrl'
  })
  
  const [migrateData, setMigrateData] = useState({
    fromDomainId: '',
    toDomainId: ''
  })
  
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    fetchDomains()
    fetchLinks()
  }, [])

  useEffect(() => {
    if (links.length > 0 && selectedLinks.size === links.length) {
      setSelectAll(true)
    } else {
      setSelectAll(false)
    }
  }, [selectedLinks, links])

  const fetchDomains = async () => {
    try {
      const response = await fetch('/api/domains')
      if (response.ok) {
        const data = await response.json()
        const verifiedDomains = data.filter((d: Domain) => d.isVerified && d.isActive)
        setDomains(verifiedDomains)
        if (verifiedDomains.length > 0) {
          setFormData(prev => ({ ...prev, domainId: verifiedDomains[0].id }))
        }
      }
    } catch (error) {
      console.error('Failed to fetch domains:', error)
    }
  }

  const fetchLinks = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/links')
      if (response.ok) {
        const data = await response.json()
        setLinks(data)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch links',
        variant: 'destructive'
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    if (!searchTerm.trim()) {
      return links
    }

    let filtered = [...links]
    
    if (filterType === 'all' || filterType === 'shortUrl') {
      filtered = filtered.filter(link => 
        link.shortUrl.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }
    
    if (filterType === 'all' || filterType === 'destination') {
      filtered = filtered.filter(link => 
        link.destinationUrl.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    return filtered
  }

  const getFilteredLinks = () => {
    if (!searchTerm.trim()) return links
    
    const filtered = handleSearch()
    return filtered
  }

  const filteredLinks = getFilteredLinks()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Short link created successfully'
        })
        setCreateDialog(false)
        setFormData({
          domainId: domains[0]?.id || '',
          slug: '',
          destinationUrl: ''
        })
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to create link',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create link',
        variant: 'destructive'
      })
    }
  }

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editDialog.link) return

    try {
      const response = await fetch(`/api/links/${editDialog.link.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destinationUrl: formData.destinationUrl,
          slug: formData.slug,
          isActive: formData.isActive
        })
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Link updated successfully'
        })
        setEditDialog({ open: false, link: null })
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to update link',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update link',
        variant: 'destructive'
      })
    }
  }

  const handleBulkEdit = async () => {
    if (selectedLinks.size === 0) {
      toast({
        title: 'Error',
        description: 'Please select at least one link',
        variant: 'destructive'
      })
      return
    }

    try {
      const response = await fetch('/api/links/bulk-edit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: Array.from(selectedLinks),
          findText: bulkEditData.findText,
          replaceText: bulkEditData.replaceText,
          field: bulkEditData.field
        })
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Links updated successfully'
        })
        setBulkEditDialog(false)
        setBulkEditData({ findText: '', replaceText: '', field: 'destinationUrl' })
        setSelectedLinks(new Set())
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to update links',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update links',
        variant: 'destructive'
      })
    }
  }

  const handleBulkDelete = async () => {
    if (selectedLinks.size === 0) return

    try {
      const response = await fetch('/api/links/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: Array.from(selectedLinks) })
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: `Deleted ${selectedLinks.size} links`
        })
        setDeleteDialog({ open: false, links: [] })
        setSelectedLinks(new Set())
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to delete links',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete links',
        variant: 'destructive'
      })
    }
  }

  const handleMigration = async () => {
    if (!migrateData.fromDomainId || !migrateData.toDomainId) {
      toast({
        title: 'Error',
        description: 'Please select both domains',
        variant: 'destructive'
      })
      return
    }

    if (migrateData.fromDomainId === migrateData.toDomainId) {
      toast({
        title: 'Error',
        description: 'Source and target domains cannot be the same',
        variant: 'destructive'
      })
      return
    }

    try {
      const response = await fetch('/api/links/migrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromDomainId: migrateData.fromDomainId,
          toDomainId: migrateData.toDomainId
        })
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: 'Success',
          description: `Migrated ${data.count} links`
        })
        setMigrateDialog(false)
        setMigrateData({ fromDomainId: '', toDomainId: '' })
        fetchLinks()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to migrate links',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to migrate links',
        variant: 'destructive'
      })
    }
  }

  const toggleSelectAll = () => {
    if (selectAll) {
      setSelectedLinks(new Set())
    } else {
      setSelectedLinks(new Set(filteredLinks.map(link => link.id)))
    }
    setSelectAll(!selectAll)
  }

  const toggleSelectLink = (id: string) => {
    const newSelected = new Set(selectedLinks)
    if (newSelected.has(id)) {
      newSelected.delete(id)
    } else {
      newSelected.add(id)
    }
    setSelectedLinks(newSelected)
  }

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      toast({
        title: 'Copied',
        description: 'Link copied to clipboard'
      })
      setTimeout(() => setCopiedId(null), 2000)
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to copy',
        variant: 'destructive'
      })
    }
  }

  const openEditDialog = (link: ShortLink) => {
    setEditDialog({ open: true, link })
    setFormData({
      domainId: link.domainId,
      slug: link.slug,
      destinationUrl: link.destinationUrl,
      isActive: link.isActive
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Short Links</h2>
          <p className="text-muted-foreground">
            Create, manage, and analyze your short links
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={migrateDialog} onOpenChange={setMigrateDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Globe className="w-4 h-4 mr-2" />
                Migrate Domain
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Migrate Domain</DialogTitle>
                <DialogDescription>
                  Change all links from one domain to another while preserving slugs
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>From Domain</Label>
                  <Select value={migrateData.fromDomainId} onValueChange={(value) => setMigrateData({ ...migrateData, fromDomainId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select source domain" />
                    </SelectTrigger>
                    <SelectContent>
                      {domains.map((domain) => (
                        <SelectItem key={domain.id} value={domain.id}>
                          {domain.subdomain ? `${domain.subdomain}.` : ''}{domain.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>To Domain</Label>
                  <Select value={migrateData.toDomainId} onValueChange={(value) => setMigrateData({ ...migrateData, toDomainId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select target domain" />
                    </SelectTrigger>
                    <SelectContent>
                      {domains.map((domain) => (
                        <SelectItem key={domain.id} value={domain.id}>
                          {domain.subdomain ? `${domain.subdomain}.` : ''}{domain.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleMigration} className="w-full">
                  Start Migration
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Button onClick={() => setCreateDialog(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Link
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search links..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={filterType} onValueChange={(value: any) => setFilterType(value)}>
              <SelectTrigger className="w-[180px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Fields</SelectItem>
                <SelectItem value="shortUrl">Short URL</SelectItem>
                <SelectItem value="destination">Destination</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={fetchLinks}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bulk Actions */}
      {selectedLinks.size > 0 && (
        <Alert>
          <CheckCircle2 className="w-4 h-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>{selectedLinks.size} links selected</span>
            <div className="flex gap-2">
              <Dialog open={bulkEditDialog} onOpenChange={setBulkEditDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Edit className="w-4 h-4 mr-2" />
                    Bulk Edit
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Bulk Edit Links</DialogTitle>
                    <DialogDescription>
                      Find and replace text in selected links
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Field to Edit</Label>
                      <Select value={bulkEditData.field} onValueChange={(value: any) => setBulkEditData({ ...bulkEditData, field: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="destinationUrl">Destination URL</SelectItem>
                          <SelectItem value="shortUrl">Short URL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Find Text</Label>
                      <Input
                        placeholder="e.g., domain.com"
                        value={bulkEditData.findText}
                        onChange={(e) => setBulkEditData({ ...bulkEditData, findText: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Replace With</Label>
                      <Input
                        placeholder="e.g., dorma.com"
                        value={bulkEditData.replaceText}
                        onChange={(e) => setBulkEditData({ ...bulkEditData, replaceText: e.target.value })}
                      />
                    </div>
                    <Button onClick={handleBulkEdit} className="w-full">
                      Apply Changes ({selectedLinks.size} links)
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setDeleteDialog({ open: true, links: filteredLinks.filter(l => selectedLinks.has(l.id)) })}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Selected
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Links Table */}
      <Card>
        <CardHeader>
          <CardTitle>Your Links</CardTitle>
          <CardDescription>
            {filteredLinks.length} links found
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading links...</div>
          ) : filteredLinks.length === 0 ? (
            <div className="text-center py-8">
              <ExternalLink className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground mb-4">No links found</p>
              <Button onClick={() => setCreateDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Link
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">
                      <Checkbox
                        checked={selectAll}
                        onCheckedChange={toggleSelectAll}
                      />
                    </TableHead>
                    <TableHead>Short URL</TableHead>
                    <TableHead>Destination</TableHead>
                    <TableHead>Domain</TableHead>
                    <TableHead>Clicks</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLinks.map((link) => (
                    <TableRow key={link.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedLinks.has(link.id)}
                          onCheckedChange={() => toggleSelectLink(link.id)}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <code className="text-sm bg-slate-100 px-2 py-1 rounded">
                            {link.shortUrl}
                          </code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyToClipboard(link.shortUrl, link.id)}
                          >
                            {copiedId === link.id ? (
                              <CheckCircle2 className="w-4 h-4 text-green-500" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[300px] truncate">
                        <span className="text-sm text-muted-foreground" title={link.destinationUrl}>
                          {link.destinationUrl}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {link.domain.subdomain ? `${link.domain.subdomain}.` : ''}{link.domain.name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{link.clickCount}</Badge>
                      </TableCell>
                      <TableCell>
                        {link.isActive ? (
                          <Badge variant="default">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {new Date(link.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => openEditDialog(link)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDeleteDialog({ open: true, links: [link] })}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={createDialog} onOpenChange={setCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Short Link</DialogTitle>
            <DialogDescription>
              Create a new short URL for your destination
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="domain">Domain *</Label>
              <Select value={formData.domainId} onValueChange={(value) => setFormData({ ...formData, domainId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a domain" />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((domain) => (
                    <SelectItem key={domain.id} value={domain.id}>
                      {domain.subdomain ? `${domain.subdomain}.` : ''}{domain.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">Destination URL *</Label>
              <Input
                id="destination"
                placeholder="https://example.com/long-url"
                value={formData.destinationUrl}
                onChange={(e) => setFormData({ ...formData, destinationUrl: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Custom Slug (optional)</Label>
              <Input
                id="slug"
                placeholder="my-custom-link"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Leave empty for auto-generated slug
              </p>
            </div>
            <Button type="submit" className="w-full">Create Link</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editDialog.open} onOpenChange={(open) => setEditDialog({ open, link: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Link</DialogTitle>
            <DialogDescription>
              Update link details
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEdit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-destination">Destination URL</Label>
              <Input
                id="edit-destination"
                placeholder="https://example.com/long-url"
                value={formData.destinationUrl}
                onChange={(e) => setFormData({ ...formData, destinationUrl: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-slug">Slug</Label>
              <Input
                id="edit-slug"
                placeholder="my-custom-link"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">Save Changes</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ open, links: [] })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete {deleteDialog.links.length > 1 ? 'Links' : 'Link'}</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {deleteDialog.links.length} {deleteDialog.links.length > 1 ? 'links' : 'link'}? 
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setDeleteDialog({ open: false, links: [] })}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleBulkDelete}>
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

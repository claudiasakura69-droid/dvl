'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { RefreshCw, TrendingUp, Eye, MousePointerClick, Globe, Calendar } from 'lucide-react'

interface AnalyticsData {
  totalClicks: number
  uniqueClicks: number
  topLinks: TopLink[]
  clicksByDomain: DomainStats[]
  clicksByCountry: CountryStats[]
  recentActivity: Activity[]
}

interface TopLink {
  id: string
  shortUrl: string
  destinationUrl: string
  clickCount: number
}

interface DomainStats {
  domainName: string
  clickCount: number
  linkCount: number
}

interface CountryStats {
  country: string | null
  clickCount: number
}

interface Activity {
  id: string
  shortUrl: string
  ipAddress: string | null
  country: string | null
  timestamp: string
}

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('7d')
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalClicks: 0,
    uniqueClicks: 0,
    topLinks: [],
    clicksByDomain: [],
    clicksByCountry: [],
    recentActivity: []
  })

  useEffect(() => {
    fetchAnalytics()
  }, [timeRange])

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/analytics?timeRange=${timeRange}`)
      if (response.ok) {
        const data = await response.json()
        setAnalytics(data)
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error)
    } finally {
      setLoading(false)
    }
  }

  const StatCard = ({ title, value, icon: Icon, subtitle }: {
    title: string
    value: number
    icon: any
    subtitle?: string
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{loading ? '-' : value}</div>
        {subtitle && (
          <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
          <p className="text-muted-foreground">
            Track your short link performance and user engagement
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="icon"
            onClick={fetchAnalytics}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Clicks"
          value={analytics.totalClicks}
          icon={MousePointerClick}
          subtitle="All links combined"
        />
        <StatCard
          title="Unique Clicks"
          value={analytics.uniqueClicks}
          icon={Eye}
          subtitle="By IP address"
        />
        <StatCard
          title="Active Links"
          value={analytics.topLinks.length}
          icon={TrendingUp}
          subtitle="With clicks"
        />
        <StatCard
          title="Total Domains"
          value={analytics.clicksByDomain.length}
          icon={Globe}
          subtitle="In use"
        />
      </div>

      {/* Top Performing Links */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Links</CardTitle>
          <CardDescription>Your most clicked short links</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading...</div>
          ) : analytics.topLinks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No data available
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Short URL</TableHead>
                  <TableHead>Destination</TableHead>
                  <TableHead className="text-right">Clicks</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analytics.topLinks.map((link) => (
                  <TableRow key={link.id}>
                    <TableCell>
                      <code className="text-sm bg-slate-100 px-2 py-1 rounded">
                        {link.shortUrl}
                      </code>
                    </TableCell>
                    <TableCell className="max-w-[300px] truncate">
                      <span className="text-sm text-muted-foreground" title={link.destinationUrl}>
                        {link.destinationUrl}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="default">{link.clickCount}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Clicks by Domain */}
        <Card>
          <CardHeader>
            <CardTitle>Clicks by Domain</CardTitle>
            <CardDescription>Performance across your domains</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Loading...</div>
            ) : analytics.clicksByDomain.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No data available
              </div>
            ) : (
              <div className="space-y-4">
                {analytics.clicksByDomain.map((domain, index) => {
                  const maxClicks = Math.max(...analytics.clicksByDomain.map(d => d.clickCount))
                  const percentage = maxClicks > 0 ? (domain.clickCount / maxClicks) * 100 : 0
                  
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{domain.domainName}</span>
                        <span className="text-sm text-muted-foreground">
                          {domain.clickCount} clicks ({domain.linkCount} links)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Clicks by Country */}
        <Card>
          <CardHeader>
            <CardTitle>Clicks by Country</CardTitle>
            <CardDescription>Geographic distribution</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Loading...</div>
            ) : analytics.clicksByCountry.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No data available
              </div>
            ) : (
              <div className="space-y-3">
                {analytics.clicksByCountry.slice(0, 10).map((item, index) => {
                  const maxClicks = Math.max(...analytics.clicksByCountry.map(d => d.clickCount))
                  const percentage = maxClicks > 0 ? (item.clickCount / maxClicks) * 100 : 0
                  
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">
                          {item.country || 'Unknown'}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {item.clickCount} clicks
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest clicks on your short links</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading...</div>
          ) : analytics.recentActivity.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No recent activity
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {analytics.recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">
                      {activity.shortUrl}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {activity.ipAddress || 'Unknown IP'} • {activity.country || 'Unknown Country'}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap ml-4">
                    {new Date(activity.timestamp).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

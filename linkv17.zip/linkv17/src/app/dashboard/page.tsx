'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Link2, Globe, BarChart3, ArrowRight, TrendingUp, TrendingDown, Plus } from 'lucide-react'
import { useRouter } from 'next/navigation'

interface Stats {
  totalDomains: number
  totalLinks: number
  totalClicks: number
  recentLinks: number
}

export default function DashboardPage() {
  const router = useRouter()
  const [stats, setStats] = useState<Stats>({
    totalDomains: 0,
    totalLinks: 0,
    totalClicks: 0,
    recentLinks: 0
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/dashboard/stats')
      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const StatCard = ({ title, value, icon: Icon, trend, onClick }: {
    title: string
    value: number
    icon: any
    trend?: number
    onClick?: () => void
  }) => (
    <Card 
      className={`transition-all hover:shadow-lg cursor-pointer ${onClick ? 'hover:border-primary' : ''}`}
      onClick={onClick}
    >
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{loading ? '-' : value}</div>
        {trend !== undefined && (
          <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
            {trend > 0 ? (
              <>
                <TrendingUp className="w-3 h-3 text-green-500" />
                <span className="text-green-500">+{trend}%</span>
              </>
            ) : trend < 0 ? (
              <>
                <TrendingDown className="w-3 h-3 text-red-500" />
                <span className="text-red-500">{trend}%</span>
              </>
            ) : (
              'No change'
            )}
            <span>from last month</span>
          </p>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            Manage your short links and domains in one place
          </p>
        </div>
        <Button onClick={() => router.push('/dashboard/links')}>
          <Plus className="w-4 h-4 mr-2" />
          Create Link
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Domains"
          value={stats.totalDomains}
          icon={Globe}
          onClick={() => router.push('/dashboard/domains')}
        />
        <StatCard
          title="Short Links"
          value={stats.totalLinks}
          icon={Link2}
          onClick={() => router.push('/dashboard/links')}
        />
        <StatCard
          title="Total Clicks"
          value={stats.totalClicks}
          icon={BarChart3}
          onClick={() => router.push('/dashboard/analytics')}
        />
        <StatCard
          title="Recent Links (7 days)"
          value={stats.recentLinks}
          icon={TrendingUp}
        />
      </div>

      {/* Quick Actions */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="hover:shadow-lg transition-all cursor-pointer group">
          <CardHeader>
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
              <Plus className="w-6 h-6 text-primary" />
            </div>
            <CardTitle>Create Short Link</CardTitle>
            <CardDescription>
              Generate a new short URL from any destination
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              variant="outline" 
              className="w-full group-hover:bg-primary group-hover:text-primary-foreground"
              onClick={() => router.push('/dashboard/links')}
            >
              Create Now <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-all cursor-pointer group">
          <CardHeader>
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
              <Globe className="w-6 h-6 text-primary" />
            </div>
            <CardTitle>Manage Domains</CardTitle>
            <CardDescription>
              Add, verify and configure your custom domains
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              variant="outline" 
              className="w-full group-hover:bg-primary group-hover:text-primary-foreground"
              onClick={() => router.push('/dashboard/domains')}
            >
              Manage Domains <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-all cursor-pointer group">
          <CardHeader>
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
              <BarChart3 className="w-6 h-6 text-primary" />
            </div>
            <CardTitle>View Analytics</CardTitle>
            <CardDescription>
              Track clicks, traffic and user engagement
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              variant="outline" 
              className="w-full group-hover:bg-primary group-hover:text-primary-foreground"
              onClick={() => router.push('/dashboard/analytics')}
            >
              View Stats <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Getting Started */}
      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
          <CardDescription>
            Follow these steps to set up your short URL system
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-primary">
              1
            </div>
            <div>
              <h4 className="font-semibold">Add Your Domains</h4>
              <p className="text-sm text-muted-foreground">
                Add the domains you want to use for short links and verify ownership with Cloudflare
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-primary">
              2
            </div>
            <div>
              <h4 className="font-semibold">Create Short Links</h4>
              <p className="text-sm text-muted-foreground">
                Generate short URLs for your destinations using your verified domains
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-primary">
              3
            </div>
            <div>
              <h4 className="font-semibold">Track Performance</h4>
              <p className="text-sm text-muted-foreground">
                Monitor click analytics and optimize your short link strategy
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

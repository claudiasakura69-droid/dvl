'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Plus, Globe, Check, X, Edit, Trash2, RefreshCw, AlertCircle } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Domain {
  id: string
  name: string
  slug: string | null
  subdomain: string | null
  cloudflareAccountId: string | null
  isVerified: boolean
  isActive: boolean
  createdAt: string
  updatedAt: string
  _count?: {
    shortLinks: number
  }
}

export default function DomainsPage() {
  const [domains, setDomains] = useState<Domain[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [verifying, setVerifying] = useState<string | null>(null)
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; domain: Domain | null }>({ open: false, domain: null })
  const [editDialog, setEditDialog] = useState<{ open: boolean; domain: Domain | null }>({ open: false, domain: null })
  
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    subdomain: '',
    cloudflareAccountId: '',
    cloudflareApiToken: ''
  })
  
  const { toast } = useToast()

  useEffect(() => {
    fetchDomains()
  }, [])

  const fetchDomains = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/domains')
      if (response.ok) {
        const data = await response.json()
        setDomains(data)
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch domains',
        variant: 'destructive'
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/domains', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Domain added successfully'
        })
        setDialogOpen(false)
        setFormData({
          name: '',
          slug: '',
          subdomain: '',
          cloudflareAccountId: '',
          cloudflareApiToken: ''
        })
        fetchDomains()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to add domain',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add domain',
        variant: 'destructive'
      })
    }
  }

  const handleVerify = async (domain: Domain) => {
    try {
      setVerifying(domain.id)
      const response = await fetch(`/api/domains/${domain.id}/verify`, {
        method: 'POST'
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Domain verified successfully'
        })
        fetchDomains()
      } else {
        const error = await response.json()
        toast({
          title: 'Verification Failed',
          description: error.error || 'Failed to verify domain',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to verify domain',
        variant: 'destructive'
      })
    } finally {
      setVerifying(null)
    }
  }

  const handleDelete = async () => {
    if (!deleteDialog.domain) return

    try {
      const response = await fetch(`/api/domains/${deleteDialog.domain.id}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Domain deleted successfully'
        })
        setDeleteDialog({ open: false, domain: null })
        fetchDomains()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to delete domain',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete domain',
        variant: 'destructive'
      })
    }
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editDialog.domain) return

    try {
      const response = await fetch(`/api/domains/${editDialog.domain.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug: formData.slug,
          subdomain: formData.subdomain,
          isActive: formData.isActive
        })
      })

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Domain updated successfully'
        })
        setEditDialog({ open: false, domain: null })
        fetchDomains()
      } else {
        const error = await response.json()
        toast({
          title: 'Error',
          description: error.error || 'Failed to update domain',
          variant: 'destructive'
        })
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update domain',
        variant: 'destructive'
      })
    }
  }

  const openEditDialog = (domain: Domain) => {
    setEditDialog({ open: true, domain })
    setFormData({
      name: domain.name,
      slug: domain.slug || '',
      subdomain: domain.subdomain || '',
      cloudflareAccountId: domain.cloudflareAccountId || '',
      cloudflareApiToken: ''
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Domains</h2>
          <p className="text-muted-foreground">
            Manage and verify your custom domains for short links
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Domain
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Domain</DialogTitle>
              <DialogDescription>
                Add a domain to use for your short links
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Domain Name *</Label>
                <Input
                  id="name"
                  placeholder="example.com"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subdomain">Subdomain (optional)</Label>
                <Input
                  id="subdomain"
                  placeholder="link"
                  value={formData.subdomain}
                  onChange={(e) => setFormData({ ...formData, subdomain: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slug">Custom Slug (optional)</Label>
                <Input
                  id="slug"
                  placeholder="my-short"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cloudflareAccountId">Cloudflare Account ID (for verification)</Label>
                <Input
                  id="cloudflareAccountId"
                  placeholder="your-account-id"
                  value={formData.cloudflareAccountId}
                  onChange={(e) => setFormData({ ...formData, cloudflareAccountId: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cloudflareApiToken">Cloudflare API Token (for verification)</Label>
                <Input
                  id="cloudflareApiToken"
                  type="password"
                  placeholder="your-api-token"
                  value={formData.cloudflareApiToken}
                  onChange={(e) => setFormData({ ...formData, cloudflareApiToken: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Required for domain verification. Will not be stored.
                </p>
              </div>
              <Button type="submit" className="w-full">Add Domain</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Domains</CardTitle>
          <CardDescription>
            Verify ownership of your domains to start creating short links
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading domains...</div>
          ) : domains.length === 0 ? (
            <div className="text-center py-8">
              <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No domains added yet</p>
              <Button className="mt-4" onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Domain
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Domain</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Links</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {domains.map((domain) => (
                  <TableRow key={domain.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {domain.subdomain ? `${domain.subdomain}.` : ''}{domain.name}
                        </div>
                        {domain.slug && (
                          <div className="text-sm text-muted-foreground">
                            Default slug: {domain.slug}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {domain.isVerified ? (
                          <Badge variant="default" className="gap-1">
                            <Check className="w-3 h-3" />
                            Verified
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="gap-1">
                            <X className="w-3 h-3" />
                            Not Verified
                          </Badge>
                        )}
                        {!domain.isActive && (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{domain._count?.shortLinks || 0} links</Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(domain.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {!domain.isVerified && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleVerify(domain)}
                            disabled={verifying === domain.id}
                          >
                            {verifying === domain.id ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Verifying...
                              </>
                            ) : (
                              'Verify'
                            )}
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => openEditDialog(domain)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setDeleteDialog({ open: true, domain })}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onOpenChange={(open) => setDeleteDialog({ open, domain: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Domain</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete <strong>{deleteDialog.domain?.name}</strong>? 
              This will also delete all short links associated with this domain.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setDeleteDialog({ open: false, domain: null })}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editDialog.open} onOpenChange={(open) => setEditDialog({ open, domain: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Domain</DialogTitle>
            <DialogDescription>
              Update domain settings
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-subdomain">Subdomain</Label>
              <Input
                id="edit-subdomain"
                placeholder="link"
                value={formData.subdomain}
                onChange={(e) => setFormData({ ...formData, subdomain: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-slug">Default Slug</Label>
              <Input
                id="edit-slug"
                placeholder="my-short"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">Save Changes</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

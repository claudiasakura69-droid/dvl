import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET all domains
export async function GET() {
  try {
    const domains = await db.domain.findMany({
      include: {
        _count: {
          select: {
            shortLinks: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })
    return NextResponse.json(domains)
  } catch (error) {
    console.error('Error fetching domains:', error)
    return NextResponse.json(
      { error: 'Failed to fetch domains' },
      { status: 500 }
    )
  }
}

// POST create domain
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, subdomain, slug, cloudflareAccountId, cloudflareApiToken } = body

    // Check if domain already exists
    const existingDomain = await db.domain.findFirst({
      where: { name }
    })

    if (existingDomain) {
      return NextResponse.json(
        { error: 'Domain already exists' },
        { status: 400 }
      )
    }

    // If cloudflare credentials provided, try to verify immediately
    let isVerified = false
    if (cloudflareAccountId && cloudflareApiToken) {
      try {
        // Verify domain using Cloudflare API
        const verifyResponse = await fetch(`https://api.cloudflare.com/client/v4/accounts/${cloudflareAccountId}/zones?name=${name}`, {
          headers: {
            'Authorization': `Bearer ${cloudflareApiToken}`,
            'Content-Type': 'application/json'
          }
        })
        
        if (verifyResponse.ok) {
          const data = await verifyResponse.json()
          if (data.success && data.result && data.result.length > 0) {
            isVerified = true
          }
        }
      } catch (error) {
        console.log('Cloudflare verification failed, domain added but not verified')
      }
    }

    const domain = await db.domain.create({
      data: {
        name,
        subdomain: subdomain || null,
        slug: slug || null,
        cloudflareAccountId: cloudflareAccountId || null,
        isVerified,
        isActive: true
      }
    })

    return NextResponse.json(domain)
  } catch (error) {
    console.error('Error creating domain:', error)
    return NextResponse.json(
      { error: 'Failed to create domain' },
      { status: 500 }
    )
  }
}

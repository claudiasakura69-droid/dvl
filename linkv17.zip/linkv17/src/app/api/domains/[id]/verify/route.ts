import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { cloudflareAccountId, cloudflareApiToken } = body

    if (!cloudflareAccountId || !cloudflareApiToken) {
      return NextResponse.json(
        { error: 'Cloudflare credentials required' },
        { status: 400 }
      )
    }

    // Get domain details
    const domain = await db.domain.findUnique({
      where: { id: params.id }
    })

    if (!domain) {
      return NextResponse.json(
        { error: 'Domain not found' },
        { status: 404 }
      )
    }

    // Verify domain using Cloudflare API
    const verifyResponse = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${cloudflareAccountId}/zones?name=${domain.name}`,
      {
        headers: {
          'Authorization': `Bearer ${cloudflareApiToken}`,
          'Content-Type': 'application/json'
        }
      }
    )

    if (!verifyResponse.ok) {
      return NextResponse.json(
        { error: 'Failed to verify with Cloudflare API' },
        { status: 400 }
      )
    }

    const data = await verifyResponse.json()

    if (!data.success || !data.result || data.result.length === 0) {
      return NextResponse.json(
        { error: 'Domain not found in Cloudflare account' },
        { status: 400 }
      )
    }

    // Update domain as verified
    const updatedDomain = await db.domain.update({
      where: { id: params.id },
      data: {
        isVerified: true,
        cloudflareAccountId
      }
    })

    return NextResponse.json(updatedDomain)
  } catch (error) {
    console.error('Error verifying domain:', error)
    return NextResponse.json(
      { error: 'Failed to verify domain' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH update domain
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { slug, subdomain, isActive } = body

    const domain = await db.domain.update({
      where: { id: params.id },
      data: {
        ...(slug !== undefined && { slug: slug || null }),
        ...(subdomain !== undefined && { subdomain: subdomain || null }),
        ...(isActive !== undefined && { isActive })
      }
    })

    return NextResponse.json(domain)
  } catch (error) {
    console.error('Error updating domain:', error)
    return NextResponse.json(
      { error: 'Failed to update domain' },
      { status: 500 }
    )
  }
}

// DELETE domain
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // First, delete all short links associated with this domain
    await db.shortLink.deleteMany({
      where: { domainId: params.id }
    })

    // Then delete the domain
    await db.domain.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting domain:', error)
    return NextResponse.json(
      { error: 'Failed to delete domain' },
      { status: 500 }
    )
  }
}

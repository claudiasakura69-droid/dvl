import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const timeRange = searchParams.get('timeRange') || '7d'

    // Calculate date range
    const now = new Date()
    let startDate: Date

    switch (timeRange) {
      case '7d':
        startDate = new Date(now.setDate(now.getDate() - 7))
        break
      case '30d':
        startDate = new Date(now.setDate(now.getDate() - 30))
        break
      case '90d':
        startDate = new Date(now.setDate(now.getDate() - 90))
        break
      case 'all':
        startDate = new Date(0)
        break
      default:
        startDate = new Date(now.setDate(now.getDate() - 7))
    }

    // Reset now to current date
    const currentDate = new Date()

    // Total clicks in range
    const totalClicks = await db.analytics.count({
      where: {
        timestamp: {
          gte: startDate
        }
      }
    })

    // Unique clicks (by IP) in range
    const uniqueClicksResult = await db.analytics.groupBy({
      by: ['ipAddress'],
      where: {
        timestamp: {
          gte: startDate
        }
      }
    })
    const uniqueClicks = uniqueClicksResult.length

    // Top links with click counts
    const topLinks = await db.shortLink.findMany({
      where: {
        analytics: {
          some: {
            timestamp: {
              gte: startDate
            }
          }
        }
      },
      include: {
        domain: true,
        _count: {
          select: {
            analytics: {
              where: {
                timestamp: {
                  gte: startDate
                }
              }
            }
          }
        }
      },
      orderBy: {
        analytics: {
          _count: 'desc'
        }
      },
      take: 10
    })

    const topLinksFormatted = topLinks.map(link => ({
      id: link.id,
      shortUrl: `${link.domain.subdomain ? `${link.domain.subdomain}.` : ''}${link.domain.name}/${link.slug}`,
      destinationUrl: link.destinationUrl,
      clickCount: link._count.analytics
    }))

    // Clicks by domain
    const domains = await db.domain.findMany({
      where: {
        isActive: true,
        shortLinks: {
          some: {
            analytics: {
              some: {
                timestamp: {
                  gte: startDate
                }
              }
            }
          }
        }
      },
      include: {
        _count: {
          select: {
            shortLinks: true
          }
        },
        shortLinks: {
          include: {
            _count: {
              select: {
                analytics: {
                  where: {
                    timestamp: {
                      gte: startDate
                    }
                  }
                }
              }
            }
          }
        }
      }
    })

    const clicksByDomain = domains.map(domain => ({
      domainName: `${domain.subdomain ? `${domain.subdomain}.` : ''}${domain.name}`,
      clickCount: domain.shortLinks.reduce((sum, link) => sum + link._count.analytics, 0),
      linkCount: domain._count.shortLinks
    })).sort((a, b) => b.clickCount - a.clickCount)

    // Clicks by country
    const clicksByCountryResult = await db.analytics.groupBy({
      by: ['country'],
      where: {
        timestamp: {
          gte: startDate
        }
      },
      _count: true
    })

    const clicksByCountry = clicksByCountryResult
      .map(item => ({
        country: item.country,
        clickCount: item._count
      }))
      .sort((a, b) => b.clickCount - a.clickCount)

    // Recent activity
    const recentActivity = await db.analytics.findMany({
      where: {
        timestamp: {
          gte: startDate
        }
      },
      include: {
        shortLink: {
          include: {
            domain: true
          }
        }
      },
      orderBy: {
        timestamp: 'desc'
      },
      take: 20
    })

    const recentActivityFormatted = recentActivity.map(activity => ({
      id: activity.id,
      shortUrl: `${activity.shortLink.domain.subdomain ? `${activity.shortLink.domain.subdomain}.` : ''}${activity.shortLink.domain.name}/${activity.shortLink.slug}`,
      ipAddress: activity.ipAddress,
      country: activity.country,
      timestamp: activity.timestamp
    }))

    return NextResponse.json({
      totalClicks,
      uniqueClicks,
      topLinks: topLinksFormatted,
      clicksByDomain,
      clicksByCountry,
      recentActivity: recentActivityFormatted
    })
  } catch (error) {
    console.error('Error fetching analytics:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const totalDomains = await db.domain.count()
    const totalLinks = await db.shortLink.count()
    const totalClicks = await db.shortLink.aggregate({
      _sum: { clickCount: true }
    })

    // Count links created in the last 7 days
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)
    const recentLinks = await db.shortLink.count({
      where: {
        createdAt: {
          gte: sevenDaysAgo
        }
      }
    })

    return NextResponse.json({
      totalDomains,
      totalLinks,
      totalClicks: totalClicks._sum.clickCount || 0,
      recentLinks
    })
  } catch (error) {
    console.error('Error fetching dashboard stats:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}

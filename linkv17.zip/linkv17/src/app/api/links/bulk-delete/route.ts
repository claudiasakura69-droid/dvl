import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { ids } = body

    if (!ids || ids.length === 0) {
      return NextResponse.json(
        { error: 'No links selected' },
        { status: 400 }
      )
    }

    // Delete analytics for these links first
    await db.analytics.deleteMany({
      where: {
        shortLinkId: { in: ids }
      }
    })

    // Delete the links
    const result = await db.shortLink.deleteMany({
      where: {
        id: { in: ids }
      }
    })

    return NextResponse.json({
      success: true,
      count: result.count
    })
  } catch (error) {
    console.error('Error bulk deleting links:', error)
    return NextResponse.json(
      { error: 'Failed to delete links' },
      { status: 500 }
    )
  }
}

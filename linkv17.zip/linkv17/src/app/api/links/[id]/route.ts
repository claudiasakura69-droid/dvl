import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PATCH update link
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { destinationUrl, slug, isActive } = body

    const link = await db.shortLink.findUnique({
      where: { id: params.id },
      include: { domain: true }
    })

    if (!link) {
      return NextResponse.json(
        { error: 'Link not found' },
        { status: 404 }
      )
    }

    const updateData: any = {}
    
    if (destinationUrl !== undefined) {
      updateData.destinationUrl = destinationUrl
    }
    
    if (slug !== undefined && slug !== link.slug) {
      // Check if new slug already exists for this domain
      const existing = await db.shortLink.findFirst({
        where: {
          domainId: link.domainId,
          slug,
          id: { not: params.id }
        }
      })

      if (existing) {
        return NextResponse.json(
          { error: 'Slug already exists for this domain' },
          { status: 400 }
        )
      }

      updateData.slug = slug
      updateData.shortUrl = `${link.domain.subdomain ? `${link.domain.subdomain}.` : ''}${link.domain.name}/${slug}`
    }
    
    if (isActive !== undefined) {
      updateData.isActive = isActive
    }

    const updatedLink = await db.shortLink.update({
      where: { id: params.id },
      data: updateData,
      include: {
        domain: true
      }
    })

    const formattedLink = {
      ...updatedLink,
      shortUrl: `${updatedLink.domain.subdomain ? `${updatedLink.domain.subdomain}.` : ''}${updatedLink.domain.name}/${updatedLink.slug}`
    }

    return NextResponse.json(formattedLink)
  } catch (error) {
    console.error('Error updating link:', error)
    return NextResponse.json(
      { error: 'Failed to update link' },
      { status: 500 }
    )
  }
}

// DELETE link
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Delete analytics for this link first
    await db.analytics.deleteMany({
      where: { shortLinkId: params.id }
    })

    // Delete the link
    await db.shortLink.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting link:', error)
    return NextResponse.json(
      { error: 'Failed to delete link' },
      { status: 500 }
    )
  }
}

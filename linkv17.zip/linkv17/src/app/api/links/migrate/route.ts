import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { fromDomainId, toDomainId } = body

    if (!fromDomainId || !toDomainId) {
      return NextResponse.json(
        { error: 'Both from and to domains are required' },
        { status: 400 }
      )
    }

    if (fromDomainId === toDomainId) {
      return NextResponse.json(
        { error: 'Source and target domains cannot be the same' },
        { status: 400 }
      )
    }

    // Get both domains
    const fromDomain = await db.domain.findUnique({
      where: { id: fromDomainId }
    })

    const toDomain = await db.domain.findUnique({
      where: { id: toDomainId }
    })

    if (!fromDomain || !toDomain) {
      return NextResponse.json(
        { error: 'One or both domains not found' },
        { status: 404 }
      )
    }

    // Get all links from source domain
    const links = await db.shortLink.findMany({
      where: {
        domainId: fromDomainId
      }
    })

    let migratedCount = 0

    for (const link of links) {
      // Check if slug already exists in target domain
      const existing = await db.shortLink.findFirst({
        where: {
          domainId: toDomainId,
          slug: link.slug
        }
      })

      if (!existing) {
        // Update the link to use the new domain
        await db.shortLink.update({
          where: { id: link.id },
          data: {
            domainId: toDomainId,
            shortUrl: `${toDomain.subdomain ? `${toDomain.subdomain}.` : ''}${toDomain.name}/${link.slug}`
          }
        })
        migratedCount++
      }
    }

    return NextResponse.json({
      success: true,
      count: migratedCount,
      message: `Migrated ${migratedCount} links from ${fromDomain.name} to ${toDomain.name}`
    })
  } catch (error) {
    console.error('Error migrating links:', error)
    return NextResponse.json(
      { error: 'Failed to migrate links' },
      { status: 500 }
    )
  }
}

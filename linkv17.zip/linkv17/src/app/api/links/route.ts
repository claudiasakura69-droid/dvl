import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { randomBytes } from 'crypto'

function generateSlug(length: number = 6): string {
  return randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length)
}

// GET all links
export async function GET() {
  try {
    const links = await db.shortLink.findMany({
      include: {
        domain: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    const formattedLinks = links.map(link => ({
      ...link,
      shortUrl: `${link.domain.subdomain ? `${link.domain.subdomain}.` : ''}${link.domain.name}/${link.slug}`
    }))

    return NextResponse.json(formattedLinks)
  } catch (error) {
    console.error('Error fetching links:', error)
    return NextResponse.json(
      { error: 'Failed to fetch links' },
      { status: 500 }
    )
  }
}

// POST create link
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { domainId, destinationUrl, slug } = body

    // Verify domain exists and is active
    const domain = await db.domain.findUnique({
      where: { id: domainId }
    })

    if (!domain) {
      return NextResponse.json(
        { error: 'Domain not found' },
        { status: 404 }
      )
    }

    if (!domain.isActive) {
      return NextResponse.json(
        { error: 'Domain is not active' },
        { status: 400 }
      )
    }

    // Generate or use provided slug
    const finalSlug = slug || domain.slug || generateSlug()

    // Check if slug already exists for this domain
    const existingLink = await db.shortLink.findFirst({
      where: {
        domainId,
        slug: finalSlug
      }
    })

    if (existingLink) {
      return NextResponse.json(
        { error: 'Slug already exists for this domain' },
        { status: 400 }
      )
    }

    const shortLink = await db.shortLink.create({
      data: {
        shortUrl: `${domain.subdomain ? `${domain.subdomain}.` : ''}${domain.name}/${finalSlug}`,
        destinationUrl,
        slug: finalSlug,
        domainId
      },
      include: {
        domain: true
      }
    })

    const formattedLink = {
      ...shortLink,
      shortUrl: `${shortLink.domain.subdomain ? `${shortLink.domain.subdomain}.` : ''}${shortLink.domain.name}/${shortLink.slug}`
    }

    return NextResponse.json(formattedLink)
  } catch (error) {
    console.error('Error creating link:', error)
    return NextResponse.json(
      { error: 'Failed to create link' },
      { status: 500 }
    )
  }
}

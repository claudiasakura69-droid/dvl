import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { ids, findText, replaceText, field } = body

    if (!ids || ids.length === 0) {
      return NextResponse.json(
        { error: 'No links selected' },
        { status: 400 }
      )
    }

    if (!findText || !replaceText) {
      return NextResponse.json(
        { error: 'Find and replace text are required' },
        { status: 400 }
      )
    }

    const updateData: any = {}

    if (field === 'destinationUrl') {
      updateData.destinationUrl = {
        forEach: (links: any[]) => {
          links.forEach(link => {
            link.destinationUrl = link.destinationUrl.replace(new RegExp(findText, 'gi'), replaceText)
          })
        }
      }
    } else if (field === 'shortUrl') {
      // For short URL, we need to update the domain part and regenerate the shortUrl
      // This is more complex as we need to parse and update
    }

    // Get the links first
    const links = await db.shortLink.findMany({
      where: {
        id: { in: ids }
      },
      include: {
        domain: true
      }
    })

    const updatedLinks: any[] = []

    for (const link of links) {
      let updatedLink

      if (field === 'destinationUrl') {
        updatedLink = await db.shortLink.update({
          where: { id: link.id },
          data: {
            destinationUrl: link.destinationUrl.replace(new RegExp(findText, 'gi'), replaceText)
          },
          include: {
            domain: true
          }
        })
      } else if (field === 'shortUrl') {
        // Replace the domain part in shortUrl
        const newShortUrl = link.shortUrl.replace(new RegExp(findText, 'gi'), replaceText)
        
        // Parse to get the new slug (last part after /)
        const newSlug = newShortUrl.split('/').pop()
        
        if (newSlug !== link.slug) {
          // Check if new slug already exists for this domain
          const existing = await db.shortLink.findFirst({
            where: {
              domainId: link.domainId,
              slug: newSlug
            }
          })

          if (!existing) {
            updatedLink = await db.shortLink.update({
              where: { id: link.id },
              data: {
                slug: newSlug,
                shortUrl: newShortUrl
              },
              include: {
                domain: true
              }
            })
          } else {
            updatedLink = link // Skip if slug already exists
          }
        } else {
          updatedLink = link // No change needed
        }
      }

      if (updatedLink) {
        updatedLinks.push(updatedLink)
      }
    }

    return NextResponse.json({
      success: true,
      count: updatedLinks.length,
      links: updatedLinks.map(link => ({
        ...link,
        shortUrl: `${link.domain.subdomain ? `${link.domain.subdomain}.` : ''}${link.domain.name}/${link.slug}`
      }))
    })
  } catch (error) {
    console.error('Error bulk editing links:', error)
    return NextResponse.json(
      { error: 'Failed to bulk edit links' },
      { status: 500 }
    )
  }
}

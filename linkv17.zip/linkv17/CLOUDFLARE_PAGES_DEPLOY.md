# Cloudflare Pages 部署配置指南

## 环境变量配置

在 Cloudflare Pages 上部署本项目前，必须设置以下环境变量以确保应用正常运行。

### ACCESS_TOKEN
此令牌用于登录身份验证，确保只有持有正确 token 的用户可以访问 Dashboard。

#### 设置步骤：
1. 打开 Cloudflare Dashboard。
2. 进入 **Pages** 项目设置。
3. 找到 **Environment variables** 区域。
4. 添加以下内容：
   - **Variable name**: `ACCESS_TOKEN`
   - **Value**: 你设置的登录 Token（建议使用强随机字符串）
5. 保存更改。

**示例值**: `dev-token-123456` (仅用于本地开发，生产环境请更换为更复杂的值)

## 注意事项
- 环境变量保存后，Cloudflare Pages 将自动重新部署项目以应用更改。
- 请妥善保管 `ACCESS_TOKEN`，泄露将导致未经授权的访问。
- 若忘记访问令牌，可在 Cloudflare Pages 环境变量中重置或更换。

## 部署建议
建议在部署到 Cloudflare Pages 前完成以下准备：
1. 数据库已正确配置（建议使用 Cloudflare D1 或兼容的数据库）。
2. 本地测试确保所有功能正常，尤其是身份验证部分。
3. 根据需要调整 Cloudflare Pages 构建设置（如 Node 版本等）。

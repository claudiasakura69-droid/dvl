# Panduan Instalasi & Deployment Lengkap

> Panduan ini mencakup instalasi lokal dan deployment ke Cloudflare Pages untuk **Windows** dan **Linux/macOS**.

---

## Daftar Isi

1. [Prasyarat](#1-prasyarat)
2. [Instalasi Lokal — Windows](#2-instalasi-lokal--windows)
3. [Instalasi Lokal — Linux/macOS](#3-instalasi-lokal--linuxmacos)
4. [Konfigurasi Database (Neon)](#4-konfigurasi-database-neon)
5. [Konfigurasi Cloudflare](#5-konfigurasi-cloudflare)
6. [Deployment ke Cloudflare Pages](#6-deployment-ke-cloudflare-pages)
7. [Custom Domain Setup](#7-custom-domain-setup)
8. [Troubleshooting](#8-troubleshooting)

---

## 1. Prasyarat

| Tool                  | Versi Minimum | Windows Download                                | Linux/macOS                                  |
|-----------------------|---------------|-------------------------------------------------|----------------------------------------------|
| **Node.js**           | 18.x+         | https://nodejs.org (MSI installer, centang "Add to PATH") | `sudo apt install nodejs` atau https://nodejs.org |
| **npm**               | 9.x+          | Termasuk saat install Node.js                   | Termasuk saat install Node.js                 |
| **Git**               | Terbaru       | https://git-scm.com/download/win                | `sudo apt install git`                        |
| **Text Editor**       | -             | VS Code: https://code.visualstudio.com          | VS Code / nano / vim                          |
| **Akun Neon**         | -             | https://console.neon.tech (gratis)              | https://console.neon.tech (gratis)            |
| **Akun Cloudflare**   | -             | https://dash.cloudflare.com (gratis)            | https://dash.cloudflare.com (gratis)          |

### Verifikasi Instalasi

**Windows (PowerShell):**
```powershell
node --version    # Harusnya v18.x atau lebih baru
npm --version     # Harusnya 9.x atau lebih baru
git --version     # Harusnya 2.x atau lebih baru
```

**Linux/macOS (Terminal):**
```bash
node --version
npm --version
git --version
```

---

## 2. Instalasi Lokal — Windows

### Step 1: Clone Repository

```powershell
# Buka PowerShell di folder tujuan
cd C:\Users\YourName\Projects

# Clone
git clone https://github.com/username/shorturl-platform.git

# Masuk ke folder project
cd shorturl-platform
```

### Step 2: Install Dependencies

**pnpm (recommended — lebih cepat, handle peer deps lebih baik):**
```powershell
pnpm install
```

**npm (alternatif):**
```powershell
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true` dan `strict-peer-dependencies=false`.

> **Jika error "Cannot find native binding":**
> ```powershell
> rmdir /s /q node_modules
> del package-lock.json
> npm install
> ```
> Atau dengan pnpm:
> ```powershell
> rmdir /s /q node_modules
> del pnpm-lock.yaml
> pnpm install
> ```

Proses ini akan mengunduh semua dependencies (sekitar 200+ paket). Tunggu hingga selesai.

### Step 3: Setup Environment Variables

```powershell
copy .env.example .env
```

Buka file `.env` dengan editor:

```powershell
code .env
# atau
notepad .env
```

Edit isi `.env`:

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================

# DATABASE — Wajib! Lihat Section 4 untuk cara mendapatkannya
DATABASE_URL="postgresql://neondb_owner:yourpassword@ep-abc123.us-east-2.aws.neon.tech/neondb?sslmode=require"

# AUTH — Token login dashboard (WAJIB min. 12 karakter!)
DASHBOARD_TOKEN="MySecretToken123"

# APP DOMAIN — Domain utama untuk dashboard
APP_DOMAIN="yoii.me"

# CLOUDFLARE — Opsional, untuk auto-verify custom domain
CLOUDFLARE_ACCOUNT_ID=""
CLOUDFLARE_API_TOKEN=""
CLOUDFLARE_PAGES_PROJECT=""
```

### Step 4: Prisma — Setup Database

```powershell
# Push schema ke database Neon (membuat tabel-tabel)
npx prisma db push

# Generate Prisma Client (dibutuhkan oleh aplikasi)
npx prisma generate
```

**Output yang diharapkan:**
```
Your database is now in sync with your Prisma schema.

✔ Generated Prisma Client
```

**Optional — Lihat database via browser:**
```powershell
npx prisma studio
# Buka http://localhost:5555 di browser
# Ini menampilkan semua tabel dan data secara visual
```

### Step 5: Jalankan Development Server

```powershell
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser. Halaman login dashboard akan muncul.

Masukkan token yang kamu set di `DASHBOARD_TOKEN` (`.env`) untuk masuk ke dashboard. Token harus **persis sama** (case-sensitive).

> **PENTING:** Tidak ada demo token. Pastikan `DASHBOARD_TOKEN` sudah di-set di `.env`.

### Step 6: Login

Masukkan token yang kamu set di `DASHBOARD_TOKEN` (`.env`) untuk masuk ke dashboard.

> **PENTING:** Tidak ada demo token. Token harus sama persis dengan yang ada di `.env`.

---

## 3. Instalasi Lokal — Linux/macOS

### Step 1: Clone Repository

```bash
cd ~/projects
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
```

### Step 2: Install Dependencies

**pnpm (recommended):**
```bash
pnpm install
```

**npm (alternatif):**
```bash
npm install
```

> **Catatan:** File `.npmrc` sudah dikonfigurasi dengan `force=true` dan `strict-peer-dependencies=false`.**
> ```bash
> rm -rf node_modules package-lock.json
> npm install
> ```
> Atau:
> ```bash
> rm -rf node_modules pnpm-lock.yaml
> pnpm install
> ```

### Step 3: Setup Environment Variables

```bash
cp .env.example .env
nano .env  # atau vim .env, code .env
```

Isi `.env` sama seperti panduan Windows (lihat Step 3 di atas).

### Step 4: Prisma — Setup Database

```bash
npx prisma db push
npx prisma generate
```

**Optional — Prisma Studio:**
```bash
npx prisma studio
# Buka http://localhost:5555
```

### Step 5: Jalankan Development Server

```bash
pnpm dev
# atau dengan npm:
npm run dev
```

Buka **http://localhost:3000** di browser.

---

## 4. Konfigurasi Database (Neon)

### Membuat Project Neon

1. Buka https://console.neon.tech
2. Sign up / Sign in (bisa pakai GitHub)
3. Klik **Create Project**
4. Isi:
   - **Project name**: `shorturl-db` (bebas)
   - **Region**: Pilih yang terdekat dengan lokasi server (misalnya `US East`)
   - **PostgreSQL version**: Default
5. Klik **Create Project**

### Mendapat Connection String

1. Setelah project dibuat, kamu akan melihat halaman dashboard
2. Klik tab **Connection Details**
3. Copy connection string, format-nya:
   ```
   postgresql://neondb_owner:randompassword@ep-purple-cloud-123456.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
4. Paste ke `.env` sebagai `DATABASE_URL`

### Verifikasi Koneksi

```powershell
# Windows
npx prisma db push
# Jika berhasil = koneksi OK

# Optional: lihat database via browser
npx prisma studio
```

### Menambahkan `?channel_binding=require`

Jika Neon menyarankan parameter tambahan, kamu bisa menambahkannya:
```
DATABASE_URL="postgresql://...neondb?sslmode=require&channel_binding=require"
```

> **Catatan:** Kedua format (`?sslmode=require` atau `?sslmode=require&channel_binding=require`) sudah didukung.

---

## 5. Konfigurasi Cloudflare

### Mendapat Account ID

1. Buka https://dash.cloudflare.com
2. Di sidebar kanan atau URL, kamu akan melihat **Account ID**
3. Copy dan simpan

### Membuat API Token

1. Buka https://dash.cloudflare.com/profile/api-tokens
2. Klik **Create Token**
3. Pilih **Custom Token** → **Get started**
4. Konfigurasi:
   - **Token name**: `ShortURL Platform`
   - **Permissions**:
     - `Zone` → `Zone` → `Read`
     - `Zone` → `DNS` → `Edit`
     - `Account` → `Cloudflare Pages` → `Edit`
   - **Account Resources**: `Include` → `Your Account`
   - **Zone Resources**: `Include` → `All Zones` (atau specific zone)
5. Klik **Continue to Summary** → **Create Token**
6. **Copy token sekarang!** Token ini tidak bisa dilihat lagi.

### Menambah Domain ke Cloudflare

1. Buka https://dash.cloudflare.com
2. Klik **Add a Site**
3. Masukkan domain kamu (contoh: `yoii.me`)
4. Pilih plan (**Free** sudah cukup)
5. Cloudflare akan menampilkan 2 **nameserver** records
6. Buka panel domain registrar kamu (Namecheap, GoDaddy, dll)
7. Ubah nameserver domain ke nameserver Cloudflare
8. Tunggu propagasi DNS (bisa 5 menit - 48 jam, biasanya cepat)

### Membuat CF Pages Project

1. Buka https://dash.cloudflare.com → **Workers & Pages**
2. Klik **Create**
3. Pilih **Pages** → **Connect to Git**
4. Pilih repository GitHub/GitLab kamu
5. Konfigurasi build (detail di Section 6)

---

## 6. Deployment ke Cloudflare Pages

### Persiapan

Pastikan:
- [ ] Repository sudah di-push ke GitHub/GitLab
- [ ] `.env.example` ada di repo (BUKAN `.env`!)
- [ ] `.npmrc` ada di repo dan berisi `force=true` dan `strict-peer-dependencies=false`
- [ ] Semua file sudah di-commit

### Build Settings di CF Pages

| Setting               | Value                                                             |
|-----------------------|-------------------------------------------------------------------|
| **Framework preset**  | `None`                                                            |
| **Build command**     | `npx prisma generate && npx opennextjs-cloudflare build`          |
| **Build output dir**  | `.open-next`                                                       |
| **Root directory**    | `/` (default)                                                     |
| **Node.js version**   | `18` atau `20`                                                    |

### ⚠️ PENTING — JANGAN gunakan build command ini:

```bash
# SALAH — akan menyebabkan infinite loop!
npm install && npx opennextjs-cloudflare build

# SALAH — opennextjs-cloudflare build memanggil npm run build secara internal
npm run build:cf
```

Build command yang benar:
```bash
# BENAR — langsung jalankan opennextjs-cloudflare build
npx prisma generate && npx opennextjs-cloudflare build
```

> `opennextjs-cloudflare build` secara internal akan menjalankan `next build`, jadi tidak perlu dipanggil terpisah.

### Environment Variables di CF Pages

Buka project CF Pages → **Settings** → **Environment variables**

Tambahkan variabel berikut:

| Variable                   | Value                                                | Type       |
|----------------------------|------------------------------------------------------|------------|
| `DATABASE_URL`             | `postgresql://neondb_owner:xxx@ep-xxx...neondb?sslmode=require` | Plaintext |
| `DASHBOARD_TOKEN`          | Token login dashboard (min 12 karakter)              | Encrypted  |
| `APP_DOMAIN`               | `yoii.me` (domain utama)                            | Plaintext  |
| `CLOUDFLARE_ACCOUNT_ID`    | Account ID dari Cloudflare                           | Plaintext  |
| `CLOUDFLARE_API_TOKEN`     | API Token yang sudah dibuat                         | Encrypted  |
| `CLOUDFLARE_PAGES_PROJECT` | `app-yoii` (nama project CF Pages)                  | Plaintext  |

> **Tips:** Untuk variabel sensitif seperti `DASHBOARD_TOKEN` dan `CLOUDFLARE_API_TOKEN`, gunakan tombol **Encrypt** di CF Pages.

### Proses Deploy

1. Push perubahan ke repository:
   ```bash
   git add .
   git commit -m "Deploy to Cloudflare Pages"
   git push origin main
   ```

2. Cloudflare Pages akan otomatis:
   - Pull code dari repository
   - Install dependencies (menggunakan `.npmrc`)
   - Jalankan build command
   - Deploy ke CDN global

3. Cek status build di:
   - CF Pages Dashboard → **Deployments** tab
   - Kamu akan melihat log build secara real-time

4. Jika build berhasil, domain akan diaktifkan:
   - `your-project.pages.dev`
   - Custom domain (jika sudah dikonfigurasi)

### Custom Domain di CF Pages

1. Buka project CF Pages → **Custom domains**
2. Klik **Set up a custom domain**
3. Masukkan domain (contoh: `yoii.me`)
4. Cloudflare akan otomatis mengkonfigurasi DNS
5. SSL certificate akan otomatis diprovisioning (biasanya 15-30 menit)

---

## 7. Custom Domain Setup

Platform ini mendukung **multi-domain** — satu dashboard bisa melayani banyak domain untuk short URL.

### Domain Utama (APP_DOMAIN)

- Domain yang digunakan untuk mengakses dashboard
- Diatur di `APP_DOMAIN` environment variable
- Contoh: `yoii.me` → dashboard bisa diakses di `https://yoii.me`

### Custom Domain untuk Short URL

Kamu bisa menambahkan domain lain (misalnya `link.co`, `go.domain.com`) yang akan digunakan khusus untuk short URL redirect.

**Cara menambahkan:**

1. **Tambahkan domain ke Cloudflare** (jika belum):
   - CF Dashboard → Add a Site → masukkan domain
   - Ubah nameserver di registrar

2. **Di dashboard aplikasi**, buka menu **Domains**
3. Klik **Add Domain**
4. Masukkan domain (contoh: `link.co`)
5. Klik **Verify** — sistem akan otomatis memverifikasi via Cloudflare API

**Cara kerja routing:**
- Request ke `yoii.me` → Dashboard (halaman login/manajemen link)
- Request ke `link.co/abc` → Redirect ke target URL
- Request ke `link.co/` (tanpa path) → 404 styled page

---

## 8. Troubleshooting

### `tee is not recognized` (Windows)

**Penyebab:** Script `dev` di `package.json` menggunakan `tee` (perintah Linux).

**Solusi:** Script sudah diperbaiki untuk cross-platform. Jika masih terjadi:

```powershell
npx next dev -p 3000
```

### Halaman 404 di localhost

**Penyebab:** Middleware memblokir request karena hostname (`localhost`) tidak cocok dengan `APP_DOMAIN`.

**Solusi:** Pastikan `middleware.ts` memiliki pengecekan localhost:

```typescript
// Allow localhost / 127.0.0.1 for local development
if (hostname === 'localhost' || hostname === '127.0.0.1') {
  return NextResponse.next();
}
```

Jika sudah ada dan masih 404, hapus cache:

```powershell
# Windows
rmdir /s /q .next
npm run dev

# Linux/macOS
rm -rf .next
npm run dev
```

### Infinite loop saat build di CF Pages

**Penyebab:** Build command memanggil `npm run build` yang memanggil `opennextjs-cloudflare build` → infinite recursion.

**Solusi:** Pastikan build command HANYA:
```bash
npx prisma generate && npx opennextjs-cloudflare build
```

JANGAN tambahkan `npm install` atau `npm run build`.

### `ERESOLVE` error saat `npm install`

**Penyebab:** Peer dependency conflict antar paket Radix UI.

**Solusi:**
1. Pastikan `.npmrc` berisi `force=true` (BUKAN `legacy-peer-deps=true`)
2. Hapus `node_modules` dan `package-lock.json`, lalu `npm install`
3. Atau gunakan `pnpm install` yang menangani peer deps lebih baik

> **JANGAN gunakan `--legacy-peer-deps`!** Flag ini memiliki bug yang menyebabkan optional dependencies tidak terinstall (lihat error di bawah).

### Error `Cannot find native binding` (@tailwindcss/oxide)

**Penyebab:** `@tailwindcss/oxide` membutuhkan native binding (binary khusus platform) yang tidak terinstall. Ini adalah bug npm saat menggunakan `--legacy-peer-deps` (https://github.com/npm/cli/issues/4828).

**Solusi:**
1. Pastikan `.npmrc` berisi `force=true` (BUKAN `legacy-peer-deps=true`)
2. Hapus semua cache dan reinstall:

```powershell
# Windows
rmdir /s /q node_modules
del package-lock.json
npm install
```

```bash
# Linux/macOS
rm -rf node_modules package-lock.json
npm install
```

### `prisma generate` error: `driverAdapters` not found

**Penyebab:** Preview feature `driverAdapters` belum diaktifkan di schema.

**Solusi:** Pastikan `prisma/schema.prisma` memiliki:

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")
  directUrl = env("DIRECT_URL")
  previewFeatures = ["driverAdapters"]
}
```

### Build error: `neon()` crash saat build

**Penyebab:** `neon()` memvalidasi connection string saat build, tapi `DATABASE_URL` belum tersedia di environment build.

**Solusi:** `src/lib/db.ts` sudah dilengkapi placeholder fallback. Pastikan kodenya:

```typescript
const sql = neon(
  connectionString && connectionString.startsWith('postgresql://')
    ? connectionString
    : 'postgresql://placeholder:placeholder@localhost/placeholder'
);
```

### Login tidak bisa di localhost

**Penyebab 1:** `DASHBOARD_TOKEN` tidak di-set di `.env`
**Penyebab 2:** Token yang dimasukkan di halaman login tidak sama dengan `DASHBOARD_TOKEN`
**Penyebab 3:** Token lama tersimpan di localStorage browser dari versi sebelumnya

**Solusi:**
1. Cek `.env` — pastikan `DASHBOARD_TOKEN` ada dan min. 12 karakter
2. Restart dev server setelah mengubah `.env`
3. Masukkan token yang **persis sama** (case-sensitive, tanpa spasi)
4. Jika masih tidak bisa, buka DevTools browser → Console → jalankan `localStorage.removeItem("token")` lalu reload

### API calls return "Unauthorized" (401)

**Penyebab:** Token yang tersimpan di browser (localStorage) berbeda dengan `DASHBOARD_TOKEN` di `.env`. Ini bisa terjadi karena:
- Sebelumnya login dengan demo token yang sudah dihapus
- Mengubah `DASHBOARD_TOKEN` di `.env` tanpa logout dan login ulang

**Solusi:**
1. Logout dari dashboard (Settings → atau buka DevTools → `localStorage.removeItem("token")`)
2. Reload halaman
3. Login ulang dengan token yang sesuai `DASHBOARD_TOKEN` di `.env`

### Database tidak terhubung

**Cara cek koneksi:**
```powershell
npx prisma db push
```
Jika error, cek:
1. `DATABASE_URL` di `.env` sudah benar
2. Format connection string: `postgresql://user:pass@host/db?sslmode=require`
3. Database Neon masih aktif (buka console.neon.tech, cek project status)
4. Jika Neon project "suspended", buka console dan aktifkan kembali

### Error `qrcode` di Cloudflare Workers

**Penyebab:** Paket `qrcode` menggunakan Node.js Canvas API yang tidak tersedia di Workers.

**Solusi:** Project sudah menggunakan `react-qr-code` (SVG-based, edge-compatible). Jika ada error, cek `package.json` dan pastikan tidak ada `qrcode` di dependencies.

---

## File Penting yang Wajib Ada

Sebelum deploy, pastikan file-file ini ada di repository:

```
.env.example                    # Template env vars (commit ini)
.npmrc                          # force=true, strict-peer-dependencies=false (commit ini)
prisma/schema.prisma            # Database schema (commit ini)
src/lib/db.ts                   # DB connection with neon adapter (commit ini)
src/middleware.ts                # Multi-domain routing (commit ini)
open-next.config.ts             # Cloudflare adapter config (commit ini)
wrangler.toml                   # Workers config (commit ini)
next.config.ts                  # Next.js config (commit ini)
package.json                    # Dependencies dan scripts (commit ini)
```

**JANGAN commit:** `.env`, `.next/`, `node_modules/`, `prisma/*.db`

Pastikan `.gitignore` berisi:
```
.env
.env.local
.next/
node_modules/
prisma/*.db
*.log
```

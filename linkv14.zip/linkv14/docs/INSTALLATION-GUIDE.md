# Panduan Instalasi & Deployment — ShortURL Platform

> Platform manajemen Short URL (clone Dub.co) — **Next.js 16 + Prisma + Neon PostgreSQL + Cloudflare Pages**
>
> Berdasarkan [OpenNext Cloudflare official docs](https://opennext.js.org/cloudflare/get-started).

---

## 1. Prasyarat

| Tool                    | Versi Minimum | Download                                |
|-------------------------|---------------|-----------------------------------------|
| **Node.js**             | 18.x+         | https://nodejs.org                       |
| **Git**                 | Terbaru       | https://git-scm.com                      |
| **Neon PostgreSQL**     | -             | https://console.neon.tech (gratis)       |
| **Akun Cloudflare**     | -             | https://dash.cloudflare.com (gratis)     |

---

## 2. Instalasi Lokal

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
npm install
cp .env.example .env
# Edit .env dengan DATABASE_URL (Neon), DASHBOARD_TOKEN, APP_DOMAIN

npx prisma db push
npx prisma generate
npm run dev
# Buka http://localhost:3000 → login dengan DASHBOARD_TOKEN
```

### Environment Variables (.env)

| Variable          | Deskripsi                                  | Contoh                                                       |
|-------------------|--------------------------------------------|--------------------------------------------------------------|
| `DATABASE_URL`    | Neon PostgreSQL connection string           | `postgresql://neondb_owner:pass@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN` | Token login dashboard (min 12 karakter)    | `MySecretToken123`                                            |
| `APP_DOMAIN`      | Domain utama dashboard (atau `*.pages.dev`) | `myproject.pages.dev`                                         |

---

## 3. Deployment ke Cloudflare Pages

### 3.1 Persyaratan File di Repository

Pastikan file-file ini ada di repo:

| File                   | Fungsi                                        |
|------------------------|-----------------------------------------------|
| `wrangler.jsonc`       | CF Pages config (`pages_build_output_dir`, `nodejs_compat`) |
| `open-next.config.ts`  | OpenNext CF adapter config                    |
| `next.config.ts`       | Next.js config                                |
| `package.json`         | dependencies & scripts                        |
| `.env.example`         | Template env vars                            |
| `prisma/schema.prisma` | Database schema (PostgreSQL + Neon adapter)   |

### 3.2 Push ke GitHub

```bash
git add .
git commit -m "Configure for Cloudflare Pages deployment"
git push origin main
```

### 3.3 Buat Project di Cloudflare Pages

1. Buka **Cloudflare Dashboard** → **Workers & Pages** → **Create**
2. Pilih **Connect to Git** → pilih repository GitHub
3. Setting konfigurasi:

| Setting                  | Value                                                  |
|--------------------------|--------------------------------------------------------|
| **Framework preset**     | `None`                                                 |
| **Build command**        | `npx prisma generate && npx @opennextjs/cloudflare build` |
| **Build output directory** | `.open-next`                                         |
| **Node.js version**      | `20` (atau latest)                                    |

4. Klik **Save and Deploy** — build pertama mungkin gagal (belum ada env vars, itu normal)

### 3.4 Set Environment Variables

**INI YANG PALING PENTING!** Tanpa ini, halaman akan blank.

1. Buka **Workers & Pages** → project → **Settings** → **Environment variables**
2. Klik **Add** dan tambahkan di **KEDUA** tab (Production **DAN** Preview):

| Variable          | Type   | Value (contoh)                                                   |
|-------------------|--------|----------------------------------------------------------------|
| `DATABASE_URL`    | Secret | `postgresql://neondb_owner:pass@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN` | Secret | `MySecretToken123`                                                 |
| `APP_DOMAIN`      | Text   | `yourproject.pages.dev`                                            |

3. Klik **Encrypt** (untuk Secret) dan **Save** di masing-masing tab
4. Pergi ke **Deployments** → klik **Retry deployment** pada deployment terbaru

> **Kenapa "Build environment variables: (none found)"?**
> Ini normal saat pertama kali deploy (belum ada env vars). Setelah menambahkan env vars di atas dan retry deployment, vars akan tersedia di build berikutnya.

### 3.5 Runtime Settings

Di Settings → **Runtime**:

| Setting                | Value               |
|------------------------|---------------------|
| **Compatibility date** | `2025-04-01`        |
| **Compatibility flags** | `nodejs_compat`    |

> `nodejs_compat` WAJIB — memungkinkan `process.env` bekerja di CF Pages/Workers runtime. Tanpa ini, database connection akan gagal dan halaman blank.

---

## 4. Tentang `wrangler.jsonc`

```jsonc
{
  "name": "shorturl-platform",
  "pages_build_output_dir": ".open-next",
  "compatibility_date": "2025-04-01",
  "compatibility_flags": ["nodejs_compat"]
}
```

**Field penting:**

| Field                        | Fungsi                                              |
|------------------------------|------------------------------------------------------|
| `pages_build_output_dir`     | CF Pages output directory                            |
| `nodejs_compat`              | WAJIB — enable `process.env`, `Buffer`, dll        |

> **JANGAN** menambahkan `main`, `assets`, `services`, `keep_vars` — field tersebut untuk **Workers** deployment, bukan Pages.

---

## 5. Database: Neon Serverless Adapter

Project ini menggunakan **Neon Serverless Adapter** (`@prisma/adapter-neon` + `@neondatabase/serverless`) untuk koneksi database.

**Mengapa bukan Prisma standard?**
- Standard PrismaClient menggunakan koneksi TCP yang **tidak didukung** di Cloudflare Workers runtime
- Neon serverless adapter menggunakan WebSocket/HTTP yang kompatibel dengan edge runtime
- Ini adalah **root cause** utama halaman blank pada deployment sebelumnya

**File `src/lib/db.ts`:**
```ts
import { PrismaClient } from "@prisma/client";
import { Pool } from "@neondatabase/serverless";
import { PrismaNeon } from "@prisma/adapter-neon";

function createPrismaClient() {
  const connectionString = process.env.DATABASE_URL!;
  const pool = new Pool({ connectionString });
  const adapter = new PrismaNeon(pool);
  return new PrismaClient({ adapter });
}
```

---

## 6. Custom Domain

1. CF Pages → **Custom domains** → **Set up a custom domain**
2. Masukkan domain (misal: `s.mydomain.com`)
3. Tambahkan **CNAME** record di DNS: `s.mydomain.com` → `yourproject.pages.dev`
4. SSL otomatis aktif (15-30 menit)
5. Update `APP_DOMAIN` env var di CF Pages Settings
6. Retry deployment

### Custom Domain untuk Short Links

1. Di dashboard, buka **Domains** → **Add Domain**
2. Masukkan domain short URL (misal: `link.mydomain.com`)
3. Tambahkan **CNAME** record di DNS: `link.mydomain.com` → `yourproject.pages.dev`
4. Middleware akan otomatis menangani routing:
   - `/` → 404 halaman
   - `/slug` → redirect ke target URL

---

## 7. Troubleshooting

### "Build environment variables: (none found)"

Ini **bukan** error — berarti env vars belum di-set. Lihat **section 3.4** di atas.

### Halaman blank setelah deploy

**Penyebab paling umum:**

1. **Env vars belum di-set** → Tambahkan di Settings → Environment variables (Production + Preview)
2. **`nodejs_compat` belum aktif** → Cek Runtime settings
3. **Database connection gagal** → Pastikan `DATABASE_URL` Neon benar dan adapter terinstall

**Cara debug:**
1. Buka browser DevTools → **Console** → periksa error
2. Buka CF Dashboard → **Workers & Pages** → project → **Logs** → lihat real-time logs
3. Push commit baru atau klik **Retry deployment**

### Login tidak bisa

1. Pastikan `DASHBOARD_TOKEN` sama di `.env` lokal dan CF dashboard
2. Browser: `localStorage.removeItem("token")` → reload
3. Cek CF Pages Logs untuk error dari `/api/auth/login`

### Error Prisma di CF Pages

```bash
# Pastikan packages terinstall
npm install @prisma/adapter-neon @neondatabase/serverless ws

# Regenerate Prisma client
npx prisma generate
```

---

## 8. Ringkasan

```bash
# Lokal
npm install && cp .env.example .env && npx prisma db push && npx prisma generate && npm run dev

# Deploy ke CF Pages
git push → CF Pages → Settings → Env Vars → Retry deploy
```

# ShortURL Platform

Short URL management platform (Dub.co clone) — Next.js 16 + Prisma + Neon PostgreSQL + Cloudflare Pages.

## Features

- 🔗 Multi-domain short URLs with analytics
- 🎯 Basic & multi-target redirect (sequential/random, country/IP routing)
- 📊 Click analytics with charts (country, device, browser, OS)
- 📱 QR code generation
- 🏥 Health check for link targets
- 📦 Bulk operations (import/export, bulk create, delete, activate/deactivate)
- 🌐 Custom domain support
- 🌗 Dark/light theme, responsive dashboard
- ⚙️ Settings (redirect status, default UTM, export/import, danger zone)

## Quick Start (Local Development)

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
npm install
cp .env.example .env   # edit with your Neon DB URL, DASHBOARD_TOKEN, APP_DOMAIN

npx prisma db push      # create tables in Neon PostgreSQL
npx prisma generate     # generate Prisma client
npm run dev             # http://localhost:3000
```

### Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Neon PostgreSQL connection string | `postgresql://user:pass@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN` | Token for dashboard login (min 12 chars) | `MySecureToken123!` |
| `APP_DOMAIN` | Your `*.pages.dev` URL or custom domain | `myproject.pages.dev` |

> Get a free Neon database at [https://console.neon.tech](https://console.neon.tech)

---

## Deploy to Cloudflare Pages

### Step 1: Push to GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### Step 2: Connect to Cloudflare Pages

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
2. Select your GitHub repository
3. Set build settings:

| Setting | Value |
|---------|-------|
| **Build command** | `npx prisma generate && npx @opennextjs/cloudflare build` |
| **Build output directory** | `.open-next` |
| **Node.js version** | `20` (or latest) |

4. Click **Save and Deploy**

### Step 3: Add Environment Variables

1. Go to your Pages project → **Settings** → **Environment variables**
2. Add these variables in **BOTH** "Production" and "Preview" tabs:

| Variable | Type | Value |
|----------|------|-------|
| `DATABASE_URL` | **Secret** | Your Neon connection string |
| `DASHBOARD_TOKEN` | **Secret** | Your dashboard login token |
| `APP_DOMAIN` | **Text** | `yourproject.pages.dev` |

3. Click **Save** → Go to **Deployments** → **Retry deployment**

### Step 4: Verify

- Visit `https://yourproject.pages.dev`
- You should see the login page
- Enter your `DASHBOARD_TOKEN` to sign in

---

## How It Works

### Architecture

- **Frontend**: Single-page app using Zustand for state management (no routing — client-side page switching)
- **Backend**: Next.js API routes with Prisma ORM
- **Database**: Neon PostgreSQL (serverless, edge-compatible)
- **Deployment**: `@opennextjs/cloudflare` converts Next.js build to CF Pages format

### Short Link Redirect Flow

1. Visitor goes to `customdomain.com/slug`
2. Middleware detects custom domain → rewrites to `/s/slug`
3. `/s/[slug]/route.ts` looks up the link in the database
4. Records click analytics (IP, country, device, browser, OS, referrer via CF headers)
5. Applies multi-target routing rules (country, IP, sequential/random)
6. Redirects with HTTP 301 + optional UTM parameters

### Multi-Target Routing Priority

1. **IP-based** → Match visitor IP against allowed IP lists
2. **Country-based** → Match visitor country (from `cf-ipcountry` header)
3. **ALL** → Fallback targets for everyone else
4. **Mode**: `sequential` (round-robin) or `random`

---

## Project Structure

```
src/
├── app/
│   ├── page.tsx              # Entry point (login/dashboard router)
│   ├── layout.tsx            # Root layout with theme provider
│   ├── s/[slug]/route.ts     # Short link redirect handler
│   └── api/
│       ├── auth/             # Login & auth check
│       ├── links/            # Links CRUD, bulk ops, clicks, health check
│       ├── domains/          # Domains CRUD & verify
│       ├── analytics/        # Analytics overview
│       ├── settings/         # App settings
│       ├── export/           # Export data (JSON)
│       ├── import/           # Import data (JSON)
│       └── danger/           # Destructive operations
├── components/
│   ├── pages/                # Page components (login, dashboard, etc.)
│   ├── dashboard/            # Layout, sidebar, header
│   ├── links/                # Link table, forms, QR code, analytics dialog
│   ├── domains/              # Domain cards, add/edit dialogs
│   └── analytics/            # Charts (clicks, country, device)
├── lib/
│   ├── api.ts                # Frontend API client
│   ├── auth.ts               # Auth middleware helper
│   ├── db.ts                 # Prisma client with Neon adapter
│   ├── store.ts              # Zustand store
│   ├── types.ts              # TypeScript interfaces
│   └── utils.ts              # Utility functions
└── middleware.ts             # Multi-domain routing middleware
```

---

## Custom Domains

1. Add domain in **Domains** page
2. In Cloudflare DNS, add a **CNAME** record pointing to `yourproject.pages.dev`
3. In Cloudflare Pages → **Custom domains**, add the domain
4. The middleware will route short links on custom domains automatically

## License

MIT

# Sistem Role & Permissions

## Overview

Sistem ini memiliki 5 level user role dengan permission yang berbeda-beda sesuai kebutuhan bisnis.

## User Roles

### 1. MASTER
- **Izin Tertinggi**
- Tidak dapat diubah (protected)
- Dibuat melalui environment variables di Cloudflare Pages
- **Permissions**:
  - ✅ Edit user (termasuk role)
  - ✅ Delete user
  - ✅ Add user
  - ✅ Edit user roles
  - ✅ Create banks
  - ✅ Edit banks
  - ✅ Delete banks
  - ✅ Move banks (deposit ↔ withdraw)
  - ✅ Toggle bank status (online/offline)
  - ✅ Create transactions
  - ✅ Edit transactions
  - ✅ Delete transactions
  - ✅ Process transactions (ubah status ke COMPLETE)
  - ✅ Create expenses
  - ✅ Delete expenses
  - ✅ Create mistakes
  - ✅ Delete mistakes

### 2. SUPERVISOR
- **Izin Tinggi**
- Dapat dibuat oleh MASTER atau environment variables
- **Permissions**:
  - ✅ Edit user
  - ❌ Delete user (tidak boleh delete user)
  - ✅ Add user
  - ✅ Edit user roles (ke level yang lebih rendah)
  - ✅ Create banks
  - ✅ Edit banks
  - ✅ Delete banks
  - ✅ Move banks
  - ✅ Toggle bank status
  - ✅ Create transactions
  - ✅ Edit transactions
  - ✅ Delete transactions
  - ✅ Process transactions
  - ✅ Create expenses
  - ✅ Delete expenses
  - ✅ Create mistakes
  - ✅ Delete mistakes

### 3. SUPPORT
- **Izin Menengah**
- **Permissions**:
  - ❌ Edit users
  - ❌ Delete users
  - ❌ Add users
  - ❌ Edit user roles
  - ✅ Create banks
  - ✅ Edit banks
  - ✅ Delete banks
  - ✅ Move banks
  - ✅ Toggle bank status
  - ✅ Create transactions
  - ✅ Edit transactions
  - ✅ Delete transactions
  - ✅ Process transactions
  - ✅ Create expenses
  - ✅ Delete expenses
  - ✅ Create mistakes
  - ✅ Delete mistakes

### 4. ADMIN (Staff)
- **Izin Rendah**
- **Permissions**:
  - ❌ Edit users
  - ❌ Delete users
  - ❌ Add users
  - ❌ Edit user roles
  - ❌ Create banks (tidak bisa edit di menu bank)
  - ❌ Edit banks
  - ❌ Delete banks
  - ❌ Move banks
  - ✅ Toggle bank status (bisa set online/offline)
  - ✅ Create transactions
  - ✅ Edit transactions
  - ✅ Delete transactions
  - ✅ Process transactions
  - ✅ Create expenses
  - ✅ Delete expenses
  - ✅ Create mistakes
  - ✅ Delete mistakes

### 5. VIEW
- **Izin Terendah (Read-Only)**
- Default role untuk user baru
- Semua fitur terkunci
- Hanya dapat melihat data
- Bisa logout

## Workflow User Baru

### Melalui Master (Menu User)

1. **Login sebagai MASTER**
2. Buka menu **User**
3. Klik tombol **Tambah User**
4. Isi form:
   - Username
   - Token (password)
   - Role (default: VIEW)
5. Klik Simpan

User baru akan memiliki role **VIEW** secara default.

### Mengubah Role User

1. Login sebagai **MASTER** atau **SUPERVISOR**
2. Buka menu **User**
3. Cari user yang ingin diubah
4. Klik tombol **Edit Role**
5. Pilih role baru (MASTER hanya bisa diubah oleh MASTER, SUPERVISOR bisa diubah oleh MASTER atau SUPERVISOR, dll)
6. Klik Simpan

### Melalui Environment Variables (Cloudflare Pages)

Untuk production, user dapat ditambahkan melalui environment variables:

**Format**: `USER_{username}_TOKEN_{role}`

Contoh:
```
USER_admin_TOKEN_MASTER=master123@
USER_supervisor_TOKEN_SUPERVISOR=supervisor123@
USER_staff_TOKEN_ADMIN=staff123@
```

Catatan:
- User MASTER hanya dapat dibuat melalui environment variables
- Jika environment variable dihapus, user tidak akan bisa login
- User baru dari environment variables harus memiliki role yang ditentukan

## Transaction Status

Setiap transaksi memiliki 2 status:

### PENDING
- Transaksi baru default status PENDING
- Tidak mempengaruhi balance bank
- Masih dapat diedit
- Dapat dihapus

### COMPLETE
- Transaksi yang sudah selesai diproses
- Memengaruhi balance bank
- Tidak dapat diedit atau dihapus (kecuali oleh MASTER/SUPERVISOR)
- Ditolak (rejected) akan revert balance

## Transaction Details

Setiap transaksi mencatat:

### Daily Transaction (Day)
- **Tanggal & Waktu**: Kapan transaksi dilakukan
- **Nama**: Nama pengirim/penerima
- **Bank**: Bank asal (dari list Bank)
- **Nominal**: Jumlah uang
- **Tujuan Bank**: Bank tujuan (opsional, dari list Bank atau "lain")
- **Status**: PENDING atau COMPLETE
- **Processed By**: User yang memproses (ubah ke COMPLETE)
- **Notes**: Catatan tambahan

### In/Out
- **Tanggal & Waktu**: Kapan perpindahan dilakukan
- **Bank Pengirim**: Bank asal (dari list atau "lain")
- **Nominal**: Jumlah uang
- **Bank Penerima**: Bank tujuan (dari list atau "lain")
- **Status**: PENDING atau COMPLETE
- **Processed By**: User yang memproses
- **Notes**: Catatan

### Expense
- **Tanggal & Waktu**: Kapan expense dilakukan
- **Kategori**: Jenis expense
- **Nominal**: Jumlah uang
- **Notes**: Catatan
- **Processed By**: User yang memproses

### Mistake
- **Tanggal & Waktu**: Kapan kesalahan tercatat
- **Bank**: Bank yang terkena (opsional)
- **Nominal**: Jumlah uang
- **Notes**: Catatan
- **Processed By**: User yang memproses

## Format Export Excel

Export data dalam format Excel dengan layout:

### Sheet Transaksi Harian (per tanggal)
Nama sheet: Format tanggal Indonesia (misal: "4 Apr 26")

**Layout Deposit** (mulai A1):
| A | B | C | D | E | F | G |
|---|---|---|---|---|---|---|
| tgl-bln-tahun Waktu | nama | bank | nominal | tujuan bank | status | proses (note) |

**Contoh Baris Deposit**:
```
4-Apr-2026 17:50 | Feri | BCA - Feri | Rp. 100.000 | Dana - Sukri | Complete | Admin1
```

**Layout Withdraw** (mulai K1):
| K | L | M | N | O | P | Q |
|---|---|---|---|---|---|---|
| tgl-bln-tahun Waktu | nama | bank | nominal | tujuan bank | status | proses (note) |

**Total**:
- Total Deposit ditampilkan di bawah data deposit
- Total Withdraw ditampilkan di bawah data withdraw

### Sheet In/Out
**Layout**:
| A | B | C | D | E | F |
|---|---|---|---|---|---|
| tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note) |

**Contoh**:
```
4-Apr-2026 17:51 | BCA - Feri | Rp. 100.000 | Dana - Sukri | Complete | Admin1
4-Apr-2026 17:52 | Telkomsel | Rp. 1.000.000 | lain | Complete | Admin1
4-Apr-2026 17:53 | lain | Rp. 1.000.000 | Dana - Sukri | Complete | Admin1
```

Catatan:
- "lain" dapat digunakan jika bank tidak ada di list
- Format sama untuk semua data

### Sheet Expense
**Layout**:
| A | B | C | D | E |
|---|---|---|---|---|
| tgl-bln-tahun Waktu | kategori | nominal | notes | proses (note) |

### Sheet Mistake
**Layout**:
| A | B | C | D | E |
|---|---|---|---|---|
| tgl-bln-tahun Waktu | bank | nominal | notes | proses (note) |

## User Credentials untuk Login

### Default Users (Local Development)

1. **MASTER**
   - Username: `admin`
   - Token: `master123@`

2. **SUPERVISOR**
   - Username: `supervisor`
   - Token: `supervisor123@`

3. **SUPPORT**
   - Username: `support`
   - Token: `support123@`

4. **ADMIN (Staff)**
   - Username: `staff`
   - Token: `staff123@`

5. **VIEW**
   - Username: `viewer`
   - Token: `viewer123@`

### Menambah User di Production

Di Cloudflare Pages:

1. Buka **Settings** > **Environment variables**
2. Tambahkan variable baru dengan format:
   ```
   USER_{username}_TOKEN_{role}=token_value
   ```
3. Klik **Save and Deploy**

Contoh:
```
USER_staff1_TOKEN_VIEW=staff123@
USER_manager_TOKEN_ADMIN=manager456@
USER_operator_TOKEN_SUPPORT=operator789@
```

## Security Notes

### Important:
1. **MASTER Role Protection**:
   - User MASTER tidak dapat dihapus
   - Role MASTER tidak dapat diubah
   - Hanya environment variables yang bisa create user MASTER

2. **Role Hierarchy**:
   - User dengan role lebih tinggi bisa mengubah role user yang lebih rendah
   - MASTER > SUPERVISOR > SUPPORT > ADMIN > VIEW
   - SUPERVISOR tidak bisa mengubah role MASTER
   - SUPPORT tidak bisa mengubah role SUPERVISOR/MASTER
   - Dst.

3. **Environment Variables**:
   - Jangan hardcode credentials di code
   - Gunakan environment variables untuk production
   - Rotate token secara berkala

4. **Transaction Security**:
   - Transaksi PENDING tidak memengaruhi balance
   - Transaksi COMPLETE mengubah balance bank
   - Mengubah status COMPLETE ke PENDING akan revert balance
   - Hanya user dengan permission yang bisa mengubah status

## Troubleshooting

### Tidak bisa login setelah role diubah

1. Cek role user di menu Users
2. Jika role VIEW, hanya bisa melihat, tidak bisa create/edit
3. Hubungi MASTER atau SUPERVISOR untuk mengubah role

### Balance tidak sesuai

1. Cek transaksi dengan status COMPLETE
2. Transaksi PENDING tidak mengubah balance
3. Hubungi user yang memproses transaksi

### User baru tidak bisa login

1. Cek apakah user ada di menu Users
2. Cek role - user VIEW hanya bisa melihat
3. Cek apakah user aktif
4. Untuk production, cek environment variables

# Cloudflare Pages Deployment Guide

## Prerequisites

1. Repository sudah di-push ke GitHub
2. Database (PostgreSQL Neon) harus disiapkan terpisah
3. Environment variables harus diset di Cloudflare Pages

## Setup Database

Karena aplikasi ini menggunakan PostgreSQL dengan Prisma, dan Cloudflare Pages adalah platform serverless static, ada beberapa pilihan:

### Opsi 1: Neon PostgreSQL (Direkomendasikan untuk Production)

1. Buat database baru di [Neon Console](https://console.neon.tech/)
2. Copy connection string dari Neon
3. Set environment variable di Cloudflare Pages:
   - `DATABASE_URL`: connection string dari Neon
   - `NEXTAUTH_SECRET`: random string untuk autentikasi
   - `MASTER_USERS`: admin/master123 (untuk user default)

### Opsi 2: Cloudflare D1 (Untuk Development - BETA)

Untuk menggunakan Cloudflare D1:
1. Buat D1 database di Cloudflare dashboard
2. Update `prisma/schema.prisma` untuk menggunakan D1 provider
3. Export database schema dan import ke D1

## Environment Variables yang Diperlukan

Di Cloudflare Pages Settings > Environment Variables, tambahkan:

1. `DATABASE_URL`
   - Connection string ke database PostgreSQL
   - Contoh: `postgresql://user:password@host:port/database?sslmode=require`

2. `NEXTAUTH_SECRET`
   - Random string untuk session encryption
   - Generate dengan: `openssl rand -base64 32`
   - Contoh: `your-random-secret-string-here`

3. `MASTER_USERS` (Opsional)
   - Format: `username:token`
   - Default: `admin:master123`

4. `NEXTAUTH_URL` (Opsional)
   - URL aplikasi Anda
   - Cloudflare Pages akan mengisi ini otomatis

## Deployment ke Cloudflare Pages

### Method 1: Melalui Cloudflare Dashboard

1. Buka [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Masuk ke Pages
3. Klik "Create a project" atau "Connect to Git"
4. Pilih repository GitHub Anda
5. Configure build settings:
   - **Framework preset**: Next.js
   - **Build command**: `bun install && bun run build`
   - **Build output directory**: `out`
   - **Root directory**: `/`
6. Klik "Save and Deploy"

### Method 2: Melalui Wrangler CLI

```bash
# Install wrangler
npm install -g wrangler

# Login ke Cloudflare
wrangler login

# Deploy
wrangler pages deploy . --project-name=bank-management
```

## Perubahan yang Dibuat untuk Cloudflare Pages

### 1. `next.config.ts`
- Dihapus `output: "standalone"`
- Ditambahkan `output: "export"` untuk static export
- Ditambahkan `images.unoptimized: true`

### 2. `package.json`
- Build command diubah ke: `"next build"`
- Menghapus perintah copy untuk standalone mode

### 3. `public/_headers`
- Menambahkan security headers
- Mengatur cache policy untuk static assets

### 4. `.cloudflare/pages.json`
- Konfigurasi build khusus Cloudflare Pages
- Build command: `bun install && bun run build`
- Output directory: `out`

## Catatan Penting

### Database Connection
- Cloudflare Pages mendukung HTTP-only request (tidak ada environment variables di runtime)
- Gunakan connection string yang support HTTP (Neon support HTTP)
- Untuk production, gunakan database provider yang mendukung serverless

### API Routes
- API routes tidak akan berfungsi di static export mode
- Fitur yang memerlukan server-side processing tidak akan tersedia
- Untuk fitur server-side, pertimbangkan:
  - Cloudflare Functions
  - Cloudflare Pages Functions
  - Pindah ke hosting dengan full Node.js support (Vercel, Railway, dll)

### Fitur yang Tidak Akan Berjalan di Cloudflare Pages (Static Export)

Karena kita menggunakan `output: "export"`, fitur berikut TIDAK akan berjalan:

❌ **TIDAK BERJALAN:**
- API routes (`/api/*`)
- Server-side rendering dinamis
- Server actions
- Database operations dari backend
- Login/session management
- Semua fitur yang memerlukan server

✅ **TETAP BERJALAN:**
- Static UI rendering
- Client-side interactions (hanya jika data static)

## Solusi Alternatif untuk Production

### Option 1: Vercel (Rekomendasi untuk Next.js)

Vercel mendukung Next.js dengan semua fitur:

```bash
# Deploy ke Vercel
vercel

# Install Vercel CLI
npm install -g vercel
vercel login
vercel
```

**Keunggulan Vercel:**
- ✅ Full Next.js support
- ✅ API routes berfungsi
- ✅ Server-side rendering
- ✅ Database connection dari server
- ✅ Semua fitur aplikasi akan berjalan
- ✅ Built-in SSL dan CDN
- ✅ Preview deployments

### Option 2: Railway

Railway juga mendukung full Node.js:

```bash
# Install Railway CLI
npm install -g @railway/cli

# Deploy
railway login
railway up
```

### Option 3: Cloudflare Pages dengan Functions

Untuk menggunakan Cloudflare Pages dengan API routes:

1. Pindah API routes ke Cloudflare Pages Functions
2. Update frontend untuk menggunakan Functions endpoints
3. Atau gunakan Cloudflare Workers untuk API

## Rekomendasi Terakhir

Untuk aplikasi Bank Management ini yang membutuhkan:
- Database operations
- API routes
- Session management
- Server-side authentication

**Sangat direkomendasikan untuk menggunakan Vercel** atau platform yang mendukung full Next.js dengan Node.js runtime.

Vercel adalah pilihan terbaik untuk:
- Next.js applications
- PostgreSQL dengan Prisma
- Full-stack applications
- Production deployment

Coba deploy ke Vercel untuk mendapatkan semua fitur aplikasi berjalan dengan sempurna.

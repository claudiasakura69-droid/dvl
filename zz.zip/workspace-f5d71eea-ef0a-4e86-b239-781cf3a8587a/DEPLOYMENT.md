# Deployment Instructions

## ⚠️ PENTING: Cloudflare Pages vs Vercel

### Cloudflare Pages (Static Export)
Karena konfigurasi saat ini menggunakan `output: "export"`, Cloudflare Pages HANYA akan men-generate static HTML/JS/CSS. 

**Fitur yang TIDAK akan berjalan di Cloudflare Pages:**
- ❌ API routes (`/api/*`)
- ❌ Server-side rendering dinamis
- ❌ Database operations dari backend
- ❌ Login/session management
- ❌ POST requests ke API

**Artinya:** Aplikasi TIDAK akan berfungsi sepenuhnya di Cloudflare Pages!

### Vercel (Rekomendasi - Full Next.js Support)

Vercel mendukung penuh Next.js dengan semua fitur server-side:

**Fitur yang akan berjalan di Vercel:**
- ✅ Semua API routes berfungsi
- ✅ Database connection
- ✅ Server-side rendering
- ✅ Login/session management
- ✅ Semua fitur aplikasi

## 📋 Cara Deploy ke Vercel (Direkomendasikan)

### 1. Push ke GitHub
```bash
git add .
git commit -m "Ready for deployment"
git push origin main
```

### 2. Deploy ke Vercel

#### Option A: Melalui Vercel Dashboard (Paling Mudah)

1. Buka [https://vercel.com](https://vercel.com)
2. Klik "Add New Project"
3. Import dari GitHub:
   - Pilih repository Anda
   - Klik "Import"
4. Vercel akan mendeteksi Next.js otomatis
5. Configure environment variables:

**Environment Variables yang Diperlukan:**
```
DATABASE_URL = postgresql://neondb_owner:PASSWORD@ep-xxx.ap-southeast-1.aws.neon.tech/neondb?sslmode=require

NEXTAUTH_SECRET = generate-random-string-contoh-abc123

MASTER_USERS = admin:master123
```

6. Klik "Deploy"

#### Option B: Menggunakan Vercel CLI

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

### 3. Setup Database di Neon

1. Buka [Neon Console](https://console.neon.tech/)
2. Copy connection string
3. Paste sebagai `DATABASE_URL` di Vercel environment variables

### 4. Set NEXTAUTH_SECRET

Generate secret key:
```bash
# Di Linux/Mac
openssl rand -base64 32

# Atau gunakan string random sendiri
# Contoh: very-long-random-secret-key-1234567890
```

Set sebagai `NEXTAUTH_SECRET` di environment variables.

## 🚀 Setelah Deploy

### Langkah awal:

1. Set up database di Neon (PostgreSQL)
2. Push ke GitHub
3. Deploy ke Vercel
4. Set environment variables di Vercel:
   - `DATABASE_URL`
   - `NEXTAUTH_SECRET`
   - `MASTER_USERS` (opsional)
5. Jalankan database migration:
   ```bash
   # Di local:
   bun run db:push
   
   # Atau masuk ke Vercel deployment dan jalankan manual
   ```

6. Login dengan akun default:
   - Username: `admin`
   - Password: `master123`

7. Buat user lain dengan role yang sesuai

### Testing:

1. Test login
2. Test semua menu
3. Test create/read/update/delete untuk semua transaksi
4. Test export ke Excel
5. Test search dan pagination

## 📁 File Konfigurasi yang Dibuat

### Vercel
- ✅ `vercel.json` - Konfigurasi deployment ke Vercel
- ✅ Environment variables terdokumentasi
- ✅ Build command: `bun run build`

### Cloudflare Pages
- ✅ `next.config.ts` - Dihapus standalone, menggunakan export
- ✅ `package.json` - Build command disederhanakan
- ✅ `public/_headers` - Security headers
- ✅ `.cloudflare/pages.json` - Build config Cloudflare
- ⚠️ **TAPI:** API routes tidak akan berjalan di static export

## 🎯 Rekomendasi

Untuk aplikasi Full-Stack Next.js dengan:
- Database (PostgreSQL + Prisma)
- API routes
- Authentication & Session
- Server-side features

**Vercel adalah pilihan terbaik** untuk deployment karena:
- Full Next.js support
- Built untuk Next.js
- Otomatis environment variables dari production
- Preview deployments
- Deploy dari GitHub dengan zero configuration
- Database connection dari server (bukan dari browser)

## 📞 Troubleshooting

### Deploy gagal di Vercel?
1. Cek `vercel.json` sudah ada
2. Cek `next.config.ts` tidak ada error
3. Cek environment variables sudah diset dengan benar
4. Cek logs di Vercel dashboard

### Database connection error?
1. Verify `DATABASE_URL` di Vercel environment
2. Cek database sudah dibuat di Neon
3. Cek connection string menggunakan format yang benar

### API routes tidak berfungsi?
- Jika di Cloudflare Pages: Ini normal untuk static export
- Gunakan Vercel untuk full support
- Pastikan tidak menggunakan `output: "export"` untuk deployment dengan API routes

## 📞 Support

- Vercel Docs: https://vercel.com/docs
- Neon Docs: https://neon.tech/docs
- Next.js Docs: https://nextjs.org/docs

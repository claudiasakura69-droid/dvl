'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowRight, Plus, Edit, Trash2, Search, ChevronLeft, ChevronRight } from 'lucide-react'
import { toast } from 'sonner'

interface InOutManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role: string } | null
}

interface InOut {
  id: string
  amount: number
  notes: string | null
  status: 'PENDING' | 'COMPLETE'
  createdAt: string
  fromBank: {
    id: string
    name: string
    accountName: string
  }
  toBank: {
    id: string
    name: string
    accountName: string
  }
  user: {
    id: string
    username: string
  }
  processor: {
    id: string
    username: string
  } | null
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: string
}

export default function InOutManagementContent({ sessionId, user }: InOutManagementContentProps) {
  const [inOuts, setInOuts] = useState<InOut[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    fromBankId: '',
    toBankId: '',
    amount: '',
    notes: '',
    status: 'PENDING' as 'PENDING' | 'COMPLETE'
  })

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'COMPLETE'>('ALL')
  const [fromBankFilter, setFromBankFilter] = useState<string>('ALL')
  const [toBankFilter, setToBankFilter] = useState<string>('ALL')

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 50

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchInOuts()
    }
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchInOuts = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/inout?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setInOuts(data.inOuts)
      }
    } catch (error) {
      console.error('Error fetching inouts:', error)
    } finally {
      setLoading(false)
    }
  }

  // Filter function
  const getFilteredInOuts = () => {
    return inOuts.filter(inout => {
      const matchesSearch =
        searchQuery === '' ||
        inout.amount.toString().includes(searchQuery) ||
        (inout.notes && inout.notes.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesStatus = statusFilter === 'ALL' || inout.status === statusFilter
      const matchesFromBank = fromBankFilter === 'ALL' || inout.fromBank.id === fromBankFilter
      const matchesToBank = toBankFilter === 'ALL' || inout.toBank.id === toBankFilter

      return matchesSearch && matchesStatus && matchesFromBank && matchesToBank
    })
  }

  // Pagination
  const filteredInOuts = getFilteredInOuts()
  const totalPages = Math.ceil(filteredInOuts.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedInOuts = filteredInOuts.slice(startIndex, endIndex)

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage)
    }
  }

  const handleAddInOut = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/inout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil ditambahkan')
        setDialogOpen(false)
        resetForm()
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menambahkan InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEdit = (inout: InOut) => {
    if (!user || (user.role !== 'MASTER' && user.role !== 'SUPERVISOR')) {
      toast.error('Anda tidak memiliki izin untuk mengedit')
      return
    }

    setEditId(inout.id)
    setFormData({
      fromBankId: inout.fromBank.id,
      toBankId: inout.toBank.id,
      amount: inout.amount.toString(),
      notes: inout.notes || '',
      status: inout.status
    })
    setEditDialogOpen(true)
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editId || !sessionId || !user) {
      toast.error('Data tidak valid')
      return
    }

    if (user.role !== 'MASTER' && user.role !== 'SUPERVISOR') {
      toast.error('Anda tidak memiliki izin untuk mengedit')
      return
    }

    try {
      const response = await fetch(`/api/inout/${editId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          fromBankId: formData.fromBankId,
          toBankId: formData.toBankId,
          amount: parseFloat(formData.amount),
          notes: formData.notes,
          status: formData.status
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil diupdate')
        setEditDialogOpen(false)
        setEditId(null)
        resetForm()
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengupdate InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDelete = async (id: string) => {
    if (!user || (user.role !== 'MASTER' && user.role !== 'SUPERVISOR')) {
      toast.error('Anda tidak memiliki izin untuk menghapus')
      return
    }

    if (!confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) {
      return
    }

    try {
      const response = await fetch(`/api/inout/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('InOut berhasil dihapus')
        fetchInOuts()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus InOut')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const resetForm = () => {
    setFormData({
      fromBankId: '',
      toBankId: '',
      amount: '',
      notes: '',
      status: 'PENDING'
    })
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getStatusBadge = (status: string) => {
    const statusColors = {
      PENDING: 'bg-yellow-100 text-yellow-800',
      COMPLETE: 'bg-green-100 text-green-800'
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors]}`}>
        {status === 'PENDING' ? 'Menunggu' : 'Selesai'}
      </span>
    )
  }

  const canEdit = user && (user.role === 'MASTER' || user.role === 'SUPERVISOR')

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <ArrowRight className="h-8 w-8" />
            In / Out
          </h1>
          <p className="text-muted-foreground">
            Catat perpindahan nominal antar bank
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Tambah InOut
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tambah Perpindahan Antar Bank</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddInOut} className="space-y-4">
              <div>
                <Label htmlFor="fromBank">Dari Bank</Label>
                <Select
                  value={formData.fromBankId}
                  onValueChange={(value) => setFormData({ ...formData, fromBankId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih bank asal" />
                  </SelectTrigger>
                  <SelectContent>
                    {banks.map((bank) => (
                      <SelectItem key={bank.id} value={bank.id}>
                        {bank.name} - {bank.accountName} ({bank.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="toBank">Ke Bank</Label>
                <Select
                  value={formData.toBankId}
                  onValueChange={(value) => setFormData({ ...formData, toBankId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih bank tujuan" />
                  </SelectTrigger>
                  <SelectContent>
                    {banks.map((bank) => (
                      <SelectItem key={bank.id} value={bank.id}>
                        {bank.name} - {bank.accountName} ({bank.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="amount">Nominal</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="notes">Catatan (Opsional)</Label>
                <Input
                  id="notes"
                  placeholder="Catatan untuk transaksi ini"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
              <Button type="submit" className="w-full">
                Simpan
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Riwayat Perpindahan</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 mb-4">
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari berdasarkan nominal atau catatan..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
              <Select
                value={statusFilter}
                onValueChange={(value: 'ALL' | 'PENDING' | 'COMPLETE') => {
                  setStatusFilter(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua Status</SelectItem>
                  <SelectItem value="PENDING">Menunggu</SelectItem>
                  <SelectItem value="COMPLETE">Selesai</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={fromBankFilter}
                onValueChange={(value) => {
                  setFromBankFilter(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Bank Asal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua Bank Asal</SelectItem>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={toBankFilter}
                onValueChange={(value) => {
                  setToBankFilter(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Bank Tujuan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua Bank Tujuan</SelectItem>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {filteredInOuts.length > 0 && (
              <div className="text-sm text-muted-foreground">
                Menampilkan {startIndex + 1} - {Math.min(endIndex, filteredInOuts.length)} dari {filteredInOuts.length} transaksi
              </div>
            )}
          </div>

          <ScrollArea className="h-[600px]">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredInOuts.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Tidak ada transaksi ditemukan</p>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Dari Bank</TableHead>
                      <TableHead>Ke Bank</TableHead>
                      <TableHead>Nominal</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Catatan</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Processor</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedInOuts.map((inout) => (
                      <TableRow key={inout.id}>
                        <TableCell className="text-sm">{formatDate(inout.createdAt)}</TableCell>
                        <TableCell>
                          <div className="font-medium">{inout.fromBank.name}</div>
                          <div className="text-xs text-muted-foreground">{inout.fromBank.accountName}</div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">{inout.toBank.name}</div>
                          <div className="text-xs text-muted-foreground">{inout.toBank.accountName}</div>
                        </TableCell>
                        <TableCell className="font-semibold">{formatCurrency(inout.amount)}</TableCell>
                        <TableCell>{getStatusBadge(inout.status)}</TableCell>
                        <TableCell className="max-w-xs truncate">{inout.notes || '-'}</TableCell>
                        <TableCell className="text-sm">{inout.user.username}</TableCell>
                        <TableCell className="text-sm">{inout.processor ? inout.processor.username : '-'}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {canEdit && (
                              <>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => handleEdit(inout)}
                                  title="Edit"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  onClick={() => handleDelete(inout.id)}
                                  title="Hapus"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {totalPages > 1 && (
                  <div className="flex items-center justify-between mt-4 px-2">
                    <div className="text-sm text-muted-foreground">
                      Halaman {currentPage} dari {totalPages}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Perpindahan Antar Bank</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <Label htmlFor="editFromBank">Dari Bank</Label>
              <Select
                value={formData.fromBankId}
                onValueChange={(value) => setFormData({ ...formData, fromBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank asal" />
                </SelectTrigger>
                <SelectContent>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editToBank">Ke Bank</Label>
              <Select
                value={formData.toBankId}
                onValueChange={(value) => setFormData({ ...formData, toBankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank tujuan" />
                </SelectTrigger>
                <SelectContent>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editAmount">Nominal</Label>
              <Input
                id="editAmount"
                type="number"
                placeholder="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editStatus">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: 'PENDING' | 'COMPLETE') => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Menunggu</SelectItem>
                  <SelectItem value="COMPLETE">Selesai</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editNotes">Catatan (Opsional)</Label>
              <Input
                id="editNotes"
                placeholder="Catatan untuk transaksi ini"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Calendar, Plus, Download, FileText, Search, Edit2, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react'
import { toast } from 'sonner'

interface DayTransactionsContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Transaction {
  id: string
  date: string
  name: string
  accountNumber: string | null
  amount: number
  type: 'DEPOSIT' | 'WITHDRAW'
  status: string
  bank: {
    id: string
    name: string
    accountName: string
    balance: number
  }
  destinationBank?: {
    id: string
    name: string
    accountName: string
  } | null
  destinationOther: string | null
  notes: string | null
  user: {
    id: string
    username: string
  }
  processor?: {
    id: string
    username: string
  } | null
}

interface Bank {
  id: string
  name: string
  accountName: string
  balance: number
  status: string
  type: string
}

export default function DayTransactionsContent({ sessionId, user }: DayTransactionsContentProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [bulkDialogOpen, setBulkDialogOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  
  // Search and filter state
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState<'ALL' | 'DEPOSIT' | 'WITHDRAW'>('ALL')
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'COMPLETE' | 'PENDING'>('ALL')
  const [filterBank, setFilterBank] = useState('ALL')
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)
  const [rowsPerPage] = useState(50)

  const [formData, setFormData] = useState({
    date: selectedDate,
    name: '',
    accountNumber: '',
    amount: '',
    type: 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
    bankId: '',
    notes: ''
  })
  const [bulkData, setBulkData] = useState('')

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchTransactions()
    }
  }, [sessionId, selectedDate])

  useEffect(() => {
    applyFilters()
  }, [transactions, searchTerm, filterType, filterStatus, filterBank, currentPage])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchTransactions = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/daily-transactions?sessionId=${sessionId}&date=${selectedDate}`)
      const data = await response.json()

      if (data.success) {
        setTransactions(data.transactions)
        setCurrentPage(1)
      }
    } catch (error) {
      console.error('Error fetching transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = [...transactions]

    // Search term filter
    if (searchTerm) {
      const lowerTerm = searchTerm.toLowerCase()
      filtered = filtered.filter(t =>
        t.name.toLowerCase().includes(lowerTerm) ||
        (t.accountNumber && t.accountNumber.includes(lowerTerm)) ||
        (t.notes && t.notes.toLowerCase().includes(lowerTerm)) ||
        (t.destinationOther && t.destinationOther.toLowerCase().includes(lowerTerm))
      )
    }

    // Type filter
    if (filterType !== 'ALL') {
      filtered = filtered.filter(t => t.type === filterType)
    }

    // Status filter
    if (filterStatus !== 'ALL') {
      filtered = filtered.filter(t => t.status === filterStatus)
    }

    // Bank filter
    if (filterBank !== 'ALL') {
      filtered = filtered.filter(t => t.bank.id === filterBank)
    }

    setFilteredTransactions(filtered)
  }

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/daily-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          date: selectedDate,
          name: '',
          accountNumber: '',
          amount: '',
          type: 'DEPOSIT',
          bankId: '',
          notes: ''
        })
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditTransaction = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user || !selectedTransaction) {
      toast.error('Session atau user tidak valid')
      return
    }

    // Check permission
    if (user.role !== 'MASTER' && user.role !== 'SUPERVISOR') {
      toast.error('Hanya MASTER dan SUPERVISOR yang bisa mengedit transaksi')
      return
    }

    try {
      const response = await fetch(`/api/daily-transactions/${selectedTransaction.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          ...formData
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil diupdate')
        setEditDialogOpen(false)
        setSelectedTransaction(null)
        setFormData({
          date: selectedDate,
          name: '',
          accountNumber: '',
          amount: '',
          type: 'DEPOSIT',
          bankId: '',
          notes: ''
        })
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal mengupdate transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteTransaction = async (txId: string) => {
    if (!sessionId) return

    if (!confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) return

    try {
      const response = await fetch(`/api/daily-transactions/${txId}?sessionId=${sessionId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Transaksi berhasil dihapus')
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menghapus transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleBulkTransactions = async () => {
    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const lines = bulkData.split('\n').filter(line => line.trim())
      const txs = lines.map(line => {
        const parts = line.split('\t')
        return {
          date: selectedDate,
          name: parts[0] || '',
          accountNumber: parts[1] || '',
          amount: parseFloat(parts[2]) || 0,
          type: parts[3]?.includes('WITHDRAW') ? 'WITHDRAW' : 'DEPOSIT' as 'DEPOSIT' | 'WITHDRAW',
          bankId: banks.find(b => `${b.name} - ${b.accountName}` === parts[3]?.trim())?.id || ''
        }
      }).filter(t => t.name && t.amount > 0 && t.bankId)

      const response = await fetch('/api/daily-transactions/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          transactions: txs,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success(`${data.successCount} transaksi berhasil ditambahkan`)
        if (data.errorCount > 0) {
          toast.error(`${data.errorCount} transaksi gagal`)
        }
        setBulkDialogOpen(false)
        setBulkData('')
        fetchBanks()
        fetchTransactions()
      } else {
        toast.error(data.error || 'Gagal menambahkan transaksi')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleExport = async () => {
    if (!sessionId) return

    try {
      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          startDate: selectedDate,
          endDate: selectedDate
        })
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `transactions_${selectedDate}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Export berhasil')
      } else {
        toast.error('Gagal export data')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat export')
    }
  }

  const openEditDialog = (tx: Transaction) => {
    setSelectedTransaction(tx)
    setFormData({
      date: tx.date.split('T')[0],
      name: tx.name,
      accountNumber: tx.accountNumber || '',
      amount: tx.amount.toString(),
      type: tx.type,
      bankId: tx.bank.id,
      notes: tx.notes || ''
    })
    setEditDialogOpen(true)
  }

  const deposits = filteredTransactions.filter(t => t.type === 'DEPOSIT')
  const withdraws = filteredTransactions.filter(t => t.type === 'WITHDRAW')
  
  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / rowsPerPage)
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  )

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const calculateTotal = (txs: Transaction[]) => txs.reduce((sum, tx) => sum + tx.amount, 0)

  const onlineDepositBanks = banks.filter(b => b.type === 'DEPOSIT' && b.status === 'online')
  const onlineWithdrawBanks = banks.filter(b => b.type === 'WITHDRAW' && b.status === 'online')
  
  const canEdit = user && (user.role === 'MASTER' || user.role === 'SUPERVISOR')

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Calendar className="h-8 w-8" />
            Day Transactions
          </h1>
          <p className="text-muted-foreground">
            Catat transaksi harian deposit dan withdraw
          </p>
        </div>

        <div className="flex gap-2 flex-wrap">
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-auto"
          />

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah Transaksi
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Transaksi</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddTransaction} className="space-y-4">
                <div>
                  <Label htmlFor="txDate">Tanggal</Label>
                  <Input
                    id="txDate"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txName">Nama</Label>
                  <Input
                    id="txName"
                    placeholder="Nama pengirim/penerima"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txAccountNumber">Nomor Rekening (Opsional)</Label>
                  <Input
                    id="txAccountNumber"
                    placeholder="1234567890"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="txAmount">Nominal</Label>
                  <Input
                    id="txAmount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="txType">Tipe</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="DEPOSIT">Deposit</SelectItem>
                      <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="txBank">Bank</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank" />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.type === 'DEPOSIT' ? (
                        <>
                          {onlineDepositBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      ) : (
                        <>
                          {onlineWithdrawBanks.map((bank) => (
                            <SelectItem key={bank.id} value={bank.id}>
                              {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                            </SelectItem>
                          ))}
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="txNotes">Catatan (Opsional)</Label>
                  <Input
                    id="txNotes"
                    placeholder="Catatan tambahan"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={bulkDialogOpen} onOpenChange={setBulkDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                Bulk Add
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Banyak Transaksi</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="bulkData">Data Transaksi (Format: Nama{`\t`}Nomor Rek{`\t`}Nominal{`\t`}Bank)</Label>
                  <Input
                    id="bulkData"
                    placeholder="Nama{tab}Nomor Rek{tab}Nominal{tab}BCA - Vera"
                    value={bulkData}
                    onChange={(e) => setBulkData(e.target.value)}
                    className="font-mono text-xs"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Gunakan tab sebagai pemisah. Setiap baris adalah satu transaksi.
                  </p>
                </div>
                <Button onClick={handleBulkTransactions} className="w-full">
                  Simpan Semua
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Search className="h-5 w-5" />
            Filter & Pencarian
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <Label htmlFor="searchTerm">Cari</Label>
              <Input
                id="searchTerm"
                placeholder="Nama, rek, catatan..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="filterType">Tipe</Label>
              <Select value={filterType} onValueChange={(value: any) => setFilterType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua</SelectItem>
                  <SelectItem value="DEPOSIT">Deposit</SelectItem>
                  <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterStatus">Status</Label>
              <Select value={filterStatus} onValueChange={(value: any) => setFilterStatus(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua</SelectItem>
                  <SelectItem value="COMPLETE">Complete</SelectItem>
                  <SelectItem value="PENDING">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="filterBank">Bank</Label>
              <Select value={filterBank} onValueChange={(value) => setFilterBank(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">Semua Bank</SelectItem>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bank Summary */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Online Deposit Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bank</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Today</TableHead>
                  <TableHead className="text-right">Final</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {onlineDepositBanks.map((bank) => {
                  const todayTotal = deposits.filter(t => t.bank.id === bank.id).reduce((sum, t) => sum + t.amount, 0)
                  return (
                    <TableRow key={bank.id}>
                      <TableCell>{bank.name} - {bank.accountName}</TableCell>
                      <TableCell className="text-right">{formatCurrency(bank.balance - todayTotal)}</TableCell>
                      <TableCell className="text-right text-green-600">+{formatCurrency(todayTotal)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(bank.balance)}</TableCell>
                    </TableRow>
                  )
                })}
                {onlineDepositBanks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      Tidak ada bank deposit online
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Online Withdraw Banks</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bank</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">Today</TableHead>
                  <TableHead className="text-right">Final</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {onlineWithdrawBanks.map((bank) => {
                  const todayTotal = withdraws.filter(t => t.bank.id === bank.id).reduce((sum, t) => sum + t.amount, 0)
                  return (
                    <TableRow key={bank.id}>
                      <TableCell>{bank.name} - {bank.accountName}</TableCell>
                      <TableCell className="text-right">{formatCurrency(bank.balance + todayTotal)}</TableCell>
                      <TableCell className="text-right text-red-600">-{formatCurrency(todayTotal)}</TableCell>
                      <TableCell className="text-right font-semibold">{formatCurrency(bank.balance)}</TableCell>
                    </TableRow>
                  )
                })}
                {onlineWithdrawBanks.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-muted-foreground">
                      Tidak ada bank withdraw online
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Transactions */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Deposits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-green-600">Deposits ({deposits.length})</span>
              <span className="text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(deposits))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px]">
              {loading ? (
                <p>Memuat data...</p>
              ) : deposits.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Belum ada transaksi deposit</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Nama</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {deposits.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="text-sm">{formatDate(tx.date)}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{tx.name}</div>
                            {tx.accountNumber && (
                              <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                            )}
                            {tx.notes && (
                              <div className="text-xs text-muted-foreground">{tx.notes}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{tx.bank.name} - {tx.bank.accountName}</TableCell>
                        <TableCell className="text-right text-green-600 font-semibold">
                          {formatCurrency(tx.amount)}
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            tx.status === 'COMPLETE' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                          }`}>
                            {tx.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {canEdit && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(tx)}
                              >
                                <Edit2 className="h-3 w-3" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteTransaction(tx.id)}
                            >
                              <Trash2 className="h-3 w-3 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Withdraws */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="text-red-600">Withdraws ({withdraws.length})</span>
              <span className="text-sm font-normal text-muted-foreground">
                Total: {formatCurrency(calculateTotal(withdraws))}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px]">
              {loading ? (
                <p>Memuat data...</p>
              ) : withdraws.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">Belum ada transaksi withdraw</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Nama</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {withdraws.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell className="text-sm">{formatDate(tx.date)}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{tx.name}</div>
                            {tx.accountNumber && (
                              <div className="text-xs text-muted-foreground">{tx.accountNumber}</div>
                            )}
                            {tx.notes && (
                              <div className="text-xs text-muted-foreground">{tx.notes}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{tx.bank.name} - {tx.bank.accountName}</TableCell>
                        <TableCell className="text-right text-red-600 font-semibold">
                          {formatCurrency(tx.amount)}
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            tx.status === 'COMPLETE' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                          }`}>
                            {tx.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {canEdit && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditDialog(tx)}
                              >
                                <Edit2 className="h-3 w-3" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteTransaction(tx.id)}
                            >
                              <Trash2 className="h-3 w-3 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <Card>
          <CardContent className="flex items-center justify-between py-4">
            <p className="text-sm text-muted-foreground">
              Menampilkan {(currentPage - 1) * rowsPerPage + 1} - {Math.min(currentPage * rowsPerPage, filteredTransactions.length)} dari {filteredTransactions.length} transaksi
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="px-4 py-2 border rounded">
                {currentPage} / {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Transaksi</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditTransaction} className="space-y-4">
            <div>
              <Label htmlFor="editDate">Tanggal</Label>
              <Input
                id="editDate"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editName">Nama</Label>
              <Input
                id="editName"
                placeholder="Nama pengirim/penerima"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editAccountNumber">Nomor Rekening (Opsional)</Label>
              <Input
                id="editAccountNumber"
                placeholder="1234567890"
                value={formData.accountNumber}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="editAmount">Nominal</Label>
              <Input
                id="editAmount"
                type="number"
                placeholder="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editType">Tipe</Label>
              <Select
                value={formData.type}
                onValueChange={(value: 'DEPOSIT' | 'WITHDRAW') => setFormData({ ...formData, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DEPOSIT">Deposit</SelectItem>
                  <SelectItem value="WITHDRAW">Withdraw</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editBank">Bank</Label>
              <Select
                value={formData.bankId}
                onValueChange={(value) => setFormData({ ...formData, bankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank" />
                </SelectTrigger>
                <SelectContent>
                  {formData.type === 'DEPOSIT' ? (
                    <>
                      {onlineDepositBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                        </SelectItem>
                      ))}
                    </>
                  ) : (
                    <>
                      {onlineWithdrawBanks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({formatCurrency(bank.balance)})
                        </SelectItem>
                      ))}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editNotes">Catatan (Opsional)</Label>
              <Input
                id="editNotes"
                placeholder="Catatan tambahan"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

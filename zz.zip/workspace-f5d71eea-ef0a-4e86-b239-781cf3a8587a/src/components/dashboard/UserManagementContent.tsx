'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Users, Activity } from 'lucide-react'

interface UserManagementContentProps {
  sessionId: string | null
}

interface UserData {
  id: string
  username: string
  isActive: boolean
  createdAt: string
  sessions: SessionData[]
}

interface SessionData {
  id: string
  loginAt: string
  logoutAt: string | null
  ipAddress: string | null
  isOnline: boolean
}

export default function UserManagementContent({ sessionId }: UserManagementContentProps) {
  const [users, setUsers] = useState<UserData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUsers()
  }, [sessionId])

  const fetchUsers = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/users?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setUsers(data.users)
      }
    } catch (error) {
      console.error('Error fetching users:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const onlineCount = users.reduce((count, user) => {
    return count + user.sessions.filter(s => s.isOnline).length
  }, 0)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Users className="h-8 w-8" />
          User Management
        </h1>
        <p className="text-muted-foreground">
          Daftar semua users yang pernah login ke sistem
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online Now</CardTitle>
            <Activity className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{onlineCount}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User List</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Memuat data...</p>
          ) : users.length === 0 ? (
            <p className="text-muted-foreground">Belum ada user yang terdaftar.</p>
          ) : (
            <div className="space-y-6">
              {users.map((user) => (
                <div key={user.id} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{user.username}</h3>
                      <p className="text-sm text-muted-foreground">
                        Created: {formatDate(user.createdAt)}
                      </p>
                    </div>
                    <Badge variant={user.isActive ? 'default' : 'secondary'}>
                      {user.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>

                  {user.sessions.length > 0 && (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Status</TableHead>
                          <TableHead>Login Time</TableHead>
                          <TableHead>Logout Time</TableHead>
                          <TableHead>IP Address</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {user.sessions.map((session) => (
                          <TableRow key={session.id}>
                            <TableCell>
                              <Badge variant={session.isOnline ? 'default' : 'secondary'}>
                                {session.isOnline ? 'Online' : 'Offline'}
                              </Badge>
                            </TableCell>
                            <TableCell>{formatDate(session.loginAt)}</TableCell>
                            <TableCell>
                              {session.logoutAt ? formatDate(session.logoutAt) : '-'}
                            </TableCell>
                            <TableCell>{session.ipAddress || '-'}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}

                  {user.sessions.length === 0 && (
                    <p className="text-sm text-muted-foreground">Belum ada session</p>
                  )}

                  <div className="border-t" />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Plus, Trash2, Wallet, Search, Edit, ChevronLeft, ChevronRight } from 'lucide-react'
import { toast } from 'sonner'

interface AkuranManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Akuran {
  id: string
  amount: number
  notes: string | null
  category: string | null
  createdAt: string
  user: {
    id: string
    username: string
    role: string
  }
  processor: {
    id: string
    username: string
    role: string
  } | null
}

export default function AkuranManagementContent({ sessionId, user }: AkuranManagementContentProps) {
  const [akurans, setAkurans] = useState<Akuran[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [formData, setFormData] = useState({
    amount: '',
    notes: '',
    category: ''
  })

  // Search and filter state
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 50

  // Edit dialog state
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editingAkuran, setEditingAkuran] = useState<Akuran | null>(null)
  const [editFormData, setEditFormData] = useState({
    amount: '',
    notes: '',
    category: ''
  })

  useEffect(() => {
    if (sessionId) {
      fetchAkurans()
    }
  }, [sessionId, selectedMonth, selectedYear])

  const fetchAkurans = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/akuran?sessionId=${sessionId}&month=${selectedMonth}&year=${selectedYear}`)
      const data = await response.json()

      if (data.success) {
        setAkurans(data.akurans)
      }
    } catch (error) {
      console.error('Error fetching akurans:', error)
      toast.error('Gagal mengambil data akuran')
    } finally {
      setLoading(false)
    }
  }

  const handleAddAkuran = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/akuran', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          amount: '',
          notes: '',
          category: ''
        })
        fetchAkurans()
      } else {
        toast.error(data.error || 'Gagal menambahkan akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteAkuran = async (akuranId: string) => {
    if (!sessionId || !user) return

    if (!confirm('Apakah Anda yakin ingin menghapus akuran ini?')) return

    try {
      const response = await fetch(`/api/akuran/${akuranId}?sessionId=${sessionId}&userId=${user.id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil dihapus')
        fetchAkurans()
      } else {
        toast.error(data.error || 'Gagal menghapus akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditAkuran = (akuran: Akuran) => {
    setEditingAkuran(akuran)
    setEditFormData({
      amount: akuran.amount.toString(),
      notes: akuran.notes || '',
      category: akuran.category || ''
    })
    setEditDialogOpen(true)
  }

  const handleUpdateAkuran = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user || !editingAkuran) return

    try {
      const response = await fetch(`/api/akuran/${editingAkuran.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseInt(editFormData.amount),
          notes: editFormData.notes || null,
          category: editFormData.category || null,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Akuran berhasil diperbarui')
        setEditDialogOpen(false)
        setEditingAkuran(null)
        fetchAkurans()
      } else {
        toast.error(data.error || 'Gagal memperbarui akuran')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const canEdit = () => {
    return user && (user.role === 'MASTER' || user.role === 'SUPERVISOR')
  }

  // Filter akurans based on search and category
  const filteredAkurans = akurans.filter((akuran) => {
    const matchesSearch =
      searchQuery === '' ||
      akuran.amount.toString().includes(searchQuery) ||
      (akuran.notes && akuran.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (akuran.category && akuran.category.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesCategory =
      categoryFilter === '' ||
      (akuran.category && akuran.category.toLowerCase() === categoryFilter.toLowerCase())

    return matchesSearch && matchesCategory
  })

  // Get unique categories for filter
  const categories = Array.from(new Set(akurans.map(a => a.category).filter(Boolean)))

  // Pagination
  const totalPages = Math.ceil(filteredAkurans.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedAkurans = filteredAkurans.slice(startIndex, endIndex)

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1)
  }, [searchQuery, categoryFilter])

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  // Month options
  const months = Array.from({ length: 12 }, (_, i) => i + 1)
  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i)

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ]

  const totalAmount = akurans.reduce((sum, akuran) => sum + akuran.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Wallet className="h-8 w-8" />
            Akuran
          </h1>
          <p className="text-muted-foreground">
            Catat pembayaran keperluan
          </p>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
            className="border rounded-md px-3 py-2 bg-background"
          >
            {months.map((month) => (
              <option key={month} value={month}>
                {monthNames[month - 1]}
              </option>
            ))}
          </select>

          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            className="border rounded-md px-3 py-2 bg-background"
          >
            {years.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tambah Akuran
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tambah Akuran Baru</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddAkuran} className="space-y-4">
                <div>
                  <Label htmlFor="amount">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="category">Kategori (Opsional)</Label>
                  <Input
                    id="category"
                    placeholder="Contoh: Makan, Transport, dll"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan tambahan"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          {/* Edit Dialog */}
          <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Akuran</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleUpdateAkuran} className="space-y-4">
                <div>
                  <Label htmlFor="edit-amount">Nominal</Label>
                  <Input
                    id="edit-amount"
                    type="number"
                    placeholder="0"
                    value={editFormData.amount}
                    onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-category">Kategori (Opsional)</Label>
                  <Input
                    id="edit-category"
                    placeholder="Contoh: Makan, Transport, dll"
                    value={editFormData.category}
                    onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
                  <Input
                    id="edit-notes"
                    placeholder="Catatan tambahan"
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan Perubahan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="text-purple-600">Total Akuran</span>
            <span className="text-sm font-normal text-muted-foreground">
              {monthNames[selectedMonth - 1]} {selectedYear}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-purple-600">
            {formatCurrency(totalAmount)}
          </div>
          <p className="text-sm text-muted-foreground mt-2">
            {akurans.length} transaksi
          </p>
        </CardContent>
      </Card>

      {/* Akuran List */}
      <Card>
        <CardHeader>
          <CardTitle>Daftar Akuran</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="space-y-4 mb-4">
            <div className="flex gap-2 flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari nominal, catatan, atau kategori..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="border rounded-md px-3 py-2 bg-background min-w-[150px]"
              >
                <option value="">Semua Kategori</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <ScrollArea className="h-[600px]">
            {loading ? (
              <p className="text-center text-muted-foreground py-8">Memuat data...</p>
            ) : paginatedAkurans.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                {filteredAkurans.length === 0 ? 'Tidak ada data yang cocok dengan pencarian' : 'Belum ada akuran'}
              </p>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Catatan</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead>Dibuat Oleh</TableHead>
                      <TableHead>Diproses Oleh</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedAkurans.map((akuran) => (
                      <TableRow key={akuran.id}>
                        <TableCell className="text-sm">{formatDate(akuran.createdAt)}</TableCell>
                        <TableCell>{akuran.category || '-'}</TableCell>
                        <TableCell>{akuran.notes || '-'}</TableCell>
                        <TableCell className="text-right text-purple-600 font-semibold">
                          {formatCurrency(akuran.amount)}
                        </TableCell>
                        <TableCell>{akuran.user.username}</TableCell>
                        <TableCell>{akuran.processor?.username || '-'}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-1 justify-end">
                            {canEdit() && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditAkuran(akuran)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteAkuran(akuran.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {/* Pagination */}
                {filteredAkurans.length > itemsPerPage && (
                  <div className="flex items-center justify-between mt-4 px-2">
                    <p className="text-sm text-muted-foreground">
                      Menampilkan {startIndex + 1} - {Math.min(endIndex, filteredAkurans.length)} dari {filteredAkurans.length} transaksi
                    </p>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <span className="text-sm">
                        Halaman {currentPage} dari {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}

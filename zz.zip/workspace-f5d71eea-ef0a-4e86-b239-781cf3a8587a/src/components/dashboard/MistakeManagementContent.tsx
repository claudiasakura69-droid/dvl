'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { AlertCircle, Plus, Edit, Trash2, Search, ChevronLeft, ChevronRight } from 'lucide-react'
import { toast } from 'sonner'

interface MistakeManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role: string } | null
}

interface Mistake {
  id: string
  amount: number
  notes: string | null
  bankId: string | null
  createdAt: string
  user: {
    id: string
    username: string
  }
  processor?: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
}

export default function MistakeManagementContent({ sessionId, user }: MistakeManagementContentProps) {
  const [mistakes, setMistakes] = useState<Mistake[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    amount: '',
    notes: '',
    bankId: ''
  })
  const [editFormData, setEditFormData] = useState({
    id: '',
    amount: '',
    notes: '',
    bankId: ''
  })
  const [searchQuery, setSearchQuery] = useState('')
  const [bankFilter, setBankFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(50)

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchMistakes()
    }
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks)
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchMistakes = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/mistake?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setMistakes(data.mistakes)
      }
    } catch (error) {
      console.error('Error fetching mistakes:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/mistake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dicatat')
        setDialogOpen(false)
        setFormData({
          amount: '',
          notes: '',
          bankId: ''
        })
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mencatat mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditClick = (mistake: Mistake) => {
    if (!user || (user.role !== 'MASTER' && user.role !== 'SUPERVISOR')) {
      toast.error('Anda tidak memiliki izin untuk mengedit')
      return
    }
    setEditFormData({
      id: mistake.id,
      amount: mistake.amount.toString(),
      notes: mistake.notes || '',
      bankId: mistake.bankId || ''
    })
    setEditDialogOpen(true)
  }

  const handleEditMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user || (user.role !== 'MASTER' && user.role !== 'SUPERVISOR')) {
      toast.error('Anda tidak memiliki izin untuk mengedit')
      return
    }

    try {
      const response = await fetch(`/api/mistake/${editFormData.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseInt(editFormData.amount),
          notes: editFormData.notes,
          bankId: editFormData.bankId || null
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil diupdate')
        setEditDialogOpen(false)
        fetchMistakes()
      } else {
        toast.error(data.error || 'Gagal mengupdate mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteMistake = async (mistakeId: string) => {
    if (!user || (user.role !== 'MASTER' && user.role !== 'SUPERVISOR')) {
      toast.error('Anda tidak memiliki izin untuk menghapus')
      return
    }

    if (!confirm('Apakah Anda yakin ingin menghapus mistake ini?')) {
      return
    }

    try {
      const response = await fetch(`/api/mistake/${mistakeId}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dihapus')
        fetchMistakes()
      } else {
        toast.error(data.error || 'Gagal menghapus mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  // Filter and pagination logic
  const filteredMistakes = mistakes.filter(mistake => {
    const matchesSearch = searchQuery === '' ||
      mistake.amount.toString().includes(searchQuery) ||
      (mistake.notes && mistake.notes.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesBank = bankFilter === '' || mistake.bankId === bankFilter
    return matchesSearch && matchesBank
  })

  const totalFiltered = filteredMistakes.length
  const totalPages = Math.ceil(totalFiltered / itemsPerPage)
  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentItems = filteredMistakes.slice(indexOfFirstItem, indexOfLastItem)

  const totalMistake = mistakes.reduce((sum, m) => sum + m.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <AlertCircle className="h-8 w-8" />
            Mistake
          </h1>
          <p className="text-muted-foreground">
            Catat kesalahan transaksi dan beban biaya kekurangan
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="destructive">
              <Plus className="mr-2 h-4 w-4" />
              Catat Mistake
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Catat Mistake</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddMistake} className="space-y-4">
              <div>
                <Label htmlFor="bank">Bank (Opsional)</Label>
                <Select
                  value={formData.bankId}
                  onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Tidak ada</SelectItem>
                    {banks.map((bank) => (
                      <SelectItem key={bank.id} value={bank.id}>
                        {bank.name} - {bank.accountName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="amount">Nominal</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="notes">Catatan (Opsional)</Label>
                <Input
                  id="notes"
                  placeholder="Jelaskan kesalahan yang terjadi"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
              <Button type="submit" className="w-full" variant="destructive">
                Catat
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Riwayat Kesalahan</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(totalMistake)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search and Filter Controls */}
          <div className="mb-4 space-y-3">
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari nominal atau catatan..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>
              <Select
                value={bankFilter}
                onValueChange={(value) => {
                  setBankFilter(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Filter Bank" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Semua Bank</SelectItem>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <ScrollArea className="h-[600px]">
            {loading ? (
              <p>Memuat data...</p>
            ) : mistakes.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada mistake</p>
            ) : (
              <>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Waktu</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead>Catatan</TableHead>
                      <TableHead className="text-right">Nominal</TableHead>
                      <TableHead>User</TableHead>
                      {(user?.role === 'MASTER' || user?.role === 'SUPERVISOR') && (
                        <TableHead className="text-right">Aksi</TableHead>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentItems.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={(user?.role === 'MASTER' || user?.role === 'SUPERVISOR') ? 6 : 5} className="text-center text-muted-foreground py-8">
                          Tidak ada data yang cocok dengan pencarian
                        </TableCell>
                      </TableRow>
                    ) : (
                      currentItems.map((mistake) => {
                        const bank = mistake.bankId ? banks.find(b => b.id === mistake.bankId) : null
                        return (
                          <TableRow key={mistake.id}>
                            <TableCell className="text-sm">{formatDate(mistake.createdAt)}</TableCell>
                            <TableCell>
                              {bank ? (
                                <div className="font-medium">{bank.name} - {bank.accountName}</div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell>{mistake.notes || '-'}</TableCell>
                            <TableCell className="text-right font-semibold text-red-600">
                              {formatCurrency(mistake.amount)}
                            </TableCell>
                            <TableCell className="text-sm">{mistake.user.username}</TableCell>
                            {(user?.role === 'MASTER' || user?.role === 'SUPERVISOR') && (
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleEditClick(mistake)}
                                    className="h-8 w-8"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteMistake(mistake.id)}
                                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                          </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>

                {/* Pagination Controls */}
                {totalFiltered > 0 && (
                  <div className="mt-4 flex items-center justify-between border-t pt-4">
                    <div className="text-sm text-muted-foreground">
                      Menampilkan {indexOfFirstItem + 1} - {Math.min(indexOfLastItem, totalFiltered)} dari {totalFiltered} transaksi
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4 mr-1" />
                        Sebelumnya
                      </Button>
                      <span className="text-sm">
                        Halaman {currentPage} dari {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Selanjutnya
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Mistake</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditMistake} className="space-y-4">
            <div>
              <Label htmlFor="edit-bank">Bank (Opsional)</Label>
              <Select
                value={editFormData.bankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
              >
                <SelectTrigger id="edit-bank">
                  <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Tidak ada</SelectItem>
                  {banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-amount">Nominal</Label>
              <Input
                id="edit-amount"
                type="number"
                placeholder="0"
                value={editFormData.amount}
                onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
              <Input
                id="edit-notes"
                placeholder="Jelaskan kesalahan yang terjadi"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
              />
            </div>
            <div className="flex gap-2">
              <Button type="submit" className="flex-1" variant="destructive">
                Update
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setEditDialogOpen(false)}
                className="flex-1"
              >
                Batal
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

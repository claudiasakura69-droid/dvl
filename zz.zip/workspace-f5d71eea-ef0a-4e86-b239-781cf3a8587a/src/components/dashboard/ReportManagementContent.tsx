'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { BarChart, Download, FileText } from 'lucide-react'
import { toast } from 'sonner'

interface ReportManagementContentProps {
  sessionId: string | null
}

interface ReportData {
  tgl: string
  deposit: number
  withdraw: number
  transaksiDeposit: number
  transaksiWithdraw: number
}

export default function ReportManagementContent({ sessionId }: ReportManagementContentProps) {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1)
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [reportData, setReportData] = useState<ReportData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (sessionId) {
      fetchReportData()
    }
  }, [sessionId, selectedMonth, selectedYear])

  const fetchReportData = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/report?sessionId=${sessionId}&month=${selectedMonth}&year=${selectedYear}`)
      const data = await response.json()

      if (data.success) {
        setReportData(data.data)
      }
    } catch (error) {
      console.error('Error fetching report data:', error)
      toast.error('Gagal mengambil data report')
    } finally {
      setLoading(false)
    }
  }

  const handleExport = async () => {
    if (!sessionId) return

    try {
      const startDate = new Date(selectedYear, selectedMonth - 1, 1)
      const endDate = new Date(selectedYear, selectedMonth, 0)

      const response = await fetch('/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          startDate: startDate.toISOString().split('T')[0],
          endDate: endDate.toISOString().split('T')[0]
        })
      })

      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `report_${selectedMonth}_${selectedYear}.xlsx`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        toast.success('Export berhasil')
      } else {
        toast.error('Gagal export data')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan saat export')
    }
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`

  // Calculate totals
  const totalDeposit = reportData.reduce((sum, item) => sum + item.deposit, 0)
  const totalWithdraw = reportData.reduce((sum, item) => sum + item.withdraw, 0)
  const totalDepositCount = reportData.reduce((sum, item) => sum + item.transaksiDeposit, 0)
  const totalWithdrawCount = reportData.reduce((sum, item) => sum + item.transaksiWithdraw, 0)

  // Month options
  const months = Array.from({ length: 12 }, (_, i) => i + 1)
  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i)

  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <BarChart className="h-8 w-8" />
            Report
          </h1>
          <p className="text-muted-foreground">
            Statistik transaksi bulanan
          </p>
        </div>

        <div className="flex gap-2 flex-wrap items-center">
          <Select
            value={selectedMonth.toString()}
            onValueChange={(value) => setSelectedMonth(parseInt(value))}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {months.map((month) => (
                <SelectItem key={month} value={month.toString()}>
                  {monthNames[month - 1]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={selectedYear.toString()}
            onValueChange={(value) => setSelectedYear(parseInt(value))}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {years.map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Deposit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(totalDeposit)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {totalDepositCount} transaksi
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Withdraw
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(totalWithdraw)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {totalWithdrawCount} transaksi
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Net Flow
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${totalDeposit - totalWithdraw >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(totalDeposit - totalWithdraw)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {totalDeposit - totalWithdraw >= 0 ? 'Surplus' : 'Defisit'}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Transaksi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalDepositCount + totalWithdrawCount}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {monthNames[selectedMonth - 1]} {selectedYear}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Report Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Detail Harian
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center text-muted-foreground py-8">Memuat data...</p>
          ) : reportData.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Tidak ada data transaksi pada periode ini
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="text-right">Deposit</TableHead>
                  <TableHead className="text-right">Jml Deposit</TableHead>
                  <TableHead className="text-right">Withdraw</TableHead>
                  <TableHead className="text-right">Jml Withdraw</TableHead>
                  <TableHead className="text-right">Net</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reportData.map((item, index) => {
                  const net = item.deposit - item.withdraw
                  return (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{item.tgl}</TableCell>
                      <TableCell className="text-right text-green-600">
                        {formatCurrency(item.deposit)}
                      </TableCell>
                      <TableCell className="text-right">{item.transaksiDeposit}</TableCell>
                      <TableCell className="text-right text-red-600">
                        {formatCurrency(item.withdraw)}
                      </TableCell>
                      <TableCell className="text-right">{item.transaksiWithdraw}</TableCell>
                      <TableCell className={`text-right font-semibold ${net >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(net)}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

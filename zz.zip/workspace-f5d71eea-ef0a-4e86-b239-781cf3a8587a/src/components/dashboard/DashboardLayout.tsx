'use client'

import { ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Users,
  Building2,
  Calendar,
  ArrowRight,
  Receipt,
  AlertCircle,
  LogOut,
  LayoutDashboard,
  BarChart,
  Wallet
} from 'lucide-react'
import { cn } from '@/lib/utils'

// Import content components
import DashboardContent from './DashboardContent'
import UserManagementContent from './UserManagementContent'
import BankManagementContent from './BankManagementContent'
import DayTransactionsContent from './DayTransactionsContent'
import InOutManagementContent from './InOutManagementContent'
import ExpenseManagementContent from './ExpenseManagementContent'
import MistakeManagementContent from './MistakeManagementContent'
import ReportManagementContent from './ReportManagementContent'
import AkuranManagementContent from './AkuranManagementContent'

type Page = 'dashboard' | 'users' | 'banks' | 'day' | 'inout' | 'expense' | 'mistake' | 'report' | 'akuran'

interface DashboardLayoutProps {
  currentPage: Page
  setCurrentPage: (page: Page) => void
  user: { id: string, username: string } | null
  onLogout: () => void
  sessionId: string | null
  children?: ReactNode
}

const menuItems = [
  { id: 'dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
  { id: 'report' as Page, label: 'Report', icon: BarChart },
  { id: 'users' as Page, label: 'Users', icon: Users },
  { id: 'banks' as Page, label: 'Bank', icon: Building2 },
  { id: 'day' as Page, label: 'Day', icon: Calendar },
  { id: 'inout' as Page, label: 'In/Out', icon: ArrowRight },
  { id: 'expense' as Page, label: 'Expense', icon: Receipt },
  { id: 'mistake' as Page, label: 'Mistake', icon: AlertCircle },
  { id: 'akuran' as Page, label: 'Akuran', icon: Wallet },
]

export default function DashboardLayout({ currentPage, setCurrentPage, user, onLogout, sessionId }: DashboardLayoutProps) {
  const renderContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardContent user={user} />

      case 'users':
        return <UserManagementContent sessionId={sessionId} />

      case 'banks':
        return <BankManagementContent sessionId={sessionId} user={user} />

      case 'day':
        return <DayTransactionsContent sessionId={sessionId} user={user} />

      case 'inout':
        return <InOutManagementContent sessionId={sessionId} user={user} />

      case 'expense':
        return <ExpenseManagementContent sessionId={sessionId} user={user} />

      case 'mistake':
        return <MistakeManagementContent sessionId={sessionId} user={user} />

      case 'report':
        return <ReportManagementContent sessionId={sessionId} />

      case 'akuran':
        return <AkuranManagementContent sessionId={sessionId} user={user} />

      default:
        return <DashboardContent user={user} />
    }
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-4 border-b">
          <h1 className="text-xl font-bold">Bank Management</h1>
          {user && (
            <p className="text-sm text-muted-foreground mt-1">
              Welcome, {user.username}
            </p>
          )}
        </div>

        <ScrollArea className="flex-1 p-4">
          <nav className="space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon
              return (
                <Button
                  key={item.id}
                  variant={currentPage === item.id ? 'default' : 'ghost'}
                  className={cn(
                    'w-full justify-start',
                    currentPage === item.id && 'bg-primary text-primary-foreground'
                  )}
                  onClick={() => setCurrentPage(item.id)}
                >
                  <Icon className="mr-2 h-4 w-4" />
                  {item.label}
                </Button>
              )
            })}
          </nav>
        </ScrollArea>

        <div className="p-4 border-t">
          <Button
            variant="destructive"
            className="w-full"
            onClick={onLogout}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Log Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  )
}

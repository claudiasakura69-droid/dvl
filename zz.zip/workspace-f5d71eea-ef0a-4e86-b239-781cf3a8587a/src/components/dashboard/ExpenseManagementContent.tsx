'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Receipt, Plus, Edit, Trash2, Search, ChevronLeft, ChevronRight } from 'lucide-react'
import { toast } from 'sonner'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface ExpenseManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role: string } | null
}

interface Expense {
  id: string
  amount: number
  notes: string | null
  category: string | null
  createdAt: string
  user: {
    id: string
    username: string
  }
  processor: {
    id: string
    username: string
  } | null
}

export default function ExpenseManagementContent({ sessionId, user }: ExpenseManagementContentProps) {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null)
  const [formData, setFormData] = useState({
    amount: '',
    notes: '',
    category: ''
  })
  const [editFormData, setEditFormData] = useState({
    amount: '',
    notes: '',
    category: ''
  })
  const [searchTerm, setSearchTerm] = useState('')
  const [categoryFilter, setCategoryFilter] = useState<string>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 50

  useEffect(() => {
    if (sessionId) {
      fetchExpenses()
    }
  }, [sessionId])

  const fetchExpenses = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/expense?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setExpenses(data.expenses)
      }
    } catch (error) {
      console.error('Error fetching expenses:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/expense', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          amount: '',
          notes: '',
          category: ''
        })
        fetchExpenses()
      } else {
        toast.error(data.error || 'Gagal menambahkan expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingExpense) return

    try {
      const response = await fetch(`/api/expense/${editingExpense.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(editFormData.amount),
          notes: editFormData.notes || null,
          category: editFormData.category || null
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil diupdate')
        setEditDialogOpen(false)
        setEditingExpense(null)
        setEditFormData({
          amount: '',
          notes: '',
          category: ''
        })
        fetchExpenses()
      } else {
        toast.error(data.error || 'Gagal mengupdate expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteExpense = async (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus expense ini?')) return

    try {
      const response = await fetch(`/api/expense/${id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil dihapus')
        fetchExpenses()
      } else {
        toast.error(data.error || 'Gagal menghapus expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (expense: Expense) => {
    setEditingExpense(expense)
    setEditFormData({
      amount: expense.amount.toString(),
      notes: expense.notes || '',
      category: expense.category || ''
    })
    setEditDialogOpen(true)
  }

  const canEditOrDelete = (): boolean => {
    if (!user) return false
    return user.role === 'MASTER' || user.role === 'SUPERVISOR'
  }

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = searchTerm === '' ||
      expense.amount.toString().includes(searchTerm) ||
      (expense.notes && expense.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (expense.category && expense.category.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = categoryFilter === 'all' || expense.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  const uniqueCategories = Array.from(new Set(expenses.map(e => e.category).filter(Boolean)))

  const totalPages = Math.ceil(filteredExpenses.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedExpenses = filteredExpenses.slice(startIndex, endIndex)

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const totalExpense = expenses.reduce((sum, exp) => sum + exp.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <Receipt className="h-8 w-8" />
            Expense
          </h1>
          <p className="text-muted-foreground">
            Catat pengeluaran operasional dan biaya lainnya
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Tambah Expense
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tambah Expense</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddExpense} className="space-y-4">
              <div>
                <Label htmlFor="category">Kategori (Opsional)</Label>
                <Input
                  id="category"
                  placeholder="Contoh: Listrik, Sewa, Internet"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="amount">Nominal</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="notes">Catatan (Opsional)</Label>
                <Input
                  id="notes"
                  placeholder="Catatan untuk pengeluaran ini"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>
              <Button type="submit" className="w-full">
                Simpan
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Riwayat Pengeluaran</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(totalExpense)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Cari nominal, catatan, atau kategori..."
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value)
                      setCurrentPage(1)
                    }}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="w-full sm:w-[200px]">
                <Select
                  value={categoryFilter}
                  onValueChange={(value) => {
                    setCategoryFilter(value)
                    setCurrentPage(1)
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Semua Kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Kategori</SelectItem>
                    {uniqueCategories.map(cat => (
                      <SelectItem key={cat} value={cat!}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <ScrollArea className="h-[600px]">
              {loading ? (
                <p>Memuat data...</p>
              ) : filteredExpenses.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  {searchTerm || categoryFilter !== 'all' ? 'Tidak ada hasil pencarian' : 'Belum ada expense'}
                </p>
              ) : (
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    Menampilkan {startIndex + 1} - {Math.min(endIndex, filteredExpenses.length)} dari {filteredExpenses.length} transaksi
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Waktu</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead>Catatan</TableHead>
                        <TableHead className="text-right">Nominal</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead className="text-right">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginatedExpenses.map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell className="text-sm">{formatDate(expense.createdAt)}</TableCell>
                          <TableCell>
                            <span className="px-2 py-1 rounded-full bg-secondary text-secondary-foreground text-xs">
                              {expense.category || 'Umum'}
                            </span>
                          </TableCell>
                          <TableCell>{expense.notes || '-'}</TableCell>
                          <TableCell className="text-right font-semibold text-red-600">
                            {formatCurrency(expense.amount)}
                          </TableCell>
                          <TableCell className="text-sm">{expense.user.username}</TableCell>
                          <TableCell className="text-right">
                            {canEditOrDelete() && (
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => openEditDialog(expense)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDeleteExpense(expense.id)}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  {totalPages > 1 && (
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="text-sm text-muted-foreground">
                        Halaman {currentPage} dari {totalPages}
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                        >
                          <ChevronLeft className="h-4 w-4" />
                          Sebelumnya
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                          disabled={currentPage === totalPages}
                        >
                          Selanjutnya
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </ScrollArea>
          </div>
        </CardContent>
      </Card>

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Expense</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditExpense} className="space-y-4">
            <div>
              <Label htmlFor="edit-category">Kategori (Opsional)</Label>
              <Input
                id="edit-category"
                placeholder="Contoh: Listrik, Sewa, Internet"
                value={editFormData.category}
                onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="edit-amount">Nominal</Label>
              <Input
                id="edit-amount"
                type="number"
                placeholder="0"
                value={editFormData.amount}
                onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="edit-notes">Catatan (Opsional)</Label>
              <Input
                id="edit-notes"
                placeholder="Catatan untuk pengeluaran ini"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
              />
            </div>
            <Button type="submit" className="w-full">
              Update
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

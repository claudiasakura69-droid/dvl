import { UserRole } from '@prisma/client'

export const ROLE_HIERARCHY = {
  MASTER: 5,
  SUPERVISOR: 4,
  SUPPORT: 3,
  ADMIN: 2,
  VIEW: 1,
} as const

export type UserPermission = {
  canEditUsers: boolean
  canDeleteUsers: boolean
  canAddUsers: boolean
  canEditUserRoles: boolean
  canCreateBanks: boolean
  canEditBanks: boolean
  canDeleteBanks: boolean
  canMoveBanks: boolean
  canToggleBankStatus: boolean
  canCreateTransactions: boolean
  canEditTransactions: boolean
  canDeleteTransactions: boolean
  canProcessTransactions: boolean
  canCreateExpenses: boolean
  canDeleteExpenses: boolean
  canCreateMistakes: boolean
  canDeleteMistakes: boolean
  canCreateAkurans: boolean
  canDeleteAkurans: boolean
}

export function getUserPermissions(role: UserRole): UserPermission {
  switch (role) {
    case UserRole.MASTER:
      return {
        canEditUsers: true,
        canDeleteUsers: true,
        canAddUsers: true,
        canEditUserRoles: true,
        canCreateBanks: true,
        canEditBanks: true,
        canDeleteBanks: true,
        canMoveBanks: true,
        canToggleBankStatus: true,
        canCreateTransactions: true,
        canEditTransactions: true,
        canDeleteTransactions: true,
        canProcessTransactions: true,
        canCreateExpenses: true,
        canDeleteExpenses: true,
        canCreateMistakes: true,
        canDeleteMistakes: true,
        canCreateAkurans: true,
        canDeleteAkurans: true,
      }

    case UserRole.SUPERVISOR:
      return {
        canEditUsers: true,
        canDeleteUsers: false, // Tidak bisa delete user
        canAddUsers: true,
        canEditUserRoles: true,
        canCreateBanks: true,
        canEditBanks: true,
        canDeleteBanks: true,
        canMoveBanks: true,
        canToggleBankStatus: true,
        canCreateTransactions: true,
        canEditTransactions: true,
        canDeleteTransactions: true,
        canProcessTransactions: true,
        canCreateExpenses: true,
        canDeleteExpenses: true,
        canCreateMistakes: true,
        canDeleteMistakes: true,
        canCreateAkurans: true,
        canDeleteAkurans: true,
      }

    case UserRole.SUPPORT:
      return {
        canEditUsers: false,
        canDeleteUsers: false,
        canAddUsers: false,
        canEditUserRoles: false,
        canCreateBanks: true,
        canEditBanks: true,
        canDeleteBanks: true,
        canMoveBanks: true,
        canToggleBankStatus: true,
        canCreateTransactions: true,
        canEditTransactions: true,
        canDeleteTransactions: true,
        canProcessTransactions: true,
        canCreateExpenses: true,
        canDeleteExpenses: true,
        canCreateMistakes: true,
        canDeleteMistakes: true,
        canCreateAkurans: true,
        canDeleteAkurans: true,
      }

    case UserRole.ADMIN:
      return {
        canEditUsers: false,
        canDeleteUsers: false,
        canAddUsers: false,
        canEditUserRoles: false,
        canCreateBanks: false, // Tidak bisa edit di menu bank
        canEditBanks: false,
        canDeleteBanks: false,
        canMoveBanks: false,
        canToggleBankStatus: true, // Bisa set online/offline
        canCreateTransactions: true,
        canEditTransactions: true,
        canDeleteTransactions: true,
        canProcessTransactions: true,
        canCreateExpenses: true,
        canDeleteExpenses: true,
        canCreateMistakes: true,
        canDeleteMistakes: true,
        canCreateAkurans: true,
        canDeleteAkurans: true,
      }

    case UserRole.VIEW:
      return {
        canEditUsers: false,
        canDeleteUsers: false,
        canAddUsers: false,
        canEditUserRoles: false,
        canCreateBanks: false,
        canEditBanks: false,
        canDeleteBanks: false,
        canMoveBanks: false,
        canToggleBankStatus: false,
        canCreateTransactions: false,
        canEditTransactions: false,
        canDeleteTransactions: false,
        canProcessTransactions: false,
        canCreateExpenses: false,
        canDeleteExpenses: false,
        canCreateMistakes: false,
        canDeleteMistakes: false,
        canCreateAkurans: false,
        canDeleteAkurans: false,
      }

    default:
      return {
        canEditUsers: false,
        canDeleteUsers: false,
        canAddUsers: false,
        canEditUserRoles: false,
        canCreateBanks: false,
        canEditBanks: false,
        canDeleteBanks: false,
        canMoveBanks: false,
        canToggleBankStatus: false,
        canCreateTransactions: false,
        canEditTransactions: false,
        canDeleteTransactions: false,
        canProcessTransactions: false,
        canCreateExpenses: false,
        canDeleteExpenses: false,
        canCreateMistakes: false,
        canDeleteMistakes: false,
        canCreateAkurans: false,
        canDeleteAkurans: false,
      }
  }
}

export function canEditRole(currentUserRole: UserRole, targetRole: UserRole): boolean {
  const currentLevel = ROLE_HIERARCHY[currentUserRole]
  const targetLevel = ROLE_HIERARCHY[targetRole]
  return currentLevel >= targetLevel
}

export function canDeleteUser(currentUserRole: UserRole): boolean {
  return currentUserRole === UserRole.MASTER
}

export function isMaster(role: UserRole): boolean {
  return role === UserRole.MASTER
}

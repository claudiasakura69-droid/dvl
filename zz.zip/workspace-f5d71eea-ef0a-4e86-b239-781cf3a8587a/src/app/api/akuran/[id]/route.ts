import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update Akuran
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, amount, notes, category, processedBy } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari akuran yang akan diupdate
    const existingAkuran = await db.akuran.findUnique({
      where: { id: params.id }
    })

    if (!existingAkuran) {
      return NextResponse.json(
        { error: 'Akuran tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cek permission untuk edit transaction
    if (!permissions.canEditTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit akuran. Hanya MASTER dan SUPERVISOR yang dapat mengedit.' },
        { status: 403 }
      )
    }

    const updateData: any = {}

    if (amount !== undefined) updateData.amount = parseFloat(amount)
    if (notes !== undefined) updateData.notes = notes
    if (category !== undefined) updateData.category = category
    if (processedBy !== undefined) updateData.processedBy = processedBy

    // Update akuran
    const akuran = await db.akuran.update({
      where: { id: params.id },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      akuran
    })
  } catch (error) {
    console.error('Update akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate akuran' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus akuran
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const userId = searchParams.get('userId')
    const akuranId = params.id

    if (!sessionId || !userId) {
      return NextResponse.json(
        { error: 'Session ID dan User ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk delete akuran
    if (!permissions.canDeleteAkurans) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus akuran' },
        { status: 403 }
      )
    }

    // Cek apakah akuran ada
    const existingAkuran = await db.akuran.findUnique({
      where: { id: akuranId }
    })

    if (!existingAkuran) {
      return NextResponse.json(
        { error: 'Akuran tidak ditemukan' },
        { status: 404 }
      )
    }

    // Hapus akuran
    await db.akuran.delete({
      where: { id: akuranId }
    })

    return NextResponse.json({
      success: true,
      message: 'Akuran berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus akuran' },
      { status: 500 }
    )
  }
}

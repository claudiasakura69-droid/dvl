import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// GET - Ambil semua akurans
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const month = searchParams.get('month')
    const year = searchParams.get('year')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    let whereClause: any = {}

    // Filter by month and year jika disediakan
    if (month && year) {
      const startDate = new Date(parseInt(year), parseInt(month) - 1, 1)
      const endDate = new Date(parseInt(year), parseInt(month), 0)
      whereClause = {
        createdAt: {
          gte: startDate,
          lte: endDate
        }
      }
    }

    const akurans = await db.akuran.findMany({
      where: whereClause,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      akurans
    })
  } catch (error) {
    console.error('Get akurans error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data akurans' },
      { status: 500 }
    )
  }
}

// POST - Buat akuran baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, category } = await req.json()

    if (!sessionId || !amount) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk create akuran
    if (!permissions.canCreateAkurans) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat akuran' },
        { status: 403 }
      )
    }

    // Buat akuran
    const akuran = await db.akuran.create({
      data: {
        amount: parseFloat(amount),
        notes: notes || null,
        category: category || null,
        userId: currentUser.id
      }
    })

    return NextResponse.json({
      success: true,
      akuran
    })
  } catch (error) {
    console.error('Create akuran error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat akuran' },
      { status: 500 }
    )
  }
}

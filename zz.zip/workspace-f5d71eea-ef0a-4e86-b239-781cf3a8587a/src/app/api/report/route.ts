import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil statistik bulanan
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const month = searchParams.get('month')
    const year = searchParams.get('year')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse bulan dan tahun
    const currentMonth = month ? parseInt(month) : new Date().getMonth() + 1
    const currentYear = year ? parseInt(year) : new Date().getFullYear()

    const startDate = new Date(currentYear, currentMonth - 1, 1)
    const endDate = new Date(currentYear, currentMonth, 0)

    // Ambil semua daily transactions di bulan ini, group by date
    const dailyTransactions = await db.dailyTransaction.findMany({
      where: {
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: { date: 'asc' }
    })

    // Group transactions by date
    const transactionsByDate: { [key: string]: any } = {}

    dailyTransactions.forEach(tx => {
      const dateKey = tx.date.toISOString().split('T')[0]
      if (!transactionsByDate[dateKey]) {
        transactionsByDate[dateKey] = {
          deposits: { total: 0, count: 0 },
          withdraws: { total: 0, count: 0 }
        }
      }

      if (tx.type === 'DEPOSIT') {
        transactionsByDate[dateKey].deposits.total += tx.amount
        transactionsByDate[dateKey].deposits.count += 1
      } else if (tx.type === 'WITHDRAW') {
        transactionsByDate[dateKey].withdraws.total += tx.amount
        transactionsByDate[dateKey].withdraws.count += 1
      }
    })

    // Convert ke array format yang diminta
    const reportData = Object.keys(transactionsByDate).map(dateKey => {
      const date = new Date(dateKey)
      const formattedDate = date.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: '2-digit'
      }).replace(/\./g, '-')

      const data = transactionsByDate[dateKey]

      return {
        tgl: formattedDate,
        deposit: data.deposits.total,
        withdraw: data.withdraws.total,
        transaksiDeposit: data.deposits.count,
        transaksiWithdraw: data.withdraws.count
      }
    })

    // Sort by date ascending
    reportData.sort((a, b) => {
      const dateA = new Date(a.tgl.split('-').reverse().join('-'))
      const dateB = new Date(b.tgl.split('-').reverse().join('-'))
      return dateA.getTime() - dateB.getTime()
    })

    return NextResponse.json({
      success: true,
      data: reportData,
      month: currentMonth,
      year: currentYear
    })
  } catch (error) {
    console.error('Get report error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data report' },
      { status: 500 }
    )
  }
}

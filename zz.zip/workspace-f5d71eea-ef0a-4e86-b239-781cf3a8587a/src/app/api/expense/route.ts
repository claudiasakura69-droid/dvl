import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// GET - Ambil semua expenses
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const expenses = await db.expense.findMany({
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      expenses
    })
  } catch (error) {
    console.error('Get expenses error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data expenses' },
      { status: 500 }
    )
  }
}

// POST - Buat expense baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, category } = await req.json()

    if (!sessionId || !amount) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk create expense
    if (!permissions.canCreateExpenses) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat expense' },
        { status: 403 }
      )
    }

    // Buat expense
    const expense = await db.expense.create({
      data: {
        amount: parseFloat(amount),
        notes: notes || null,
        category: category || null,
        userId: currentUser.id
      }
    })

    return NextResponse.json({
      success: true,
      expense
    })
  } catch (error) {
    console.error('Create expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat expense' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update Expense
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, amount, notes, category, processedBy } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari expense yang akan diupdate
    const existingExpense = await db.expense.findUnique({
      where: { id: params.id }
    })

    if (!existingExpense) {
      return NextResponse.json(
        { error: 'Expense tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cek permission untuk edit transaction
    if (!permissions.canEditTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit expense. Hanya MASTER dan SUPERVISOR yang dapat mengedit.' },
        { status: 403 }
      )
    }

    const updateData: any = {}

    if (amount !== undefined) updateData.amount = parseFloat(amount)
    if (notes !== undefined) updateData.notes = notes
    if (category !== undefined) updateData.category = category
    if (processedBy !== undefined) updateData.processedBy = processedBy

    // Update expense
    const expense = await db.expense.update({
      where: { id: params.id },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      expense
    })
  } catch (error) {
    console.error('Update expense error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate expense' },
      { status: 500 }
    )
  }
}

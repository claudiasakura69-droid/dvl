import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// GET - Ambil semua mistakes
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const mistakes = await db.mistake.findMany({
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      mistakes
    })
  } catch (error) {
    console.error('Get mistakes error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data mistakes' },
      { status: 500 }
    )
  }
}

// POST - Buat mistake baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, amount, notes, bankId } = await req.json()

    if (!sessionId || !amount) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk create mistake
    if (!permissions.canCreateMistakes) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat mistake' },
        { status: 403 }
      )
    }

    // Jika bankId disertakan, cek bank
    if (bankId) {
      const bank = await db.bank.findUnique({
        where: { id: bankId }
      })

      if (!bank) {
        return NextResponse.json(
          { error: 'Bank tidak ditemukan' },
          { status: 404 }
        )
      }
    }

    // Buat mistake
    const mistake = await db.mistake.create({
      data: {
        amount: parseFloat(amount),
        notes: notes || null,
        bankId: bankId || null,
        userId: currentUser.id
      }
    })

    return NextResponse.json({
      success: true,
      mistake
    })
  } catch (error) {
    console.error('Create mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat mistake' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update Mistake
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, amount, notes, bankId, processedBy } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari mistake yang akan diupdate
    const existingMistake = await db.mistake.findUnique({
      where: { id: params.id }
    })

    if (!existingMistake) {
      return NextResponse.json(
        { error: 'Mistake tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cek permission untuk edit transaction
    if (!permissions.canEditTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit mistake. Hanya MASTER dan SUPERVISOR yang dapat mengedit.' },
        { status: 403 }
      )
    }

    const updateData: any = {}

    if (amount !== undefined) updateData.amount = parseFloat(amount)
    if (notes !== undefined) updateData.notes = notes
    if (bankId !== undefined) updateData.bankId = bankId
    if (processedBy !== undefined) updateData.processedBy = processedBy

    // Update mistake
    const mistake = await db.mistake.update({
      where: { id: params.id },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      mistake
    })
  } catch (error) {
    console.error('Update mistake error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate mistake' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole, TransactionStatus } from '@prisma/client'
import { getUserPermissions } from '@/lib/permissions'

// GET - Ambil transaksi harian berdasarkan tanggal
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const dateStr = searchParams.get('date')
    const type = searchParams.get('type') // 'DEPOSIT' atau 'WITHDRAW' atau undefined untuk semua

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tanggal
    let startDate: Date
    let endDate: Date

    if (dateStr) {
      const date = new Date(dateStr)
      startDate = new Date(date.setHours(0, 0, 0, 0))
      endDate = new Date(date.setHours(23, 59, 59, 999))
    } else {
      // Default hari ini
      const today = new Date()
      startDate = new Date(today.setHours(0, 0, 0, 0))
      endDate = new Date(today.setHours(23, 59, 59, 999))
    }

    // Build query
    const where: any = {
      date: {
        gte: startDate,
        lte: endDate
      }
    }

    if (type) {
      where.type = type
    }

    // Ambil transaksi harian dengan relasi lengkap
    const transactions = await db.dailyTransaction.findMany({
      where,
      include: {
        bank: true,
        destinationBank: true,
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      },
      orderBy: { date: 'desc' }
    })

    return NextResponse.json({
      success: true,
      transactions
    })
  } catch (error) {
    console.error('Get daily transactions error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data transaksi harian' },
      { status: 500 }
    )
  }
}

// POST - Buat transaksi baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, date, name, accountNumber, amount, type, bankId, destinationBankId, destinationOther, notes, status } = await req.json()

    if (!sessionId || !date || !name || !amount || !type || !bankId) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    if (!['DEPOSIT', 'WITHDRAW'].includes(type)) {
      return NextResponse.json(
        { error: 'Type tidak valid' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk create transaction
    if (!permissions.canCreateTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat transaksi' },
        { status: 403 }
      )
    }

    // Cari bank yang akan menerima transaksi
    const bank = await db.bank.findUnique({
      where: { id: bankId }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Parse tanggal
    const transactionDate = new Date(date)

    // Default status PENDING
    const transactionStatus = status || TransactionStatus.PENDING

    // Buat transaksi
    const transaction = await db.dailyTransaction.create({
      data: {
        date: transactionDate,
        name,
        accountNumber: accountNumber || null,
        amount: parseFloat(amount),
        type,
        bankId,
        status: transactionStatus,
        destinationBankId: destinationBankId || null,
        destinationOther: destinationOther || null,
        notes: notes || null,
        userId: currentUser.id
      }
    })

    // Jika status COMPLETE, update balance bank
    if (transactionStatus === TransactionStatus.COMPLETE) {
      const newBalance = type === 'DEPOSIT'
        ? bank.balance + parseFloat(amount)
        : bank.balance - parseFloat(amount)

      await db.bank.update({
        where: { id: bankId },
        data: { balance: newBalance }
      })
    }

    return NextResponse.json({
      success: true,
      transaction
    })
  } catch (error) {
    console.error('Create daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat transaksi' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TransactionStatus } from '@prisma/client'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update transaksi (status, processedBy, dll)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, status, processedBy, notes, destinationBankId, destinationOther, name, amount, type, date, bankId } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari transaksi yang akan diupdate
    const existingTransaction = await db.dailyTransaction.findUnique({
      where: { id: params.id },
      include: {
        bank: true
      }
    })

    if (!existingTransaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cek permission untuk edit transaction
    if (!permissions.canEditTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit transaksi. Hanya MASTER dan SUPERVISOR yang dapat mengedit.' },
        { status: 403 }
      )
    }

    const updateData: any = {}

    // Update basic fields
    if (name !== undefined) updateData.name = name
    if (amount !== undefined) updateData.amount = parseFloat(amount)
    if (type !== undefined) updateData.type = type
    if (date !== undefined) updateData.date = new Date(date)
    if (bankId !== undefined) updateData.bankId = bankId

    // Update status
    if (status && status !== existingTransaction.status) {
      updateData.status = status

      // Jika berubah dari PENDING ke COMPLETE, update balance bank
      if (existingTransaction.status === TransactionStatus.PENDING && status === TransactionStatus.COMPLETE) {
        const newBalance = existingTransaction.type === 'DEPOSIT'
          ? existingTransaction.bank.balance + existingTransaction.amount
          : existingTransaction.bank.balance - existingTransaction.amount

        await db.bank.update({
          where: { id: existingTransaction.bankId },
          data: { balance: newBalance }
        })
      }
      // Jika berubah dari COMPLETE ke PENDING, revert balance bank
      else if (existingTransaction.status === TransactionStatus.COMPLETE && status === TransactionStatus.PENDING) {
        const newBalance = existingTransaction.type === 'DEPOSIT'
          ? existingTransaction.bank.balance - existingTransaction.amount
          : existingTransaction.bank.balance + existingTransaction.amount

        await db.bank.update({
          where: { id: existingTransaction.bankId },
          data: { balance: newBalance }
        })
      }
    }

    // Update processedBy (user yang memproses)
    if (processedBy !== undefined) {
      updateData.processedBy = processedBy
    } else if (status === TransactionStatus.COMPLETE && !existingTransaction.processedBy) {
      // Auto set processedBy jika status COMPLETE dan belum ada processor
      updateData.processedBy = currentUser.id
    }

    // Update notes
    if (notes !== undefined) {
      updateData.notes = notes
    }

    // Update destination
    if (destinationBankId !== undefined) {
      updateData.destinationBankId = destinationBankId
    }
    if (destinationOther !== undefined) {
      updateData.destinationOther = destinationOther
    }

    // Update transaksi
    const transaction = await db.dailyTransaction.update({
      where: { id: params.id },
      data: updateData,
      include: {
        bank: true,
        destinationBank: true,
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      transaction
    })
  } catch (error) {
    console.error('Update daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate transaksi' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus transaksi
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk delete transaction
    if (!permissions.canDeleteTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus transaksi' },
        { status: 403 }
      )
    }

    // Cari transaksi yang akan dihapus
    const existingTransaction = await db.dailyTransaction.findUnique({
      where: { id: params.id },
      include: {
        bank: true
      }
    })

    if (!existingTransaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Jika status COMPLETE, revert balance bank sebelum hapus
    if (existingTransaction.status === TransactionStatus.COMPLETE) {
      const newBalance = existingTransaction.type === 'DEPOSIT'
        ? existingTransaction.bank.balance - existingTransaction.amount
        : existingTransaction.bank.balance + existingTransaction.amount

      await db.bank.update({
        where: { id: existingTransaction.bankId },
        data: { balance: newBalance }
      })
    }

    // Hapus transaksi
    await db.dailyTransaction.delete({
      where: { id: params.id }
    })

    return NextResponse.json({
      success: true,
      message: 'Transaksi berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete daily transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus transaksi' },
      { status: 500 }
    )
  }
}

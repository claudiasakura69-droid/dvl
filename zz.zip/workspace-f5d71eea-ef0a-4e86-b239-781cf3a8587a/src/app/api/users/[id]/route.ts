import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole } from '@prisma/client'
import { getUserPermissions, canEditRole, canDeleteUser, isMaster } from '@/lib/permissions'

// PUT - Update user (role dan isActive)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, role, isActive } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari user yang akan diupdate
    const targetUser = await db.user.findUnique({
      where: { id: params.id }
    })

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    // Tidak boleh mengubah role MASTER
    if (isMaster(targetUser.role)) {
      return NextResponse.json(
        { error: 'User MASTER tidak dapat diubah' },
        { status: 403 }
      )
    }

    // Cek permission: tidak boleh mengubah role user sendiri jika lebih tinggi
    if (currentUser.id === params.id) {
      return NextResponse.json(
        { error: 'Anda tidak dapat mengubah role sendiri' },
        { status: 403 }
      )
    }

    // Cek permission untuk edit user
    if (!permissions.canEditUsers) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit user' },
        { status: 403 }
      )
    }

    // Jika mengubah role, cek permission
    if (role && role !== targetUser.role) {
      if (!permissions.canEditUserRoles) {
        return NextResponse.json(
          { error: 'Anda tidak memiliki izin untuk mengubah role user' },
          { status: 403 }
        )
      }

      if (!canEditRole(currentUser.role, role)) {
        return NextResponse.json(
          { error: 'Anda tidak dapat menetapkan role ini' },
          { status: 403 }
        )
      }
    }

    // Update user
    const updateData: any = {}
    if (role) updateData.role = role
    if (isActive !== undefined) updateData.isActive = isActive

    const user = await db.user.update({
      where: { id: params.id },
      data: updateData
    })

    return NextResponse.json({
      success: true,
      user
    })
  } catch (error) {
    console.error('Update user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate user' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus user (hanya MASTER)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user

    // Hanya MASTER yang bisa delete user
    if (!canDeleteUser(currentUser.role)) {
      return NextResponse.json(
        { error: 'Hanya user MASTER yang dapat menghapus user' },
        { status: 403 }
      )
    }

    // Cari user yang akan dihapus
    const targetUser = await db.user.findUnique({
      where: { id: params.id }
    })

    if (!targetUser) {
      return NextResponse.json(
        { error: 'User tidak ditemukan' },
        { status: 404 }
      )
    }

    // Tidak boleh menghapus user MASTER
    if (isMaster(targetUser.role)) {
      return NextResponse.json(
        { error: 'User MASTER tidak dapat dihapus' },
        { status: 403 }
      )
    }

    // Tidak boleh menghapus diri sendiri
    if (currentUser.id === params.id) {
      return NextResponse.json(
        { error: 'Anda tidak dapat menghapus diri sendiri' },
        { status: 403 }
      )
    }

    // Hapus user (cascade akan menghapus sessions dan transactions)
    await db.user.delete({
      where: { id: params.id }
    })

    return NextResponse.json({
      success: true,
      message: 'User berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus user' },
      { status: 500 }
    )
  }
}

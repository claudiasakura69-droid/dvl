import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { UserRole } from '@prisma/client'
import { getUserPermissions, canEditRole, canDeleteUser } from '@/lib/permissions'

// GET - Ambil semua users
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user dengan role
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Ambil semua users dengan sessions mereka
    const users = await db.user.findMany({
      include: {
        sessions: {
          orderBy: { loginAt: 'desc' },
          take: 10
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    // Format data
    const formattedUsers = users.map(user => ({
      id: user.id,
      username: user.username,
      role: user.role,
      isActive: user.isActive,
      isMaster: user.role === UserRole.MASTER,
      createdAt: user.createdAt,
      sessions: user.sessions.map(s => ({
        id: s.id,
        loginAt: s.loginAt,
        logoutAt: s.logoutAt,
        ipAddress: s.ipAddress,
        isOnline: !s.logoutAt
      }))
    }))

    return NextResponse.json({
      success: true,
      users: formattedUsers,
      currentUser: {
        id: currentUser.id,
        username: currentUser.username,
        role: currentUser.role,
        permissions
      }
    })
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data users' },
      { status: 500 }
    )
  }
}

// POST - Buat user baru (hanya MASTER dan SUPERVISOR)
export async function POST(req: NextRequest) {
  try {
    const { sessionId, username, token, role } = await req.json()

    if (!sessionId || !username || !token) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission: hanya MASTER dan SUPERVISOR yang bisa add user
    if (!permissions.canAddUsers) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menambah user' },
        { status: 403 }
      )
    }

    // User baru default role VIEW
    const newUserRole = role || UserRole.VIEW

    // Jika role bukan default VIEW, cek apakah current user bisa set role tersebut
    if (newUserRole !== UserRole.VIEW) {
      if (!canEditRole(currentUser.role, newUserRole)) {
        return NextResponse.json(
          { error: 'Anda tidak memiliki izin untuk menetapkan role ini' },
          { status: 403 }
        )
      }
    }

    // Cek apakah username sudah ada
    const existingUser = await db.user.findUnique({
      where: { username }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username sudah digunakan' },
        { status: 400 }
      )
    }

    // Buat user baru
    const user = await db.user.create({
      data: {
        username,
        token,
        role: newUserRole,
        isActive: true
      }
    })

    return NextResponse.json({
      success: true,
      user
    })
  } catch (error) {
    console.error('Create user error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat user' },
      { status: 500 }
    )
  }
}

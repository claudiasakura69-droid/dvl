import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update bank
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, name, accountName, accountNumber, balance, type, userId } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari bank yang akan diupdate
    const existingBank = await db.bank.findUnique({
      where: { id: params.id }
    })

    if (!existingBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Hanya MASTER dan SUPERVISOR yang bisa edit bank
    if (!permissions.canEditBanks) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit bank. Hanya MASTER dan SUPERVISOR yang dapat mengedit bank.' },
        { status: 403 }
      )
    }

    // Update bank
    const bank = await db.bank.update({
      where: { id: params.id },
      data: {
        name: name || existingBank.name,
        accountName: accountName || existingBank.accountName,
        accountNumber: accountNumber !== undefined ? accountNumber : existingBank.accountNumber,
        balance: balance !== undefined ? parseFloat(balance) : existingBank.balance,
        type: type || existingBank.type
      }
    })

    // Catat history jika ada perubahan balance
    if (balance !== undefined && balance !== existingBank.balance) {
      await db.bankHistory.create({
        data: {
          bankId: bank.id,
          eventType: 'UPDATED',
          oldBalance: existingBank.balance,
          newBalance: balance,
          notes: 'Balance diperbarui',
          userId: userId || currentUser.id
        }
      })
    }

    return NextResponse.json({
      success: true,
      bank
    })
  } catch (error) {
    console.error('Update bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate bank' },
      { status: 500 }
    )
  }
}

// DELETE - Hapus bank
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const userId = searchParams.get('userId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari bank yang akan dihapus
    const bank = await db.bank.findUnique({
      where: { id: params.id }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Hanya MASTER dan SUPERVISOR yang bisa delete bank
    if (!permissions.canDeleteBanks) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk menghapus bank. Hanya MASTER dan SUPERVISOR yang dapat menghapus bank.' },
        { status: 403 }
      )
    }

    // Hapus bank (cascade akan menghapus history dan transactions)
    await db.bank.delete({
      where: { id: params.id }
    })

    return NextResponse.json({
      success: true,
      message: 'Bank berhasil dihapus'
    })
  } catch (error) {
    console.error('Delete bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat menghapus bank' },
      { status: 500 }
    )
  }
}

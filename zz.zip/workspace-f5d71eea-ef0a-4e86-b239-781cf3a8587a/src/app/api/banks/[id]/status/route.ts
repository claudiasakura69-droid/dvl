import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Update status bank (online/offline)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, status, userId } = await req.json()

    if (!sessionId || !status) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    if (!['online', 'offline'].includes(status)) {
      return NextResponse.json(
        { error: 'Status tidak valid' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cari bank yang akan diupdate
    const existingBank = await db.bank.findUnique({
      where: { id: params.id }
    })

    if (!existingBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Update status bank
    const bank = await db.bank.update({
      where: { id: params.id },
      data: {
        status
      }
    })

    // Catat history
    await db.bankHistory.create({
      data: {
        bankId: bank.id,
        eventType: 'STATUS_CHANGED',
        oldValue: existingBank.status,
        newValue: status,
        notes: `Status diubah menjadi ${status}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      bank
    })
  } catch (error) {
    console.error('Update bank status error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate status bank' },
      { status: 500 }
    )
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Ambil detail bank dengan perhitungan saldo
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')
    const dateStr = searchParams.get('date')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cari bank
    const bank = await db.bank.findUnique({
      where: { id: params.id }
    })

    if (!bank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    // Tentukan tanggal target (hari ini atau tanggal yang dipilih)
    const targetDate = dateStr ? new Date(dateStr) : new Date()
    targetDate.setHours(23, 59, 59, 999)

    // Hitung semua transaksi dari awal sampai target date
    const allDailyTransactions = await db.dailyTransaction.findMany({
      where: {
        bankId: params.id,
        date: {
          lte: targetDate
        }
      }
    })

    const allInOutTransactions = await db.inOut.findMany({
      where: {
        OR: [
          { fromBankId: params.id },
          { toBankId: params.id }
        ],
        createdAt: {
          lte: targetDate
        }
      }
    })

    const allExpenses = await db.expense.findMany({
      where: {
        createdAt: {
          lte: targetDate
        }
      }
    })

    const allMistakes = await db.mistake.findMany({
      where: {
        bankId: params.id,
        createdAt: {
          lte: targetDate
        }
      }
    })

    const allAkurans = await db.akuran.findMany({
      where: {
        createdAt: {
          lte: targetDate
        }
      }
    })

    // Hitung transaksi hari ini
    const todayStart = new Date(targetDate)
    todayStart.setHours(0, 0, 0, 0)

    const todayDailyTransactions = allDailyTransactions.filter(t => t.date >= todayStart)
    const todayInOutTransactions = allInOutTransactions.filter(t => t.createdAt >= todayStart)
    const todayExpenses = allExpenses.filter(t => t.createdAt >= todayStart)
    const todayMistakes = allMistakes.filter(t => t.createdAt >= todayStart)
    const todayAkurans = allAkurans.filter(t => t.createdAt >= todayStart)

    // Perhitungan semua transaksi (dari awal sampai hari ini)
    const allTotalDaily = allDailyTransactions.reduce((sum, t) => sum + (t.type === 'DEPOSIT' ? t.amount : -t.amount), 0)
    
    // InOut: jika dari bank = minus, jika ke bank = plus
    const allTotalInOut = allInOutTransactions.reduce((sum, t) => {
      if (t.fromBankId === params.id) return sum - t.amount
      if (t.toBankId === params.id) return sum + t.amount
      return sum
    }, 0)

    const allTotalExpense = allExpenses.reduce((sum, t) => sum + t.amount, 0)
    const allTotalMistake = allMistakes.reduce((sum, t) => sum + t.amount, 0)
    const allTotalAkuran = allAkurans.reduce((sum, t) => sum + t.amount, 0)

    // Perhitungan transaksi hari ini
    const todayTotalDaily = todayDailyTransactions.reduce((sum, t) => sum + (t.type === 'DEPOSIT' ? t.amount : -t.amount), 0)
    
    const todayTotalInOut = todayInOutTransactions.reduce((sum, t) => {
      if (t.fromBankId === params.id) return sum - t.amount
      if (t.toBankId === params.id) return sum + t.amount
      return sum
    }, 0)

    const todayTotalExpense = todayExpenses.reduce((sum, t) => sum + t.amount, 0)
    const todayTotalMistake = todayMistakes.reduce((sum, t) => sum + t.amount, 0)
    const todayTotalAkuran = todayAkurans.reduce((sum, t) => sum + t.amount, 0)

    // Hitung total saldo akhir
    // saldo awal + semua transaksi + inOut - expense - mistake - akuran
    const totalSaldo = bank.balance + allTotalDaily + allTotalInOut - allTotalExpense - allTotalMistake - allTotalAkuran

    return NextResponse.json({
      success: true,
      bank: {
        id: bank.id,
        name: bank.name,
        accountName: bank.accountName,
        accountNumber: bank.accountNumber,
        type: bank.type,
        balance: bank.balance, // Saldo awal
        status: bank.status,
        createdAt: bank.createdAt,
        updatedAt: bank.updatedAt
      },
      perhitungan: {
        semuaTransaksi: allTotalDaily,
        semuaInOut: allTotalInOut,
        semuaExpense: allTotalExpense,
        semuaMistake: allTotalMistake,
        semuaAkurans: allTotalAkuran,
        transaksiHariIni: todayTotalDaily,
        inOutHariIni: todayTotalInOut,
        expenseHariIni: todayTotalExpense,
        mistakeHariIni: todayTotalMistake,
        akuranHariIni: todayTotalAkuran,
        totalSaldo: totalSaldo
      },
      history: {
        dailyTransactions: allDailyTransactions.length,
        inOutTransactions: allInOutTransactions.length,
        expenses: allExpenses.length,
        mistakes: allMistakes.length,
        akurans: allAkurans.length
      }
    })
  } catch (error) {
    console.error('Get bank detail error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil detail bank' },
      { status: 500 }
    )
  }
}

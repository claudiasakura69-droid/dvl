import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT - Move bank dari deposit ke withdraw atau sebaliknya
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, newType, userId } = await req.json()

    if (!sessionId || !newType) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    if (!['DEPOSIT', 'WITHDRAW'].includes(newType)) {
      return NextResponse.json(
        { error: 'Type tidak valid' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Cari bank yang akan dipindahkan
    const existingBank = await db.bank.findUnique({
      where: { id: params.id }
    })

    if (!existingBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    if (existingBank.type === newType) {
      return NextResponse.json(
        { error: 'Bank sudah berada di tipe tersebut' },
        { status: 400 }
      )
    }

    // Update type bank
    const bank = await db.bank.update({
      where: { id: params.id },
      data: {
        type: newType
      }
    })

    // Catat history
    await db.bankHistory.create({
      data: {
        bankId: bank.id,
        eventType: 'MOVED',
        oldType: existingBank.type,
        newType: newType,
        oldBalance: existingBank.balance,
        newBalance: existingBank.balance,
        notes: `Dipindahkan dari ${existingBank.type} ke ${newType}`,
        userId
      }
    })

    return NextResponse.json({
      success: true,
      bank
    })
  } catch (error) {
    console.error('Move bank error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat memindahkan bank' },
      { status: 500 }
    )
  }
}

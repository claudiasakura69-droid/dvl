import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const { sessionId } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cari session yang masih aktif
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: {
        user: true
      }
    })

    if (!session) {
      return NextResponse.json(
        { error: 'Session tidak ditemukan' },
        { status: 404 }
      )
    }

    if (session.logoutAt) {
      return NextResponse.json(
        { error: 'Session sudah logout' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      success: true,
      user: {
        id: session.user.id,
        username: session.user.username,
        role: session.user.role
      }
    })
  } catch (error) {
    console.error('Session check error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengecek session' },
      { status: 500 }
    )
  }
}

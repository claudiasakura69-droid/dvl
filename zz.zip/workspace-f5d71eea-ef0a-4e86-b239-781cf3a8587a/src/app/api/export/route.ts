import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import * as XLSX from 'xlsx'

// POST - Export data ke Excel dengan format sesuai requirement
export async function POST(req: NextRequest) {
  try {
    const { sessionId, startDate, endDate } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    // Parse tanggal
    const start = startDate ? new Date(startDate) : new Date()
    const end = endDate ? new Date(endDate) : new Date(startDate || new Date())

    start.setHours(0, 0, 0, 0)
    end.setHours(23, 59, 59, 999)

    // Ambil semua dates dalam range
    const dates: Date[] = []
    const currentDate = new Date(start)
    while (currentDate <= end) {
      dates.push(new Date(currentDate))
      currentDate.setDate(currentDate.getDate() + 1)
    }

    // Buat workbook
    const workbook = XLSX.utils.book_new()

    // Format tanggal Indonesia
    const formatDate = (date: Date) => {
      return date.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: '2-digit'
      }).replace(/\./g, '')
    }

    const formatDateTime = (date: Date) => {
      return `${formatDate(date)} ${date.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit'
      })}`
    }

    const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`

    // ==========================================
    // PART 1: Day Transactions - 1 sheet per tanggal
    // ==========================================
    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      // Ambil data untuk tanggal ini
      const dailyTransactions = await db.dailyTransaction.findMany({
        where: {
          date: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          bank: true,
          destinationBank: true,
          user: true,
          processor: true
        },
        orderBy: { date: 'desc' }
      })

      if (dailyTransactions.length === 0) continue

      // Persiapkan data untuk sheet ini
      const sheetData: any[] = []

      // ========================
      // TABLE DEPOSIT (A-G)
      // ========================
      
      // Header Deposit
      sheetData.push(['tgl-bln-tahun Waktu', 'nama', 'bank', 'nominal', 'tujuan bank', 'status', 'proses (note)'])
      sheetData.push([]) // Empty row untuk spacing

      // Deposit data
      const deposits = dailyTransactions.filter(t => t.type === 'DEPOSIT')
      deposits.forEach(t => {
        const destination = t.destinationBank
          ? `${t.destinationBank.name} - ${t.destinationBank.accountName}`
          : t.destinationOther || '-'

        sheetData.push([
          formatDateTime(t.date),
          t.name,
          `${t.bank.name} - ${t.bank.accountName}`,
          formatCurrency(t.amount),
          destination,
          t.status,
          t.processor?.username || t.user.username
        ])
      })

      // Total Deposit
      if (deposits.length > 0) {
        const totalDeposit = deposits.reduce((sum, t) => sum + t.amount, 0)
        sheetData.push(['', '', '', 'Total Deposit:', formatCurrency(totalDeposit), '', '', ''])
      }

      // Empty row sebelum Withdraw
      sheetData.push([])
      sheetData.push(['===================', '', '', '', '', '', '', '']) // Separator
      sheetData.push([])

      // ========================
      // TABLE WITHDRAW (Mulai setelah deposit)
      // ========================
      
      // Header Withdraw
      sheetData.push(['tgl-bln-tahun Waktu', 'nama', 'bank', 'nominal', 'tujuan bank', 'status', 'proses (note)'])
      sheetData.push([]) // Empty row untuk spacing

      // Withdraw data
      const withdraws = dailyTransactions.filter(t => t.type === 'WITHDRAW')
      withdraws.forEach(t => {
        const destination = t.destinationBank
          ? `${t.destinationBank.name} - ${t.destinationBank.accountName}`
          : t.destinationOther || '-'

        sheetData.push([
          formatDateTime(t.date),
          t.name,
          `${t.bank.name} - ${t.bank.accountName}`,
          formatCurrency(t.amount),
          destination,
          t.status,
          t.processor?.username || t.user.username
        ])
      })

      // Total Withdraw
      if (withdraws.length > 0) {
        const totalWithdraw = withdraws.reduce((sum, t) => sum + t.amount, 0)
        sheetData.push(['', '', '', 'Total Withdraw:', formatCurrency(totalWithdraw), '', '', ''])
      }

      // Buat worksheet untuk tanggal ini
      const worksheet = XLSX.utils.aoa_to_sheet(sheetData)

      // Set column widths
      worksheet['!cols'] = [
        { wch: 20 }, // tgl-bln-tahun Waktu
        { wch: 20 }, // nama
        { wch: 25 }, // bank
        { wch: 15 }, // nominal
        { wch: 25 }, // tujuan bank
        { wch: 10 }, // status
        { wch: 20 }, // proses (note)
      ]

      // Add sheet dengan nama tanggal
      const sheetName = formatDate(date)
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName)
    }

    // ==========================================
    // PART 2: In/Out - 1 sheet untuk semua tanggal
    // ==========================================
    
    const inOutSheetData: any[] = [
      ['tgl-bln-tahun Waktu', 'bank (pengirim)', 'nominal', 'tujuan bank (penerima)', 'status', 'proses (note)']
    ]

    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const inOuts = await db.inOut.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          fromBank: true,
          toBank: true,
          user: true,
          processor: true
        },
        orderBy: { createdAt: 'desc' }
      })

      inOuts.forEach(inout => {
        const fromBank = inout.fromBank
          ? `${inout.fromBank.name} - ${inout.fromBank.accountName}`
          : inout.destinationOther || '-'

        const toBank = inout.toBank
          ? `${inout.toBank.name} - ${inout.toBank.accountName}`
          : inout.destinationOther || '-'

        inOutSheetData.push([
          formatDateTime(inout.createdAt),
          fromBank,
          formatCurrency(inout.amount),
          toBank,
          inout.status,
          inout.processor?.username || inout.user.username
        ])
      })
    }

    if (inOutSheetData.length > 1) {
      const inOutWorksheet = XLSX.utils.aoa_to_sheet(inOutSheetData)
      inOutWorksheet['!cols'] = [
        { wch: 20 }, // tgl-bln-tahun Waktu
        { wch: 25 }, // bank (pengirim)
        { wch: 15 }, // nominal
        { wch: 25 }, // tujuan bank (penerima)
        { wch: 10 }, // status
        { wch: 20 }, // proses (note)
      ]
      XLSX.utils.book_append_sheet(workbook, inOutWorksheet, 'In/Out')
    }

    // ==========================================
    // PART 3: Expense - 1 sheet untuk semua tanggal
    // ==========================================
    
    const expenseSheetData: any[] = [
      ['tgl-bln-tahun Waktu', 'bank (pengirim)', 'nominal', 'tujuan bank (penerima)', 'status', 'proses (note)']
    ]

    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const expenses = await db.expense.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          user: true,
          processor: true
        },
        orderBy: { createdAt: 'desc' }
      })

      expenses.forEach(exp => {
        expenseSheetData.push([
          formatDateTime(exp.createdAt),
          '-', // bank (pengirim) - expense tidak ada bank pengirim
          formatCurrency(exp.amount),
          '-', // tujuan bank (penerima) - expense tidak ada tujuan bank
          '-', // status - expense tidak ada status
          exp.processor?.username || exp.user.username
        ])
      })
    }

    if (expenseSheetData.length > 1) {
      const expenseWorksheet = XLSX.utils.aoa_to_sheet(expenseSheetData)
      expenseWorksheet['!cols'] = [
        { wch: 20 }, // tgl-bln-tahun Waktu
        { wch: 25 }, // bank (pengirim)
        { wch: 15 }, // nominal
        { wch: 25 }, // tujuan bank (penerima)
        { wch: 10 }, // status
        { wch: 20 }, // proses (note)
      ]
      XLSX.utils.book_append_sheet(workbook, expenseWorksheet, 'Expense')
    }

    // ==========================================
    // PART 4: Mistake - 1 sheet untuk semua tanggal
    // ==========================================
    
    const mistakeSheetData: any[] = [
      ['tgl-bln-tahun Waktu', 'bank (pengirim)', 'nominal', 'tujuan bank (penerima)', 'status', 'proses (note)']
    ]

    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const mistakes = await db.mistake.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          user: true,
          processor: true
        },
        orderBy: { createdAt: 'desc' }
      })

      mistakes.forEach(mistake => {
        let bankName = '-'
        if (mistake.bankId) {
          // Note: Untuk mistake, kita ambil bank info
          // Bank relation bisa diinclude jika diperlukan
          bankName = 'Bank ID: ' + mistake.bankId
        }

        mistakeSheetData.push([
          formatDateTime(mistake.createdAt),
          bankName, // bank (pengirim) - bank yang terkena kesalahan
          formatCurrency(mistake.amount),
          '-', // tujuan bank (penerima) - mistake tidak ada tujuan
          '-', // status - mistake tidak ada status
          mistake.processor?.username || mistake.user.username
        ])
      })
    }

    if (mistakeSheetData.length > 1) {
      const mistakeWorksheet = XLSX.utils.aoa_to_sheet(mistakeSheetData)
      mistakeWorksheet['!cols'] = [
        { wch: 20 }, // tgl-bln-tahun Waktu
        { wch: 25 }, // bank (pengirim)
        { wch: 15 }, // nominal
        { wch: 25 }, // tujuan bank (penerima)
        { wch: 10 }, // status
        { wch: 20 }, // proses (note)
      ]
      XLSX.utils.book_append_sheet(workbook, mistakeWorksheet, 'Mistake')
    }

    // ==========================================
    // PART 5: Akuran - 1 sheet untuk semua tanggal
    // ==========================================
    
    const akuranSheetData: any[] = [
      ['tgl-bln-tahun Waktu', 'bank (pengirim)', 'nominal', 'tujuan bank (penerima)', 'status', 'proses (note)']
    ]

    for (const date of dates) {
      const dayStart = new Date(date)
      dayStart.setHours(0, 0, 0, 0)
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)

      const akurans = await db.akuran.findMany({
        where: {
          createdAt: {
            gte: dayStart,
            lte: dayEnd
          }
        },
        include: {
          user: true,
          processor: true
        },
        orderBy: { createdAt: 'desc' }
      })

      akurans.forEach(akuran => {
        akuranSheetData.push([
          formatDateTime(akuran.createdAt),
          '-', // bank (pengirim) - akuran tidak ada bank pengirim
          formatCurrency(akuran.amount),
          '-', // tujuan bank (penerima) - akuran tidak ada tujuan bank
          '-', // status - akuran tidak ada status
          akuran.processor?.username || akuran.user.username
        ])
      })
    }

    if (akuranSheetData.length > 1) {
      const akuransWorksheet = XLSX.utils.aoa_to_sheet(akuranSheetData)
      akuransWorksheet['!cols'] = [
        { wch: 20 }, // tgl-bln-tahun Waktu
        { wch: 25 }, // bank (pengirim)
        { wch: 15 }, // nominal
        { wch: 25 }, // tujuan bank (penerima)
        { wch: 10 }, // status
        { wch: 20 }, // proses (note)
      ]
      XLSX.utils.book_append_sheet(workbook, akuransWorksheet, 'Akuran')
    }

    // ==========================================
    // Generate buffer dan return file
    // ==========================================
    
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })

    // Return as file
    return new NextResponse(buffer as Buffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="transactions_${formatDate(start)}_${formatDate(end)}.xlsx"`
      }
    })
  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat export data' },
      { status: 500 }
    )
  }
}

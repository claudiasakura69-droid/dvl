import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getUserPermissions } from '@/lib/permissions'

// PUT - Update InOut transaction
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { sessionId, fromBankId, toBankId, amount, notes, status, processedBy } = await req.json()

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cari transaksi yang akan diupdate
    const existingTransaction = await db.inOut.findUnique({
      where: { id: params.id }
    })

    if (!existingTransaction) {
      return NextResponse.json(
        { error: 'Transaksi tidak ditemukan' },
        { status: 404 }
      )
    }

    // Cek permission untuk edit transaction
    if (!permissions.canEditTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk mengedit transaksi. Hanya MASTER dan SUPERVISOR yang dapat mengedit.' },
        { status: 403 }
      )
    }

    const updateData: any = {}

    if (fromBankId !== undefined) updateData.fromBankId = fromBankId
    if (toBankId !== undefined) updateData.toBankId = toBankId
    if (amount !== undefined) updateData.amount = parseFloat(amount)
    if (notes !== undefined) updateData.notes = notes
    if (status !== undefined) updateData.status = status
    if (processedBy !== undefined) updateData.processedBy = processedBy

    // Update transaksi
    const transaction = await db.inOut.update({
      where: { id: params.id },
      data: updateData,
      include: {
        fromBank: true,
        toBank: true,
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      transaction
    })
  } catch (error) {
    console.error('Update InOut transaction error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengupdate transaksi' },
      { status: 500 }
    )
  }
}

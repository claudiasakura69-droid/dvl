import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TransactionStatus } from '@prisma/client'
import { getUserPermissions } from '@/lib/permissions'

// GET - Ambil semua InOut transactions
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID wajib diisi' },
        { status: 400 }
      )
    }

    // Cek session valid
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const inOuts = await db.inOut.findMany({
      include: {
        fromBank: true,
        toBank: true,
        user: {
          select: {
            id: true,
            username: true,
            role: true
          }
        },
        processor: {
          select: {
            id: true,
            username: true,
            role: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({
      success: true,
      inOuts
    })
  } catch (error) {
    console.error('Get inouts error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengambil data InOut' },
      { status: 500 }
    )
  }
}

// POST - Buat InOut baru
export async function POST(req: NextRequest) {
  try {
    const { sessionId, fromBankId, toBankId, amount, notes, status, destinationOther } = await req.json()

    if (!sessionId || !fromBankId || !toBankId || !amount) {
      return NextResponse.json(
        { error: 'Data tidak lengkap' },
        { status: 400 }
      )
    }

    // Cek session valid dan dapatkan user
    const session = await db.userSession.findUnique({
      where: { id: sessionId },
      include: { user: true }
    })

    if (!session || session.logoutAt) {
      return NextResponse.json(
        { error: 'Session tidak valid' },
        { status: 401 }
      )
    }

    const currentUser = session.user
    const permissions = getUserPermissions(currentUser.role)

    // Cek permission untuk create transaction
    if (!permissions.canCreateTransactions) {
      return NextResponse.json(
        { error: 'Anda tidak memiliki izin untuk membuat transaksi' },
        { status: 403 }
      )
    }

    if (fromBankId === toBankId) {
      return NextResponse.json(
        { error: 'Bank asal dan tujuan tidak boleh sama' },
        { status: 400 }
      )
    }

    // Cari kedua bank
    const fromBank = await db.bank.findUnique({
      where: { id: fromBankId }
    })

    const toBank = await db.bank.findUnique({
      where: { id: toBankId }
    })

    if (!fromBank || !toBank) {
      return NextResponse.json(
        { error: 'Bank tidak ditemukan' },
        { status: 404 }
      )
    }

    const amountFloat = parseFloat(amount)

    // Default status PENDING
    const transactionStatus = status || TransactionStatus.PENDING

    // Buat InOut transaction
    const inOut = await db.inOut.create({
      data: {
        fromBankId,
        toBankId,
        amount: amountFloat,
        status: transactionStatus,
        notes: notes || null,
        destinationOther: destinationOther || null,
        userId: currentUser.id
      }
    })

    // Jika status COMPLETE, update balance kedua bank
    if (transactionStatus === TransactionStatus.COMPLETE) {
      await db.bank.update({
        where: { id: fromBankId },
        data: { balance: fromBank.balance - amountFloat }
      })

      await db.bank.update({
        where: { id: toBankId },
        data: { balance: toBank.balance + amountFloat }
      })
    }

    return NextResponse.json({
      success: true,
      inOut
    })
  } catch (error) {
    console.error('Create inout error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat membuat InOut' },
      { status: 500 }
    )
  }
}

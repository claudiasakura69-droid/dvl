import { PrismaClient, UserRole } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Create default admin user with MASTER role
  const adminUser = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      token: 'master123@',
      role: UserRole.MASTER,
      isActive: true
    }
  })

  console.log('Default admin user created/updated:', adminUser)

  // Create additional test users with different roles (optional)
  const supervisor = await prisma.user.upsert({
    where: { username: 'supervisor' },
    update: {},
    create: {
      username: 'supervisor',
      token: 'supervisor123@',
      role: UserRole.SUPERVISOR,
      isActive: true
    }
  })

  console.log('Supervisor user created/updated:', supervisor)

  const support = await prisma.user.upsert({
    where: { username: 'support' },
    update: {},
    create: {
      username: 'support',
      token: 'support123@',
      role: UserRole.SUPPORT,
      isActive: true
    }
  })

  console.log('Support user created/updated:', support)

  const admin = await prisma.user.upsert({
    where: { username: 'staff' },
    update: {},
    create: {
      username: 'staff',
      token: 'staff123@',
      role: UserRole.ADMIN,
      isActive: true
    }
  })

  console.log('Admin (staff) user created/updated:', admin)

  const viewer = await prisma.user.upsert({
    where: { username: 'viewer' },
    update: {},
    create: {
      username: 'viewer',
      token: 'viewer123@',
      role: UserRole.VIEW,
      isActive: true
    }
  })

  console.log('Viewer user created/updated:', viewer)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

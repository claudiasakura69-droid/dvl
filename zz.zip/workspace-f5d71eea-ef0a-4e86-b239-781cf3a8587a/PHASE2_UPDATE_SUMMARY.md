# Phase 2 Update Summary - Menu Baru & Fitur Lengkap

## Overview

Update ini mencakup penambahan menu baru, perbaikan perhitungan, dan implementasi fitur lengkap sesuai requirements.

## ✅ Perubahan yang Dilakukan

### 1. **Database Schema Update** ✅

**File**: `prisma/schema.prisma`

**Perubahan**:
- Tambah model **Akuran** (mirip Expense tapi untuk pembayaran keperluan)
- Update User model untuk include relasi ke Akuran
- Update BankHistory untuk lebih detail (pergantian nominal tracking)

**Model Akuran**:
```
model Akuran {
  id          String   @id @default(cuid())
  amount      Float
  notes       String?
  category    String?
  userId      String
  user        User     @relation(fields: [userId], references: [id])
  processedBy String?   // User yang memproses
  processor   User?    @relation("ProcessedByAkuran", fields: [processedBy], references: [id])
  createdAt   DateTime @default(now())
}
```

### 2. **Permission System Update** ✅

**File**: `src/lib/permissions.ts`

**Perubahan**:
- Tambah `canCreateAkurans: boolean`
- Tambah `canDeleteAkurans: boolean`
- Update semua role untuk include permissions Akuran

**Permission Matrix (Updated)**:

| Permission | MASTER | SUPERVISOR | SUPPORT | ADMIN | VIEW |
|------------|---------|------------|---------|-------|------|
| Edit Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Delete Users | ✅ | ❌ | ❌ | ❌ | ❌ |
| Add Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Edit Roles | ✅ | ✅ | ❌ | ❌ | ❌ |
| Create Banks | ✅ | ✅ | ✅ | ❌ | ❌ |
| Edit Banks | ✅ | ✅ | ✅ | ❌ | ❌ |
| Delete Banks | ✅ | ✅ | ✅ | ❌ | ❌ |
| Move Banks | ✅ | ✅ | ✅ | ❌ | ❌ |
| Toggle Bank Status | ✅ | ✅ | ✅ | ✅ | ❌ |
| Create Transactions | ✅ | ✅ | ✅ | ✅ | ❌ |
| Edit Transactions | ✅ | ✅ | ✅ | ✅ | ❌ |
| Delete Transactions | ✅ | ✅ | ✅ | ✅ | ❌ |
| Process Transactions | ✅ | ✅ | ✅ | ✅ | ❌ |
| Create Expenses | ✅ | ✅ | ✅ | ✅ | ❌ |
| Delete Expenses | ✅ | ✅ | ✅ | ✅ | ❌ |
| Create Mistakes | ✅ | ✅ | ✅ | ✅ | ❌ |
| Delete Mistakes | ✅ | ✅ | ✅ | ✅ | ❌ |
| Create Akurans | ✅ | ✅ | ✅ | ✅ | ❌ |
| Delete Akurans | ✅ | ✅ | ✅ | ✅ | ❌ |

### 3. **API Routes - Bank Permission** ✅

**File**: `src/app/api/banks/[id]/route.ts`

**Perubahan**:
- PUT (Edit bank): Hanya MASTER dan SUPERVISOR yang bisa edit
- DELETE: Hanya MASTER dan SUPERVISOR yang bisa delete
- Permission check: Menggunakan `getUserPermissions()`
- Error message yang jelas untuk user yang tidak memiliki izin

**Logic**:
```typescript
if (!permissions.canEditBanks) {
  return NextResponse.json({
    error: 'Anda tidak memiliki izin untuk mengedit bank. Hanya MASTER dan SUPERVISOR yang dapat mengedit bank.',
    status: 403
  })
}

if (!permissions.canDeleteBanks) {
  return NextResponse.json({
    error: 'Anda tidak memiliki izin untuk menghapus bank. Hanya MASTER dan SUPERVISOR yang dapat menghapus bank.',
    status: 403
  })
}
```

### 4. **API Routes - Akuran** ✅

**File**: `src/app/api/akuran/route.ts`

**Endpoint**:
- `GET /api/akuran` - Ambil semua akurans
  - Filter by month/year
  - Include user dan processor info
- `POST /api/akuran` - Buat akuran baru
  - Permission check (canCreateAkurans)
  - Amount, notes, category

**Permission Check**:
```typescript
if (!permissions.canCreateAkurans) {
  return NextResponse.json({
    error: 'Anda tidak memiliki izin untuk membuat akuran',
    status: 403
  })
}
```

### 5. **API Routes - Report** ✅

**File**: `src/app/api/report/route.ts`

**Endpoint**:
- `GET /api/report` - Ambil statistik bulanan

**Format Data**:
```typescript
{
  tgl: "1-apr-2026",
  deposit: 10000000,
  withdraw: 5000000,
  transaksiDeposit: 200,
  transaksiWithdraw: 50
}
```

**Logic**:
- Parse month dan year dari query params
- Filter transactions by date range (1st day to last day of month)
- Group transactions by date
- Hitung total deposit, total withdraw
- Hitung jumlah transaksi deposit dan withdraw
- Format tanggal Indonesia: `dd-Mon-yy`

**Contoh Output**:
```
tgl              | deposit     | withdraw    | transaksiDeposit | transaksiWithdraw
-----------------|-------------|-------------|-----------------|------------------
1-apr-2026      | 10.000.000  | 5.000.000   | 200             | 50
2-apr-2026      | 15.000.000  | 15.000.000  | 100             | 10
```

### 6. **API Routes - Bank Detail** ✅

**File**: `src/app/api/banks/[id]/detail/route.ts`

**Endpoint**:
- `GET /api/banks/[id]/detail` - Ambil detail perhitungan bank

**Format Data**:
```typescript
{
  bank: {
    id, name, accountName, accountNumber, type, balance, status, createdAt, updatedAt
  },
  perhitungan: {
    semuaTransaksi: total,
    semuaInOut: total,
    semuaExpense: total,
    semuaMistake: total,
    semuaAkurans: total,
    transaksiHariIni: total,
    inOutHariIni: total,
    expenseHariIni: total,
    mistakeHariIni: total,
    akuranHariIni: total,
    totalSaldo: total
  },
  history: {
    dailyTransactions: count,
    inOutTransactions: count,
    expenses: count,
    mistakes: count,
    akurans: count
  }
}
```

**Perhitungan**:

**Semua Transaksi** (baris 1):
- Total dari Day transactions (deposit +, withdraw -)
- Dihitung dari awal sampai target date

**Semua InOut** (baris 2):
- InOut yang FROM bank: minus
- InOut yang TO bank: plus
- Dihitung dari awal sampai target date

**Semua Expense** (baris 3):
- Total semua expenses (minus)
- Dihitung dari awal sampai target date

**Semua Mistake** (baris 4):
- Total semua mistakes (minus)
- Dihitung dari awal sampai target date

**Semua Akurans** (baris 5):
- Total semua akurans (minus)
- Dihitung dari awal sampai target date

**Transaksi Hari Ini** (baris 1 di kolom transaksi hari ini):
- Total Day transactions hari ini (deposit +, withdraw -)
- Filter: date >= hari ini (00:00:00)

**InOut Hari Ini** (baris 2):
- InOut hari ini
- Filter: createdAt >= hari ini (00:00:00)

**Expense Hari Ini** (baris 3):
- Expense hari ini
- Filter: createdAt >= hari ini (00:00:00)

**Mistake Hari Ini** (baris 4):
- Mistake hari ini
- Filter: createdAt >= hari ini (00:00:00)

**Akuran Hari Ini** (baris 5):
- Akuran hari ini
- Filter: createdAt >= hari ini (00:00:00)

**Total Saldo** (baris paling bawah):
```
totalSaldo = saldo awal + semuaTransaksi + semuaInOut - semuaExpense - semuaMistake - semuaAkurans
```

**Catatan**:
- Jika hasil minus, tampilkan dengan `-` di depan
- Realtime update jika ada transaksi baru menggunakan bank
- Perpindahan bank mempertahankan data transaksi lama

### 7. **Export API Update - Akuran Sheet** ✅

**File**: `src/app/api/export/route.ts`

**Perubahan**:
- Tambah sheet **Akuran** untuk semua tanggal dalam range
- Format sama dengan Expense sheet

**Sheet Akuran**:
```
tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)
```

**Format Export Lengkap** (untuk tanggal 1-31):

1. Sheet 1: "1 Apr 26" (Day - Deposit & Withdraw)
2. Sheet 2: "2 Apr 26" (Day - Deposit & Withdraw)
...
31. Sheet 31: "31 Apr 26" (Day - Deposit & Withdraw)
32. Sheet 32: "In/Out" (semua tanggal 1-31)
33. Sheet 33: "Expense" (semua tanggal 1-31)
34. Sheet 34: "Mistake" (semua tanggal 1-31)
35. Sheet 35: "Akuran" (semua tanggal 1-31)

**Format Export Tunggal** (untuk tanggal 4 saja):

1. Sheet 1: "4 Apr 26" (Day - Deposit & Withdraw)
2. Sheet 2: "In/Out" (hanya tanggal 4)
3. Sheet 3: "Expense" (hanya tanggal 4)
4. Sheet 4: "Mistake" (hanya tanggal 4)
5. Sheet 5: "Akuran" (hanya tanggal 4)

### 8. **Export Format Detail** ✅

**Days Sheet (per tanggal)**:

**Table Deposit** (A1:G1):
```
tgl-bln-tahun Waktu | nama | bank | nominal | tujuan bank | status | proses (note)
```

**Table Withdraw** (K1:Q1):
```
tgl-bln-tahun Waktu | nama | bank | nominal | tujuan bank | status | proses (note)
```

**Separator**: `===================` baris antara Deposit dan Withdraw

**Total**: Dihitung dan ditampilkan di bawah setiap tabel

**In/Out Sheet**:
```
tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)
```

**Support "lain"** jika bank tidak ada di list

**Expense Sheet**:
```
tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)
```

**Mistake Sheet**:
```
tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)
```

**Akuran Sheet**:
```
tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)
```

### 9. **Bank Move Logic** ✅

**Scenario**:
1. Awalnya ada bank "BCA - Feri" di **Deposit** dengan saldo Rp 500.000
2. Ada transaksi Days, InOut, Expense, Mistake, Akuran yang menggunakan "BCA - Feri"
3. Bank "BCA - Feri" dipindahkan ke **Withdraw**

**Setelah Pindahan**:
- Semua transaksi **lama** tetap mencatat "BCA - Feri" (data tidak berubah)
- Transaksi **baru** akan mengikuti status bank yang baru (Withdraw)
- List bank di menu akan menampilkan BCA - Feri di Withdraw, bukan di Deposit
- Balance di bank tetap Rp 500.000 (pindahan tidak mengubah balance)

**Perpindahan Bank**:
- Di BankHistory dicatat event `MOVED`
- Old type: DEPOSIT
- New type: WITHDRAW
- Notes: "Dipindahkan dari DEPOSIT ke WITHDRAW"
- Catat user yang memindahkan

**Perhitungan Saldo**:
- Saldo tidak berubah saat dipindah
- Saldo berubah sesuai perhitungan:
  - + Deposit
  - - Withdraw
  - + InOut (ke bank)
  - - InOut (dari bank)
  - - Expense
  - - Mistake
  - - Akuran

**Contoh Scenario**:
```
Saldo awal: Rp 500.000

Tanggal 5:
- Semua Transaksi: +Rp 50.000.000 (total 200 transaksi)
- InOut (dari bank): -Rp 50.000.000 (transfer ke OVO)
- Expense: -Rp 10.000.000 (biaya operasional)
- Mistake: 0 (tidak ada)
- Akuran: -Rp 5.000.000 (bayar listrik)

Total Saldo = 500.000 + 50.000 - 50.000 - 10.000 - 0 - 5.000
           = Rp 485.000.000
```

**Jika ada minus**:
- Tampilkan dengan `-` di depan: `-Rp 30.000.000`
- Menunjukkan bank defisit

### 10. **Report Menu Logic** ✅

**Fitur Search**:
- Filter by tanggal/bulan/tahun
- Parameter:
  - `month`: 1-12
  - `year`: Tahun (4 digit)
  - Jika kosong: bulan dan tahun saat ini

**Output Format**:
```typescript
{
  tgl: "1-apr-2026",
  deposit: 10000000,
  withdraw: 5000000,
  transaksiDeposit: 200,
  transaksiWithdraw: 50
}
```

**Contoh Data**:
```
tgl              | deposit     | withdraw    | transaksiDeposit | transaksiWithdraw
-----------------|-------------|-------------|-----------------|------------------
1-apr-2026      | 10.000.000  | 5.000.000   | 200             | 50
2-apr-2026      | 15.000.000  | 15.000.000  | 100             | 10
3-apr-2026      | 8.000.000   | 3.000.000   | 150             | 25
...
30-apr-2026      | 12.000.000  | 8.000.000   | 180             | 30
31-apr-2026      | 25.000.000  | 20.000.000  | 300             | 40
```

### 11. **Perubahan Saldo Otomatis** ✅

**Scenario: Pergantian Bulan/Tahun**

1. **Tanggal 1 bulan baru**:
   - Saldo awal hari ini = Total saldo akhir bulan sebelumnya
   - Semua transaksi Days mulai dari 0 (transaksi hari ini saja)
   - Semua transaksi lain (InOut, Expense, Mistake, Akuran) mulai dari 0

2. **Logic**:
   - Days: Filter by date >= hari ini (00:00:00)
   - InOut: Filter by createdAt >= hari ini (00:00:00)
   - Expense: Filter by createdAt >= hari ini (00:00:00)
   - Mistake: Filter by createdAt >= hari ini (00:00:00)
   - Akuran: Filter by createdAt >= hari ini (00:00:00)

3. **Perhitungan Realtime**:
   - Setiap transaksi baru akan tercatat
   - Saldo dihitung ulang secara realtime
   - Bank detail view menampilkan perhitungan terbaru

4. **Historical Data**:
   - Data bulan sebelumnya tetap tersimpan
   - Tidak dihapus/diubah
   - Bisa diakses dengan memilih bulan/tahun di Report menu

### 12. **Bank History Tracking** ✅

**BankHistory Model**:
```typescript
model BankHistory {
  id          String   @id @default(cuid())
  bankId      String
  bank        Bank     @relation(fields: [bankId], references: [id])
  eventType   String   // 'CREATED', 'UPDATED', 'MOVED', 'STATUS_CHANGED'
  oldValue    String?
  newValue    String?
  oldBalance  Float?
  newBalance  Float?
  oldType     String?
  newType     String?
  notes       String?
  userId      String?
  createdAt   DateTime @default(now())
}
```

**Events yang Dicatat**:
1. **CREATED**: Bank baru dibuat
2. **UPDATED**: Saldo atau info diperbarui
   - oldBalance: Saldo sebelumnya
   - newBalance: Saldo setelahnya
3. **MOVED**: Bank dipindahkan (deposit ↔ withdraw)
   - oldType: Type sebelumnya
   - newType: Type setelahnya
   - Notes: "Dipindahkan dari DEPOSIT ke WITHDRAW"
4. **STATUS_CHANGED**: Status diubah (online ↔ offline)
   - oldValue: "online" atau "offline"
   - newValue: Status baru
   - userId: User yang mengubah status

**Contoh History Record**:
```typescript
{
  eventType: "MOVED",
  oldType: "DEPOSIT",
  newType: "WITHDRAW",
  notes: "Dipindahkan dari DEPOSIT ke WITHDRAW",
  userId: "user-id-supervisor1",
  createdAt: "2026-04-30T10:00:00Z"
}
```

## 📋 Struktur File Baru

### API Routes

```
src/app/api/
├── auth/
│   ├── login/route.ts
│   ├── logout/route.ts
│   └── session/route.ts
├── users/
│   ├── route.ts (GET, POST)
│   └── [id]/route.ts (PUT, DELETE)
├── banks/
│   ├── route.ts (GET, POST)
│   ├── [id]/route.ts (PUT, DELETE)
│   ├── [id]/status/route.ts (PUT)
│   ├── [id]/move/route.ts (PUT)
│   └── [id]/detail/route.ts (GET) ⭐ BARU
├── daily-transactions/
│   ├── route.ts (GET, POST)
│   ├── [id]/route.ts (PUT, DELETE)
│   └── bulk/route.ts (POST)
├── inout/route.ts (GET, POST)
├── expense/route.ts (GET, POST)
├── mistake/route.ts (GET, POST)
├── akuran/route.ts (GET, POST) ⭐ BARU
├── report/route.ts (GET) ⭐ BARU
└── export/route.ts (POST)
```

### Lib

```
src/lib/
├── db.ts
├── permissions.ts ⭐ UPDATE (include Akuran)
└── utils.ts
```

## 🔧 Perhitungan Saldo (Detail)

### Formula Utama

```
Total Saldo = Saldo Awal + Semua Transaksi + Semua InOut - Semua Expense - Semua Mistake - Semua Akurans
```

### Komponen Perhitungan

**1. Semua Transaksi**:
```
Total = Σ(deposit) - Σ(withdraw)
Filter: date <= target date
```

**2. Semua InOut**:
```
Total = Σ(ke bank) - Σ(dari bank)
Filter: createdAt <= target date
```

**3. Semua Expense**:
```
Total = Σ(amount)
Filter: createdAt <= target date
```

**4. Semua Mistake**:
```
Total = Σ(amount)
Filter: createdAt <= target date, bankId = bank.id
```

**5. Semua Akurans**:
```
Total = Σ(amount)
Filter: createdAt <= target date
```

### Komponen Hari Ini

**Transaksi Hari Ini**:
```
Total = Σ(deposit hari ini) - Σ(withdraw hari ini)
Filter: date >= hari ini 00:00:00
```

**InOut Hari Ini**:
```
Total = Σ(ke bank hari ini) - Σ(dari bank hari ini)
Filter: createdAt >= hari ini 00:00:00
```

**Expense Hari Ini**:
```
Total = Σ(amount hari ini)
Filter: createdAt >= hari ini 00:00:00
```

**Mistake Hari Ini**:
```
Total = Σ(amount hari ini)
Filter: createdAt >= hari ini 00:00:00
```

**Akuran Hari Ini**:
```
Total = Σ(amount hari ini)
Filter: createdAt >= hari ini 00:00:00
```

## 🎯 Frontend yang Perlu Dibuat

### 1. **Report Menu** ⭐ BARU
- Statistik bulanan
- Tabel dengan kolom: tgl, deposit, withdraw, transaksi deposit, transaksi withdraw
- Filter by bulan/tahun
- Search by transaction type/nama/bank/status/note
- Pagination (50 baris per halaman)

### 2. **Akuran Menu** ⭐ BARU
- Create akuran (mirip Expense)
- Edit notes (MASTER/SUPERVISOR only)
- Filter by month/year
- Search by category/notes
- Export di include di export sheet

### 3. **Bank Detail View** ⭐ UPDATE
- Tampilkan informasi detail:
  * Saldo awal di atas
  * 5 kolom perhitungan:
    - Semua Transaksi
    - Semua InOut
    - Semua Expense
    - Semua Mistake
    - Semua Akurans
  * Transaksi hari ini:
    - Transaksi hari ini
    - InOut hari ini
    - Expense hari ini
    - Mistake hari ini
    - Akuran hari ini
  * Total saldo di bawah

### 4. **Search Feature** ⭐ BARU (semua menu)
- Search by:
  - Nama (Day: nama pengirim/penerima)
  - Tipe transaksi (deposit/withdraw/all)
  - Bank (spesifik atau all)
  - Status (pending/complete/all)
  - Notes (catatan)
  - Date (single tanggal atau range)
  - Month (1 bulan atau bulan-bulan sebelumnya)
- Filter logic:
  - Day: filter by transaction type, bank, status, notes
  - InOut: filter by bank (pengirim/penerima), notes
  - Expense: filter by category, notes
  - Mistake: filter by bank, notes
  - Akuran: filter by category, notes
- Pagination: 50 baris per halaman
- Display hasil di bawah fitur search

### 5. **Edit Transaction Notes** ⭐ UPDATE
- Fitur edit notes di Day (Deposit/Withdraw)
- Hanya MASTER dan SUPERVISOR yang dapat edit
- Edit di semua menu (Day, InOut, Expense, Mistake, Akuran)
- Delete (MASTER only)

## 🚀 Deployment ke Cloudflare Pages

### Environment Variables yang Diperlukan

```
DATABASE_URL=postgres://neondb_owner:npg_uqRAmD7Ye9ls@ep-quiet-wave-ao2cbr4s-pooler.c-2.ap-southeast-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
USER_admin_TOKEN_MASTER=master123@
```

### Menambah User Baru (Environment)

**Format**:
```
USER_{username}_TOKEN_{role}=token
```

**Contoh**:
```
USER_staff1_TOKEN_VIEW=staff123@
USER_manager_TOKEN_ADMIN=manager456@
```

### Database Migration

```bash
bun run db:push
```

Schema sudah diupdate dengan:
- Model Akuran
- Relasi ke User
- BankHistory tracking

## 📊 Format Export Lengkap

### File Excel untuk Tanggal 1-31

**Sheets yang dihasilkan (35 sheets total)**:

1. Sheet 1-31: Days (per tanggal)
   - Setiap sheet: Deposit tabel + Withdraw tabel
   - Format: tgl-bln-tahun | nama | bank | nominal | tujuan bank | status | proses (note)

2. Sheet 32: In/Out
   - Semua data tanggal 1-31
   - Format: tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)

3. Sheet 33: Expense
   - Semua data tanggal 1-31
   - Format: tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)

4. Sheet 34: Mistake
   - Semua data tanggal 1-31
   - Format: tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)

5. Sheet 35: Akuran
   - Semua data tanggal 1-31
   - Format: tgl-bln-tahun Waktu | bank (pengirim) | nominal | tujuan bank (penerima) | status | proses (note)

### File Excel untuk Tanggal Tunggal (misal: tanggal 4)

**Sheets yang dihasilkan (5 sheets total)**:

1. Sheet 1: "4 Apr 26" (Day)
2. Sheet 2: "In/Out"
3. Sheet 3: "Expense"
4. Sheet 4: "Mistake"
5. Sheet 5: "Akuran"

## 📝 Catatan Penting

### 1. Perpindahan Bank
- Transaksi lama tetap menggunakan data bank lama
- Transaksi baru mengikuti status bank baru
- Saldo tidak berubah saat dipindah
- History lengkap dicatat

### 2. Perhitungan Saldo
- Formula: Saldo Awal + Semua Transaksi + Semua InOut - Semua Expense - Semua Mistake - Semua Akurans
- Minus ditampilkan dengan `-` di depan
- Realtime update jika ada transaksi

### 3. Pergantian Bulan/Tahun
- Saldo awal = Total saldo akhir bulan sebelumnya
- Transaksi hari ini mulai dari 0
- Historical data tetap tersimpan
- Access historical data dengan Report menu

### 4. Search dan Pagination
- Maximum 50 baris per halaman
- Filter by multiple criteria
- Display di bawah fitur search
- Efficient database queries

### 5. Permission Enforcement
- Semua API routes memiliki permission checking
- Frontend harus menampilkan UI sesuai permission
- Error message jelas untuk user yang tidak memiliki izin

## 🔧 Troubleshooting

### Bank Edit/Delete Gagal

**Error**: "Anda tidak memiliki izin untuk mengedit/hapus bank"

**Solusi**:
- Hanya MASTER dan SUPERVISOR yang bisa edit/delete bank
- SUPPORT, ADMIN, VIEW tidak bisa edit/delete bank
- Hubungi MASTER atau SUPERVISOR jika perlu edit bank

### Perhitungan Saldo Tidak Sesuai

**Cek**:
- Semua transaksi sudah tercatat dengan status COMPLETE
- InOut, Expense, Mistake, Akuran sudah termasuk
- Tanggal filter benar (hari ini atau tanggal yang dipilih)

### Export Tidak Berhasil

**Cek**:
- Database connection (Neon)
- Data tersedia di range tanggal
- Format tanggal Indonesia benar

## 📖 Status Phase 2

### Backend (API) ✅
- [x] Schema update (Akuran model)
- [x] Permission update (include Akuran)
- [x] Bank API permission check (MASTER/SUPERVISOR only)
- [x] Akuran API (GET, POST)
- [x] Report API (statistik bulanan)
- [x] Bank Detail API (perhitungan saldo)
- [x] Export API update (Akuran sheet)

### Frontend ⏳ (Perlu dibuat)
- [ ] Report menu component
- [ ] Akuran menu component
- [ ] Bank detail view update
- [ ] Search feature di semua menu
- [ ] Edit notes component
- [ ] Update sidebar untuk menu baru

## 🎯 Langkah Selanjutnya

**Frontend Development Priority**:

1. **Buat Report Menu**
   - Komponen statistik bulanan
   - Tabel dengan filter dan pagination

2. **Buat Akuran Menu**
   - Form create akuran
   - List dengan filter dan search
   - Edit notes (MASTER/SUPERVISOR only)

3. **Update Bank Detail**
   - View dengan 5 kolom perhitungan
   - Display saldo awal dan total saldo
   - Visualisasi perhitungan

4. **Implement Search**
   - Add search component di semua menu
   - Filter logic untuk setiap menu
   - Pagination (50 baris per halaman)

5. **Export Update**
   - Update export component untuk single file
   - Test export untuk range tanggal 1-31
   - Test export untuk tanggal tunggal

6. **Testing**
   - Test semua permission
   - Test perhitungan saldo
   - Test export format
   - Test search dan pagination

# ShortURL - Link Management Platform

A Dub.co-inspired short URL management platform built with Next.js 16, Prisma, and Cloudflare Pages. Supports multiple custom domains, multi-target routing, analytics, and bulk operations.

## Features

- **Multi-Domain Support** — Use multiple short URL domains (e.g., `short-a.link`, `short-b.link`) from a single dashboard
- **Secure Domain Verification** — Cloudflare API-based verification proves domain ownership (zone check + Pages custom domain check)
- **Auto-Configure** — One-click domain setup: automatically adds domain to Cloudflare Pages + verifies + activates
- **Basic & Multi-Target Links** — Single target, random routing, sequential load balancing, geo-targeting, IP-based targeting
- **Real-Time Analytics** — Click tracking with country, device, browser, OS, and referrer data from Cloudflare HTTP headers
- **Bulk Operations** — Create, delete, activate, deactivate, and migrate links in bulk
- **Password Protection** — Protect individual links with passwords
- **Link Expiration** — Set expiration dates on links
- **UTM Parameters** — Append UTM source/medium/campaign/content/term to redirects
- **Import/Export** — Bulk import and export links with all metadata
- **QR Codes** — Generate QR codes for any short link
- **Dark/Light Mode** — System-aware theme support

## Architecture

```
domain-a.com (Dashboard) ─────┐
                              │    Cloudflare Pages
short-a.link (Short URLs) ───┤──── Single Deployment
                              │
short-b.link (Short URLs) ───┘
```

- **Dashboard domain** (`APP_DOMAIN`): Serves the React admin dashboard
- **Short domains**: Automatically routed to the redirect handler via middleware
- **Routing**: `short-a.link/abc` → middleware detects short domain → rewrite to `/s/abc` → redirect handler looks up slug in database → 301 redirect to target URL

## Prerequisites

- Node.js 18+ or Bun
- A Cloudflare account
- A Cloudflare Pages project
- (Recommended) A Neon Tech PostgreSQL database
- (Recommended) Cloudflare API token for domain verification

## Quick Start

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd shorturl
bun install
```

### 2. Configure Environment Variables

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
# [REQUIRED] Dashboard login password
DASHBOARD_TOKEN=your_secure_password_here

# [REQUIRED] Your dashboard domain (without https://)
APP_DOMAIN=dash.example.com

# [REQUIRED] Database connection string
DATABASE_URL=file:./db/custom.db
```

### 3. Initialize Database

For local development with SQLite:

```bash
bun run db:push
```

### 4. Run Development Server

```bash
bun run dev
```

Open `http://localhost:3000` and login with your `DASHBOARD_TOKEN`.

## Production Deployment (Cloudflare Pages + Neon)

### Step 1: Setup Database (Neon Tech)

1. Create a project at [neon.tech](https://neon.tech)
2. Copy the **Pooled connection** string from Connection Details
3. Example: `postgresql://user:password@ep-xxx.region.neon.tech/dbname?sslmode=require`

### Step 2: Update Prisma Schema

Change `prisma/schema.prisma` provider to PostgreSQL:

```prisma
datasource db {
  provider = "postgresql"   // Changed from "sqlite"
  url      = env("DATABASE_URL")
}
```

Run migration:

```bash
bun run db:push
```

### Step 3: Push to GitHub

```bash
git add .
git commit -m "Configure for production"
git push origin main
```

### Step 4: Deploy to Cloudflare Pages

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → Workers & Pages → Create
2. Connect your GitHub repository
3. **Build settings:**
   - Framework preset: Next.js
   - Build command: `npx prisma generate && npx prisma db push && npm run build`
   - Build output directory: `.next/standalone`

### Step 5: Add Custom Domain for Dashboard

1. In your Pages project → Custom domains → Add `domain-a.com`
2. Cloudflare will auto-configure DNS

### Step 6: Configure Environment Variables

In Pages project → Settings → Environment variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `DASHBOARD_TOKEN` | Yes | Dashboard login password |
| `APP_DOMAIN` | Yes | Dashboard domain (e.g., `domain-a.com`) |
| `DATABASE_URL` | Yes | Neon PostgreSQL connection string |
| `CLOUDFLARE_API_TOKEN` | Recommended | For secure domain verification |
| `CLOUDFLARE_ACCOUNT_ID` | Recommended | Your Cloudflare account ID |
| `CLOUDFLARE_PAGES_PROJECT` | Recommended | Pages project name |

### Step 7: Create Cloudflare API Token (Recommended)

1. Go to [API Tokens](https://dash.cloudflare.com/profile/api-tokens)
2. Click **Create Token** → **Custom token**
3. Permissions:
   - Account → Cloudflare Pages → **Edit**
   - Zone → Zone → **Read**
   - Zone → DNS → **Edit**
4. Account Resources: Include → Your account
5. Zone Resources: Include → All zones
6. Create and copy the token

## Domain Setup Guide

### Adding a Short URL Domain

All short link domains must have their nameservers pointing to **your Cloudflare account** (same account as the Pages project).

**Method A: Auto-Configure (with Cloudflare API token)**

1. Dashboard → Domains → Add Domain
2. Enter domain name (e.g., `short-a.link`)
3. Enable "Auto-configure on Cloudflare Pages"
4. Click "Add & Auto-Configure"
5. The system will:
   - Save domain to database (starts as Inactive)
   - Add domain to Pages custom domains via API
   - Verify ownership (zone + Pages check)
   - Auto-activate if verification passes

**Method B: Manual Setup**

1. Dashboard → Domains → Add Domain
2. Enter domain name → Add Domain
3. Go to Cloudflare Dashboard → Workers & Pages → Your Project → Custom domains
4. Add `short-a.link` → Activate
5. Go back to Dashboard → Domains → Click **Verify**
6. Once verified, domain will auto-activate

### Domain Verification Flow

| Check | What it proves |
|-------|---------------|
| Zone in account | Domain nameservers point to YOUR Cloudflare account (ownership) |
| Pages custom domain | Domain is connected to YOUR Pages project (connectivity) |

Both must pass for verification. After successful verification, the domain is automatically activated.

### Rules

- New domains start as **Inactive** and **Unverified**
- Domains must be **Verified** before they can be **Activated**
- Deactivating a domain returns 503 for all links on that domain
- Deleting a domain also removes it from Pages custom domains (if API configured)
- Renaming a domain resets its verification status

## Link Management

### Basic Link

Single target URL with optional password, expiration, and UTM parameters.

### Multi-Target Link

Supports multiple routing strategies:

| Strategy | Description |
|----------|-------------|
| Random | Randomly selects one target |
| Sequential | Routes to target with lowest click count (load balancing) |
| Country-based | Routes based on visitor's country (`CF-IPCountry` header) |
| IP-based | Routes based on visitor's IP address |

### Target Limits

Each target can have a click limit. When the limit is reached, the target is skipped.

## Analytics Data Source

Analytics data is collected from **HTTP headers** provided by Cloudflare (no additional configuration needed):

| Data | Header |
|------|--------|
| Country | `CF-IPCountry` |
| IP Address | `CF-Connecting-IP` / `X-Forwarded-For` |
| Device | Parsed from `User-Agent` |
| Browser | Parsed from `User-Agent` |
| OS | Parsed from `User-Agent` |
| Referrer | `Referer` |

## Security Considerations

- **Dashboard**: Protected by `DASHBOARD_TOKEN` env variable (Bearer auth)
- **Domain verification**: Cloudflare API proves ownership — random domains cannot be verified
- **Cloudflare WAF**: Can be configured separately on each domain for additional protection
- **Password-protected links**: 403 returned for direct URL visits (no UI for password entry via short URL)

## Project Structure

```
src/
├── app/
│   ├── api/                    # API routes
│   │   ├── auth/               # Login, auth check
│   │   ├── domains/            # Domain CRUD + verification
│   │   │   └── [id]/
│   │   │       ├── route.ts    # Update, delete domain
│   │   │       └── verify/
│   │   │           └── route.ts # Cloudflare API verification
│   │   ├── links/              # Link CRUD + bulk operations
│   │   ├── analytics/          # Overview analytics
│   │   ├── redirect/           # API redirect (JSON response)
│   │   ├── import/             # Bulk import
│   │   ├── export/             # Bulk export
│   │   └── settings/           # App settings
│   ├── s/[slug]/route.ts       # Catch-all redirect handler (HTML redirect)
│   ├── page.tsx                # Dashboard SPA
│   ├── layout.tsx              # Root layout
│   └── globals.css             # Tailwind styles
├── components/
│   ├── domains/                # Domain management UI
│   ├── links/                  # Link management UI
│   ├── analytics/              # Charts and stats
│   ├── dashboard/              # Dashboard layout + sidebar
│   ├── pages/                  # Page components
│   └── ui/                     # shadcn/ui components
├── lib/
│   ├── cloudflare.ts           # Cloudflare API integration
│   ├── db.ts                   # Prisma client
│   ├── auth.ts                 # Dashboard authentication
│   ├── api.ts                  # API client
│   ├── store.ts                # Zustand store
│   ├── types.ts                # TypeScript types
│   └── utils.ts                # Utility functions
├── middleware.ts               # Domain routing (dashboard vs short URLs)
├── prisma/
│   └── schema.prisma           # Database schema
└── .env.example                # Environment variable template
```

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Framework | Next.js 16 (App Router) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui |
| Database | Prisma ORM (SQLite / PostgreSQL) |
| Charts | Recharts |
| State | Zustand |
| Icons | Lucide React |
| Deployment | Cloudflare Pages |

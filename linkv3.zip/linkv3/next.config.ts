import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Cloudflare Pages: do NOT use "standalone" — @opennextjs/cloudflare handles the build
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow Prisma to work in edge runtime (Neon adapter uses HTTP, no native engine)
  experimental: {
    serverActions: {
      bodySizeLimit: "2mb",
    },
  },
};

export default nextConfig;

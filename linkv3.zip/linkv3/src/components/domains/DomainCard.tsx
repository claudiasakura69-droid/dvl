"use client";

import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Check,
  X,
  Edit,
  Trash2,
  Shield,
  Power,
  Cloud,
  Wifi,
  Info,
} from "lucide-react";
import type { ShortDomain } from "@/lib/types";

interface DomainCardProps {
  domain: ShortDomain;
  cloudflareConfigured: boolean;
  onEdit: (domain: ShortDomain) => void;
  onDelete: (domain: ShortDomain) => void;
  onVerify: (domain: ShortDomain) => void;
  onToggle: (domain: ShortDomain) => void;
  verifying?: boolean;
  verifyError?: string | null;
}

export default function DomainCard({
  domain,
  cloudflareConfigured,
  onEdit,
  onDelete,
  onVerify,
  onToggle,
  verifying = false,
  verifyError,
}: DomainCardProps) {
  return (
    <Card className={verifyError ? "border-destructive/50" : ""}>
      <CardContent className="pt-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium">{domain.domain}</h3>
              <Badge
                variant={domain.isActive ? "default" : "destructive"}
                className="text-xs"
              >
                {domain.isActive ? "Active" : "Inactive"}
              </Badge>
              {domain.isVerified ? (
                <Badge className="bg-green-500/10 text-green-600 dark:text-green-400 text-xs border-green-500/20">
                  <Check className="mr-1 h-3 w-3" /> Verified
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs text-amber-600 dark:text-amber-400 border-amber-500/30">
                  <X className="mr-1 h-3 w-3" /> Unverified
                </Badge>
              )}
            </div>
            {domain.slug && (
              <p className="text-xs text-muted-foreground">
                Slug prefix: <code className="rounded bg-muted px-1 py-0.5">{domain.slug}</code>
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              {domain._count?.links ?? 0} links
            </p>
            {domain.verifiedAt && (
              <p className="text-xs text-muted-foreground">
                Verified: {new Date(domain.verifiedAt).toLocaleString()}
              </p>
            )}
            {cloudflareConfigured && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Cloud className="h-3 w-3" /> Cloudflare API ready
              </p>
            )}
            {!cloudflareConfigured && (
              <p className="text-xs text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <Wifi className="h-3 w-3" /> API not configured (DNS fallback)
              </p>
            )}
            {!domain.isVerified && !domain.isActive && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Shield className="h-3 w-3" /> Verify first to activate
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-1.5">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onVerify(domain)}
              disabled={domain.isVerified || verifying}
              className="gap-1 text-xs h-7"
            >
              {verifying ? (
                <React.Fragment>
                  <span className="h-3 w-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Checking
                </React.Fragment>
              ) : (
                <React.Fragment>
                  <Shield className="h-3 w-3" />
                  Verify
                </React.Fragment>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onToggle(domain)}
              disabled={!domain.isActive && !domain.isVerified}
              className="gap-1 text-xs h-7"
              title={
                !domain.isActive && !domain.isVerified
                  ? "Domain must be verified before activation"
                  : undefined
              }
            >
              <Power className="h-3 w-3" />
              {domain.isActive ? "Deactivate" : "Activate"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(domain)}
              className="gap-1 text-xs h-7"
            >
              <Edit className="h-3 w-3" />
              Edit
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(domain)}
              className="gap-1 text-xs h-7 text-destructive hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" />
              Delete
            </Button>
          </div>
        </div>

        {/* Verify Error Message */}
        {verifyError && (
          <div className="mt-3 rounded-md bg-destructive/10 border border-destructive/20 p-3">
            <p className="text-xs text-destructive font-medium flex items-center gap-1">
              <Info className="h-3 w-3" />
              Verification failed
            </p>
            <p className="text-xs text-muted-foreground mt-1">{verifyError}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

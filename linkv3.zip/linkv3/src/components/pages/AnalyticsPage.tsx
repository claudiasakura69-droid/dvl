"use client";

import { useState, useEffect, useCallback } from "react";
import StatsCards from "@/components/analytics/StatsCards";
import ClicksChart from "@/components/analytics/ClicksChart";
import CountryChart from "@/components/analytics/CountryChart";
import DeviceChart from "@/components/analytics/DeviceChart";
import { getOverviewAnalytics } from "@/lib/api";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState("7d");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [clicksOverTime, setClicksOverTime] = useState<any[]>([]);
  const [topLinks, setTopLinks] = useState<any[]>([]);
  const [topCountries, setTopCountries] = useState<any[]>([]);
  const [topDevices, setTopDevices] = useState<any[]>([]);
  const [topBrowsers, setTopBrowsers] = useState<any[]>([]);
  const [topOs, setTopOs] = useState<any[]>([]);

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getOverviewAnalytics({ range: dateRange });
      if (res) {
        setStats(res);
        setClicksOverTime(
          (res.clicksOverTime || []).map((item: any) => ({
            date: new Date(item.date).toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
            }),
            clicks: item.clicks ?? 0,
          }))
        );

        // Map topLinks - backend returns {id, slug, title, createdAt, clickCount}
        setTopLinks(
          (res.topLinks || []).map((l: any) => ({
            link: l,
            clicks: l.clickCount ?? l._count?.clicks ?? 0,
          }))
        );

        // clicksByCountry - backend maps to {country, count}
        setTopCountries(
          (res.clicksByCountry || []).map((c: any) => ({
            country: c.country,
            count: c.count ?? c._count?.id ?? 0,
          }))
        );

        // clicksByDevice - backend maps to {device, count}
        setTopDevices(
          (res.clicksByDevice || []).map((d: any) => ({
            device: d.device,
            count: d.count ?? d._count?.id ?? 0,
          }))
        );

        // clicksByBrowser - backend maps to {browser, count}
        setTopBrowsers(
          (res.clicksByBrowser || []).map((b: any) => ({
            browser: b.browser,
            count: b.count ?? b._count?.id ?? 0,
          }))
        );

        // clicksByOs - backend maps to {os, count}
        setTopOs(
          (res.clicksByOs || []).map((o: any) => ({
            os: o.os,
            count: o.count ?? o._count?.id ?? 0,
          }))
        );
      }
    } catch (err: any) {
      const msg = err.message || "Failed to load analytics data";
      setError(msg);
      toast.error(msg);
      // Show empty data - NO fake data
      setStats(null);
      setClicksOverTime([]);
      setTopLinks([]);
      setTopCountries([]);
      setTopDevices([]);
      setTopBrowsers([]);
      setTopOs([]);
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">Analytics</h2>
        <Select value={dateRange} onValueChange={setDateRange}>
          <SelectTrigger className="w-[130px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1d">Today</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="flex items-center gap-3 rounded-lg border border-destructive/50 bg-destructive/5 p-4">
          <AlertCircle className="h-5 w-5 text-destructive shrink-0" />
          <div>
            <p className="text-sm font-medium text-destructive">Connection Error</p>
            <p className="text-xs text-muted-foreground">{error}</p>
          </div>
          <Button variant="outline" size="sm" className="ml-auto shrink-0" onClick={loadAnalytics}>
            Retry
          </Button>
        </div>
      )}

      {/* Stats Cards */}
      <StatsCards stats={stats} loading={loading} />

      {/* Clicks Over Time */}
      <ClicksChart
        data={clicksOverTime}
        loading={loading}
      />

      {/* Charts Row */}
      <div className="grid gap-4 lg:grid-cols-2">
        <CountryChart data={topCountries} loading={loading} />
        <DeviceChart data={topDevices} loading={loading} />
      </div>

      {/* Top Links */}
      <div className="rounded-lg border">
        <div className="border-b px-4 py-3">
          <h3 className="text-sm font-medium">Top Links</h3>
        </div>
        {loading ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : topLinks.length === 0 ? (
          <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
            No link data available.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Short URL</TableHead>
                <TableHead>Destination</TableHead>
                <TableHead className="text-right">Clicks</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {topLinks.map((item: any) => (
                <TableRow key={item.link?.id || item.id}>
                  <TableCell className="font-medium text-sm">
                    {item.link?.slug || "—"}
                  </TableCell>
                  <TableCell className="max-w-[300px] truncate text-xs text-muted-foreground">
                    {item.link?.title || "—"}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {item.clicks}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Browser & OS Tables */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg border">
          <div className="border-b px-4 py-3">
            <h3 className="text-sm font-medium">Browsers</h3>
          </div>
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : topBrowsers.length === 0 ? (
            <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
              No browser data available.
            </div>
          ) : (
            <Table>
              <TableBody>
                {topBrowsers.map((item: any) => (
                  <TableRow key={item.browser}>
                    <TableCell className="text-sm">{item.browser}</TableCell>
                    <TableCell className="text-right text-sm">{item.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>

        <div className="rounded-lg border">
          <div className="border-b px-4 py-3">
            <h3 className="text-sm font-medium">Operating Systems</h3>
          </div>
          {loading ? (
            <div className="space-y-2 p-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : topOs.length === 0 ? (
            <div className="flex h-24 items-center justify-center text-sm text-muted-foreground">
              No OS data available.
            </div>
          ) : (
            <Table>
              <TableBody>
                {topOs.map((item: any) => (
                  <TableRow key={item.os}>
                    <TableCell className="text-sm">{item.os}</TableCell>
                    <TableCell className="text-right text-sm">{item.count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </div>
  );
}

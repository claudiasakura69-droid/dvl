"use client";

import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import DomainCard from "@/components/domains/DomainCard";
import AddDomainDialog from "@/components/domains/AddDomainDialog";
import EditDomainDialog from "@/components/domains/EditDomainDialog";
import { useAppStore } from "@/lib/store";
import { apiGet, apiPost, apiPut, apiDelete } from "@/lib/api";
import { Plus } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import type { ShortDomain } from "@/lib/types";

interface DomainsResponse extends ShortDomain {
  _cloudflareConfigured?: boolean;
}

export default function DomainsPage() {
  const [domains, setDomains] = useState<DomainsResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editTarget, setEditTarget] = useState<ShortDomain | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ShortDomain | null>(null);
  const [cloudflareConfigured, setCloudflareConfigured] = useState(false);

  // Verify state per-domain
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  const loadDomains = useCallback(async () => {
    setLoading(true);
    try {
      const res = await apiGet<DomainsResponse[]>("/domains");
      const list = Array.isArray(res) ? res : [];
      setDomains(list);
      // Check if Cloudflare is configured from the first item's metadata
      if (list.length > 0 && list[0]._cloudflareConfigured !== undefined) {
        setCloudflareConfigured(list[0]._cloudflareConfigured);
      }
    } catch {
      setDomains([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDomains();
  }, [loadDomains]);

  const handleAdd = async (domain: string, slug: string, autoConfigure: boolean) => {
    const res = await apiPost<any>("/domains", {
      domain,
      slug: slug || undefined,
      autoConfigure,
    });

    // Update cloudflare configured status from response
    if (res?._cloudflareConfigured !== undefined) {
      setCloudflareConfigured(res._cloudflareConfigured);
    }

    toast.success(
      res?.isVerified
        ? "Domain added and verified successfully!"
        : "Domain added to database"
    );

    setShowAddDialog(false);
    loadDomains();
    return res;
  };

  const handleUpdate = async (id: string, data: { domain: string; slug: string }) => {
    try {
      await apiPut(`/domains/${id}`, data);
      toast.success("Domain updated");
      setEditTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to update domain");
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      const res = await apiDelete<any>(`/domains/${deleteTarget.id}`);
      toast.success("Domain deleted");
      // Show cleanup info
      if (res?._pagesCleanup) {
        const cleanup = res._pagesCleanup;
        if (cleanup.success) {
          toast.info("Also removed from Cloudflare Pages custom domains");
        } else if (cleanup.error) {
          toast.warning(`Pages cleanup: ${cleanup.error}`);
        }
      }
      setDeleteTarget(null);
      loadDomains();
    } catch (err: any) {
      toast.error(err.message || "Failed to delete domain");
    }
  };

  const handleVerify = async (domain: ShortDomain) => {
    setVerifyingId(domain.id);
    setVerifyError(null);

    try {
      const res = await apiPost<any>(`/domains/${domain.id}/verify`);

      if (res?._message) {
        toast.success(res._message);
      } else {
        toast.success("Domain verified successfully");
      }

      loadDomains();
    } catch (err: any) {
      // Parse the verification error response
      const errorData = err.data || {};
      const actionNeeded = errorData.actionNeeded;
      const instructions = errorData.instructions;
      const method = errorData.method;

      if (instructions && Array.isArray(instructions)) {
        // Show detailed verification instructions from the server
        const detailMsg = instructions.slice(0, 3).join("\n");
        setVerifyError(detailMsg);
        toast.error(errorData.message || "Verification failed", { duration: 8000 });
      } else {
        setVerifyError(err.message || "Verification failed");
        toast.error(err.message || "Verification failed", { duration: 5000 });
      }
    } finally {
      setVerifyingId(null);
    }
  };

  const handleToggle = async (domain: ShortDomain) => {
    try {
      await apiPut(`/domains/${domain.id}`, { isActive: !domain.isActive });
      toast.success(`Domain ${domain.isActive ? "deactivated" : "activated"}`);
      loadDomains();
    } catch (err: any) {
      if (err.data?.requiresVerification) {
        toast.error(err.data.message || "Domain must be verified before activation", { duration: 6000 });
      } else {
        toast.error(err.message || "Failed to toggle domain status");
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Domains</h2>
          <p className="text-xs text-muted-foreground">
            {cloudflareConfigured ? (
              <span className="text-green-600 dark:text-green-400 flex items-center gap-1">
                Cloudflare API connected — auto-configure available
              </span>
            ) : (
              <span className="text-amber-600 dark:text-amber-400">
                Cloudflare API not configured — manual setup required
              </span>
            )}
          </p>
        </div>
        <Button onClick={() => setShowAddDialog(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Domain
        </Button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="h-32 animate-pulse rounded-lg bg-muted"
            />
          ))}
        </div>
      ) : domains.length === 0 ? (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <p className="text-sm text-muted-foreground">No domains configured.</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Add a domain to start creating short links.
          </p>
          {!cloudflareConfigured && (
            <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
              Tip: Configure CLOUDFLARE_API_TOKEN, CLOUDFLARE_ACCOUNT_ID, and CLOUDFLARE_PAGES_PROJECT
              for automatic domain setup.
            </p>
          )}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {domains.map((domain) => (
            <DomainCard
              key={domain.id}
              domain={domain}
              cloudflareConfigured={cloudflareConfigured}
              onEdit={setEditTarget}
              onDelete={setDeleteTarget}
              onVerify={handleVerify}
              onToggle={handleToggle}
              verifying={verifyingId === domain.id}
              verifyError={verifyingId === domain.id ? verifyError : null}
            />
          ))}
        </div>
      )}

      <AddDomainDialog
        open={showAddDialog}
        onClose={() => setShowAddDialog(false)}
        onAdd={handleAdd}
        cloudflareConfigured={cloudflareConfigured}
      />

      {editTarget && (
        <EditDomainDialog
          open={!!editTarget}
          onClose={() => setEditTarget(null)}
          domain={editTarget}
          onUpdate={handleUpdate}
        />
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Domain</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deleteTarget?.domain}&quot;?
              This will also delete all {deleteTarget?._count?.links ?? 0} links associated with this domain.
              {cloudflareConfigured && (
                <span className="block mt-2 text-xs">
                  The domain will also be removed from your Cloudflare Pages custom domains.
                </span>
              )}
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// ─── User-Agent Parsing ───────────────────────────────────────────────────────

function parseUserAgent(ua: string | null): { device: string; browser: string; os: string } {
  if (!ua) return { device: "Unknown", browser: "Unknown", os: "Unknown" };

  let device = "Desktop";
  if (/tablet|ipad|playbook|silk/i.test(ua)) {
    device = "Tablet";
  } else if (/mobile|iphone|ipod|android.*mobile|blackberry|opera mini|iemobile/i.test(ua)) {
    device = "Mobile";
  }

  let browser = "Unknown";
  if (ua.includes("Firefox/")) {
    browser = "Firefox";
  } else if (ua.includes("Edg/")) {
    browser = "Edge";
  } else if (ua.includes("OPR/") || ua.includes("Opera/")) {
    browser = "Opera";
  } else if (ua.includes("Chrome/")) {
    browser = "Chrome";
  } else if (ua.includes("Safari/")) {
    browser = "Safari";
  }

  let os = "Unknown";
  if (ua.includes("iPhone") || ua.includes("iPad")) {
    os = "iOS";
  } else if (ua.includes("Android")) {
    os = "Android";
  } else if (ua.includes("Windows NT 10") || ua.includes("Windows")) {
    os = "Windows";
  } else if (ua.includes("Mac OS X")) {
    os = "macOS";
  } else if (ua.includes("CrOS")) {
    os = "ChromeOS";
  } else if (ua.includes("Linux")) {
    os = "Linux";
  }

  return { device, browser, os };
}

// ─── Header Helpers ───────────────────────────────────────────────────────────

function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    const ips = forwarded.split(",").map((ip) => ip.trim());
    return ips[0] || "Unknown";
  }

  const realIp = request.headers.get("x-real-ip");
  if (realIp) return realIp;

  const cfIp = request.headers.get("cf-connecting-ip");
  if (cfIp) return cfIp;

  return "Unknown";
}

function getCountry(request: NextRequest): string {
  const cfCountry = request.headers.get("cf-ipcountry");
  if (cfCountry && cfCountry.length === 2) return cfCountry.toUpperCase();
  return "";
}

function getReferrer(request: NextRequest): string {
  const referrer = request.headers.get("referer");
  if (!referrer) return "direct";
  try {
    const url = new URL(referrer);
    return url.hostname;
  } catch {
    return "direct";
  }
}

// ─── Styled HTML Error Pages ──────────────────────────────────────────────────

const errorPageStyle = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #0a0a0a;
    color: #e5e5e5;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 1rem;
  }
  .container {
    text-align: center;
    max-width: 480px;
  }
  .icon {
    font-size: 4rem;
    margin-bottom: 1.5rem;
    opacity: 0.6;
  }
  h1 {
    font-size: 2rem;
    font-weight: 700;
    color: #fafafa;
    margin-bottom: 0.75rem;
  }
  p {
    font-size: 1rem;
    color: #a3a3a3;
    line-height: 1.6;
    margin-bottom: 1.5rem;
  }
  .badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background: #1a1a2e;
    border: 1px solid #2a2a3e;
    border-radius: 9999px;
    font-size: 0.75rem;
    color: #737373;
    font-family: monospace;
  }
`;

function html404(slug: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Link Not Found</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#128279;</div><h1>Link Not Found</h1><p>The short link <strong>/${slug}</strong> does not exist or has been removed.</p><span class="badge">404</span></div></body></html>`;
}

function htmlDomainInactive(host: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Domain Inactive</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#9888;&#65039;</div><h1>Domain Inactive</h1><p>The domain <strong>${host}</strong> is currently inactive. Links on this domain are not accessible.</p><span class="badge">503</span></div></body></html>`;
}

function htmlDomainUnknown(host: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Domain Not Found</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#127760;</div><h1>Domain Not Recognized</h1><p>The domain <strong>${host}</strong> is not configured for short links.</p><span class="badge">404</span></div></body></html>`;
}

function htmlLinkExpired(slug: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Link Expired</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#9200;</div><h1>Link Expired</h1><p>The short link <strong>/${slug}</strong> has expired and is no longer available.</p><span class="badge">410</span></div></body></html>`;
}

function htmlLinkInactive(slug: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Link Inactive</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#128274;</div><h1>Link Inactive</h1><p>The short link <strong>/${slug}</strong> has been deactivated and is no longer accessible.</p><span class="badge">404</span></div></body></html>`;
}

function htmlPasswordRequired(slug: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Password Required</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#128273;</div><h1>Password Required</h1><p>The short link <strong>/${slug}</strong> is password-protected. Password-protected links cannot be accessed via direct URL visits. Please use the dashboard to access this link.</p><span class="badge">403</span></div></body></html>`;
}

function htmlNoTarget(slug: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>No Target Available</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#128533;</div><h1>No Target Available</h1><p>The short link <strong>/${slug}</strong> has no available targets. All targets may have reached their click limits.</p><span class="badge">429</span></div></body></html>`;
}

// ─── CORS Headers ─────────────────────────────────────────────────────────────

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "*",
};

// ─── GET Handler ──────────────────────────────────────────────────────────────

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const host = request.headers.get("host") || "";

    if (!slug || !host) {
      return new NextResponse(html404(slug || "unknown"), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // Remove port from host if present (e.g., short.example.com:3000 -> short.example.com)
    const hostname = host.split(":")[0];

    // 1. Look up domain by hostname
    const domainRecord = await db.shortDomain.findFirst({
      where: { domain: hostname },
    });

    if (!domainRecord) {
      return new NextResponse(htmlDomainUnknown(hostname), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 2. Check if domain is active
    if (!domainRecord.isActive) {
      return new NextResponse(htmlDomainInactive(hostname), {
        status: 503,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 3. Look up short link by slug + domainId
    const link = await db.shortLink.findFirst({
      where: { slug, domainId: domainRecord.id },
      include: {
        domain: true,
        targets: {
          where: { isActive: true },
          orderBy: { order: "asc" },
        },
      },
    });

    if (!link) {
      return new NextResponse(html404(slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 4. Check if link is active
    if (!link.isActive) {
      return new NextResponse(htmlLinkInactive(slug), {
        status: 404,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 5. Check if link has expired
    if (link.expiredAt && link.expiredAt < new Date()) {
      return new NextResponse(htmlLinkExpired(slug), {
        status: 410,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 6. Check password protection — password-protected links can't be served via direct URL visit
    if (link.password) {
      return new NextResponse(htmlPasswordRequired(slug), {
        status: 403,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 7. Extract real visitor data from headers
    const visitorIp = getClientIp(request);
    const visitorCountry = getCountry(request);
    const ua = request.headers.get("user-agent");
    const { device, browser, os } = parseUserAgent(ua);
    const visitorReferrer = getReferrer(request);
    const cfRay = request.headers.get("cf-ray") || "";
    const cfWorker = request.headers.get("cf-worker") || "";

    // 8. Determine redirect target using same routing logic as /api/redirect
    let selectedTarget;

    if (link.type === "basic") {
      selectedTarget = link.targets[0];

      if (!selectedTarget) {
        return new NextResponse(htmlNoTarget(slug), {
          status: 429,
          headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
        });
      }

      if (
        selectedTarget.clickLimit > 0 &&
        selectedTarget.currentClicks >= selectedTarget.clickLimit
      ) {
        return new NextResponse(htmlNoTarget(slug), {
          status: 429,
          headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
        });
      }
    } else {
      // Multi-target routing
      const availableTargets = link.targets.filter((t) => {
        if (t.clickLimit > 0 && t.currentClicks >= t.clickLimit) return false;
        return true;
      });

      if (availableTargets.length === 0) {
        return new NextResponse(htmlNoTarget(slug), {
          status: 429,
          headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
        });
      }

      // Priority 1: IP-based targets
      const ipMatchTargets = availableTargets.filter((t) => {
        if (!t.ipList) return false;
        const allowedIps = t.ipList.split(",").map((ip) => ip.trim());
        return allowedIps.includes(visitorIp);
      });

      if (ipMatchTargets.length > 0) {
        selectedTarget = ipMatchTargets[0];
      } else {
        // Priority 2: Country-based targets
        const countryMatchTargets = availableTargets.filter(
          (t) => t.country !== "ALL" && t.country === visitorCountry
        );

        if (countryMatchTargets.length > 0) {
          selectedTarget = countryMatchTargets[0];
        } else {
          // Priority 3: ALL country targets
          const allTargets = availableTargets.filter((t) => t.country === "ALL");

          if (allTargets.length === 0) {
            selectedTarget = availableTargets[0];
          } else if (link.mode === "random") {
            selectedTarget = allTargets[Math.floor(Math.random() * allTargets.length)];
          } else {
            // Sequential: find target with lowest currentClicks
            selectedTarget = allTargets.reduce((prev, curr) =>
              prev.currentClicks <= curr.currentClicks ? prev : curr
            );
          }
        }
      }
    }

    if (!selectedTarget) {
      return new NextResponse(htmlNoTarget(slug), {
        status: 429,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      });
    }

    // 9. Increment click count on the target
    await db.linkTarget.update({
      where: { id: selectedTarget.id },
      data: { currentClicks: { increment: 1 } },
    });

    // 10. Record the click with real visitor data
    await db.click.create({
      data: {
        linkId: link.id,
        targetId: selectedTarget.id,
        ip: visitorIp,
        country: visitorCountry,
        city: "",
        region: "",
        device,
        browser,
        os,
        referrer: visitorReferrer,
        cfRay,
        cfWorker,
      },
    });

    // 11. Build final URL with UTM parameters if configured
    let targetUrl = selectedTarget.url;
    try {
      const urlObj = new URL(targetUrl);
      if (link.utmSource) urlObj.searchParams.set("utm_source", link.utmSource);
      if (link.utmMedium) urlObj.searchParams.set("utm_medium", link.utmMedium);
      if (link.utmCampaign) urlObj.searchParams.set("utm_campaign", link.utmCampaign);
      if (link.utmContent) urlObj.searchParams.set("utm_content", link.utmContent);
      if (link.utmTerm) urlObj.searchParams.set("utm_term", link.utmTerm);
      targetUrl = urlObj.toString();
    } catch {
      // If URL parsing fails, use the original URL
    }

    // 12. Perform 301 redirect
    const redirectResponse = NextResponse.redirect(targetUrl, 301);
    redirectResponse.headers.set("X-Link-Id", link.id);
    redirectResponse.headers.set("X-Target-Id", selectedTarget.id);
    return redirectResponse;
  } catch (error) {
    console.error("Error processing catch-all redirect:", error);
    return new NextResponse(
      `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Error</title><style>${errorPageStyle}</style></head><body><div class="container"><div class="icon">&#128533;</div><h1>Something went wrong</h1><p>An unexpected error occurred while processing your request. Please try again.</p><span class="badge">500</span></div></body></html>`,
      {
        status: 500,
        headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders },
      }
    );
  }
}

// ─── OPTIONS Handler (CORS preflight) ─────────────────────────────────────────

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: corsHeaders });
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

function startOfDay(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

function startOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Monday
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function startOfMonth(date: Date): Date {
  const d = new Date(date);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
}

function formatDayKey(date: Date): string {
  return date.toISOString().split("T")[0];
}

// GET - Analytics overview
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const now = new Date();

    // Run independent queries in parallel
    const [
      totalLinks,
      activeLinks,
      totalDomains,
      activeDomains,
      allClicks,
      clicksToday,
      clicksThisWeek,
      clicksThisMonth,
      recentClicks,
      topLinks,
      clicksByCountryRaw,
      clicksByDeviceRaw,
      clicksByBrowserRaw,
      clicksOverTimeRaw,
      // Note: OS groupBy is handled separately via findMany due to Prisma/SQLite bug with 'os' column
    ] = await Promise.all([
      // Total & active links
      db.shortLink.count(),
      db.shortLink.count({ where: { isActive: true } }),

      // Total & active domains
      db.shortDomain.count(),
      db.shortDomain.count({ where: { isActive: true } }),

      // Total clicks
      db.click.count(),

      // Clicks today
      db.click.count({
        where: { createdAt: { gte: startOfDay(now) } },
      }),

      // Clicks this week
      db.click.count({
        where: { createdAt: { gte: startOfWeek(now) } },
      }),

      // Clicks this month
      db.click.count({
        where: { createdAt: { gte: startOfMonth(now) } },
      }),

      // Recent 20 clicks (used for OS aggregation too)
      db.click.findMany({
        take: 20,
        orderBy: { createdAt: "desc" },
        include: {
          link: {
            select: { id: true, slug: true },
          },
        },
      }),

      // Top 10 links by click count
      db.shortLink.findMany({
        take: 10,
        orderBy: { clicks: { _count: "desc" } },
        select: {
          id: true,
          slug: true,
          title: true,
          createdAt: true,
          _count: {
            select: { clicks: true },
          },
        },
      }),

      // Clicks by country (top 10)
      db.click.groupBy({
        by: ["country"],
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
        take: 10,
        where: { country: { not: "" } },
      }),

      // Clicks by device
      db.click.groupBy({
        by: ["device"],
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
        where: { device: { not: "" } },
      }),

      // Clicks by browser
      db.click.groupBy({
        by: ["browser"],
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
        where: { browser: { not: "" } },
      }),

      // Clicks over last 7 days (grouped by day)
      db.click.findMany({
        where: {
          createdAt: {
            gte: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
          },
        },
        select: {
          createdAt: true,
        },
      }),
    ]);

    // Build clicks over time (last 7 days)
    const clicksByDay: Record<string, number> = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
      clicksByDay[formatDayKey(d)] = 0;
    }

    for (const click of clicksOverTimeRaw) {
      if (!click.createdAt) continue;
      const key = formatDayKey(new Date(click.createdAt));
      if (clicksByDay[key] !== undefined) {
        clicksByDay[key]++;
      }
    }

    const clicksOverTime = Object.entries(clicksByDay).map(([date, count]) => ({
      date,
      clicks: count,
    }));

    // Aggregate OS from recentClicks (avoiding Prisma groupBy bug with 'os' column name in SQLite)
    const osMap: Record<string, number> = {};
    for (const click of recentClicks) {
      const os = click.os?.trim();
      if (os && os !== "Unknown") {
        osMap[os] = (osMap[os] || 0) + 1;
      }
    }
    const clicksByOs = Object.entries(osMap)
      .map(([os, count]) => ({ os, count }))
      .sort((a, b) => b.count - a.count);

    return NextResponse.json({
      totalLinks,
      activeLinks,
      totalDomains,
      activeDomains,
      totalClicks: allClicks,
      clicksToday,
      clicksThisWeek,
      clicksThisMonth,
      topLinks: topLinks.map((l) => ({
        ...l,
        clickCount: l._count.clicks,
        _count: undefined,
      })),
      clicksByCountry: clicksByCountryRaw.map((c) => ({
        country: c.country || "Unknown",
        count: c._count?.id || 0,
      })),
      clicksByDevice: clicksByDeviceRaw.map((d) => ({
        device: d.device || "Unknown",
        count: d._count?.id || 0,
      })),
      clicksByBrowser: clicksByBrowserRaw.map((b) => ({
        browser: b.browser || "Unknown",
        count: b._count?.id || 0,
      })),
      clicksByOs,
      recentClicks,
      clicksOverTime,
    });
  } catch (error) {
    console.error("Error fetching analytics overview:", error);
    return NextResponse.json(
      { error: "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}

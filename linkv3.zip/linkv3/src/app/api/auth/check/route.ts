import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("Authorization");

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "No token provided" }, { status: 401 });
    }

    const token = authHeader.replace("Bearer ", "");
    const validToken = process.env.DASHBOARD_TOKEN;

    if (!validToken) {
      return NextResponse.json(
        { error: "Server not configured. DASHBOARD_TOKEN is not set." },
        { status: 500 }
      );
    }

    if (token === validToken) {
      return NextResponse.json({ authenticated: true });
    }

    return NextResponse.json({ error: "Invalid token" }, { status: 401 });
  } catch {
    return NextResponse.json({ error: "Authentication check failed" }, { status: 401 });
  }
}

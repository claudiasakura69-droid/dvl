import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * Parse User-Agent string to extract device type, browser, and OS
 */
function parseUserAgent(ua: string | null): { device: string; browser: string; os: string } {
  if (!ua) return { device: "Unknown", browser: "Unknown", os: "Unknown" };

  // Device detection
  let device = "Desktop";
  if (/tablet|ipad|playbook|silk/i.test(ua)) {
    device = "Tablet";
  } else if (/mobile|iphone|ipod|android.*mobile|blackberry|opera mini|iemobile/i.test(ua)) {
    device = "Mobile";
  }

  // Browser detection
  let browser = "Unknown";
  if (ua.includes("Firefox/")) {
    browser = "Firefox";
  } else if (ua.includes("Edg/")) {
    browser = "Edge";
  } else if (ua.includes("OPR/") || ua.includes("Opera/")) {
    browser = "Opera";
  } else if (ua.includes("Chrome/")) {
    browser = "Chrome";
  } else if (ua.includes("Safari/")) {
    browser = "Safari";
  }

  // OS detection (check specific mobile OS before general desktop OS)
  let os = "Unknown";
  if (ua.includes("iPhone") || ua.includes("iPad")) {
    os = "iOS";
  } else if (ua.includes("Android")) {
    os = "Android";
  } else if (ua.includes("Windows NT 10") || ua.includes("Windows")) {
    os = "Windows";
  } else if (ua.includes("Mac OS X")) {
    os = "macOS";
  } else if (ua.includes("CrOS")) {
    os = "ChromeOS";
  } else if (ua.includes("Linux")) {
    os = "Linux";
  }

  return { device, browser, os };
}

/**
 * Get client IP from request headers
 */
function getClientIp(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for");
  if (forwarded) {
    // x-forwarded-for can contain multiple IPs: "client, proxy1, proxy2"
    const ips = forwarded.split(",").map((ip) => ip.trim());
    return ips[0] || "Unknown";
  }

  const realIp = request.headers.get("x-real-ip");
  if (realIp) return realIp;

  // Cloudflare headers
  const cfIp = request.headers.get("cf-connecting-ip");
  if (cfIp) return cfIp;

  return "Unknown";
}

/**
 * Get country from Cloudflare headers or fallback
 */
function getCountry(request: NextRequest): string {
  // Cloudflare provides country code via cf-ipcountry header
  const cfCountry = request.headers.get("cf-ipcountry");
  if (cfCountry && cfCountry.length === 2) return cfCountry.toUpperCase();

  return "";
}

/**
 * Get referrer from request headers
 */
function getReferrer(request: NextRequest): string {
  const referrer = request.headers.get("referer");
  if (!referrer) return "direct";
  try {
    const url = new URL(referrer);
    return url.hostname;
  } catch {
    return "direct";
  }
}

// GET - Redirect logic
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const slug = searchParams.get("slug");
    const domain = searchParams.get("domain");

    if (!slug) {
      return NextResponse.json({ error: "Slug is required" }, { status: 400 });
    }

    // Find the link by slug and optionally domain
    let link;

    if (domain) {
      // Find by domain name + slug
      const domainRecord = await db.shortDomain.findFirst({
        where: { domain },
      });

      if (!domainRecord) {
        return NextResponse.json({ error: "Link not found" }, { status: 404 });
      }

      // Check if domain is active
      if (!domainRecord.isActive) {
        return NextResponse.json({ error: "Domain is inactive" }, { status: 404 });
      }

      link = await db.shortLink.findFirst({
        where: { slug, domainId: domainRecord.id },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    } else {
      // Find by slug alone (first match, or use default domain)
      link = await db.shortLink.findFirst({
        where: { slug },
        include: {
          domain: true,
          targets: {
            where: { isActive: true },
            orderBy: { order: "asc" },
          },
        },
      });
    }

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    // Check if link is active
    if (!link.isActive) {
      return NextResponse.json({ error: "Link is inactive" }, { status: 404 });
    }

    // Check if link has expired
    if (link.expiredAt && link.expiredAt < new Date()) {
      return NextResponse.json({ error: "Link has expired" }, { status: 410 });
    }

    // Check password protection
    const providedPassword = searchParams.get("password");
    if (link.password) {
      if (!providedPassword || providedPassword !== link.password) {
        return NextResponse.json(
          { error: "Password required", passwordProtected: true },
          { status: 403 }
        );
      }
    }

    // Extract REAL visitor data from request headers
    const visitorIp = getClientIp(request);
    const visitorCountry = getCountry(request);
    const ua = request.headers.get("user-agent");
    const { device, browser, os } = parseUserAgent(ua);
    const visitorReferrer = getReferrer(request);
    const cfRay = request.headers.get("cf-ray") || "";
    const cfWorker = request.headers.get("cf-worker") || "";

    // Determine redirect target
    let selectedTarget;

    if (link.type === "basic") {
      // Basic: single target
      selectedTarget = link.targets[0];

      if (!selectedTarget) {
        return NextResponse.json(
          { error: "No active target found" },
          { status: 404 }
        );
      }

      // Check click limit for basic
      if (
        selectedTarget.clickLimit > 0 &&
        selectedTarget.currentClicks >= selectedTarget.clickLimit
      ) {
        return NextResponse.json(
          { error: "Click limit reached" },
          { status: 429 }
        );
      }
    } else {
      // Multi-target routing logic
      const availableTargets = link.targets.filter((t) => {
        // Filter by click limit
        if (t.clickLimit > 0 && t.currentClicks >= t.clickLimit) {
          return false;
        }
        return true;
      });

      if (availableTargets.length === 0) {
        return NextResponse.json(
          { error: "No available targets" },
          { status: 404 }
        );
      }

      // Priority 1: IP-based targets
      const ipMatchTargets = availableTargets.filter((t) => {
        if (!t.ipList) return false;
        const allowedIps = t.ipList.split(",").map((ip) => ip.trim());
        return allowedIps.includes(visitorIp);
      });

      if (ipMatchTargets.length > 0) {
        selectedTarget = ipMatchTargets[0];
      } else {
        // Priority 2: Country-based targets
        const countryMatchTargets = availableTargets.filter(
          (t) => t.country !== "ALL" && t.country === visitorCountry
        );

        if (countryMatchTargets.length > 0) {
          selectedTarget = countryMatchTargets[0];
        } else {
          // Priority 3: ALL country targets
          const allTargets = availableTargets.filter(
            (t) => t.country === "ALL"
          );

          if (allTargets.length === 0) {
            // Fall back to any available target
            selectedTarget = availableTargets[0];
          } else if (link.mode === "random") {
            selectedTarget = allTargets[Math.floor(Math.random() * allTargets.length)];
          } else {
            // Sequential: find the target with lowest currentClicks
            selectedTarget = allTargets.reduce((prev, curr) =>
              prev.currentClicks <= curr.currentClicks ? prev : curr
            );
          }
        }
      }
    }

    if (!selectedTarget) {
      return NextResponse.json(
        { error: "No suitable target found" },
        { status: 404 }
      );
    }

    // Increment click count on the target
    await db.linkTarget.update({
      where: { id: selectedTarget.id },
      data: { currentClicks: { increment: 1 } },
    });

    // Record the click with REAL visitor data
    await db.click.create({
      data: {
        linkId: link.id,
        targetId: selectedTarget.id,
        ip: visitorIp,
        country: visitorCountry,
        city: "", // City requires GeoIP database, left empty unless Cloudflare provides it
        region: "",
        device,
        browser,
        os,
        referrer: visitorReferrer,
        cfRay,
        cfWorker,
      },
    });

    // Return redirect info
    return NextResponse.json({
      url: selectedTarget.url,
      status: 301,
      linkId: link.id,
      targetId: selectedTarget.id,
    });
  } catch (error) {
    console.error("Error processing redirect:", error);
    return NextResponse.json({ error: "Redirect failed" }, { status: 500 });
  }
}

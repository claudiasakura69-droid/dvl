import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";
import { addPagesDomain, getCloudflareConfig } from "@/lib/cloudflare";

// GET - List all domains
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const domains = await db.shortDomain.findMany({
      orderBy: { createdAt: "desc" },
      include: {
        links: {
          select: { id: true },
        },
      },
    });

    const { isConfigured } = getCloudflareConfig();

    const domainsWithCount = domains.map((d) => ({
      ...d,
      _count: { links: d.links.length },
      links: undefined,
      _cloudflareConfigured: isConfigured,
    }));

    return NextResponse.json(domainsWithCount);
  } catch (error) {
    console.error("Error fetching domains:", error);
    return NextResponse.json({ error: "Failed to fetch domains" }, { status: 500 });
  }
}

// POST - Create domain
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { domain, slug, autoConfigure } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json({ error: "Domain is required" }, { status: 400 });
    }

    // Basic domain format validation
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      return NextResponse.json({ error: "Invalid domain format" }, { status: 400 });
    }

    // Check if domain already exists
    const existing = await db.shortDomain.findUnique({ where: { domain } });
    if (existing) {
      return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
    }

    // Create domain in database (starts as INACTIVE until verified)
    const created = await db.shortDomain.create({
      data: {
        domain,
        slug: slug || "",
        isActive: false,
        isVerified: false,
      },
    });

    // If autoConfigure is requested and Cloudflare API is configured, add to Pages
    let pagesResult: { success: boolean; status?: string; error?: string } | null = null;
    if (autoConfigure) {
      const { isConfigured } = getCloudflareConfig();
      if (isConfigured) {
        pagesResult = await addPagesDomain(domain);

        // If Pages domain was added successfully, auto-verify via Cloudflare API
        if (pagesResult.success) {
          const { verifyDomain } = await import("@/lib/cloudflare");
          const verifyResult = await verifyDomain(domain);
          if (verifyResult.verified) {
            // Auto-activate when auto-verified (both verified + active)
            await db.shortDomain.update({
              where: { id: created.id },
              data: { isVerified: true, isActive: true, verifiedAt: new Date() },
            });
            created.isVerified = true;
            created.isActive = true;
            created.verifiedAt = new Date().toISOString();
          }
        }
      } else {
        pagesResult = { success: false, error: "Cloudflare API not configured" };
      }
    }

    return NextResponse.json(
      {
        ...created,
        _pagesResult: pagesResult,
        _cloudflareConfigured: getCloudflareConfig().isConfigured,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating domain:", error);
    return NextResponse.json({ error: "Failed to create domain" }, { status: 500 });
  }
}

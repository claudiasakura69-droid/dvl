import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";
import { verifyDomain, addPagesDomain, getCloudflareConfig } from "@/lib/cloudflare";

// POST - Verify domain ownership + connectivity
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const result = await verifyDomain(existing.domain);

    if (result.verified) {
      const updated = await db.shortDomain.update({
        where: { id },
        data: {
          isVerified: true,
          isActive: true, // Auto-activate on successful verification
          verifiedAt: new Date(),
        },
      });

      return NextResponse.json({
        ...updated,
        _message: result.message,
        _method: result.method,
        _details: result.details,
      });
    }

    // Not verified - provide actionable instructions
    await db.shortDomain.update({
      where: { id },
      data: {
        isVerified: false,
        verifiedAt: null,
      },
    });

    const { isConfigured } = getCloudflareConfig();

    // Generate instructions based on verification method and what failed
    let instructions: string[] = [];
    let actionNeeded = "";

    if (result.method === "cloudflare_api") {
      const { zoneExists, pagesDomainExists } = result.details;

      if (!zoneExists) {
        actionNeeded = "zone_missing";
        instructions = [
          `The domain "${existing.domain}" is NOT a zone in your Cloudflare account.`,
          "This means either:",
          "  - The domain's nameservers don't point to Cloudflare, OR",
          "  - The domain is in a DIFFERENT Cloudflare account than your Pages project",
          "",
          "To fix this:",
          "  1. Go to your domain registrar (where you bought the domain)",
          "  2. Change nameservers to Cloudflare's nameservers for this zone",
          "  3. Make sure the domain is in the SAME Cloudflare account as your Pages project",
          "  4. Wait for DNS propagation (usually minutes, up to 48 hours)",
          "  5. Click Verify again",
        ];
      } else if (!pagesDomainExists) {
        actionNeeded = "pages_domain_missing";
        instructions = [
          `Domain "${existing.domain}" is verified as yours (zone found), but it's not yet added to your Pages project.`,
          "",
          "To fix this, choose one:",
          "",
          "Option A - Auto-add (recommended, uses Cloudflare API):",
          "  Click the 'Configure' button instead of 'Verify' to auto-add it.",
          "",
          "Option B - Manual:",
          "  1. Go to Cloudflare Dashboard → Workers & Pages → Your Project",
          "  2. Click 'Custom domains' tab",
          "  3. Click 'Set up a custom domain'",
          "  4. Enter the domain and activate it",
          "  5. Click Verify again",
        ];
      }
    } else {
      // DNS check mode (no API token)
      actionNeeded = "dns_check_failed";
      instructions = [
        "DNS verification failed. For secure domain ownership verification:",
        "",
        "Configure these environment variables in your Cloudflare Pages project:",
        "  CLOUDFLARE_API_TOKEN - Create at Cloudflare Dashboard → My Profile → API Tokens",
        "    Required permissions: Zone:Read, Workers Routes:Edit",
        "  CLOUDFLARE_ACCOUNT_ID - Found in Cloudflare Dashboard → Workers & Pages → Overview",
        "  CLOUDFLARE_PAGES_PROJECT - Your project name (e.g., 'bebastesting' from bebastesting.pages.dev)",
        "",
        "Then click Verify again for secure Cloudflare API verification.",
        "",
        "Or manually verify DNS: add a CNAME record for the domain pointing to your *.pages.dev domain.",
      ];
    }

    return NextResponse.json(
      {
        error: "Verification failed",
        message: result.message,
        method: result.method,
        details: result.details,
        actionNeeded,
        instructions,
        cloudflareConfigured: isConfigured,
      },
      { status: 422 }
    );
  } catch (error) {
    console.error("Error verifying domain:", error);
    return NextResponse.json({ error: "Failed to verify domain" }, { status: 500 });
  }
}

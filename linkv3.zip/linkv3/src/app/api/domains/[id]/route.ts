import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";
import { removePagesDomain, getCloudflareConfig } from "@/lib/cloudflare";

// GET - Get single domain
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const domain = await db.shortDomain.findUnique({
      where: { id },
      include: {
        links: {
          select: { id: true },
        },
      },
    });

    if (!domain) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const domainWithCount = {
      ...domain,
      _count: { links: domain.links.length },
      links: undefined,
    };

    return NextResponse.json(domainWithCount);
  } catch (error) {
    console.error("Error fetching domain:", error);
    return NextResponse.json({ error: "Failed to fetch domain" }, { status: 500 });
  }
}

// PUT - Update domain
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();
    const { domain, slug, isActive, isVerified } = body;

    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // If domain is being changed, check uniqueness
    if (domain && domain !== existing.domain) {
      const domainConflict = await db.shortDomain.findUnique({ where: { domain } });
      if (domainConflict) {
        return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
      }

      // If Cloudflare API is configured, remove old domain from Pages and add new one
      const { isConfigured } = getCloudflareConfig();
      if (isConfigured) {
        await removePagesDomain(existing.domain);
        await import("@/lib/cloudflare").then((cf) => cf.addPagesDomain(domain));
      }
    }

    // RULE: Domain must be verified before it can be activated
    if (isActive === true && !existing.isVerified) {
      return NextResponse.json(
        {
          error: "Domain must be verified before activation",
          message: `Domain "${existing.domain}" is not verified. Please verify domain ownership first by clicking the Verify button.`,
          requiresVerification: true,
        },
        { status: 403 }
      );
    }

    // If renaming domain, reset verification (new domain needs re-verification)
    const updateData: Record<string, unknown> = {};
    if (domain !== undefined && domain !== existing.domain) {
      updateData.domain = domain;
      updateData.isVerified = false;
      updateData.verifiedAt = null;
    }
    if (slug !== undefined) updateData.slug = slug;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (isVerified !== undefined) updateData.isVerified = isVerified;

    const updated = await db.shortDomain.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error updating domain:", error);
    return NextResponse.json({ error: "Failed to update domain" }, { status: 500 });
  }
}

// DELETE - Delete domain (cascades to links, optionally removes from Pages)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await db.shortDomain.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    // Optionally remove from Cloudflare Pages custom domains
    let pagesCleanup: { success: boolean; error?: string } | null = null;
    const { isConfigured } = getCloudflareConfig();
    if (isConfigured) {
      pagesCleanup = await removePagesDomain(existing.domain);
    }

    // Delete from database (cascades to links, targets, clicks)
    await db.shortDomain.delete({ where: { id } });

    return NextResponse.json({
      success: true,
      _pagesCleanup: pagesCleanup,
    });
  } catch (error) {
    console.error("Error deleting domain:", error);
    return NextResponse.json({ error: "Failed to delete domain" }, { status: 500 });
  }
}

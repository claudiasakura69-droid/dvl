import { NextRequest, NextResponse } from "next/server";

/**
 * Get the valid dashboard token from environment variables.
 * DASHBOARD_TOKEN must be set in .env or Cloudflare environment variables.
 */
function getValidToken(): string {
  const token = process.env.DASHBOARD_TOKEN;
  if (!token) {
    console.error("⚠️ DASHBOARD_TOKEN is not set. Please configure it in .env or Cloudflare environment variables.");
  }
  return token || "";
}

export function isAuthenticated(request: NextRequest): boolean {
  const validToken = getValidToken();
  if (!validToken) return false; // No token configured = no access

  const authHeader = request.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.replace("Bearer ", "");
  return token === validToken;
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

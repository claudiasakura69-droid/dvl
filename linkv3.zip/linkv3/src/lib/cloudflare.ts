/**
 * Cloudflare API Integration
 *
 * This module provides functions to interact with the Cloudflare API for:
 * 1. Verifying domain ownership (zone in account)
 * 2. Managing Pages custom domains (add/remove/list)
 * 3. DNS record verification
 *
 * Required environment variables:
 * - CLOUDFLARE_API_TOKEN: API token with Zone:Read, Workers Routes:Edit, Pages:Edit
 * - CLOUDFLARE_ACCOUNT_ID: Your Cloudflare account ID
 * - CLOUDFLARE_PAGES_PROJECT: Your Pages project name (e.g., "bebastesting" from bebastesting.pages.dev)
 */

// ─── Environment Variable Helpers ──────────────────────────────────────────────

export function getCloudflareConfig(): {
  apiToken: string;
  accountId: string;
  projectName: string;
  isConfigured: boolean;
} {
  const apiToken = process.env.CLOUDFLARE_API_TOKEN || "";
  const accountId = process.env.CLOUDFLARE_ACCOUNT_ID || "";
  const projectName = process.env.CLOUDFLARE_PAGES_PROJECT || "";

  return {
    apiToken,
    accountId,
    projectName,
    isConfigured: !!(apiToken && accountId && projectName),
  };
}

// ─── Cloudflare API Types ──────────────────────────────────────────────────────

interface CfApiResponse<T> {
  success: boolean;
  errors: Array<{ code: number; message: string }>;
  result: T;
}

interface CfZone {
  id: string;
  name: string;
  status: string;
  paused: boolean;
  name_servers: string[];
}

interface CfPagesDomain {
  id?: string;
  name: string;
  status: "active" | "pending" | "pending_deletion" | "deactivated" | "initializing";
  ssl?: {
    type: string;
    status: string;
  };
  created_on?: string;
}

// ─── Zone Operations ──────────────────────────────────────────────────────────

/**
 * Check if a domain exists as a zone in the Cloudflare account.
 * This proves the user OWNS the domain (nameservers point to Cloudflare).
 */
export async function checkZoneExists(domain: string): Promise<{
  exists: boolean;
  zoneId?: string;
  status?: string;
  nameServers?: string[];
  error?: string;
}> {
  const { apiToken, accountId, isConfigured } = getCloudflareConfig();

  if (!isConfigured) {
    return { exists: false, error: "Cloudflare API not configured" };
  }

  try {
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/zones?name=${encodeURIComponent(domain)}`,
      {
        headers: {
          Authorization: `Bearer ${apiToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const data: CfApiResponse<CfZone[]> = await res.json();

    if (!data.success) {
      const msg = data.errors?.[0]?.message || "Unknown API error";
      return { exists: false, error: msg };
    }

    if (data.result.length === 0) {
      return {
        exists: false,
        error: `Domain "${domain}" is not a zone in your Cloudflare account. Make sure the domain's nameservers point to Cloudflare and it's in the same account as your Pages project.`,
      };
    }

    const zone = data.result[0];
    return {
      exists: true,
      zoneId: zone.id,
      status: zone.status,
      nameServers: zone.name_servers,
    };
  } catch (error) {
    console.error("Cloudflare zone check error:", error);
    return { exists: false, error: "Failed to check domain zone. Network error or API unavailable." };
  }
}

/**
 * List all zones in the account (for debugging / dropdown).
 */
export async function listZones(): Promise<{
  zones: Array<{ id: string; name: string; status: string }>;
  error?: string;
}> {
  const { apiToken, isConfigured } = getCloudflareConfig();

  if (!isConfigured) {
    return { zones: [], error: "Cloudflare API not configured" };
  }

  try {
    const res = await fetch("https://api.cloudflare.com/client/v4/zones?per_page=100", {
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "application/json",
      },
    });

    const data: CfApiResponse<CfZone[]> = await res.json();

    if (!data.success) {
      return { zones: [], error: data.errors?.[0]?.message || "Unknown API error" };
    }

    return {
      zones: data.result.map((z) => ({ id: z.id, name: z.name, status: z.status })),
    };
  } catch (error) {
    return { zones: [], error: "Network error" };
  }
}

// ─── Pages Custom Domain Operations ───────────────────────────────────────────

/**
 * List all custom domains on the Pages project.
 */
export async function listPagesDomains(): Promise<{
  domains: Array<{ name: string; status: string }>;
  error?: string;
}> {
  const { apiToken, accountId, projectName, isConfigured } = getCloudflareConfig();

  if (!isConfigured) {
    return { domains: [], error: "Cloudflare API not configured" };
  }

  try {
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}/domains`,
      {
        headers: {
          Authorization: `Bearer ${apiToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const data: CfApiResponse<CfPagesDomain[]> = await res.json();

    if (!data.success) {
      return { domains: [], error: data.errors?.[0]?.message || "Unknown API error" };
    }

    return {
      domains: data.result.map((d) => ({ name: d.name, status: d.status })),
    };
  } catch (error) {
    return { domains: [], error: "Network error" };
  }
}

/**
 * Add a custom domain to the Pages project.
 * This automatically configures the DNS record if the zone is in the same account.
 */
export async function addPagesDomain(domain: string): Promise<{
  success: boolean;
  status?: string;
  error?: string;
}> {
  const { apiToken, accountId, projectName, isConfigured } = getCloudflareConfig();

  if (!isConfigured) {
    return { success: false, error: "Cloudflare API not configured" };
  }

  try {
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}/domains`,
      {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${apiToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name: domain }),
      }
    );

    const data: CfApiResponse<CfPagesDomain> = await res.json();

    if (!data.success) {
      const msg = data.errors?.[0]?.message || "Unknown API error";
      return { success: false, error: msg };
    }

    return {
      success: true,
      status: data.result.status,
    };
  } catch (error) {
    console.error("Cloudflare add domain error:", error);
    return { success: false, error: "Network error or API unavailable." };
  }
}

/**
 * Remove a custom domain from the Pages project.
 */
export async function removePagesDomain(domain: string): Promise<{
  success: boolean;
  error?: string;
}> {
  const { apiToken, accountId, projectName, isConfigured } = getCloudflareConfig();

  if (!isConfigured) {
    return { success: false, error: "Cloudflare API not configured" };
  }

  try {
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${accountId}/pages/projects/${projectName}/domains/${domain}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${apiToken}`,
          "Content-Type": "application/json",
        },
      }
    );

    const data: CfApiResponse<null> = await res.json();

    if (!data.success) {
      const msg = data.errors?.[0]?.message || "Unknown API error";
      return { success: false, error: msg };
    }

    return { success: true };
  } catch (error) {
    console.error("Cloudflare remove domain error:", error);
    return { success: false, error: "Network error or API unavailable." };
  }
}

/**
 * Check if a specific domain is configured on the Pages project.
 */
export async function checkPagesDomain(domain: string): Promise<{
  exists: boolean;
  status?: string;
  sslStatus?: string;
  error?: string;
}> {
  const { domains, error } = await listPagesDomains();

  if (error) {
    return { exists: false, error };
  }

  const found = domains.find(
    (d) => d.name.toLowerCase() === domain.toLowerCase()
  );

  if (!found) {
    return {
      exists: false,
      error: `Domain "${domain}" is not configured as a custom domain on your Pages project. Add it in Cloudflare Dashboard → Workers & Pages → Your Project → Custom domains.`,
    };
  }

  return { exists: true, status: found.status };
}

// ─── Combined Verification ────────────────────────────────────────────────────

export interface VerificationResult {
  verified: boolean;
  method: "cloudflare_api" | "dns_check" | "none";
  message: string;
  details: {
    zoneExists?: boolean;
    zoneStatus?: string;
    pagesDomainExists?: boolean;
    pagesDomainStatus?: string;
    dnsCname?: string;
    dnsARecords?: string[];
  };
}

/**
 * Full domain verification with two tiers:
 *
 * TIER 1 (Cloudflare API - most secure):
 *   - Checks if domain is a ZONE in the Cloudflare account → proves ownership
 *   - Checks if domain is a CUSTOM DOMAIN on the Pages project → proves connectivity
 *   - Both must pass for verification
 *
 * TIER 2 (DNS check - fallback if no API token):
 *   - Checks CNAME record pointing to *.pages.dev
 *   - Checks A record resolving to Cloudflare IPs
 *   - Less secure (any Cloudflare-proxied domain passes)
 */
export async function verifyDomain(domain: string): Promise<VerificationResult> {
  const { isConfigured } = getCloudflareConfig();

  if (isConfigured) {
    return verifyViaCloudflareApi(domain);
  }

  return verifyViaDns(domain);
}

async function verifyViaCloudflareApi(domain: string): Promise<VerificationResult> {
  // Step 1: Check if domain is a zone in the account
  const zoneResult = await checkZoneExists(domain);

  if (!zoneResult.exists) {
    return {
      verified: false,
      method: "cloudflare_api",
      message: zoneResult.error || `Domain "${domain}" is not a zone in your Cloudflare account.`,
      details: {
        zoneExists: false,
      },
    };
  }

  // Step 2: Check if domain is a custom domain on the Pages project
  const pagesResult = await checkPagesDomain(domain);

  if (!pagesResult.exists) {
    return {
      verified: false,
      method: "cloudflare_api",
      message: `Domain ownership verified (zone found), but it's not yet configured as a custom domain on your Pages project.`,
      details: {
        zoneExists: true,
        zoneStatus: zoneResult.status,
        pagesDomainExists: false,
      },
    };
  }

  // Both checks passed!
  const parts: string[] = [];
  if (zoneResult.status) parts.push(`Zone status: ${zoneResult.status}`);
  if (pagesResult.status) parts.push(`Pages status: ${pagesResult.status}`);

  return {
    verified: true,
    method: "cloudflare_api",
    message: `Domain verified via Cloudflare API. ${parts.join(", ")}.`,
    details: {
      zoneExists: true,
      zoneStatus: zoneResult.status,
      pagesDomainExists: true,
      pagesDomainStatus: pagesResult.status,
    },
  };
}

async function verifyViaDns(domain: string): Promise<VerificationResult> {
  try {
    // Check CNAME record
    const cnameRes = await fetch(
      `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=CNAME`
    );
    const cnameData = await cnameRes.json();

    if (cnameData.Answer && cnameData.Answer.length > 0) {
      const cnameTargets = cnameData.Answer.map((a: any) => a.data.toLowerCase());
      const isPagesCname = cnameTargets.some(
        (target: string) => target.endsWith(".pages.dev") || target.endsWith(".cfargotunnel.com")
      );

      if (isPagesCname) {
        return {
          verified: true,
          method: "dns_check",
          message: `CNAME points to ${cnameTargets[0]} (DNS check)`,
          details: { dnsCname: cnameTargets[0] },
        };
      }

      return {
        verified: false,
        method: "dns_check",
        message: `CNAME points to ${cnameTargets.join(", ")} which is not a *.pages.dev domain. Configure Cloudflare API for secure verification.`,
        details: { dnsCname: cnameTargets.join(", ") },
      };
    }

    // Check A records
    const aRes = await fetch(
      `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=A`
    );
    const aData = await aRes.json();

    if (aData.Answer && aData.Answer.length > 0) {
      const aRecords: string[] = aData.Answer.map((a: any) => a.data);
      const cfIpPrefixes = [
        "104.16.", "104.17.", "104.18.", "104.19.", "104.20.", "104.21.",
        "104.22.", "104.23.", "104.24.", "104.25.", "104.26.", "104.27.", "104.28.",
        "172.64.", "172.65.", "172.66.", "172.67.",
        "173.245.48.", "173.245.49.", "173.245.50.", "173.245.51.",
        "162.158.", "188.114.96.", "188.114.97.", "188.114.98.", "188.114.99.",
        "198.41.128.", "198.41.129.", "198.41.130.", "198.41.131.",
      ];

      const isCloudflareIp = aRecords.some((ip: string) =>
        cfIpPrefixes.some((prefix) => ip.startsWith(prefix))
      );

      if (isCloudflareIp) {
        return {
          verified: true,
          method: "dns_check",
          message: `A record resolves to Cloudflare IP (DNS check). Note: For secure ownership verification, configure CLOUDFLARE_API_TOKEN.`,
          details: { dnsARecords: aRecords },
        };
      }

      return {
        verified: false,
        method: "dns_check",
        message: `A record resolves to ${aRecords.join(", ")} which are not Cloudflare IPs.`,
        details: { dnsARecords: aRecords },
      };
    }

    return {
      verified: false,
      method: "dns_check",
      message: `No DNS records found for ${domain}. Add a CNAME record pointing to your *.pages.dev domain.`,
      details: {},
    };
  } catch (error) {
    return {
      verified: false,
      method: "none",
      message: "DNS lookup failed. Try again later or configure Cloudflare API for verification.",
      details: {},
    };
  }
}

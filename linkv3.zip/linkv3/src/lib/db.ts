/**
 * Database Client — Edge-Compatible (Cloudflare Workers / Pages)
 *
 * Uses @prisma/adapter-neon with @neondatabase/serverless for HTTP-based
 * PostgreSQL access. Works on both Node.js (local dev) and Cloudflare Workers.
 *
 * REQUIREMENTS:
 * - DATABASE_URL must be a PostgreSQL connection string (Neon recommended)
 * - For Cloudflare Pages: set DATABASE_URL in Environment Variables
 * - For local dev: set DATABASE_URL in .env.local
 *
 * Get a free Neon database at: https://console.neon.tech
 */

import { neon } from '@neondatabase/serverless';
import { PrismaNeon } from '@prisma/adapter-neon';
import { PrismaClient } from '@prisma/client';

function createPrismaClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL || '';

  if (!connectionString) {
    console.warn('[db] DATABASE_URL not set. Database operations will fail.');
    console.warn('[db] Set DATABASE_URL in .env.local (local) or Cloudflare Pages env vars (production).');
  }

  // neon() accepts any string and only fails on actual queries
  const sql = neon(connectionString);
  const adapter = new PrismaNeon(sql);

  return new PrismaClient({ adapter });
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db: PrismaClient = globalForPrisma.prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db;
}

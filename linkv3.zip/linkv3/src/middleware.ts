import { NextRequest, NextResponse } from "next/server";

// ─── Styled HTML 404 Page (matches redirect handler theme) ────────────────────

function htmlShortDomainRoot(host: string): string {
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Link Not Found</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #0a0a0a;
    color: #e5e5e5;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 1rem;
  }
  .container {
    text-align: center;
    max-width: 480px;
  }
  .icon {
    font-size: 4rem;
    margin-bottom: 1.5rem;
    opacity: 0.6;
  }
  h1 {
    font-size: 2rem;
    font-weight: 700;
    color: #fafafa;
    margin-bottom: 0.75rem;
  }
  p {
    font-size: 1rem;
    color: #a3a3a3;
    line-height: 1.6;
    margin-bottom: 1.5rem;
  }
  .badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    background: #1a1a2e;
    border: 1px solid #2a2a3e;
    border-radius: 9999px;
    font-size: 0.75rem;
    color: #737373;
    font-family: monospace;
  }
</style>
</head><body>
<div class="container">
  <div class="icon">&#128279;</div>
  <h1>No Short Link Provided</h1>
  <p>This is a short URL domain. Please provide a valid short link path to be redirected.</p>
  <span class="badge">404</span>
</div>
</body></html>`;
}

export function middleware(request: NextRequest) {
  // Read APP_DOMAIN inside the function (not at module level)
  // so it works correctly on Cloudflare Workers where env vars are bound at request time
  const appDomain = process.env.APP_DOMAIN || "";

  const host = request.headers.get("host") || "";
  const { pathname } = request.nextUrl;

  // Strip port for comparison (e.g., localhost:3000 → localhost)
  const hostname = host.split(":")[0];

  // 0. If APP_DOMAIN is not configured, bypass middleware entirely (local dev mode)
  if (!appDomain) {
    return NextResponse.next();
  }

  // 1. If host matches APP_DOMAIN → serve the dashboard normally
  if (hostname === appDomain || hostname.endsWith("." + appDomain)) {
    return NextResponse.next();
  }

  // 2. Host doesn't match APP_DOMAIN → treat as short domain request

  // Skip internal / framework paths
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/__nextjs") ||
    pathname.startsWith("/_vercel") ||
    pathname.startsWith("/_cloudflare") ||
    pathname.includes(".")
  ) {
    return NextResponse.next();
  }

  // Root path on short domain → return styled 404 page
  if (pathname === "/") {
    return new NextResponse(htmlShortDomainRoot(hostname), {
      status: 404,
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  }

  // Any other path on short domain → rewrite to /s[path] so it hits the redirect handler
  const rewriteUrl = request.nextUrl.clone();
  rewriteUrl.pathname = `/s${pathname}`;
  return NextResponse.rewrite(rewriteUrl);
}

export const config = {
  matcher: ["/:path*"],
};

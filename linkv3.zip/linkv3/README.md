# ShortURL - Link Management Platform

A Dub.co-inspired short URL management platform built with Next.js 16, deployed on **Cloudflare Pages** with **Neon PostgreSQL**. Supports multiple custom domains, multi-target routing, analytics, and bulk operations.

## Features

- **Multi-Domain Support** — Use multiple short URL domains (e.g., `short-a.link`, `short-b.link`) from a single dashboard
- **Secure Domain Verification** — Cloudflare API-based verification proves domain ownership (zone check + Pages custom domain check)
- **Auto-Configure** — One-click domain setup: automatically adds domain to Cloudflare Pages + verifies + activates
- **Basic & Multi-Target Links** — Single target, random routing, sequential load balancing, geo-targeting, IP-based targeting
- **Real-Time Analytics** — Click tracking with country, device, browser, OS, and referrer data from Cloudflare HTTP headers
- **Bulk Operations** — Create, delete, activate, deactivate, and migrate links in bulk
- **Password Protection** — Protect individual links with passwords
- **Link Expiration** — Set expiration dates on links
- **UTM Parameters** — Append UTM source/medium/campaign/content/term to redirects
- **Import/Export** — Bulk import and export links with all metadata
- **QR Codes** — Generate QR codes for any short link
- **Dark/Light Mode** — System-aware theme support

## Architecture

```
domain-a.com (Dashboard) ─────┐
                              │    Cloudflare Pages
short-a.link (Short URLs) ───┤──── Single Deployment
                              │
short-b.link (Short URLs) ───┘
```

- **Dashboard domain** (`APP_DOMAIN`): Serves the React admin dashboard
- **Short domains**: Automatically routed to the redirect handler via middleware
- **Routing**: `short-a.link/abc` → middleware detects short domain → rewrite to `/s/abc` → redirect handler looks up slug in database → 301 redirect to target URL
- **Database**: Neon PostgreSQL via `@prisma/adapter-neon` + `@neondatabase/serverless` (edge-compatible HTTP driver)
- **Deployment**: `@opennextjs/cloudflare` converts Next.js to Cloudflare Workers

## Prerequisites

- Node.js 18+ or Bun
- A [Neon](https://neon.tech) PostgreSQL database (free tier available)
- A [Cloudflare](https://cloudflare.com) account with Pages
- (Recommended) Cloudflare API token for automatic domain verification

---

## Installation & Setup

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd shorturl
bun install
```

### 2. Create Neon PostgreSQL Database

1. Go to [neon.tech](https://neon.tech) → Create Project
2. Copy the **connection string** from Connection Details
3. Format: `postgresql://user:password@ep-xxx.region.neon.tech/dbname?sslmode=require`

### 3. Configure Environment Variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
# [REQUIRED] Dashboard login password
DASHBOARD_TOKEN=your_secure_password_here

# [REQUIRED] Dashboard domain (leave empty for local dev)
APP_DOMAIN=

# [REQUIRED] Neon PostgreSQL connection string
DATABASE_URL=postgresql://user:pass@ep-xxx.region.neon.tech/dbname?sslmode=require
```

### 4. Initialize Database

```bash
# Generate Prisma client
bun run db:generate

# Push schema to database (creates tables)
DATABASE_URL="postgresql://user:pass@ep-xxx.region.neon.tech/dbname?sslmode=require" bun run db:push
```

> Alternatively, run the SQL migration manually: `prisma/migrations/0_init/migration.sql`

### 5. Run Development Server

```bash
bun run dev
```

Open `http://localhost:3000` and login with your `DASHBOARD_TOKEN`.

---

## Production Deployment (Cloudflare Pages)

### Step 1: Push Code to GitHub

```bash
git add .
git commit -m "Deploy to Cloudflare Pages"
git push origin main
```

### Step 2: Create Cloudflare Pages Project

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → Workers & Pages → Create
2. Connect your GitHub repository
3. **Build settings:**

| Setting | Value |
|---------|-------|
| Framework preset | Next.js (Static) |
| Build command | `npx prisma generate && opennextjs-cloudflare build` |
| Build output directory | `.open-next` |

> **Note:** If using Bun, change the build command to:
> `npx prisma generate && bunx opennextjs-cloudflare build`

### Step 3: Add Custom Domain for Dashboard

1. In your Pages project → **Custom domains** → Add your dashboard domain (e.g., `domain-a.com`)
2. Cloudflare will auto-configure DNS (CNAME record)

### Step 4: Configure Environment Variables

In Pages project → **Settings** → **Environment variables** → **Add**:

| Variable | Required | Example |
|----------|----------|---------|
| `DASHBOARD_TOKEN` | **Yes** | `your_secure_password` |
| `APP_DOMAIN` | **Yes** | `domain-a.com` |
| `DATABASE_URL` | **Yes** | `postgresql://user:pass@ep-xxx.neon.tech/dbname?sslmode=require` |
| `CLOUDFLARE_API_TOKEN` | Recommended | (see Step 5) |
| `CLOUDFLARE_ACCOUNT_ID` | Recommended | `abc123def456` |
| `CLOUDFLARE_PAGES_PROJECT` | Recommended | `my-shorturl-project` |

### Step 5: Create Cloudflare API Token (Recommended)

Required for automatic domain verification and auto-configure:

1. Go to [API Tokens](https://dash.cloudflare.com/profile/api-tokens) → **Create Token** → **Custom token**
2. Permissions:
   - Account → Cloudflare Pages → **Edit**
   - Zone → Zone → **Read**
   - Zone → DNS → **Edit**
3. Account Resources: Include → Your account
4. Zone Resources: Include → All zones (or specific zones)
5. Create and copy the token → Set as `CLOUDFLARE_API_TOKEN`

### Step 6: Add Short URL Domains

After deployment, go to your dashboard (`domain-a.com`):

**Method A: Auto-Configure (with Cloudflare API token)**
1. Dashboard → Domains → Add Domain
2. Enter domain (e.g., `short-a.link`) → Enable "Auto-configure" → Add & Auto-Configure
3. System automatically: adds to Pages, verifies ownership, activates domain

**Method B: Manual**
1. Dashboard → Domains → Add Domain (enter domain name)
2. Go to Cloudflare Dashboard → Workers & Pages → Your Project → Custom domains → Add domain
3. Back to Dashboard → Domains → Click **Verify** → Domain auto-activates on success

### Important: All Domains Must Use Same Cloudflare Account

All short URL domains must have their **nameservers pointing to the same Cloudflare account** as your Pages project. The verification system checks that the domain exists as a Zone in YOUR account — this proves ownership.

---

## Domain Verification & Rules

| Rule | Description |
|------|-------------|
| New domains start as Inactive & Unverified | Security default |
| Must verify before activating | Prevents random domains from being used |
| Verification = Zone + Pages check | Proves both ownership AND connectivity |
| Verification auto-activates | On successful verify, domain is automatically activated |
| Renaming resets verification | New domain needs re-verification |
| Deleting removes from Pages | API automatically cleans up custom domain |

---

## Link Routing Strategies

| Strategy | Description |
|----------|-------------|
| Basic | Single target URL |
| Random | Randomly selects one target |
| Sequential | Routes to target with lowest click count (load balancing) |
| Country-based | Routes based on `CF-IPCountry` header |
| IP-based | Routes based on visitor's IP address |

Priority order: IP match → Country match → ALL targets (random/sequential)

---

## Analytics Data Source

Collected from **Cloudflare HTTP headers** (no external services needed):

| Data | Header |
|------|--------|
| Country | `CF-IPCountry` |
| IP Address | `CF-Connecting-IP` |
| Device/Browser/OS | Parsed from `User-Agent` |
| Referrer | `Referer` |

---

## Project Structure

```
src/
├── app/
│   ├── api/                    # API routes (edge-compatible)
│   ├── s/[slug]/route.ts       # Catch-all redirect handler
│   ├── page.tsx                # Dashboard SPA
│   └── layout.tsx              # Root layout
├── components/
│   ├── domains/                # Domain management UI
│   ├── links/                  # Link management UI
│   ├── analytics/              # Charts and stats
│   ├── dashboard/              # Dashboard layout + sidebar
│   └── ui/                     # shadcn/ui components
├── lib/
│   ├── cloudflare.ts           # Cloudflare API integration
│   ├── db.ts                   # Prisma + Neon adapter (edge)
│   ├── auth.ts                 # Dashboard authentication
│   ├── api.ts                  # Frontend API client
│   ├── store.ts                # Zustand state
│   └── types.ts                # TypeScript types
├── middleware.ts               # Domain routing middleware
├── prisma/
│   ├── schema.prisma           # PostgreSQL schema
│   └── migrations/             # SQL migrations
├── open-next.config.ts         # @opennextjs/cloudflare config
├── wrangler.toml               # Cloudflare Worker config
└── .env.example                # Environment variable template
```

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Framework | Next.js 16 (App Router) |
| Runtime | Cloudflare Workers (via @opennextjs/cloudflare) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui |
| Database | Neon PostgreSQL |
| ORM | Prisma + @prisma/adapter-neon |
| Charts | Recharts |
| State | Zustand |
| Icons | Lucide React |

---

## Troubleshooting

### 404 on Cloudflare Pages after deployment

**Cause**: Wrong build configuration. This project uses `@opennextjs/cloudflare`, not `next build --standalone`.

**Fix**: Ensure your build command is `opennextjs-cloudflare build` and output directory is `.open-next`.

### Database connection errors

**Cause**: `DATABASE_URL` is not set or uses the wrong format.

**Fix**: Set `DATABASE_URL` to your Neon PostgreSQL connection string with `?sslmode=require`.

### Domain verification fails

**Cause**: Domain nameservers don't point to your Cloudflare account, or API token is missing/wrong permissions.

**Fix**: 
1. Check nameservers at your domain registrar
2. Verify `CLOUDFLARE_API_TOKEN` has Zone:Read + Pages:Edit permissions
3. Ensure the domain is in the SAME Cloudflare account as your Pages project

### Middleware not routing short domains

**Cause**: `APP_DOMAIN` is not set in environment variables.

**Fix**: Set `APP_DOMAIN` to your dashboard domain (e.g., `domain-a.com`). Leave empty for local development.

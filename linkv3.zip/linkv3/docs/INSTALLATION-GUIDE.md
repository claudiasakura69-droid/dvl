# Panduan Instalasi & Deployment — ShortURL Platform

> Platform manajemen ShortURL (clone Dub.co) yang dibangun dengan **Next.js 16 + Prisma + TypeScript + Tailwind CSS + shadcn/ui**.
>
> Panduan ini ditulis dalam Bahasa Indonesia dengan istilah teknis dalam bahasa Inggris untuk kemudahan referensi.

---

## Daftar Isi (Table of Contents)

1. [Prasyarat (Prerequisites)](#1-prasyarat-prerequisites)
2. [Instalasi Lokal (Local Installation)](#2-instalasi-lokal-local-installation)
3. [Setup Database — Neon Tech (PostgreSQL)](#3-setup-database--neon-tech-postgresql)
4. [Setup Database — TiDB (Alternatif)](#4-setup-database--tidb-alternatif)
5. [Push ke GitHub](#5-push-ke-github)
6. [Deploy ke Cloudflare Pages](#6-deploy-ke-cloudflare-pages)
7. [Konfigurasi Environment Variables](#7-konfigurasi-environment-variables)
8. [Setup Custom Domain untuk Short URL](#8-setup-custom-domain-untuk-short-url)
9. [Migrasi Domain](#9-migrasi-domain)
10. [Troubleshooting](#10-troubleshooting)
11. [Appendix: Contoh .env.example](#11-appendix-contoh-envexample)

---

## 1. Prasyarat (Prerequisites)

Sebelum memulai instalasi, pastikan kamu sudah memenuhi prasyarat berikut:

### Software yang Diperlukan

| Software      | Versi Minimum | Keterangan                                  |
|---------------|---------------|---------------------------------------------|
| **Node.js**   | 18+           | Runtime JavaScript                         |
| **Bun**       | Latest        | Runtime & package manager (alternatif npm)  |
| **Git**       | 2.30+         | Version control                            |
| **npm** / **yarn** / **pnpm** | —  | Bun menjadi pilihan utama di project ini |

### Akun yang Diperlukan

| Layanan         | URL                       | Keterangan                                    |
|-----------------|---------------------------|-----------------------------------------------|
| **GitHub**      | https://github.com        | Untuk source code repository                  |
| **Cloudflare**  | https://dash.cloudflare.com | Untuk deployment & custom domain            |
| **Neon Tech**   | https://neon.tech         | Database PostgreSQL serverless (rekomendasi)  |
| **TiDB Cloud**  | https://tidbcloud.com     | Alternatif database (opsional)               |

### Install Bun (jika belum ada)

```bash
# macOS / Linux
curl -fsSL https://bun.sh/install | bash

# Verifikasi instalasi
bun --version
```

### Install Node.js (jika belum ada)

```bash
# Menggunakan nvm (Node Version Manager)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 18
nvm use 18

# Verifikasi
node --version
npm --version
```

### Install Git (jika belum ada)

```bash
# Ubuntu / Debian
sudo apt update && sudo apt install git

# macOS (via Homebrew)
brew install git

# Verifikasi
git --version
```

---

## 2. Instalasi Lokal (Local Installation)

Ikuti langkah-langkah berikut untuk menjalankan project secara lokal di komputer kamu.

### Step 2.1 — Clone Repository

```bash
# Clone dari GitHub (setelah push, lihat Section 5)
git clone https://github.com/username/shorturl-platform.git

# Masuk ke direktori project
cd shorturl-platform
```

> **Note:** Jika belum push ke GitHub, kamu bisa langsung bekerja di direktori project yang sudah ada.

### Step 2.2 — Install Dependencies

```bash
# Menggunakan Bun (direkomendasikan)
bun install

# Atau menggunakan npm
npm install

# Atau menggunakan pnpm
pnpm install
```

Proses ini akan menginstall semua dependencies yang terdaftar di `package.json`, termasuk:

- **Next.js 16** — Framework React fullstack
- **Prisma** — ORM untuk database
- **shadcn/ui** — Component library
- **Recharts** — Library untuk chart/visualisasi
- **Zustand** — State management
- **next-themes** — Dark/light mode support
- **qrcode** — QR code generation

### Step 2.3 — Setup Environment Variables

```bash
# Copy file .env.example ke .env
cp .env.example .env

# Edit file .env sesuai konfigurasi kamu
nano .env
# atau
code .env
# atau
vim .env
```

Pastikan file `.env` berisi minimal konfigurasi berikut:

```env
# Database — untuk development lokal (SQLite)
DATABASE_URL="file:./db/custom.db"

# Token autentikasi dashboard (minimal 12 karakter)
DASHBOARD_TOKEN="Master123@"

# URL aplikasi (untuk development lokal)
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

### Step 2.4 — Setup Database

```bash
# Push schema ke database (membuat tabel berdasarkan prisma/schema.prisma)
bun run db:push

# Generate Prisma Client (diperlukan agar bisa import @prisma/client)
bun run db:generate
```

> **Penjelasan:**
> - `db:push` → Membaca `prisma/schema.prisma` dan membuat/memperbarui tabel di database tanpa membuat migration file.
> - `db:generate` → Menghasilkan Prisma Client di `node_modules/.prisma/client` berdasarkan schema.

**File `prisma/schema.prisma` berisi 4 model utama:**

| Model         | Tabel Database   | Deskripsi                            |
|---------------|------------------|--------------------------------------|
| `AppSetting`  | `app_settings`   | Pengaturan aplikasi (key-value)      |
| `ShortDomain` | `short_domains`  | Domain yang digunakan untuk short URL |
| `ShortLink`   | `short_links`    | Link pendek dengan metadata lengkap  |
| `LinkTarget`  | `link_targets`   | Target URL untuk multi-target routing |
| `Click`       | `clicks`         | Data klik/analytics per pengunjung   |

### Step 2.5 — Jalankan Development Server

```bash
# Jalankan Next.js development server di port 3000
bun run dev
```

Buka browser dan akses:
- **Dashboard:** http://localhost:3000
- **Login:** Masukkan token dari `DASHBOARD_TOKEN` (default: `Master123@`)

### Step 2.6 — Verifikasi Instalasi

Setelah server berjalan, verifikasi:

- [ ] Dashboard berhasil dimuat di http://localhost:3000
- [ ] Login dengan token berhasil
- [ ] Halaman Overview menampilkan statistik
- [ ] Bisa membuat link baru di halaman Links
- [ ] Short URL redirect berfungsi

---

## 3. Setup Database — Neon Tech (PostgreSQL)

Neon Tech menyediakan PostgreSQL serverless yang **gratis** untuk penggunaan dasar. Ini adalah rekomendasi utama untuk database production.

### Step 3.1 — Buat Akun Neon

1. Buka **https://neon.tech**
2. Klik tombol **Sign Up**
3. Pilih salah satu metode registrasi:
   - **GitHub** (direkomendasikan, 1 klik)
   - **Google**
   - **Email & Password**

### Step 3.2 — Buat Project Baru

1. Setelah login, klik **"Create a project"**
2. Isi konfigurasi project:

   | Field               | Value yang Disarankan                      |
   |---------------------|--------------------------------------------|
   | **Project name**    | `shorturl-db`                              |
   | **Region**          | `AWS Asia Pacific (Singapore) — ap-southeast-1` |
   | **PostgreSQL version** | Default (16) — biarkan sesuai default     |
   | **Branch name**     | `main` — biarkan default                   |

3. Klik **"Create project"**
4. Tunggu proses provisioning (~10-20 detik)

### Step 3.3 — Dapatkan Connection String

1. Setelah project dibuat, Neon akan menampilkan halaman dashboard
2. Klik tab **"Connection details"** atau look di sidebar
3. Salin **connection string** yang formatnya seperti:

```
postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
```

### Step 3.4 — Update Konfigurasi Project

**a) Update file `.env`:**

```env
# Ganti DATABASE_URL dari SQLite ke PostgreSQL Neon
DATABASE_URL="postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"
```

**b) Update `prisma/schema.prisma`:**

Ubah provider database dari `sqlite` ke `postgresql`:

```prisma
// SEBELUM (development lokal dengan SQLite)
datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

// SESUDAH (production dengan PostgreSQL Neon)
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

> **PENTING:** Jangan lupa juga menghapus baris `@default(cuid())` jika ada masalah kompatibilitas, atau pastikan menggunakan `@default(uuid())` atau `@default(cuid())` yang kompatibel dengan PostgreSQL. CUID umumnya kompatibel dengan PostgreSQL.

### Step 3.5 — Push Schema ke Database Neon

```bash
# Push schema (membuat tabel di PostgreSQL Neon)
bun run db:push

# Generate ulang Prisma Client
bun run db:generate
```

### Step 3.6 — Verifikasi Koneksi Database

```bash
# Test koneksi database
bunx prisma db execute --stdin <<< "SELECT 1 as test;"

# Atau gunakan Prisma Studio untuk melihat data
bunx prisma studio
```

Jika berhasil, Prisma Studio akan terbuka di http://localhost:5555 dan kamu bisa melihat semua tabel.

### Tips Neon Tech

| Tips | Deskripsi |
|------|-----------|
| **Auto-suspend** | Database Neon otomatis suspend setelah idle. Request pertama akan sedikit lebih lambat (~1-2 detik). |
| **Connection pooling** | Gunakan pooled connection string (port 6543) untuk production agar lebih efisien. |
| **Branching** | Neon mendukung database branching untuk development/testing. |
| **Free tier** | 0.5 GiB storage, 1 project, auto-suspend. Cukup untuk project kecil-menengah. |

---

## 4. Setup Database — TiDB (Alternatif)

TiDB adalah database SQL yang kompatibel dengan MySQL dan mendukung fitur NoSQL. TiDB Cloud menyediakan tier serverless yang gratis.

### Step 4.1 — Buat Akun TiDB Cloud

1. Buka **https://tidbcloud.com**
2. Klik **"Sign Up"** atau **"Start Free"**
3. Daftar menggunakan:
   - **Google**
   - **GitHub**
   - **Email & Password**

### Step 4.2 — Buat Cluster Serverless

1. Setelah login, klik **"Create Cluster"**
2. Pilih **Serverless Tier** (gratis)
3. Isi konfigurasi:

   | Field               | Value yang Disarakan                      |
   |---------------------|--------------------------------------------|
   | **Cluster name**    | `shorturl-db`                              |
   | **Region**          | `AWS ap-southeast-1 (Singapore)`           |
   | **Create password** | Buat password yang kuat & catat di tempat aman |

4. Klik **"Create"**
5. Tunggu provisioning (~2-5 menit)

### Step 4.3 — Dapatkan Connection String

1. Setelah cluster aktif, buka halaman cluster
2. Klik **"Connect"** di sidebar
3. Pilih **"General"** tab
4. Salin connection string. Formatnya seperti:

```
mysql://root:xxxxxxxxxxxx@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?ssl={"rejectUnauthorized":true}
```

### Step 4.4 — Update Konfigurasi Project

> **Catatan Penting:** TiDB menggunakan protokol MySQL, bukan PostgreSQL. Kamu perlu menyesuaikan Prisma provider.

**a) Update file `.env`:**

```env
# Untuk TiDB (MySQL-compatible)
DATABASE_URL="mysql://root:xxxxxxxxxxxx@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?sslaccept=strict"
```

**b) Update `prisma/schema.prisma`:**

```prisma
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}
```

**c) Push schema dan generate client:**

```bash
bun run db:push
bun run db:generate
```

### Step 4.5 — Catatan Penting untuk TiDB

| Catatan | Deskripsi |
|---------|-----------|
| **MySQL Compatibility** | TiDB menggunakan dialect MySQL, bukan PostgreSQL. Pastikan query Prisma kompatibel. |
| **SSL Required** | TiDB Cloud mengharuskan SSL connection. Pastikan `sslaccept=strict` ada di connection string. |
| **Free tier limits** | 1 cluster serverless, 5 GiB storage, 50 million row reads/bulan. |
| **Latency** | Untuk pengguna di Indonesia, region Singapore memberikan latensi terbaik. |

---

## 5. Push ke GitHub

Menyimpan source code ke GitHub memudahkan kolaborasi, backup, dan integrasi dengan layanan deployment seperti Cloudflare Pages.

### Step 5.1 — Pastikan .gitignore Sudah Benar

Pastikan file berikut ada di `.gitignore` (seharusnya sudah ada dari Next.js template):

```gitignore
# Dependencies
node_modules/
.pnp
.pnp.js

# Next.js
.next/
out/

# Production
build/
dist/

# Misc
.DS_Store
*.pem

# Debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Local env files
.env
.env*.local

# Vercel
.vercel

# TypeScript
*.tsbuildinfo
next-env.d.ts

# Database
db/*.db
db/*.db-journal

# Prisma
prisma/migrations/

# IDE
.vscode/
.idea/

# Logs
*.log
dev.log
server.log
```

### Step 5.2 — Inisialisasi Git & Commit

```bash
# Inisialisasi git repository (jika belum ada)
git init

# Tambahkan semua file ke staging
git add .

# Buat commit pertama
git commit -m "Initial commit: ShortURL Platform (Dub.co clone) - Next.js 16 + Prisma + TypeScript"
```

### Step 5.3 — Buat Repository di GitHub

#### Opsi A: Menggunakan GitHub Web UI

1. Buka **https://github.com/new**
2. Isi form:
   - **Repository name:** `shorturl-platform`
   - **Description:** "Short URL Management Platform — Dub.co Clone built with Next.js 16 + Prisma"
   - **Visibility:** `Private` (direkomendasikan) atau `Public`
   - **JANGAN centang** "Add a README", "Add .gitignore", "Choose a license" (karena sudah ada)
3. Klik **"Create repository"**
4. Ikuti instruksi di halaman untuk push existing repository

#### Opsi B: Menggunakan GitHub CLI (`gh`)

```bash
# Install GitHub CLI jika belum ada
# macOS
brew install gh

# Ubuntu/Debian
sudo apt install gh

# Login ke GitHub
gh auth login

# Buat repository dan push sekaligus
gh repo create shorturl-platform --private --source=. --push
```

### Step 5.4 — Push ke GitHub

```bash
# Tambahkan remote origin (opsional jika menggunakan gh repo create)
git remote add origin https://github.com/username/shorturl-platform.git

# Set branch utama ke main
git branch -M main

# Push ke GitHub
git push -u origin main
```

### Step 5.5 — Verifikasi

- [ ] Repository berhasil dibuat di GitHub
- [ ] Semua file ter-upload
- [ ] `.env` TIDAK ter-upload (cek di GitHub, file ini harus ada di .gitignore)

---

## 6. Deploy ke Cloudflare Pages

Cloudflare Pages mendukung deployment Next.js langsung dari repository GitHub dengan CI/CD otomatis.

### Step 6.1 — Persiapan Build

Sebelum deploy, pastikan project bisa build dengan sukses secara lokal:

```bash
# Build project
bun run build
```

Jika build berhasil, lanjutkan ke langkah deployment.

### Step 6.2 — Deploy via Cloudflare Dashboard

#### Langkah 1: Login ke Cloudflare

1. Buka **https://dash.cloudflare.com**
2. Login menggunakan akun Cloudflare kamu

#### Langkah 2: Buat Project Pages Baru

1. Di sidebar kiri, klik **"Workers & Pages"**
2. Klik tombol **"Create"** (atau "Create application")
3. Pilih tab **"Pages"**
4. Klik **"Connect to Git"**

#### Langkah 3: Hubungkan Repository GitHub

1. Pilih **GitHub** sebagai Git provider
2. Klik **"Connect GitHub"** dan authorize Cloudflare
3. Pilih repository **`shorturl-platform`** dari daftar

#### Langkah 4: Konfigurasi Build

Isi konfigurasi build sebagai berikut:

| Setting                    | Value                                           |
|---------------------------|-------------------------------------------------|
| **Project name**          | `shorturl-platform` (atau nama yang kamu inginkan) |
| **Production branch**     | `main`                                          |
| **Framework preset**      | `Next.js (Static)` atau `None`                  |
| **Build command**         | `npx @cloudflare/next-on-pages`                 |
| **Build output directory**| `.vercel/output/static`                         |

> **Catatan:** Jika menggunakan preset Next.js, beberapa setting mungkin sudah otomatis terisi.

#### Langkah 5: Environment Variables (Build Time)

Tambahkan environment variables yang dibutuhkan saat build (lihat **Section 7** untuk detail lengkap):

| Variable            | Value                               |
|---------------------|-------------------------------------|
| `DATABASE_URL`      | Connection string Neon/TiDB kamu    |
| `DASHBOARD_TOKEN`   | Token rahasia kamu                  |

#### Langkah 6: Deploy

1. Klik **"Save and Deploy"**
2. Tunggu proses build (biasanya 2-5 menit untuk pertama kali)
3. Jika berhasil, kamu akan mendapatkan URL:
   ```
   https://shorturl-platform.pages.dev
   ```

### Step 6.3 — Deploy via Wrangler CLI (Alternatif)

Jika lebih suka menggunakan command line:

```bash
# Install Wrangler CLI secara global
npm install -g wrangler

# Login ke Cloudflare
wrangler login

# Build project terlebih dahulu
bun run build
npx @cloudflare/next-on-pages

# Deploy ke Cloudflare Pages
wrangler pages deploy .vercel/output/static --project-name=shorturl-platform

# Untuk deploy ke branch production
wrangler pages deploy .vercel/output/static --project-name=shorturl-platform --branch=main
```

### Step 6.4 — Auto-Deploy Setup

Setelah pertama kali deploy via dashboard, setiap push ke branch `main` akan otomatis trigger re-deploy:

```bash
# Buat perubahan kode
git add .
git commit -m "feat: update short URL logic"
git push origin main

# Cloudflare Pages akan otomatis build & deploy
```

### Step 6.5 — Preview Deployments

Cloudflare Pages juga membuat preview deployment untuk setiap pull request:

1. Buat branch baru: `git checkout -b feature/new-feature`
2. Push ke GitHub: `git push origin feature/new-feature`
3. Buat Pull Request di GitHub
4. Cloudflare akan otomatis membuat preview URL seperti:
   ```
   https://abc123.shorturl-platform.pages.dev
   ```

---

## 7. Konfigurasi Environment Variables

Environment variables adalah konfigurasi penting yang harus diatur di setiap environment (development, production).

### Daftar Environment Variables

| Variable                | Required | Deskripsi                                  | Contoh                                |
|-------------------------|----------|--------------------------------------------|---------------------------------------|
| `DATABASE_URL`          | ✅ Ya    | Connection string database                | `postgresql://user:pass@host/db?sslmode=require` |
| `DASHBOARD_TOKEN`       | ✅ Ya    | Token autentikasi untuk login dashboard    | `Master123@` (min. 12 karakter)      |
| `NEXT_PUBLIC_APP_URL`   | ✅ Ya    | URL publik aplikasi                       | `https://shorturl.example.com`        |
| `NODE_ENV`              | Opsional | Environment mode                          | `production` / `development`          |

### Konfigurasi di Cloudflare Pages Dashboard

1. Buka **https://dash.cloudflare.com**
2. Pergi ke **Workers & Pages** → pilih project kamu
3. Klik **Settings** → **Environment variables**
4. Klik **Add variables**
5. Tambahkan variables berikut:

#### Production Environment

| Variable                | Value                                           |
|-------------------------|-------------------------------------------------|
| `DATABASE_URL`          | `postgresql://neondb_owner:xxx@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN`       | `Master123@` (ganti dengan token yang kuat!)    |
| `NEXT_PUBLIC_APP_URL`   | `https://shorturl-platform.pages.dev`           |

#### Preview Environment (untuk PR preview)

| Variable                | Value                                           |
|-------------------------|-------------------------------------------------|
| `DATABASE_URL`          | (sama dengan production, atau gunakan DB staging) |
| `DASHBOARD_TOKEN`       | `Master123@`                                    |
| `NEXT_PUBLIC_APP_URL`   | `https://abc123.shorturl-platform.pages.dev`    |

### Keamanan Token

> ⚠️ **PERINGATAN KEAMANAN:**

- **Jangan** pernah commit file `.env` ke Git
- **Jangan** gunakan token default `Master123@` di production
- Buat token yang kuat: minimal 12 karakter, kombinasi huruf besar, kecil, angka, dan simbol
- Gunakan password generator: `openssl rand -base64 24`

```bash
# Contoh generate token yang kuat
openssl rand -base64 24
# Output: xK9#mP2$vL5&nQ8@wR3!tY7*hJ
```

---

## 8. Setup Custom Domain untuk Short URL

Platform ini mendukung penggunaan domain khusus untuk short URL, misalnya:
- `go.example.com/abc` → redirect ke target URL
- `link.example.com/promo` → redirect ke landing page

### Step 8.1 — Tambahkan Domain ke Cloudflare

1. Login ke **https://dash.cloudflare.com**
2. Klik **"Add a site"** di sidebar
3. Masukkan nama domain kamu (contoh: `example.com`)
4. Pilih plan (**Free** sudah cukup)
5. Cloudflare akan menampilkan **2 NS records** (nameservers)
6. Login ke registrar domain kamu (Namecheap, GoDaddy, dll.)
7. **Ubah nameserver** domain ke nameserver Cloudflare:
   ```
   ns1.cloudflare.com
   ns2.cloudflare.com
   ```
8. Tunggu propagasi DNS (bisa memakan waktu 15 menit - 48 jam)

### Step 8.2 — Setup DNS Records

Setelah domain aktif di Cloudflare, tambahkan DNS records:

#### Opsi A: Root Domain (example.com)

| Type  | Name | Target                          | Proxy   | TTL  |
|-------|------|---------------------------------|---------|------|
| CNAME | @    | `shorturl-platform.pages.dev`   | Proxied | Auto |

#### Opsi B: Subdomain (go.example.com atau link.example.com)

| Type  | Name | Target                          | Proxy   | TTL  |
|-------|------|---------------------------------|---------|------|
| CNAME | go   | `shorturl-platform.pages.dev`   | Proxied | Auto |

> **Catatan:** Pastikan proxy status berwarna **oranye (Proxied)**, bukan abu-abu (DNS only). Ini diperlukan untuk fitur Cloudflare seperti SSL, DDoS protection, dll.

### Step 8.3 — Tambahkan Custom Domain di Pages Project

1. Di Cloudflare dashboard, buka **Workers & Pages** → pilih project
2. Klik **Custom domains**
3. Klik **"Set up a custom domain"**
4. Masukkan domain (contoh: `go.example.com`)
5. Klik **"Continue"**
6. Pilih **"Activate domain"**
7. Tunggu SSL certificate provisioning (biasanya ~15 menit)

### Step 8.4 — Tambahkan Domain di Dashboard ShortURL

1. Login ke dashboard ShortURL kamu
2. Pergi ke menu **Domains**
3. Klik **"Add Domain"**
4. Isi form:

   | Field            | Value                   |
   |------------------|-------------------------|
   | **Domain**       | `go.example.com`        |
   | **Slug**         | `go` (opsional)         |
   | **Active**       | ✅ Centang              |

5. Klik **Save**
6. Domain akan muncul di daftar domain

### Step 8.5 — Verifikasi Domain

1. Di halaman Domains, klik icon **verify** pada domain yang baru ditambahkan
2. Sistem akan memeriksa apakah DNS sudah terkonfigurasi dengan benar
3. Jika berhasil, status akan berubah menjadi **"Verified"** ✅

### Step 8.6 — Mulai Gunakan Short URL dengan Custom Domain

Sekarang kamu bisa membuat link baru dan memilih custom domain:

1. Pergi ke menu **Links** → **Create Link**
2. Di form, pilih domain `go.example.com`
3. Masukkan slug (contoh: `promo`)
4. Masukkan destination URL
5. Save

Short URL: `https://go.example.com/promo` → akan redirect ke destination URL

---

## 9. Migrasi Domain

Migrasi domain berguna ketika kamu ingin memindahkan semua link dari satu domain ke domain lain. Misalnya, pindah dari `go.example.com` ke `link.example.com`.

### Step 9.1 — Buka Bulk Operations

1. Login ke dashboard ShortURL
2. Pergi ke menu **Bulk Operations**

### Step 9.2 — Pilih Operasi "Change Domain"

1. Di bagian **"Change Domain"**, kamu akan melihat dua dropdown:
   - **Domain Asal** (Source Domain) — domain yang ingin ditinggalkan
   - **Domain Tujuan** (Target Domain) — domain yang baru

2. Pilih domain asal dan domain tujuan

### Step 9.3 — Review & Apply

1. Klik tombol **"Preview Changes"** (jika tersedia)
2. Sistem akan menampilkan:
   - Jumlah link yang akan dipindahkan
   - Daftar slug yang berpotensi konflik
   - Konfirmasi perubahan

3. Klik **"Apply"** untuk memproses migrasi

### Step 9.4 — Penanganan Konflik Slug

Jika ada slug yang sudah digunakan di domain tujuan:

- **Opsi 1: Skip** — Link yang konflik tidak akan dipindahkan
- **Opsi 2: Overwrite** — Link lama di domain tujuan akan dihapus dan diganti
- **Opsi 3: Rename** — Slug akan diberi suffix otomatis (contoh: `promo-2`)

### Step 9.5 — Verifikasi Migrasi

Setelah migrasi selesai:

- [ ] Cek halaman **Links** — pastikan domain sudah berubah
- [ ] Test beberapa short URL di domain baru — pastikan redirect berfungsi
- [ ] Cek halaman **Analytics** — data klik tetap tersimpan

### Step 9.6 — Tips Migrasi

| Tips | Deskripsi |
|------|-----------|
| **Backup dulu** | Selalu export data via Settings > Export sebelum migrasi |
| **Test dulu** | Buat beberapa link test di domain tujuan sebelum migrasi besar |
| **DNS overlap** | Pastikan DNS kedua domain sudah aktif sebelum migrasi |
| **Monitoring** | Setelah migrasi, pantau analytics untuk memastikan redirect berfungsi |

---

## 10. Troubleshooting

Berikut adalah masalah umum yang mungkin dihadapi beserta solusinya.

### 10.1 — Database Connection Error

**Gejala:**
```
Error: P1001 - Can't reach database server
```
atau
```
Error: P3009 - migrate found failed migrations
```

**Solusi:**

```bash
# 1. Periksa koneksi internet
ping neon.tech

# 2. Periksa DATABASE_URL di .env
# Pastikan formatnya benar:
# postgresql://user:password@host/database?sslmode=require

# 3. Test koneksi manual
bunx prisma db execute --stdin <<< "SELECT 1;"

# 4. Jika menggunakan Neon, coba reset connection:
# Buka dashboard Neon > click "Reset password" pada role

# 5. Pastikan provider di prisma/schema.prisma sesuai
# PostgreSQL → provider = "postgresql"
# MySQL/TiDB → provider = "mysql"
# SQLite → provider = "sqlite"
```

**Untuk Neon khususnya:**

| Masalah | Solusi |
|---------|--------|
| `sslmode=require` error | Pastikan `?sslmode=require` ada di URL |
| Connection timeout | Neon auto-suspend, request pertama lambat. Tunggu dan coba lagi |
| `P1001` repeatedly | Cek apakah IP address di-block. Neon biasanya allow all |

### 10.2 — Build Failure di Cloudflare Pages

**Gejala:**
```
Error during build: Exit code 1
```

**Solusi:**

```bash
# 1. Build locally dulu untuk cek error
bun run build

# 2. Pastikan semua dependencies terinstall
rm -rf node_modules bun.lock
bun install

# 3. Pastikan Prisma Client ter-generate
bun run db:generate

# 4. Cek TypeScript errors
npx tsc --noEmit

# 5. Cek next.config.ts - pastikan tidak ada konfigurasi yang konflik
```

**Cloudflare-specific issues:**

| Masalah | Solusi |
|---------|--------|
| Build command salah | Gunakan `npx @cloudflare/next-on-pages` |
| Output directory salah | Set ke `.vercel/output/static` |
| Runtime error `Node.js` | Pastikan `NODE_ENV=production` di env vars |
| Middleware tidak kompatibel | Cloudflare Pages tidak support semua Next.js middleware. Cek compatibility. |

### 10.3 — Domain Tidak Resolve

**Gejala:**
- Custom domain menampilkan `ERR_NAME_NOT_RESOLVED`
- SSL certificate error

**Solusi:**

```bash
# 1. Cek DNS propagation
dig go.example.com
# atau
nslookup go.example.com

# 2. Pastikan CNAME record sudah benar di Cloudflare
# CNAME → project-name.pages.dev

# 3. Pastikan nameserver domain sudah diarahkan ke Cloudflare
# ns1.cloudflare.com
# ns2.cloudflare.com

# 4. Tunggu propagasi DNS (bisa 15 menit - 48 jam)
```

**Checklist DNS:**

- [ ] Nameserver domain sudah diarahkan ke Cloudflare
- [ ] CNAME record sudah dibuat di Cloudflare DNS
- [ ] Proxy status = Proxied (oranye)
- [ ] Custom domain sudah ditambahkan di Pages project
- [ ] SSL certificate sudah aktif (tunggu ~15 menit)

### 10.4 — Link Tidak Redirect

**Gejala:**
- Short URL menampilkan 404
- Short URL tidak redirect ke target

**Solusi:**

```bash
# 1. Cek apakah link aktif di database
bunx prisma studio
# Buka tabel short_links, cek field isActive = true

# 2. Cek apakah domain sudah terdaftar & aktif
# Di dashboard > Domains, pastikan domain active & verified

# 3. Cek route handler
# Pastikan /api/redirect berfungsi:
curl -I https://your-domain.pages.dev/api/redirect?slug=test-slug

# 4. Cek logs di Cloudflare Pages
# Dashboard > Workers & Pages > project > Logs > Real-time logs
```

**Common causes:**

| Penyebab | Solusi |
|----------|--------|
| `isActive = false` | Aktifkan link di dashboard atau update via Prisma |
| Domain tidak terdaftar | Tambahkan domain di menu Domains |
| Slug duplikat | Pastikan kombinasi slug + domainId unik |
| Target tidak sehat | Cek health target URL di halaman Links |

### 10.5 — Login / Auth Error

**Gejala:**
- Token diterima tapi dashboard tidak dimuat
- "Unauthorized" error

**Solusi:**

```bash
# 1. Pastikan DASHBOARD_TOKEN sama antara .env dan yang diinput
echo $DASHBOARD_TOKEN

# 2. Cek endpoint auth
curl -X POST https://your-domain.pages.dev/api/auth/check \
  -H "Content-Type: application/json" \
  -d '{"token":"your-token-here"}'

# 3. Pastikan token minimal 12 karakter
```

### 10.6 — Prisma Error

**Gejala:**
```
Error: @prisma/client did not initialize yet
```

**Solusi:**

```bash
# Regenerate Prisma Client
bun run db:generate

# Jika masih error, hapus cache
rm -rf node_modules/.prisma
rm -rf node_modules/@prisma
bun run db:generate
```

### 10.7 — Port Already in Use

**Gejala:**
```
Error: Port 3000 is already in use
```

**Solusi:**

```bash
# Cek proses yang menggunakan port 3000
lsof -i :3000

# Kill proses
kill -9 <PID>

# Atau gunakan port lain
bun run dev --port 3001
```

---

## 11. Appendix: Contoh .env.example

Berikut adalah contoh lengkap file `.env.example` yang bisa kamu salin ke root project:

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================

# --------------------------------------------
# DATABASE
# --------------------------------------------
# Untuk development lokal (SQLite):
DATABASE_URL="file:./db/custom.db"

# Untuk production dengan Neon Tech (PostgreSQL):
# DATABASE_URL="postgresql://neondb_owner:your_password@ep-xxx.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"

# Untuk production dengan TiDB (MySQL-compatible):
# DATABASE_URL="mysql://root:your_password@gateway01.ap-southeast-1.prod.aws.tidbcloud.com:4000/shorturl_db?sslaccept=strict"

# --------------------------------------------
# AUTHENTICATION
# --------------------------------------------
# Token untuk login ke dashboard (MINIMAL 12 karakter!)
# GANTI TOKEN INI DENGAN TOKEN YANG KUAT DI PRODUCTION!
DASHBOARD_TOKEN="Master123@"

# --------------------------------------------
# APP CONFIGURATION
# --------------------------------------------
# URL publik aplikasi (digunakan untuk redirect, OG meta, dll.)
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Untuk production:
# NEXT_PUBLIC_APP_URL="https://shorturl-platform.pages.dev"
# NEXT_PUBLIC_APP_URL="https://go.example.com"

# --------------------------------------------
# OPTIONAL CONFIGURATION
# --------------------------------------------
# Node environment
# NODE_ENV="development"

# ============================================
# JANGAN COMMIT FILE INI KE GIT!
# Pastikan .env ada di .gitignore
# ============================================
```

---

## Checklist Deployment

Gunakan checklist berikut untuk memastikan deployment berjalan lancar:

### Local Development
- [ ] Bun terinstall (`bun --version`)
- [ ] Dependencies terinstall (`bun install`)
- [ ] `.env` sudah dikonfigurasi
- [ ] Database sudah di-push (`bun run db:push`)
- [ ] Prisma Client ter-generate (`bun run db:generate`)
- [ ] Dev server berjalan (`bun run dev`)
- [ ] Login ke dashboard berhasil
- [ ] Bisa membuat dan test short URL

### Database Production
- [ ] Akun Neon/TiDB dibuat
- [ ] Project/cluster dibuat
- [ ] Connection string didapatkan
- [ ] `DATABASE_URL` di-update
- [ ] `prisma/schema.prisma` provider diubah
- [ ] `db:push` berhasil ke database production
- [ ] Koneksi terverifikasi

### GitHub
- [ ] `.gitignore` memuat `.env`
- [ ] Git repository terinisialisasi
- [ ] Semua file committed
- [ ] Repository dibuat di GitHub
- [ ] Code berhasil di-push
- [ ] `.env` TIDAK ada di GitHub

### Cloudflare Pages
- [ ] Akun Cloudflare aktif
- [ ] Pages project dibuat
- [ ] GitHub repository terhubung
- [ ] Build command benar
- [ ] Environment variables dikonfigurasi
- [ ] Deploy pertama berhasil
- [ ] Aplikasi bisa diakses via `*.pages.dev`

### Custom Domain
- [ ] Domain ditambahkan ke Cloudflare
- [ ] Nameserver diubah ke Cloudflare
- [ ] DNS record (CNAME) dibuat
- [ ] Custom domain ditambahkan di Pages
- [ ] SSL certificate aktif
- [ ] Domain ditambahkan di dashboard ShortURL
- [ ] Short URL berfungsi di custom domain

---

## Resource & Link Berguna

| Resource | URL |
|----------|-----|
| Next.js Documentation | https://nextjs.org/docs |
| Prisma Documentation | https://www.prisma.io/docs |
| Neon Tech Docs | https://neon.tech/docs |
| TiDB Cloud Docs | https://docs.pingcap.com/tidbcloud |
| Cloudflare Pages Docs | https://developers.cloudflare.com/pages |
| Bun Documentation | https://bun.sh/docs |
| shadcn/ui Components | https://ui.shadcn.com |
| Tailwind CSS Docs | https://tailwindcss.com/docs |

---

> **Dibuat oleh:** Tim Development ShortURL Platform
>
> **Terakhir diperbarui:** 2025
>
> Jika mengalami masalah yang tidak tercakup di panduan ini, silakan buka issue di repository GitHub atau hubungi tim development.

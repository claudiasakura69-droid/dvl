import { NextRequest, NextResponse } from "next/server";

export function isAuthenticated(request: NextRequest): boolean {
  const authHeader = request.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.replace("Bearer ", "");
  const validToken = process.env.DASHBOARD_TOKEN;
  if (!validToken) return false;
  return token === validToken;
}

export function unauthorized(): NextResponse {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

import { NextRequest, NextResponse } from "next/server";

// Multi-domain routing middleware
// - APP_DOMAIN → dashboard (pass through)
// - *.pages.dev → dashboard (pass through for initial setup)
// - Custom domains on / → styled 404
// - Custom domains on /path → rewrite to /s/path for redirect handler
export const config = {
  matcher: ["/:path*"],
};

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const host = request.headers.get("host") || "";
  const hostname = host.split(":")[0];

  const appDomain = process.env.APP_DOMAIN || "";

  // Allow localhost / 127.0.0.1 for local development
  if (hostname === 'localhost' || hostname === '127.0.0.1') {
    return NextResponse.next();
  }

  // Allow *.pages.dev domains for initial Cloudflare Pages access
  if (hostname.endsWith('.pages.dev')) {
    return NextResponse.next();
  }

  // If no APP_DOMAIN set, or request is for the APP_DOMAIN, pass through
  if (!appDomain || hostname === appDomain || hostname === `www.${appDomain}`) {
    return NextResponse.next();
  }

  // Always pass through Next.js internals, API routes, and static assets
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/__nextjs") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/robots") ||
    pathname.startsWith("/sitemap") ||
    pathname.endsWith(".ico") ||
    pathname.endsWith(".png") ||
    pathname.endsWith(".jpg") ||
    pathname.endsWith(".svg") ||
    pathname.endsWith(".css") ||
    pathname.endsWith(".js")
  ) {
    return NextResponse.next();
  }

  // Root path on custom domain → styled 404
  if (pathname === "/" || pathname === "") {
    return new NextResponse(
      `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Link Not Found</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #f8fafc; color: #1e293b; }
    .container { text-align: center; padding: 2rem; max-width: 400px; }
    h1 { font-size: 4rem; font-weight: 800; color: #e2e8f0; margin-bottom: 0.5rem; }
    p { color: #64748b; font-size: 1rem; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="container">
    <h1>404</h1>
    <p>The link you're looking for doesn't exist.</p>
  </div>
</body>
</html>`,
      { status: 404, headers: { "Content-Type": "text/html; charset=utf-8" } }
    );
  }

  // Rewrite to /s{pathname} so the catch-all redirect handler processes it
  const url = request.nextUrl.clone();
  url.pathname = `/s${pathname}`;
  return NextResponse.rewrite(url);
}

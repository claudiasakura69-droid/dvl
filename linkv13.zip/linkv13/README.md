# ShortURL Platform

Platform manajemen Short URL (clone Dub.co) — Next.js 16, Prisma, Neon PostgreSQL, Cloudflare Pages.

## Tech Stack

| Technology              | Keterangan                               |
|-------------------------|------------------------------------------|
| **Next.js**             | 16.2+ (App Router)                       |
| **TypeScript**          | 5.x                                      |
| **Prisma**              | 6.x (PostgreSQL)                         |
| **PostgreSQL**          | Neon (serverless)                        |
| **Tailwind CSS**        | 4.x                                      |
| **shadcn/ui**           | Radix UI + Tailwind                      |
| **Cloudflare Pages**    | @opennextjs/cloudflare                   |
| **State Management**    | Zustand                                  |

---

## Quick Start

```bash
# 1. Install
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
npm install

# 2. Setup .env
cp .env.example .env
# Edit .env — isi DATABASE_URL (Neon), DASHBOARD_TOKEN, APP_DOMAIN

# 3. Database
npx prisma db push
npx prisma generate

# 4. Run
npm run dev
# Buka http://localhost:3000
```

---

## Environment Variables

| Variable          | Required | Description                              |
|-------------------|----------|------------------------------------------|
| `DATABASE_URL`    | ✅       | Neon PostgreSQL connection string         |
| `DASHBOARD_TOKEN` | ✅       | Token untuk login dashboard               |
| `APP_DOMAIN`      | ✅       | Domain utama (pages.dev atau custom)      |

---

## Deploy ke Cloudflare Pages

### Build Settings

| Setting                  | Value                                |
|--------------------------|--------------------------------------|
| **Framework preset**     | `None`                               |
| **Build command**        | `npx @opennextjs/cloudflare build`   |
| **Build output directory** | `.open-next`                       |
| **Node.js version**      | `20`                                 |

### Environment Variables di Dashboard

1. Workers & Pages → project → **Settings** → **Environment variables**
2. Tambahkan di **KEDUA** tab (Production + Preview):
   - `DATABASE_URL` — Neon PostgreSQL connection string
   - `DASHBOARD_TOKEN` — Token login
   - `APP_DOMAIN` — `*.pages.dev` URL atau custom domain
3. **Save** di kedua tab → **Retry deployment**

### File yang WAJIB ada di repo

- `wrangler.jsonc` — `nodejs_compat` flag (TANPA `[vars]`!)
- `open-next.config.ts` — OpenNext adapter config
- `public/_headers` — Static asset caching

> Panduan lengkap: [docs/INSTALLATION-GUIDE.md](./docs/INSTALLATION-GUIDE.md)

---

## Fitur

- **Multi-domain** — Satu dashboard, banyak domain short URL
- **Multi-target routing** — Sequential / random redirect
- **Analytics** — Tracking klik, device, browser, lokasi
- **QR Code** — SVG QR code untuk setiap link
- **Health check** — Monitoring target URL
- **Bulk operations** — Import, export, migrasi domain
- **Dashboard** — shadcn/ui, dark mode, responsive

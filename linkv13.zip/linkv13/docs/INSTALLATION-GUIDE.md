# Panduan Instalasi & Deployment — ShortURL Platform

> Platform manajemen Short URL (clone Dub.co) — **Next.js 16 + Prisma + Neon PostgreSQL + Cloudflare Pages**

---

## 1. Prasyarat

| Tool                    | Versi Minimum | Download                                |
|-------------------------|---------------|-----------------------------------------|
| **Node.js**             | 18.x+         | https://nodejs.org                       |
| **Git**                 | Terbaru       | https://git-scm.com                      |
| **Neon PostgreSQL**     | -             | https://console.neon.tech (gratis)       |
| **Akun Cloudflare**     | -             | https://dash.cloudflare.com (gratis)     |

---

## 2. Instalasi Lokal

### Step 1: Clone & Install

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform

npm install
```

### Step 2: Setup Environment Variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
DATABASE_URL="postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require"
DASHBOARD_TOKEN="MySecretToken123"
APP_DOMAIN="yourproject.pages.dev"
```

> **PENTING:** `DATABASE_URL` harus menggunakan format PostgreSQL dari Neon. Format `file:` (SQLite) **TIDAK** didukung.

### Step 3: Setup Database (Neon)

```bash
npx prisma db push
npx prisma generate
```

### Step 4: Jalankan

```bash
npm run dev
```

Buka **http://localhost:3000** → halaman login akan muncul → masukkan token dari `DASHBOARD_TOKEN`.

---

## 3. Konfigurasi Database (Neon)

1. Buka https://console.neon.tech → **Create Project**
2. Pilih region terdekat (Singapore direkomendasikan)
3. Copy connection string dari **Connection Details**
4. Paste ke `.env` sebagai `DATABASE_URL`

Format: `postgresql://neondb_owner:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`

---

## 4. Deployment ke Cloudflare Pages

### 4.1 File yang WAJIB ada di repository

| File                   | Fungsi                                            |
|------------------------|---------------------------------------------------|
| `wrangler.jsonc`       | Konfigurasi CF Pages (`nodejs_compat`, output dir) |
| `open-next.config.ts`  | Konfigurasi OpenNext adapter untuk CF              |
| `next.config.ts`       | Konfigurasi Next.js                               |
| `package.json`         | Dependencies & build scripts                      |
| `.npmrc`               | `force=true` untuk menghindari peer dep conflicts |
| `.env.example`         | Template environment variables                    |
| `public/_headers`      | Static asset caching rules                        |
| `prisma/schema.prisma` | Database schema (PostgreSQL)                      |

### 4.2 Push ke GitHub

```bash
git add .
git commit -m "Configure for Cloudflare Pages deployment"
git push origin main
```

### 4.3 Hubungkan ke Cloudflare Pages

1. Buka https://dash.cloudflare.com → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
2. Pilih repository GitHub kamu
3. Konfigurasi build settings:

| Setting                  | Value                                              |
|--------------------------|----------------------------------------------------|
| **Framework preset**     | `None`                                             |
| **Build command**        | `npx @opennextjs/cloudflare build`                 |
| **Build output directory** | `.open-next`                                      |
| **Node.js version**      | `20` (recommended) atau `18`                       |

4. Klik **Save and Deploy**

### 4.4 Set Environment Variables di CF Pages

> **INI YANG PALING PENTING!** Tanpa ini, build akan gagal atau halaman akan blank.

1. Buka **Workers & Pages** → project kamu → **Settings** → **Environment variables**
2. Klik **Add variables** dan tambahkan di **KEDUA** tab (Production **dan** Preview):

| Variable          | Value (contoh)                                                                  |
|-------------------|---------------------------------------------------------------------------------|
| `DATABASE_URL`    | `postgresql://neondb_owner:pass@ep-xxx.neon.tech/neondb?sslmode=require`        |
| `DASHBOARD_TOKEN` | `MySecretToken123`                                                              |
| `APP_DOMAIN`      | `yourproject.pages.dev`                                                         |

3. Setelah menambahkan variables, **WAJIB** klik **Save** pada masing-masing tab
4. Lalu pergi ke **Deployments** → klik **Retry deployment** (atau push commit baru)

> **Kenapa "Build environment variables: (none found)"?**
> Itu berarti environment variables belum di-set di CF Pages dashboard. Ikuti langkah di atas.

### 4.5 Tentang `wrangler.jsonc`

File ini **WAJIB** ada di repository. Isinya:

```jsonc
{
  "name": "shorturl-platform",
  "pages_build_output_dir": ".open-next",
  "compatibility_date": "2025-04-01",
  "compatibility_flags": ["nodejs_compat"]
}
```

- **`nodejs_compat`**: WAJIB — tanpa ini, `process.env` tidak bekerja di Cloudflare Workers
- **`pages_build_output_dir`**: harus `.open-next` (output dari `@opennextjs/cloudflare build`)
- **JANGAN tambahkan `[vars]`** di file ini — environment variables diatur melalui dashboard

---

## 5. Custom Domain

1. CF Pages project → **Custom domains** → **Set up a custom domain**
2. Masukkan domain (contoh: `yourdomain.com`)
3. SSL certificate otomatis (15-30 menit)
4. Update `APP_DOMAIN` di env vars (Production + Preview)
5. Retry deployment

---

## 6. Troubleshooting

### "Build environment variables: (none found)"

**Penyebab:** Environment variables belum di-set di CF Pages dashboard.

**Solusi:**
1. Workers & Pages → project → Settings → Environment variables
2. Tambahkan `DATABASE_URL`, `DASHBOARD_TOKEN`, `APP_DOMAIN`
3. Save di kedua tab (Production + Preview)
4. Retry deployment

### Deploy berhasil tapi halaman blank

1. Buka DevTools (F12) → Console — periksa error
2. Pastikan `wrangler.jsonc` ADA di repo dengan `nodejs_compat`
3. Pastikan environment variables sudah di-set di dashboard
4. Pastikan `DATABASE_URL` menggunakan format PostgreSQL (bukan SQLite)

### Error `prisma: Cannot find module`

```bash
npx prisma generate
```

### Login tidak bisa (Invalid token)

1. Pastikan `DASHBOARD_TOKEN` sama di `.env` lokal dan CF Pages dashboard
2. Restart dev server setelah mengubah `.env`
3. Di browser: `localStorage.removeItem("token")` → reload

### Build gagal di CF Pages

1. Pastikan build command: `npx @opennextjs/cloudflare build`
2. Pastikan Node.js version: `20`
3. Pastikan build output directory: `.open-next`
4. Periksa build log di CF Pages dashboard

---

## 7. Ringkasan Perintah

```bash
# Lokal development
npm install
cp .env.example .env          # edit dengan values kamu
npx prisma db push            # buat tabel di Neon
npx prisma generate           # generate Prisma client
npm run dev                   # http://localhost:3000

# Build untuk Cloudflare Pages
npm run build:cf              # output ke .open-next/

# Preview lokal dengan Wrangler (opsional)
npm run preview               # simulasi CF Pages locally

# Deploy manual via CLI (opsional)
npm run deploy
```

# ShortURL Platform

Short URL management platform (Dub.co clone) — Next.js 16 + Cloudflare KV + Cloudflare Pages.

## Features

- 🔗 Multi-domain short URLs with analytics
- 🎯 Basic & multi-target redirect (sequential/random, country/IP routing)
- 📊 Click analytics with charts (country, device, browser, OS)
- 📱 QR code generation
- 🏥 Health check for link targets
- 📦 Bulk operations (import/export, bulk create, delete, activate/deactivate)
- 🌐 Custom domain support with Cloudflare DNS
- 🌗 Dark/light theme, responsive dashboard
- ⚙️ Settings (redirect status, default UTM, export/import, danger zone)
- ⚡ Zero database connection issues — uses Cloudflare KV (native to CF Pages)

## Quick Start (Local Development)

```bash
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform
npm install
cp .env.example .env   # edit with your DASHBOARD_TOKEN

npm run dev             # http://localhost:3000
```

### Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DASHBOARD_TOKEN` | Token for dashboard login (min 12 chars) | `MySecureToken123!` |
| `APP_DOMAIN` | Your `*.pages.dev` URL or custom domain | `myproject.pages.dev` |

> **Note**: Local development uses an in-memory KV store (data resets on restart). Data persists on Cloudflare Pages.

---

## Deploy to Cloudflare Pages

### Step 1: Create KV Namespace

```bash
npx wrangler kv:namespace create "SHORTURL_KV"
```

Copy the `id` from the output. You'll need it in Step 3.

### Step 2: Push to GitHub

```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### Step 3: Connect to Cloudflare Pages

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
2. Select your GitHub repository
3. Set build settings:

| Setting | Value |
|---------|-------|
| **Build command** | `npx @opennextjs/cloudflare build` |
| **Build output directory** | `.open-next` |
| **Node.js version** | `20` (or latest) |

4. Click **Save and Deploy**

### Step 4: Add Environment Variables

1. Go to your Pages project → **Settings** → **Environment variables**
2. Add these variables in **Production** tab:

| Variable | Type | Value |
|----------|------|-------|
| `DASHBOARD_TOKEN` | **Secret** | Your dashboard login token |
| `APP_DOMAIN` | **Text** | `yourproject.pages.dev` |

3. Click **Save**

### Step 5: Add KV Namespace Binding

1. Go to your Pages project → **Settings** → **Functions** → **KV namespace bindings**
2. Click **Add binding**
3. Set:
   - **Variable name**: `KV`
   - **KV Namespace**: Select the namespace created in Step 1 (or paste the ID)
4. Click **Save**
5. Go to **Deployments** → **Retry deployment**

### Step 6: Verify

- Visit `https://yourproject.pages.dev`
- You should see the login page
- Enter your `DASHBOARD_TOKEN` to sign in

---

## How It Works

### Architecture

- **Frontend**: Single-page app using Zustand for state management
- **Backend**: Next.js API routes with Cloudflare KV storage
- **Database**: Cloudflare KV (key-value store, native to CF Pages)
- **Deployment**: `@opennextjs/cloudflare` converts Next.js build to CF Pages format

### Data Storage (Cloudflare KV)

| Key Pattern | Value | Description |
|-------------|-------|-------------|
| `domain:{id}` | Domain JSON | Individual domain data |
| `link:{id}` | Link JSON | Individual link data (targets embedded) |
| `idx:domains` | `["id1", ...]` | Domain ID index |
| `idx:links` | `["id1", ...]` | Link ID index |
| `idx:clicks:{linkId}` | `["clickId1", ...]` | Click IDs per link |
| `click:{id}` | Click JSON | Individual click record |
| `app:settings` | Settings JSON | Application settings |

### Short Link Redirect Flow

1. Visitor goes to `customdomain.com/slug`
2. Middleware detects custom domain → rewrites to `/s/slug`
3. `/s/[slug]/route.ts` looks up the link in KV
4. Records click analytics (IP, country, device, browser, OS, referrer via CF headers)
5. Applies multi-target routing rules (country, IP, sequential/random)
6. Redirects with HTTP 301 + optional UTM parameters

### Multi-Target Routing Priority

1. **IP-based** → Match visitor IP against allowed IP lists
2. **Country-based** → Match visitor country (from `cf-ipcountry` header)
3. **ALL** → Fallback targets for everyone else
4. **Mode**: `sequential` (round-robin) or `random`

---

## Project Structure

```
src/
├── app/
│   ├── page.tsx              # Entry point (login/dashboard router)
│   ├── layout.tsx            # Root layout with theme provider
│   ├── s/[slug]/route.ts     # Short link redirect handler
│   └── api/
│       ├── auth/             # Login & auth check
│       ├── links/            # Links CRUD, bulk ops, clicks, health check
│       ├── domains/          # Domains CRUD & verify
│       ├── analytics/        # Analytics overview
│       ├── settings/         # App settings
│       ├── export/           # Export data (JSON)
│       ├── import/           # Import data (JSON)
│       └── danger/           # Destructive operations
├── components/
│   ├── pages/                # Page components (login, dashboard, etc.)
│   ├── dashboard/            # Layout, sidebar, header
│   ├── links/                # Link table, forms, QR code, analytics dialog
│   ├── domains/              # Domain cards, add/edit dialogs
│   └── analytics/            # Charts (clicks, country, device)
├── lib/
│   ├── api.ts                # Frontend API client
│   ├── auth.ts               # Auth middleware helper
│   ├── db.ts                 # KV-based database operations
│   ├── kv.ts                 # Cloudflare KV abstraction (MemoryKV fallback)
│   ├── store.ts              # Zustand store
│   ├── types.ts              # TypeScript interfaces
│   └── utils.ts              # Utility functions
└── middleware.ts             # Multi-domain routing (production only)
```

---

## Custom Domains

1. Add domain in **Domains** page
2. In Cloudflare DNS, add a **CNAME** record pointing to `yourproject.pages.dev`
3. In Cloudflare Pages → **Custom domains**, add the domain
4. The middleware will route short links on custom domains automatically

## License

MIT

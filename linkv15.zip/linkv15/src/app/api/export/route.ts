import { NextRequest, NextResponse } from "next/server";
import { exportAll } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Export all links, domains, and clicks as JSON
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const includeClicks = request.nextUrl.searchParams.get("includeClicks") === "true";

    const data = await exportAll(includeClicks);

    return NextResponse.json({
      links: data.links,
      domains: data.domains,
      clicks: data.clicks,
      exportedAt: data.exportedAt,
    });
  } catch (error) {
    console.error("Error exporting data:", error);
    return NextResponse.json({ error: "Failed to export data" }, { status: 500 });
  }
}

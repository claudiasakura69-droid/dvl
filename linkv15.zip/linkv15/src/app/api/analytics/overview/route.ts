import { NextRequest, NextResponse } from "next/server";
import { getAnalyticsOverview } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Analytics overview
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const data = await getAnalyticsOverview();

    return NextResponse.json(data);
  } catch (error) {
    console.error("Error fetching analytics overview:", error);
    return NextResponse.json(
      { error: "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}

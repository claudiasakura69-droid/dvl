import { NextRequest, NextResponse } from "next/server";
import { getAllDomains, getLinks, createDomain } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - List all domains
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const domains = await getAllDomains();

    const domainsWithCount = await Promise.all(
      domains.map(async (d) => {
        const { total } = await getLinks({ domainId: d.id, page: 1, limit: 1 });
        return {
          ...d,
          _count: { links: total },
        };
      })
    );

    return NextResponse.json(domainsWithCount);
  } catch (error) {
    console.error("Error fetching domains:", error);
    return NextResponse.json({ error: "Failed to fetch domains" }, { status: 500 });
  }
}

// POST - Create domain
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { domain, slug } = body;

    if (!domain || typeof domain !== "string") {
      return NextResponse.json({ error: "Domain is required" }, { status: 400 });
    }

    // Basic domain format validation
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
    if (!domainRegex.test(domain)) {
      return NextResponse.json({ error: "Invalid domain format" }, { status: 400 });
    }

    try {
      const created = await createDomain({
        domain,
        slug: slug || "",
      });

      return NextResponse.json(created, { status: 201 });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "Domain already exists") {
        return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
      }
      throw err;
    }
  } catch (error) {
    console.error("Error creating domain:", error);
    return NextResponse.json({ error: "Failed to create domain" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { getDomainById, getLinks, updateDomain, deleteDomain } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Get single domain
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const domain = await getDomainById(id);

    if (!domain) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const { total } = await getLinks({ domainId: id, page: 1, limit: 1 });
    const domainWithCount = {
      ...domain,
      _count: { links: total },
    };

    return NextResponse.json(domainWithCount);
  } catch (error) {
    console.error("Error fetching domain:", error);
    return NextResponse.json({ error: "Failed to fetch domain" }, { status: 500 });
  }
}

// PUT - Update domain
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();
    const { domain, slug, isActive, isVerified } = body;

    const existing = await getDomainById(id);
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    try {
      const updated = await updateDomain(id, {
        ...(domain !== undefined && { domain }),
        ...(slug !== undefined && { slug }),
        ...(isActive !== undefined && { isActive }),
        ...(isVerified !== undefined && { isVerified }),
      });

      return NextResponse.json(updated);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "Domain already exists") {
        return NextResponse.json({ error: "Domain already exists" }, { status: 409 });
      }
      throw err;
    }
  } catch (error) {
    console.error("Error updating domain:", error);
    return NextResponse.json({ error: "Failed to update domain" }, { status: 500 });
  }
}

// DELETE - Delete domain (cascades to links)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await getDomainById(id);
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    await deleteDomain(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting domain:", error);
    return NextResponse.json({ error: "Failed to delete domain" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { getDomainById, updateDomain } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Verify domain
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await getDomainById(id);
    if (!existing) {
      return NextResponse.json({ error: "Domain not found" }, { status: 404 });
    }

    const updated = await updateDomain(id, { isVerified: true });

    return NextResponse.json(updated);
  } catch (error) {
    console.error("Error verifying domain:", error);
    return NextResponse.json({ error: "Failed to verify domain" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { getAllSettings, updateSettings, updateSetting } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Return all settings
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const settings = await getAllSettings();
    return NextResponse.json(settings);
  } catch (error) {
    console.error("Error fetching settings:", error);
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 });
  }
}

// PUT - Save/update settings
export async function PUT(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();

    // Support single key-value update
    if (body.key && body.value !== undefined) {
      const result = await updateSetting(body.key, String(body.value));
      return NextResponse.json(result);
    }

    // Support batch update with { settings: Record<string, string> }
    if (body.settings && typeof body.settings === "object") {
      const result = await updateSettings(body.settings);
      return NextResponse.json({ success: true, updated: result.updated });
    }

    return NextResponse.json(
      { error: "Provide { key, value } or { settings: { key: value, ... } }" },
      { status: 400 }
    );
  } catch (error) {
    console.error("Error saving settings:", error);
    return NextResponse.json({ error: "Failed to save settings" }, { status: 500 });
  }
}

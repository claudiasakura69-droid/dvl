import { NextRequest, NextResponse } from "next/server";
import { importData } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Import JSON data (links, domains)
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { links, domains } = body as {
      links?: Array<{
        slug: string;
        domainId: string;
        type?: string;
        mode?: string;
        title?: string;
        description?: string;
        url?: string;
        targets?: Array<{
          url: string;
          clickLimit?: number;
          country?: string;
          ipList?: string;
          order?: number;
        }>;
      }>;
      domains?: Array<{
        domain: string;
        slug?: string;
        isActive?: boolean;
      }>;
      clicks?: unknown[];
    };

    const result = await importData({ links, domains });

    return NextResponse.json({
      imported: {
        domains: result.imported.domains,
        links: result.imported.links,
      },
      skipped: result.skipped,
      errors: result.errors,
    });
  } catch (error) {
    console.error("Error importing data:", error);
    return NextResponse.json({ error: "Failed to import data" }, { status: 500 });
  }
}

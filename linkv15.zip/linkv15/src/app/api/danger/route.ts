import { NextRequest, NextResponse } from "next/server";
import { dangerOperation } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Handle destructive operations
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { action } = body as { action: string };

    if (!["deleteAllLinks", "deleteAllClicks", "resetDatabase"].includes(action)) {
      return NextResponse.json(
        { error: "Invalid action. Use: deleteAllLinks, deleteAllClicks, or resetDatabase" },
        { status: 400 }
      );
    }

    const result = await dangerOperation(action);

    return NextResponse.json({
      success: result.success,
      deleted: result.deleted,
    });
  } catch (error) {
    console.error("Error performing danger operation:", error);
    return NextResponse.json({ error: "Operation failed" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import {
  createLink,
  getLinks,
  getDomainById,
  updateManyLinks,
  deleteManyLinks,
} from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

function generateSlug(length = 6): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// POST - Bulk operations
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case "create": {
        const { links: linksToCreate } = body as {
          links: Array<{ slug: string; url: string; domainId: string; title?: string }>;
        };

        if (!Array.isArray(linksToCreate) || linksToCreate.length === 0) {
          return NextResponse.json({ error: "links array is required" }, { status: 400 });
        }

        // Verify domains exist
        const domainIds = [...new Set(linksToCreate.map((l) => l.domainId))];
        const domainMap = new Map<string, boolean>();
        for (const domainId of domainIds) {
          const domain = await getDomainById(domainId);
          domainMap.set(domainId, !!domain);
        }

        let created = 0;
        let skipped = 0;
        const errors: string[] = [];

        for (const linkData of linksToCreate) {
          if (!linkData.url || !linkData.domainId) {
            skipped++;
            continue;
          }
          if (!domainMap.has(linkData.domainId) || !domainMap.get(linkData.domainId)) {
            errors.push(`Link "${linkData.slug || "unknown"}": Domain not found`);
            skipped++;
            continue;
          }

          const slug = linkData.slug || generateSlug();

          try {
            await createLink({
              slug,
              domainId: linkData.domainId,
              type: "basic",
              mode: "sequential",
              title: linkData.title || "",
              targets: [{ url: linkData.url }],
            });
            created++;
          } catch (err: unknown) {
            const msg = err instanceof Error ? err.message : String(err);
            if (msg === "Slug already exists for this domain") {
              skipped++;
            } else {
              errors.push(`Link "${slug}": ${msg}`);
            }
          }
        }

        return NextResponse.json({ success: true, created, skipped, errors });
      }

      case "changeDomain": {
        const { oldDomainId, newDomainId } = body;

        if (!oldDomainId || !newDomainId) {
          return NextResponse.json(
            { error: "oldDomainId and newDomainId are required" },
            { status: 400 }
          );
        }

        // Verify new domain exists
        const newDomain = await getDomainById(newDomainId);
        if (!newDomain) {
          return NextResponse.json({ error: "Target domain not found" }, { status: 404 });
        }

        // Check for slug conflicts in the new domain
        const oldLinksResult = await getLinks({ domainId: oldDomainId, page: 1, limit: 999999 });
        const newLinksResult = await getLinks({ domainId: newDomainId, page: 1, limit: 999999 });

        const existingSlugSet = new Set(newLinksResult.links.map((l) => l.slug));
        const conflictingSlugs = oldLinksResult.links.filter((l) => existingSlugSet.has(l.slug));

        if (conflictingSlugs.length > 0) {
          return NextResponse.json(
            {
              error: `Slug conflicts found: ${conflictingSlugs.map((l) => l.slug).join(", ")}`,
            },
            { status: 409 }
          );
        }

        const oldLinkIds = oldLinksResult.links.map((l) => l.id);
        const count = await updateManyLinks(oldLinkIds, { domainId: newDomainId });

        return NextResponse.json({ success: true, count });
      }

      case "delete": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const count = await deleteManyLinks(linkIds);

        return NextResponse.json({ success: true, count });
      }

      case "activate": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const count = await updateManyLinks(linkIds, { isActive: true });

        return NextResponse.json({ success: true, count });
      }

      case "deactivate": {
        const { linkIds } = body;

        if (!Array.isArray(linkIds) || linkIds.length === 0) {
          return NextResponse.json({ error: "linkIds array is required" }, { status: 400 });
        }

        const count = await updateManyLinks(linkIds, { isActive: false });

        return NextResponse.json({ success: true, count });
      }

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Error performing bulk operation:", error);
    return NextResponse.json({ error: "Bulk operation failed" }, { status: 500 });
  }
}

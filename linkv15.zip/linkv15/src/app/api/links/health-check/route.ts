import { NextRequest, NextResponse } from "next/server";
import { healthCheck } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// POST - Health check for link targets
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const { linkId } = body;

    try {
      const result = await healthCheck(linkId || undefined);

      return NextResponse.json(result);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "Link not found") {
        return NextResponse.json({ error: "Link not found" }, { status: 404 });
      }
      throw err;
    }
  } catch (error) {
    console.error("Error performing health check:", error);
    return NextResponse.json({ error: "Health check failed" }, { status: 500 });
  }
}

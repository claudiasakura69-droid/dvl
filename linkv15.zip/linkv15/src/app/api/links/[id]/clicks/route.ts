import { NextRequest, NextResponse } from "next/server";
import { getLinkById, getClicksByLink } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Click analytics for a specific link
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const searchParams = request.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")));
    const startDate = searchParams.get("startDate");
    const endDate = searchParams.get("endDate");

    // Verify link exists
    const link = await getLinkById(id);

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    const result = await getClicksByLink(id, {
      page,
      limit,
      startDate: startDate || undefined,
      endDate: endDate || undefined,
    });

    return NextResponse.json({
      clicks: result.clicks,
      total: result.total,
      page: result.page,
      totalPages: result.totalPages,
    });
  } catch (error) {
    console.error("Error fetching clicks:", error);
    return NextResponse.json({ error: "Failed to fetch clicks" }, { status: 500 });
  }
}

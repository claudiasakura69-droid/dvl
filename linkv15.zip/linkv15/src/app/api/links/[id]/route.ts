import { NextRequest, NextResponse } from "next/server";
import { getLinkById, updateLink, deleteLink } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - Get single link with targets
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const link = await getLinkById(id);

    if (!link) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    return NextResponse.json(link);
  } catch (error) {
    console.error("Error fetching link:", error);
    return NextResponse.json({ error: "Failed to fetch link" }, { status: 500 });
  }
}

// PUT - Update link
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await getLinkById(id);
    if (!existing) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    // Destructure updatable fields
    const {
      slug,
      domainId,
      type,
      mode,
      title,
      description,
      password,
      ogTitle,
      ogDescription,
      ogImage,
      utmSource,
      utmMedium,
      utmCampaign,
      utmContent,
      utmTerm,
      isActive,
      expiredAt,
      targets,
    } = body;

    try {
      const updated = await updateLink(id, {
        ...(slug !== undefined && { slug }),
        ...(domainId !== undefined && { domainId }),
        ...(type !== undefined && { type }),
        ...(mode !== undefined && { mode }),
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description }),
        ...(password !== undefined && { password }),
        ...(ogTitle !== undefined && { ogTitle }),
        ...(ogDescription !== undefined && { ogDescription }),
        ...(ogImage !== undefined && { ogImage }),
        ...(utmSource !== undefined && { utmSource }),
        ...(utmMedium !== undefined && { utmMedium }),
        ...(utmCampaign !== undefined && { utmCampaign }),
        ...(utmContent !== undefined && { utmContent }),
        ...(utmTerm !== undefined && { utmTerm }),
        ...(isActive !== undefined && { isActive }),
        ...(expiredAt !== undefined && {
          expiredAt: expiredAt ? new Date(expiredAt).toISOString() : null,
        }),
        ...(Array.isArray(targets) && {
          targets: targets.map((t: {
            url: string;
            clickLimit?: number;
            country?: string;
            ipList?: string;
            order?: number;
            isActive?: boolean;
          }) => ({
            url: t.url,
            clickLimit: t.clickLimit || 0,
            country: t.country || "ALL",
            ipList: t.ipList || "",
            order: t.order || 0,
            isActive: t.isActive !== undefined ? t.isActive : true,
          })),
        }),
      });

      return NextResponse.json(updated);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "Slug already exists for this domain") {
        return NextResponse.json(
          { error: "Slug already exists for this domain" },
          { status: 409 }
        );
      }
      throw err;
    }
  } catch (error) {
    console.error("Error updating link:", error);
    return NextResponse.json({ error: "Failed to update link" }, { status: 500 });
  }
}

// DELETE - Delete link and all related data
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const { id } = await params;
    const existing = await getLinkById(id);
    if (!existing) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    await deleteLink(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting link:", error);
    return NextResponse.json({ error: "Failed to delete link" }, { status: 500 });
  }
}

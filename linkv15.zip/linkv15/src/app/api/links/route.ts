import { NextRequest, NextResponse } from "next/server";
import { getLinks, createLink } from "@/lib/db";
import { isAuthenticated, unauthorized } from "@/lib/auth";

// GET - List links with pagination, search, and filters
export async function GET(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const searchParams = request.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get("limit") || "20")));
    const search = searchParams.get("search") || "";
    const domainId = searchParams.get("domainId") || "";
    const type = searchParams.get("type") || "";
    const isActive = searchParams.get("isActive");

    const result = await getLinks({
      page,
      limit,
      search: search || undefined,
      domainId: domainId || undefined,
      type: type || undefined,
      isActive: isActive || undefined,
    });

    return NextResponse.json({
      links: result.links,
      total: result.total,
      page: result.page,
      totalPages: result.totalPages,
    });
  } catch (error) {
    console.error("Error fetching links:", error);
    return NextResponse.json({ error: "Failed to fetch links" }, { status: 500 });
  }
}

// POST - Create a new short link
export async function POST(request: NextRequest) {
  if (!isAuthenticated(request)) return unauthorized();

  try {
    const body = await request.json();
    const {
      slug,
      domainId,
      type = "basic",
      mode = "sequential",
      title,
      description,
      password,
      ogTitle,
      ogDescription,
      ogImage,
      utmSource,
      utmMedium,
      utmCampaign,
      utmContent,
      utmTerm,
      expiredAt,
      targets,
    } = body;

    // Validation
    if (!slug || typeof slug !== "string") {
      return NextResponse.json({ error: "Slug is required" }, { status: 400 });
    }

    if (!domainId) {
      return NextResponse.json({ error: "Domain ID is required" }, { status: 400 });
    }

    // Validate targets
    const targetsArray = Array.isArray(targets) ? targets : [];

    if (type === "basic" && targetsArray.length !== 1) {
      return NextResponse.json(
        { error: "Basic type requires exactly 1 target" },
        { status: 400 }
      );
    }

    if (type === "multi" && targetsArray.length < 1) {
      return NextResponse.json(
        { error: "Multi type requires at least 1 target" },
        { status: 400 }
      );
    }

    // Parse expiredAt if provided
    const expiredAtValue = expiredAt ? new Date(expiredAt).toISOString() : null;

    try {
      const link = await createLink({
        slug,
        domainId,
        type,
        mode,
        title: title || "",
        description: description || "",
        password: password || "",
        ogTitle: ogTitle || "",
        ogDescription: ogDescription || "",
        ogImage: ogImage || "",
        utmSource: utmSource || "",
        utmMedium: utmMedium || "",
        utmCampaign: utmCampaign || "",
        utmContent: utmContent || "",
        utmTerm: utmTerm || "",
        expiredAt: expiredAtValue,
        targets: targetsArray.map((t: {
          url: string;
          clickLimit?: number;
          country?: string;
          ipList?: string;
          order?: number;
        }) => ({
          url: t.url,
          clickLimit: t.clickLimit || 0,
          country: t.country || "ALL",
          ipList: t.ipList || "",
          order: t.order || 0,
        })),
      });

      return NextResponse.json(link, { status: 201 });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg === "Domain not found") {
        return NextResponse.json({ error: "Domain not found" }, { status: 404 });
      }
      if (msg === "Slug already exists for this domain") {
        return NextResponse.json(
          { error: "Slug already exists for this domain" },
          { status: 409 }
        );
      }
      throw err;
    }
  } catch (error) {
    console.error("Error creating link:", error);
    return NextResponse.json({ error: "Failed to create link" }, { status: 500 });
  }
}

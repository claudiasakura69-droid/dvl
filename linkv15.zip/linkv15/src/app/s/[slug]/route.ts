import { NextRequest, NextResponse } from "next/server";
import { getDomainByHostname, getLinkBySlug, recordClick } from "@/lib/db";

function parseUserAgent(ua: string): { device: string; browser: string; os: string } {
  let device = "Unknown";
  let browser = "Unknown";
  let os = "Unknown";

  if (!ua) return { device, browser, os };

  if (/Mobile|Android.*Mobile|iPhone|iPod/.test(ua)) {
    device = "Mobile";
  } else if (/iPad|Android(?!.*Mobile)|Tablet/.test(ua)) {
    device = "Tablet";
  } else {
    device = "Desktop";
  }

  if (/Edg\//.test(ua)) {
    browser = "Edge";
  } else if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) {
    browser = "Chrome";
  } else if (/Firefox\//.test(ua)) {
    browser = "Firefox";
  } else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) {
    browser = "Safari";
  } else if (/Opera|OPR\//.test(ua)) {
    browser = "Opera";
  }

  if (/Windows NT 10/.test(ua)) {
    os = "Windows";
  } else if (/Windows NT/.test(ua)) {
    os = "Windows";
  } else if (/Mac OS X/.test(ua)) {
    os = "macOS";
  } else if (/Android/.test(ua)) {
    os = "Android";
  } else if (/iPhone|iPad|iPod/.test(ua)) {
    os = "iOS";
  } else if (/Linux/.test(ua)) {
    os = "Linux";
  }

  return { device, browser, os };
}

function errorHtml(title: string, message: string, status: number): NextResponse {
  return new NextResponse(
    `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #f8fafc; color: #1e293b; }
    .container { text-align: center; padding: 2rem; max-width: 400px; }
    h1 { font-size: 4rem; font-weight: 800; color: #e2e8f0; margin-bottom: 0.5rem; }
    h2 { font-size: 1.25rem; font-weight: 600; margin-bottom: 0.5rem; }
    p { color: #64748b; font-size: 1rem; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="container">
    <h1>${status}</h1>
    <h2>${title}</h2>
    <p>${message}</p>
  </div>
</body>
</html>`,
    { status, headers: { "Content-Type": "text/html; charset=utf-8" } }
  );
}

function getClientIp(request: NextRequest): string {
  const cfIp = request.headers.get("cf-connecting-ip");
  if (cfIp) return cfIp;
  const xff = request.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return "unknown";
}

function getCountry(request: NextRequest): string {
  return request.headers.get("cf-ipcountry") || "";
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const hostname = request.headers.get("host")?.split(":")[0] || "";

    if (!slug) {
      return errorHtml("Not Found", "No slug provided.", 404);
    }

    const domain = await getDomainByHostname(hostname);

    if (!domain) {
      return errorHtml("Domain Not Found", "This domain is not configured for short links.", 404);
    }

    if (!domain.isActive) {
      return errorHtml("Service Unavailable", "This domain is currently inactive.", 503);
    }

    const link = await getLinkBySlug(domain.id, slug);

    if (!link) {
      return errorHtml("Link Not Found", "This short link does not exist or has been removed.", 404);
    }

    if (!link.isActive) {
      return errorHtml("Link Inactive", "This short link has been deactivated.", 410);
    }

    if (link.expiredAt && new Date(link.expiredAt) < new Date()) {
      return errorHtml("Link Expired", "This short link has expired.", 410);
    }

    if (link.password) {
      return errorHtml("Password Protected", "This link requires a password to access.", 403);
    }

    const targets = (link.targets || []).filter((t) => t.isActive);

    if (!targets || targets.length === 0) {
      return errorHtml("No Targets", "This short link has no active targets.", 503);
    }

    const ip = getClientIp(request);
    const country = getCountry(request);
    const { device, browser, os } = parseUserAgent(request.headers.get("user-agent") || "");
    const referrer = request.headers.get("referer") || "";

    let targetUrl = "";
    let matchedTargetId = targets[0].id;

    if (link.type === "basic" && targets.length >= 1) {
      const t = targets[0];

      if (t.clickLimit > 0 && t.currentClicks >= t.clickLimit) {
        return errorHtml("Limit Reached", "This link has reached its click limit.", 429);
      }

      if (t.country !== "ALL" && country && t.country !== country) {
        return errorHtml("Restricted", "This link is not available in your region.", 403);
      }

      if (t.ipList) {
        const allowedIps = t.ipList.split(",").map((s) => s.trim()).filter(Boolean);
        if (allowedIps.length > 0 && !allowedIps.includes(ip)) {
          return errorHtml("Restricted", "You are not authorized to access this link.", 403);
        }
      }

      targetUrl = t.url;
      matchedTargetId = t.id;
    } else if (link.type === "multi") {
      let matchedTarget = targets[0];

      const ipTarget = targets.find((t) => {
        if (!t.ipList) return false;
        const allowedIps = t.ipList.split(",").map((s) => s.trim()).filter(Boolean);
        return allowedIps.includes(ip);
      });

      if (ipTarget) {
        matchedTarget = ipTarget;
      } else if (country) {
        const countryTarget = targets.find((t) => t.country === country);
        if (countryTarget) {
          matchedTarget = countryTarget;
        }
      }

      if (matchedTarget.clickLimit > 0 && matchedTarget.currentClicks >= matchedTarget.clickLimit) {
        const nextTarget = targets.find((t) =>
          t.id !== matchedTarget.id &&
          (t.clickLimit === 0 || t.currentClicks < t.clickLimit)
        );
        if (!nextTarget) {
          return errorHtml("Limit Reached", "All targets have reached their click limits.", 429);
        }
        matchedTarget = nextTarget;
      }

      if (link.mode === "sequential" && !ipTarget && !(country && targets.find((t) => t.country === country))) {
        const totalCurrentClicks = targets.reduce((sum, t) => sum + t.currentClicks, 0);
        const idx = totalCurrentClicks % targets.length;
        matchedTarget = targets[idx];

        if (matchedTarget.clickLimit > 0 && matchedTarget.currentClicks >= matchedTarget.clickLimit) {
          const fallback = targets.find((t) => t.clickLimit === 0 || t.currentClicks < t.clickLimit);
          if (!fallback) {
            return errorHtml("Limit Reached", "All targets have reached their click limits.", 429);
          }
          matchedTarget = fallback;
        }
      }

      targetUrl = matchedTarget.url;
      matchedTargetId = matchedTarget.id;
    } else {
      targetUrl = targets[0].url;
      matchedTargetId = targets[0].id;
    }

    // Record click (recordClick handles target click count increment internally)
    await recordClick({
      linkId: link.id,
      targetId: matchedTargetId,
      ip,
      country,
      device,
      browser,
      os,
      referrer,
    });

    // Append UTM params
    const urlObj = new URL(targetUrl);
    if (link.utmSource) urlObj.searchParams.set("utm_source", link.utmSource);
    if (link.utmMedium) urlObj.searchParams.set("utm_medium", link.utmMedium);
    if (link.utmCampaign) urlObj.searchParams.set("utm_campaign", link.utmCampaign);
    if (link.utmContent) urlObj.searchParams.set("utm_content", link.utmContent);
    if (link.utmTerm) urlObj.searchParams.set("utm_term", link.utmTerm);
    targetUrl = urlObj.toString();

    return NextResponse.redirect(targetUrl, 301);
  } catch (error) {
    console.error("Redirect handler error:", error);
    return errorHtml("Internal Server Error", "Something went wrong processing your request.", 500);
  }
}

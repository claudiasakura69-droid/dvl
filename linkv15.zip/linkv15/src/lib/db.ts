// KV-based database operations
// Replaces Prisma/PostgreSQL with Cloudflare KV storage
// Data persists in KV on Cloudflare Pages; uses MemoryKV for local dev

import { getKV } from "./kv";
import type { ShortDomain, ShortLink, LinkTarget, Click, DashboardStats } from "./types";

// ─── Helpers ───

function generateId(): string {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).substring(2, 10);
  return `${ts}${rand}`;
}

function nowISO(): string {
  return new Date().toISOString();
}

function formatDate(d: string): Date {
  return new Date(d);
}

// ══════════════════════════════════════════
//  DOMAIN OPERATIONS
// ══════════════════════════════════════════

export async function getAllDomains(): Promise<ShortDomain[]> {
  const kv = await getKV();
  const ids = (await kv.getJSON<string[]>("idx:domains")) || [];
  const domains = await Promise.all(
    ids.map((id) => kv.getJSON<ShortDomain>(`domain:${id}`))
  );
  return domains.filter((d): d is ShortDomain => !!d);
}

export async function getDomainById(id: string): Promise<ShortDomain | null> {
  const kv = await getKV();
  return kv.getJSON<ShortDomain>(`domain:${id}`);
}

export async function getDomainByHostname(hostname: string): Promise<ShortDomain | null> {
  const kv = await getKV();
  const id = await kv.get(`lookup:domain:${hostname}`);
  if (!id) return null;
  return kv.getJSON<ShortDomain>(`domain:${id}`);
}

export async function getDomainCount(where?: { isActive?: boolean }): Promise<number> {
  const domains = await getAllDomains();
  if (!where) return domains.length;
  return domains.filter((d) => {
    if (where.isActive !== undefined) return d.isActive === where.isActive;
    return true;
  }).length;
}

export async function createDomain(data: {
  domain: string;
  slug?: string;
  isActive?: boolean;
}): Promise<ShortDomain> {
  const kv = await getKV();
  const id = generateId();

  // Check duplicate by hostname
  const existingId = await kv.get(`lookup:domain:${data.domain}`);
  if (existingId) throw new Error("Domain already exists");

  const domain: ShortDomain = {
    id,
    domain: data.domain,
    slug: data.slug || "",
    isActive: data.isActive !== undefined ? data.isActive : true,
    isVerified: false,
    verifiedAt: null,
    createdAt: nowISO(),
    updatedAt: nowISO(),
  };

  await kv.putJSON(`domain:${id}`, domain);
  await kv.put(`lookup:domain:${data.domain}`, id);

  const ids = (await kv.getJSON<string[]>("idx:domains")) || [];
  ids.unshift(id);
  await kv.putJSON("idx:domains", ids);

  return domain;
}

export async function updateDomain(
  id: string,
  data: Partial<{
    domain: string;
    slug: string;
    isActive: boolean;
    isVerified: boolean;
  }>
): Promise<ShortDomain | null> {
  const kv = await getKV();
  const existing = await kv.getJSON<ShortDomain>(`domain:${id}`);
  if (!existing) return null;

  // If domain name is changing, update lookup
  if (data.domain && data.domain !== existing.domain) {
    const conflictId = await kv.get(`lookup:domain:${data.domain}`);
    if (conflictId) throw new Error("Domain already exists");
    await kv.delete(`lookup:domain:${existing.domain}`);
    await kv.put(`lookup:domain:${data.domain}`, id);
  }

  const updated: ShortDomain = {
    ...existing,
    ...(data.domain !== undefined && { domain: data.domain }),
    ...(data.slug !== undefined && { slug: data.slug }),
    ...(data.isActive !== undefined && { isActive: data.isActive }),
    ...(data.isVerified !== undefined && {
      isVerified: data.isVerified,
      verifiedAt: data.isVerified ? nowISO() : existing.verifiedAt,
    }),
    updatedAt: nowISO(),
  };

  await kv.putJSON(`domain:${id}`, updated);
  return updated;
}

export async function deleteDomain(id: string): Promise<void> {
  const kv = await getKV();
  const domain = await kv.getJSON<ShortDomain>(`domain:${id}`);
  if (!domain) return;

  // Delete the domain
  await kv.delete(`domain:${id}`);
  await kv.delete(`lookup:domain:${domain.domain}`);

  // Remove from index
  const ids = (await kv.getJSON<string[]>("idx:domains")) || [];
  await kv.putJSON("idx:domains", ids.filter((i) => i !== id));

  // Delete all links under this domain
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
  for (const linkId of linkIds) {
    const link = await kv.getJSON<ShortLink>(`link:${linkId}`);
    if (link && link.domainId === id) {
      await deleteLinkById(linkId, kv);
    }
  }
}

// ══════════════════════════════════════════
//  LINK OPERATIONS
// ══════════════════════════════════════════

export async function getLinks(params: {
  page: number;
  limit: number;
  search?: string;
  domainId?: string;
  type?: string;
  isActive?: string;
}): Promise<{ links: any[]; total: number; page: number; totalPages: number }> {
  const kv = await getKV();
  const allIds = (await kv.getJSON<string[]>("idx:links")) || [];

  // Load all links and filter
  const allLinks: Array<ShortLink & { _count?: { clicks: number; targets: number } }> = [];
  for (const id of allIds) {
    const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
    if (!link) continue;
    if (link.isDeleted) continue;

    // Apply filters
    if (params.search) {
      const s = params.search.toLowerCase();
      if (
        !link.slug.toLowerCase().includes(s) &&
        !link.title.toLowerCase().includes(s) &&
        !link.description.toLowerCase().includes(s)
      )
        continue;
    }
    if (params.domainId && link.domainId !== params.domainId) continue;
    if (params.type && link.type !== params.type) continue;
    if (params.isActive && link.isActive !== (params.isActive === "true")) continue;

    // Get click count
    const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${id}`)) || [];
    allLinks.push({
      ...link,
      targets: undefined,
      _count: {
        clicks: clickIds.length,
        targets: link.targets ? link.targets.length : 0,
      },
    });
  }

  // Sort by createdAt desc
  allLinks.sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const total = allLinks.length;
  const totalPages = Math.ceil(total / params.limit);
  const start = (params.page - 1) * params.limit;
  const paged = allLinks.slice(start, start + params.limit);

  // Enrich with domain info
  const enriched = await Promise.all(
    paged.map(async (link) => {
      const domain = await kv.getJSON<ShortDomain>(`domain:${link.domainId}`);
      return {
        ...link,
        domain: domain
          ? { id: domain.id, domain: domain.domain, slug: domain.slug }
          : null,
      };
    })
  );

  return {
    links: enriched,
    total,
    page: params.page,
    totalPages,
  };
}

export async function getLinkById(id: string): Promise<any | null> {
  const kv = await getKV();
  const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
  if (!link || link.isDeleted) return null;

  const domain = await kv.getJSON<ShortDomain>(`domain:${link.domainId}`);
  const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${id}`)) || [];

  return {
    ...link,
    targets: link.targets || [],
    domain: domain
      ? { id: domain.id, domain: domain.domain, slug: domain.slug }
      : null,
    _count: { clicks: clickIds.length, targets: (link.targets || []).length },
  };
}

export async function getLinkBySlug(
  domainId: string,
  slug: string
): Promise<(ShortLink & { targets?: LinkTarget[] }) | null> {
  const kv = await getKV();
  const lookupKey = `lookup:link:${domainId}:${slug}`;
  const linkId = await kv.get(lookupKey);
  if (!linkId) return null;

  const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${linkId}`);
  if (!link || link.isDeleted) return null;
  return link;
}

export async function createLink(data: {
  slug: string;
  domainId: string;
  type: "basic" | "multi";
  mode: "random" | "sequential";
  title?: string;
  description?: string;
  password?: string;
  expiredAt?: string | null;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  utmContent?: string;
  utmTerm?: string;
  targets?: Array<{
    url: string;
    clickLimit?: number;
    country?: string;
    ipList?: string;
    order?: number;
  }>;
}): Promise<any> {
  const kv = await getKV();

  // Verify domain exists
  const domain = await kv.getJSON<ShortDomain>(`domain:${data.domainId}`);
  if (!domain) throw new Error("Domain not found");

  // Check slug uniqueness
  const lookupKey = `lookup:link:${data.domainId}:${data.slug}`;
  const existingId = await kv.get(lookupKey);
  if (existingId) throw new Error("Slug already exists for this domain");

  const id = generateId();
  const targets: LinkTarget[] = (data.targets || []).map((t, i) => ({
    id: generateId(),
    linkId: id,
    url: t.url,
    clickLimit: t.clickLimit || 0,
    currentClicks: 0,
    country: t.country || "ALL",
    ipList: t.ipList || "",
    order: t.order ?? i,
    isActive: true,
    lastChecked: null,
    isHealthy: null,
    httpStatus: null,
    createdAt: nowISO(),
    updatedAt: nowISO(),
  }));

  const link: ShortLink & { targets?: LinkTarget[] } = {
    id,
    slug: data.slug,
    domainId: data.domainId,
    type: data.type,
    mode: data.mode,
    title: data.title || "",
    description: data.description || "",
    password: data.password || "",
    ogTitle: data.ogTitle || "",
    ogDescription: data.ogDescription || "",
    ogImage: data.ogImage || "",
    utmSource: data.utmSource || "",
    utmMedium: data.utmMedium || "",
    utmCampaign: data.utmCampaign || "",
    utmContent: data.utmContent || "",
    utmTerm: data.utmTerm || "",
    isActive: true,
    expiredAt: data.expiredAt || null,
    createdAt: nowISO(),
    updatedAt: nowISO(),
    targets,
  };

  await kv.putJSON(`link:${id}`, link);
  await kv.put(lookupKey, id);

  const ids = (await kv.getJSON<string[]>("idx:links")) || [];
  ids.unshift(id);
  await kv.putJSON("idx:links", ids);

  return {
    ...link,
    targets,
    domain: { id: domain.id, domain: domain.domain, slug: domain.slug },
  };
}

export async function updateLink(
  id: string,
  data: Partial<{
    slug: string;
    domainId: string;
    type: string;
    mode: string;
    title: string;
    description: string;
    password: string;
    ogTitle: string;
    ogDescription: string;
    ogImage: string;
    utmSource: string;
    utmMedium: string;
    utmCampaign: string;
    utmContent: string;
    utmTerm: string;
    isActive: boolean;
    expiredAt: string | null;
    targets: Array<{
      url: string;
      clickLimit?: number;
      country?: string;
      ipList?: string;
      order?: number;
      isActive?: boolean;
    }>;
  }>
): Promise<any | null> {
  const kv = await getKV();
  const existing = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
  if (!existing || existing.isDeleted) return null;

  const newSlug = data.slug !== undefined ? data.slug : existing.slug;
  const newDomainId = data.domainId !== undefined ? data.domainId : existing.domainId;

  // Check slug uniqueness if changed
  if (data.slug !== undefined || data.domainId !== undefined) {
    const newLookupKey = `lookup:link:${newDomainId}:${newSlug}`;
    const conflictId = await kv.get(newLookupKey);
    if (conflictId && conflictId !== id) {
      throw new Error("Slug already exists for this domain");
    }
    // Update lookups
    if (data.slug !== undefined || data.domainId !== undefined) {
      await kv.delete(`lookup:link:${existing.domainId}:${existing.slug}`);
      await kv.put(newLookupKey, id);
    }
  }

  // Handle targets replacement
  let targets = existing.targets || [];
  if (Array.isArray(data.targets)) {
    targets = data.targets.map((t, i) => ({
      id: generateId(),
      linkId: id,
      url: t.url,
      clickLimit: t.clickLimit || 0,
      currentClicks: 0,
      country: t.country || "ALL",
      ipList: t.ipList || "",
      order: t.order ?? i,
      isActive: t.isActive !== undefined ? t.isActive : true,
      lastChecked: null,
      isHealthy: null,
      httpStatus: null,
      createdAt: nowISO(),
      updatedAt: nowISO(),
    }));
  }

  const updated: ShortLink & { targets?: LinkTarget[] } = {
    ...existing,
    ...(data.slug !== undefined && { slug: data.slug }),
    ...(data.domainId !== undefined && { domainId: data.domainId }),
    ...(data.type !== undefined && { type: data.type }),
    ...(data.mode !== undefined && { mode: data.mode }),
    ...(data.title !== undefined && { title: data.title }),
    ...(data.description !== undefined && { description: data.description }),
    ...(data.password !== undefined && { password: data.password }),
    ...(data.ogTitle !== undefined && { ogTitle: data.ogTitle }),
    ...(data.ogDescription !== undefined && { ogDescription: data.ogDescription }),
    ...(data.ogImage !== undefined && { ogImage: data.ogImage }),
    ...(data.utmSource !== undefined && { utmSource: data.utmSource }),
    ...(data.utmMedium !== undefined && { utmMedium: data.utmMedium }),
    ...(data.utmCampaign !== undefined && { utmCampaign: data.utmCampaign }),
    ...(data.utmContent !== undefined && { utmContent: data.utmContent }),
    ...(data.utmTerm !== undefined && { utmTerm: data.utmTerm }),
    ...(data.isActive !== undefined && { isActive: data.isActive }),
    ...(data.expiredAt !== undefined && {
      expiredAt: data.expiredAt ? data.expiredAt : null,
    }),
    targets,
    updatedAt: nowISO(),
  };

  await kv.putJSON(`link:${id}`, updated);

  const domain = await kv.getJSON<ShortDomain>(`domain:${updated.domainId}`);
  return {
    ...updated,
    targets,
    domain: domain
      ? { id: domain.id, domain: domain.domain, slug: domain.slug }
      : null,
  };
}

async function deleteLinkById(id: string, kv: any): Promise<void> {
  const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
  if (!link) return;

  // Soft delete
  await kv.putJSON(`link:${id}`, { ...link, isDeleted: true });
  await kv.delete(`lookup:link:${link.domainId}:${link.slug}`);

  // Delete clicks
  const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${id}`)) || [];
  for (const clickId of clickIds) {
    await kv.delete(`click:${clickId}`);
  }
  await kv.delete(`idx:clicks:${id}`);

  // Remove from index
  const ids = (await kv.getJSON<string[]>("idx:links")) || [];
  await kv.putJSON("idx:links", ids.filter((i: string) => i !== id));
}

export async function deleteLink(id: string): Promise<void> {
  const kv = await getKV();
  await deleteLinkById(id, kv);
}

export async function countLinks(where?: {
  isActive?: boolean;
}): Promise<number> {
  const kv = await getKV();
  const ids = (await kv.getJSON<string[]>("idx:links")) || [];
  if (!where) return ids.length;

  let count = 0;
  for (const id of ids) {
    const link = await kv.getJSON<ShortLink>(`link:${id}`);
    if (!link || link.isDeleted) continue;
    if (where.isActive !== undefined && link.isActive !== where.isActive) continue;
    count++;
  }
  return count;
}

export async function updateManyLinks(
  ids: string[],
  data: { isActive?: boolean; domainId?: string }
): Promise<number> {
  const kv = await getKV();
  let count = 0;
  for (const id of ids) {
    const link = await kv.getJSON<ShortLink>(`link:${id}`);
    if (!link || link.isDeleted) continue;

    const updated = {
      ...link,
      ...(data.isActive !== undefined && { isActive: data.isActive }),
      ...(data.domainId !== undefined && { domainId: data.domainId }),
      updatedAt: nowISO(),
    };
    await kv.putJSON(`link:${id}`, updated);
    count++;
  }
  return count;
}

export async function deleteManyLinks(ids: string[]): Promise<number> {
  const kv = await getKV();
  let count = 0;
  for (const id of ids) {
    await deleteLinkById(id, kv);
    count++;
  }
  return count;
}

// ══════════════════════════════════════════
//  CLICK OPERATIONS
// ══════════════════════════════════════════

export async function recordClick(data: {
  linkId: string;
  targetId: string;
  ip: string;
  country: string;
  device: string;
  browser: string;
  os: string;
  referrer: string;
}): Promise<Click> {
  const kv = await getKV();
  const id = generateId();

  const click: Click = {
    id,
    linkId: data.linkId,
    targetId: data.targetId,
    ip: data.ip,
    country: data.country,
    city: "",
    region: "",
    device: data.device,
    browser: data.browser,
    os: data.os,
    referrer: data.referrer,
    createdAt: nowISO(),
  };

  await kv.putJSON(`click:${id}`, click);

  // Add to link's click index
  const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${data.linkId}`)) || [];
  clickIds.unshift(id);
  // Keep max 10000 clicks per link to prevent KV value from being too large
  if (clickIds.length > 10000) clickIds.length = 10000;
  await kv.putJSON(`idx:clicks:${data.linkId}`, clickIds);

  // Add to global recent clicks index
  const recentIds = (await kv.getJSON<string[]>("idx:clicks:recent")) || [];
  recentIds.unshift(id);
  // Keep max 500 recent clicks
  if (recentIds.length > 500) recentIds.length = 500;
  await kv.putJSON("idx:clicks:recent", recentIds);

  // Update target click count
  const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(
    `link:${data.linkId}`
  );
  if (link?.targets) {
    const target = link.targets.find((t) => t.id === data.targetId);
    if (target) {
      target.currentClicks += 1;
      await kv.putJSON(`link:${data.linkId}`, link);
    }
  }

  return click;
}

export async function getClicksByLink(
  linkId: string,
  params: { page: number; limit: number; startDate?: string; endDate?: string }
): Promise<{ clicks: any[]; total: number; page: number; totalPages: number }> {
  const kv = await getKV();
  const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${linkId}`)) || [];

  // Load all clicks and filter by date
  let clicks: (Click & { target?: { id: string; url: string } })[] = [];
  for (const id of clickIds) {
    const click = await kv.getJSON<Click>(`click:${id}`);
    if (!click) continue;

    if (params.startDate && click.createdAt < params.startDate) continue;
    if (params.endDate && click.createdAt > params.endDate) continue;

    // Get target info
    const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(
      `link:${linkId}`
    );
    const target = link?.targets?.find((t) => t.id === click.targetId);

    clicks.push({
      ...click,
      target: target ? { id: target.id, url: target.url } : null,
    });
  }

  // Sort by date desc
  clicks.sort(
    (a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const total = clicks.length;
  const totalPages = Math.ceil(total / params.limit);
  const start = (params.page - 1) * params.limit;
  const paged = clicks.slice(start, start + params.limit);

  return { clicks: paged, total, page: params.page, totalPages };
}

export async function getTotalClicksCount(): Promise<number> {
  const kv = await getKV();
  const recentIds = (await kv.getJSON<string[]>("idx:clicks:recent")) || [];
  // This is approximate - counts from the recent index
  // For accurate total, we'd need to iterate all link click indices
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
  let total = 0;
  for (const linkId of linkIds) {
    const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${linkId}`)) || [];
    total += clickIds.length;
  }
  return total;
}

export async function getRecentClicks(limit: number): Promise<any[]> {
  const kv = await getKV();
  const recentIds = (await kv.getJSON<string[]>("idx:clicks:recent")) || [];

  const clicks: any[] = [];
  for (const id of recentIds.slice(0, limit)) {
    const click = await kv.getJSON<Click>(`click:${id}`);
    if (!click) continue;

    const link = await kv.getJSON<ShortLink>(`link:${click.linkId}`);
    clicks.push({
      ...click,
      link: link ? { id: link.id, slug: link.slug } : null,
    });
  }

  return clicks;
}

export async function deleteAllClicks(): Promise<number> {
  const kv = await getKV();
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
  let count = 0;

  for (const linkId of linkIds) {
    const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${linkId}`)) || [];
    for (const clickId of clickIds) {
      await kv.delete(`click:${clickId}`);
      count++;
    }
    await kv.delete(`idx:clicks:${linkId}`);
  }

  await kv.delete("idx:clicks:recent");

  // Reset target click counts
  for (const linkId of linkIds) {
    const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(
      `link:${linkId}`
    );
    if (link?.targets) {
      for (const target of link.targets) {
        target.currentClicks = 0;
      }
      await kv.putJSON(`link:${linkId}`, link);
    }
  }

  return count;
}

export async function getClicksSince(since: Date): Promise<Click[]> {
  const kv = await getKV();
  const recentIds = (await kv.getJSON<string[]>("idx:clicks:recent")) || [];
  const sinceISO = since.toISOString();

  const clicks: Click[] = [];
  for (const id of recentIds) {
    const click = await kv.getJSON<Click>(`click:${id}`);
    if (!click) continue;
    if (click.createdAt >= sinceISO) {
      clicks.push(click);
    }
  }
  return clicks;
}

export async function getAllClicksForAnalytics(): Promise<Click[]> {
  const kv = await getKV();
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
  const clicks: Click[] = [];

  for (const linkId of linkIds) {
    const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${linkId}`)) || [];
    for (const clickId of clickIds) {
      const click = await kv.getJSON<Click>(`click:${clickId}`);
      if (click) clicks.push(click);
    }
  }

  return clicks;
}

// ══════════════════════════════════════════
//  ANALYTICS
// ══════════════════════════════════════════

export async function getAnalyticsOverview(): Promise<{
  totalLinks: number;
  activeLinks: number;
  totalDomains: number;
  activeDomains: number;
  totalClicks: number;
  clicksToday: number;
  clicksThisWeek: number;
  clicksThisMonth: number;
  topLinks: any[];
  clicksByCountry: { country: string; count: number }[];
  clicksByDevice: { device: string; count: number }[];
  clicksByBrowser: { browser: string; count: number }[];
  clicksByOs: { os: string; count: number }[];
  recentClicks: any[];
  clicksOverTime: { date: string; clicks: number }[];
}> {
  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  const startOfWeek = new Date(startOfDay);
  const day = startOfWeek.getDay();
  startOfWeek.setDate(startOfWeek.getDate() - (day === 0 ? 6 : day - 1));
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const allClicks = await getAllClicksForAnalytics();

  const totalLinks = await countLinks();
  const activeLinks = await countLinks({ isActive: true });
  const totalDomains = await getDomainCount();
  const activeDomains = await getDomainCount({ isActive: true });
  const totalClicks = allClicks.length;

  // Time-filtered clicks
  const todayClicks = allClicks.filter(
    (c) => new Date(c.createdAt) >= startOfDay
  );
  const weekClicks = allClicks.filter(
    (c) => new Date(c.createdAt) >= startOfWeek
  );
  const monthClicks = allClicks.filter(
    (c) => new Date(c.createdAt) >= startOfMonth
  );

  // Group by various dimensions
  const countryMap: Record<string, number> = {};
  const deviceMap: Record<string, number> = {};
  const browserMap: Record<string, number> = {};
  const osMap: Record<string, number> = {};
  const dayMap: Record<string, number> = {};

  for (const click of allClicks) {
    if (click.country) countryMap[click.country] = (countryMap[click.country] || 0) + 1;
    if (click.device) deviceMap[click.device] = (deviceMap[click.device] || 0) + 1;
    if (click.browser) browserMap[click.browser] = (browserMap[click.browser] || 0) + 1;
    if (click.os) osMap[click.os] = (osMap[click.os] || 0) + 1;

    const dayKey = click.createdAt.split("T")[0];
    dayMap[dayKey] = (dayMap[dayKey] || 0) + 1;
  }

  // Top links by click count
  const kv = await getKV();
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
  const linkClickCounts: Array<{ id: string; slug: string; title: string; clickCount: number }> = [];
  for (const linkId of linkIds) {
    const link = await kv.getJSON<ShortLink>(`link:${linkId}`);
    if (!link || link.isDeleted) continue;
    const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${linkId}`)) || [];
    linkClickCounts.push({
      id: link.id,
      slug: link.slug,
      title: link.title,
      clickCount: clickIds.length,
    });
  }
  linkClickCounts.sort((a, b) => b.clickCount - a.clickCount);

  // Build clicks over time for last 7 days
  const clicksOverTime: { date: string; clicks: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const key = d.toISOString().split("T")[0];
    clicksOverTime.push({
      date: key,
      clicks: dayMap[key] || 0,
    });
  }

  // Recent clicks
  const recentClicks = await getRecentClicks(20);

  return {
    totalLinks,
    activeLinks,
    totalDomains,
    activeDomains,
    totalClicks,
    clicksToday: todayClicks.length,
    clicksThisWeek: weekClicks.length,
    clicksThisMonth: monthClicks.length,
    topLinks: linkClickCounts.slice(0, 10),
    clicksByCountry: Object.entries(countryMap)
      .map(([country, count]) => ({ country, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10),
    clicksByDevice: Object.entries(deviceMap)
      .map(([device, count]) => ({ device, count }))
      .sort((a, b) => b.count - a.count),
    clicksByBrowser: Object.entries(browserMap)
      .map(([browser, count]) => ({ browser, count }))
      .sort((a, b) => b.count - a.count),
    clicksByOs: Object.entries(osMap)
      .map(([os, count]) => ({ os, count }))
      .sort((a, b) => b.count - a.count),
    recentClicks,
    clicksOverTime,
  };
}

// ══════════════════════════════════════════
//  SETTINGS
// ══════════════════════════════════════════

const SETTINGS_KEY = "app:settings";

const DEFAULT_SETTINGS: Record<string, string> = {
  redirectStatus: "301",
  healthInterval: "300",
  defaultUtmSource: "",
  defaultUtmMedium: "",
  defaultUtmCampaign: "",
  defaultUtmContent: "",
  defaultUtmTerm: "",
};

export async function getAllSettings(): Promise<Record<string, string>> {
  const kv = await getKV();
  const saved = (await kv.getJSON<Record<string, string>>(SETTINGS_KEY)) || {};
  return { ...DEFAULT_SETTINGS, ...saved };
}

export async function getSetting(
  key: string,
  defaultValue: string = ""
): Promise<string> {
  const all = await getAllSettings();
  return all[key] ?? defaultValue;
}

export async function updateSettings(
  settings: Record<string, string>
): Promise<{ success: boolean; updated: number }> {
  const kv = await getKV();
  const existing = (await kv.getJSON<Record<string, string>>(SETTINGS_KEY)) || {};
  const merged = { ...existing, ...settings };
  await kv.putJSON(SETTINGS_KEY, merged);
  return { success: true, updated: Object.keys(settings).length };
}

export async function updateSetting(
  key: string,
  value: string
): Promise<{ success: boolean; key: string; value: string }> {
  return updateSettings({ [key]: value }).then(() => ({
    success: true,
    key,
    value,
  }));
}

export async function deleteAllSettings(): Promise<void> {
  const kv = await getKV();
  await kv.delete(SETTINGS_KEY);
}

// ══════════════════════════════════════════
//  IMPORT / EXPORT
// ══════════════════════════════════════════

export async function exportAll(includeClicks: boolean): Promise<{
  links: any[];
  domains: ShortDomain[];
  clicks: Click[];
  exportedAt: string;
}> {
  const domains = await getAllDomains();
  const kv = await getKV();
  const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];

  const links: any[] = [];
  for (const id of linkIds) {
    const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
    if (!link || link.isDeleted) continue;

    const domain = await kv.getJSON<ShortDomain>(`domain:${link.domainId}`);
    links.push({
      ...link,
      targets: link.targets || [],
      domain: domain
        ? { id: domain.id, domain: domain.domain, slug: domain.slug }
        : null,
    });
  }

  let clicks: Click[] = [];
  if (includeClicks) {
    clicks = await getAllClicksForAnalytics();
  }

  return {
    links,
    domains,
    clicks,
    exportedAt: nowISO(),
  };
}

export async function importData(data: {
  links?: any[];
  domains?: any[];
}): Promise<{
  imported: { domains: number; links: number };
  skipped: number;
  errors: string[];
}> {
  const errors: string[] = [];
  let domainsCreated = 0;
  let linksCreated = 0;
  let skipped = 0;

  // Import domains
  if (data.domains?.length) {
    for (const d of data.domains) {
      if (!d.domain) {
        errors.push("Skipped domain with empty domain value");
        skipped++;
        continue;
      }
      try {
        await createDomain({
          domain: d.domain,
          slug: d.slug || "",
          isActive: d.isActive !== undefined ? d.isActive : true,
        });
        domainsCreated++;
      } catch (err: any) {
        errors.push(`Domain "${d.domain}": ${err.message}`);
        skipped++;
      }
    }
  }

  // Import links
  if (data.links?.length) {
    const allDomains = await getAllDomains();
    const domainByString = new Map(allDomains.map((d) => [d.domain, d.id]));

    for (const linkData of data.links) {
      if (!linkData.slug) {
        errors.push("Skipped link with empty slug");
        skipped++;
        continue;
      }

      try {
        let domainId = linkData.domainId;

        // Try to resolve by domain string
        if (domainId && !domainId.startsWith(Date.now().toString(36)[0])) {
          const mapped = domainByString.get(domainId);
          if (mapped) domainId = mapped;
        }

        if (!domainId) {
          errors.push(`Link "${linkData.slug}": No valid domain ID`);
          skipped++;
          continue;
        }

        const targets = linkData.targets?.length
          ? linkData.targets
          : linkData.url
            ? [{ url: linkData.url }]
            : [];

        if (targets.length === 0) {
          errors.push(`Link "${linkData.slug}": No targets`);
          skipped++;
          continue;
        }

        await createLink({
          slug: linkData.slug,
          domainId,
          type: linkData.type || "basic",
          mode: linkData.mode || "sequential",
          title: linkData.title || "",
          description: linkData.description || "",
          targets,
        });

        linksCreated++;
      } catch (err: any) {
        errors.push(`Link "${linkData.slug}": ${err.message}`);
        skipped++;
      }
    }
  }

  return {
    imported: { domains: domainsCreated, links: linksCreated },
    skipped,
    errors,
  };
}

// ══════════════════════════════════════════
//  DANGER ZONE
// ══════════════════════════════════════════

export async function dangerOperation(
  action: string
): Promise<{ success: boolean; deleted: Record<string, number> }> {
  const kv = await getKV();

  switch (action) {
    case "deleteAllLinks": {
      const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
      let linkCount = 0;
      let targetCount = 0;
      let clickCount = 0;

      for (const id of linkIds) {
        const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(
          `link:${id}`
        );
        if (link) {
          linkCount++;
          targetCount += (link.targets || []).length;
          const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${id}`)) || [];
          clickCount += clickIds.length;
          for (const cid of clickIds) await kv.delete(`click:${cid}`);
          await kv.delete(`idx:clicks:${id}`);
          await kv.delete(`link:${id}`);
        }
      }
      await kv.putJSON("idx:links", []);
      await kv.delete("idx:clicks:recent");

      return { success: true, deleted: { links: linkCount, targets: targetCount, clicks: clickCount, domains: 0 } };
    }

    case "deleteAllClicks": {
      const count = await deleteAllClicks();
      return { success: true, deleted: { links: 0, targets: 0, clicks: count, domains: 0 } };
    }

    case "resetDatabase": {
      const linkIds = (await kv.getJSON<string[]>("idx:links")) || [];
      const domainIds = (await kv.getJSON<string[]>("idx:domains")) || [];
      let linkCount = 0;
      let targetCount = 0;
      let clickCount = 0;

      for (const id of linkIds) {
        const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${id}`);
        if (link) {
          linkCount++;
          targetCount += (link.targets || []).length;
          const clickIds = (await kv.getJSON<string[]>(`idx:clicks:${id}`)) || [];
          clickCount += clickIds.length;
          for (const cid of clickIds) await kv.delete(`click:${cid}`);
          await kv.delete(`idx:clicks:${id}`);
          await kv.delete(`link:${id}`);
        }
      }

      for (const id of domainIds) {
        const domain = await kv.getJSON<ShortDomain>(`domain:${id}`);
        if (domain) {
          await kv.delete(`lookup:domain:${domain.domain}`);
        }
        await kv.delete(`domain:${id}`);
      }

      await kv.putJSON("idx:links", []);
      await kv.putJSON("idx:domains", []);
      await kv.delete("idx:clicks:recent");
      await kv.delete(SETTINGS_KEY);

      return {
        success: true,
        deleted: { links: linkCount, targets: targetCount, clicks: clickCount, domains: domainIds.length },
      };
    }

    default:
      throw new Error("Invalid action");
  }
}

// ══════════════════════════════════════════
//  HEALTH CHECK
// ══════════════════════════════════════════

export async function healthCheck(linkId?: string): Promise<{
  checked: number;
  healthy: number;
  unhealthy: number;
  results: Array<{ targetId: string; url: string; isHealthy: boolean; httpStatus: number | null }>;
}> {
  const kv = await getKV();

  let linksToCheck: Array<{ id: string; targets: LinkTarget[] }> = [];

  if (linkId) {
    const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${linkId}`);
    if (!link) throw new Error("Link not found");
    linksToCheck = [{ id: link.id, targets: link.targets || [] }];
  } else {
    const allIds = (await kv.getJSON<string[]>("idx:links")) || [];
    for (const id of allIds) {
      const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[]; isActive?: boolean }>(`link:${id}`);
      if (link && link.isActive && !link.isDeleted) {
        linksToCheck.push({ id: link.id, targets: (link.targets || []).filter((t) => t.isActive) });
      }
    }
  }

  const allTargets = linksToCheck.flatMap((l) => l.targets);
  if (allTargets.length === 0) {
    return { checked: 0, healthy: 0, unhealthy: 0, results: [] };
  }

  const results: Array<{ targetId: string; url: string; isHealthy: boolean; httpStatus: number | null }> = [];

  for (const target of allTargets) {
    try {
      const response = await fetch(target.url, {
        method: "HEAD",
        redirect: "follow",
        signal: AbortSignal.timeout(5000),
      });
      const isHealthy = response.ok || response.status < 500;
      results.push({ targetId: target.id, url: target.url, isHealthy, httpStatus: response.status });

      // Update target in link data
      const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${target.linkId}`);
      if (link?.targets) {
        const t = link.targets.find((x) => x.id === target.id);
        if (t) {
          t.isHealthy = isHealthy;
          t.httpStatus = response.status;
          t.lastChecked = nowISO();
          await kv.putJSON(`link:${target.linkId}`, link);
        }
      }
    } catch {
      results.push({ targetId: target.id, url: target.url, isHealthy: false, httpStatus: null });

      const link = await kv.getJSON<ShortLink & { targets?: LinkTarget[] }>(`link:${target.linkId}`);
      if (link?.targets) {
        const t = link.targets.find((x) => x.id === target.id);
        if (t) {
          t.isHealthy = false;
          t.lastChecked = nowISO();
          await kv.putJSON(`link:${target.linkId}`, link);
        }
      }
    }
  }

  const healthy = results.filter((r) => r.isHealthy).length;
  return { checked: results.length, healthy, unhealthy: results.length - healthy, results };
}

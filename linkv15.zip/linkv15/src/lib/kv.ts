// Cloudflare KV abstraction with in-memory fallback for local development
// On Cloudflare Pages: uses real KV binding via getRequestContext()
// On local dev (next dev): uses in-memory Map (data resets on restart)

export interface KVStore {
  get(key: string): Promise<string | null>;
  getJSON<T>(key: string): Promise<T | null>;
  put(key: string, value: string): Promise<void>;
  putJSON(key: string, value: unknown): Promise<void>;
  delete(key: string): Promise<void>;
  list(options?: { prefix?: string; limit?: number }): Promise<Array<{ name: string }>>;
}

// ─── In-memory fallback for local development ───
class MemoryKV implements KVStore {
  private store = new Map<string, string>();

  async get(key: string): Promise<string | null> {
    return this.store.get(key) ?? null;
  }

  async getJSON<T>(key: string): Promise<T | null> {
    const raw = this.store.get(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  }

  async put(key: string, value: string): Promise<void> {
    this.store.set(key, value);
  }

  async putJSON(key: string, value: unknown): Promise<void> {
    this.store.set(key, JSON.stringify(value));
  }

  async delete(key: string): Promise<void> {
    this.store.delete(key);
  }

  async list(options?: { prefix?: string; limit?: number }): Promise<Array<{ name: string }>> {
    const prefix = options?.prefix || "";
    let keys = [...this.store.keys()].filter((k) => k.startsWith(prefix));
    if (options?.limit) keys = keys.slice(0, options.limit);
    return keys.map((k) => ({ name: k }));
  }
}

// ─── Cloudflare KV wrapper ───
class CloudflareKV implements KVStore {
  private kv: any;

  constructor(kv: any) {
    this.kv = kv;
  }

  async get(key: string): Promise<string | null> {
    return this.kv.get(key);
  }

  async getJSON<T>(key: string): Promise<T | null> {
    return (await this.kv.get(key, { type: "json" })) as T | null;
  }

  async put(key: string, value: string): Promise<void> {
    return this.kv.put(key, value);
  }

  async putJSON(key: string, value: unknown): Promise<void> {
    return this.kv.put(key, JSON.stringify(value));
  }

  async delete(key: string): Promise<void> {
    return this.kv.delete(key);
  }

  async list(options?: { prefix?: string; limit?: number }): Promise<Array<{ name: string }>> {
    const result = await this.kv.list({
      prefix: options?.prefix,
      limit: options?.limit,
    });
    return result.keys.map((k: any) => ({ name: k.name }));
  }
}

let _store: KVStore | null = null;
let _isMemory = false;

export async function getKV(): Promise<KVStore> {
  if (_store) return _store;

  try {
    const { getRequestContext } = await import("@opennextjs/cloudflare");
    const ctx = getRequestContext();
    if (ctx.env?.KV) {
      _store = new CloudflareKV(ctx.env.KV);
    } else {
      _store = new MemoryKV();
      _isMemory = true;
    }
  } catch {
    _store = new MemoryKV();
    _isMemory = true;
  }

  return _store;
}

export function isMemoryKV(): boolean {
  return _isMemory;
}

"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import type { ShortDomain } from "@/lib/types";

interface EditDomainDialogProps {
  open: boolean;
  onClose: () => void;
  domain: ShortDomain;
  onUpdate: (id: string, data: { domain: string; slug: string }) => Promise<void>;
}

export default function EditDomainDialog({ open, onClose, domain, onUpdate }: EditDomainDialogProps) {
  const [domainName, setDomainName] = useState(domain.domain);
  const [slug, setSlug] = useState(domain.slug);
  const [saving, setSaving] = useState(false);

  React.useEffect(() => {
    if (open) {
      setDomainName(domain.domain);
      setSlug(domain.slug);
    }
  }, [open, domain]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domainName.trim()) return;
    setSaving(true);
    try {
      await onUpdate(domain.id, { domain: domainName, slug });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent description="Edit domain settings.">
        <DialogHeader>
          <DialogTitle>Edit Domain</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Domain *</Label>
            <Input
              value={domainName}
              onChange={(e) => setDomainName(e.target.value)}
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label>Slug</Label>
            <Input
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !domainName.trim()}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

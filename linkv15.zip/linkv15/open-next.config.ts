import { defineCloudflareConfig } from "@opennextjs/cloudflare";

export default defineCloudflareConfig({
  override: {
    // Ensure middleware runs on all routes for custom domain handling
    middleware: {
      external: true,
    },
  },
});

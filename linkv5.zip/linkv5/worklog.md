---
Task ID: 1
Agent: main
Task: Fix Prisma 7 error - pin to Prisma v6, full project audit

Work Log:
- User reported `npx prisma generate` failing with Prisma CLI 7.8.0
- Error: `url` property no longer supported in schema datasource (Prisma 7 breaking change)
- Pinned `prisma`, `@prisma/client` to exact v6.11.1 in package.json (removed `^` prefix)
- `@prisma/adapter-neon` was already pinned to 6.19.3
- Full audit of ALL 45+ source files in the project

Stage Summary:
- package.json: `prisma: "6.11.1"`, `@prisma/client: "6.11.1"` (pinned, no caret)
- NO imports of deleted packages (next-auth, next-intl, sharp, @dnd-kit, react-syntax-highlighter) found anywhere
- ALL pages verified correct: LoginPage, OverviewPage, LinksPage, CreateLinkPage, EditLinkPage, DomainsPage, AnalyticsPage, BulkOperationsPage, SettingsPage, NotFoundPage
- ALL API routes verified correct: auth, links, domains, analytics, settings, export, import, danger, bulk
- ALL components verified correct: DashboardLayout, SidebarNav, Header, LinkTable, LinkFormBasic, LinkFormMulti, LinkTargetRow, QRCodeDialog, LinkAnalyticsDialog, DomainCard, AddDomainDialog, EditDomainDialog, StatsCards, ClicksChart, CountryChart, DeviceChart
- Infrastructure verified: middleware.ts, db.ts, auth.ts, store.ts, api.ts, types.ts, cloudflare.ts, layout.tsx
- User needs to: delete node_modules + package-lock.json, run npm install, then npx prisma generate

# ShortURL Platform

Platform manajemen Short URL (clone Dub.co) yang dibangun dengan Next.js, Prisma, dan Cloudflare Pages. Mendukung multi-domain, multi-target routing, analytics, QR Code, dan banyak fitur lainnya.

## Tech Stack

| Technology              | Versi / Keterangan                   |
|-------------------------|--------------------------------------|
| **Next.js**             | 15.3.4 (App Router)                  |
| **TypeScript**          | 5.x                                  |
| **Prisma**              | 6.11.1 (driverAdapters)              |
| **PostgreSQL**          | Neon (serverless, HTTP-based)        |
| **Tailwind CSS**        | 4.x                                  |
| **shadcn/ui**           | Radix UI + Tailwind                  |
| **Cloudflare Pages**    | Deployment via @opennextjs/cloudflare |
| **QR Code**             | react-qr-code (SVG, edge-compatible) |
| **State Management**    | Zustand                              |

## Quick Start

```bash
# 1. Clone repository
git clone https://github.com/username/shorturl-platform.git
cd shorturl-platform

# 2. Install dependencies
npm install --legacy-peer-deps

# 3. Setup environment variables
cp .env.example .env
# Edit .env — isi DATABASE_URL, DASHBOARD_TOKEN, APP_DOMAIN

# 4. Push schema & generate Prisma Client
npx prisma db push
npx prisma generate

# 5. Jalankan development server
npm run dev
# Buka http://localhost:3000
```

## Environment Variables

| Variable                   | Required | Description                                                |
|----------------------------|----------|------------------------------------------------------------|
| `DATABASE_URL`             | ✅       | Neon PostgreSQL connection string                          |
| `DASHBOARD_TOKEN`          | ✅       | Auth token untuk login dashboard (min. 12 karakter)        |
| `APP_DOMAIN`               | ✅       | Domain utama dashboard (middleware routing)                |
| `CLOUDFLARE_ACCOUNT_ID`    | Opsional | CF Account ID (auto-verify domain)                         |
| `CLOUDFLARE_API_TOKEN`     | Opsional | CF API Token — Zone:Read, Pages:Edit                      |
| `CLOUDFLARE_PAGES_PROJECT` | Opsional | Nama project CF Pages                                      |

## Deployment

### Cloudflare Pages

```bash
# Build command:
npx prisma generate && npx opennextjs-cloudflare build

# Build output directory:
.open-next
```

Untuk panduan lengkap deployment ke Cloudflare Pages, custom domain setup, dan troubleshooting, lihat **[Panduan Instalasi & Deployment](./docs/INSTALLATION-GUIDE.md)**.

## Fitur Utama

- **Multi-domain** — Satu dashboard, banyak domain untuk short URL
- **Multi-target routing** — Sequential atau random redirect ke multiple URL
- **Analytics** — Tracking klik, device, browser, lokasi, referrer
- **QR Code** — Generate QR Code SVG untuk setiap short URL
- **Custom domain verification** — Auto-verify via Cloudflare API
- **Health check** — Monitoring status target URL
- **Bulk operations** — Import, export, migrasi domain secara massal
- **Dashboard** — UI modern dengan shadcn/ui, dark mode support

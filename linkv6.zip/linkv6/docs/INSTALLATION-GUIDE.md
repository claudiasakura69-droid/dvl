# Panduan Instalasi & Deployment — ShortURL Platform

> Platform manajemen ShortURL (clone Dub.co) yang dibangun dengan **Next.js 15.3.4 + Prisma 6.11.1 + PostgreSQL (Neon) + Cloudflare Pages**.
>
> Panduan ini ditulis dalam Bahasa Indonesia dengan istilah teknis dalam bahasa Inggris untuk kemudahan referensi.

---

## Daftar Isi (Table of Contents)

1. [Prasyarat (Prerequisites)](#1-prasyarat-prerequisites)
2. [Clone & Install Dependencies](#2-clone--install-dependencies)
3. [Setup Database Neon (PostgreSQL)](#3-setup-database-neon-postgresql)
4. [Konfigurasi Environment Variables](#4-konfigurasi-environment-variables)
5. [Push Schema & Generate Prisma](#5-push-schema--generate-prisma)
6. [Jalankan Development Server](#6-jalankan-development-server)
7. [Push ke GitHub](#7-push-ke-github)
8. [Deploy ke Cloudflare Pages](#8-deploy-ke-cloudflare-pages)
9. [Setup Custom Domain](#9-setup-custom-domain)
10. [Cloudflare API Token Setup](#10-cloudflare-api-token-setup)
11. [Troubleshooting](#11-troubleshooting)
12. [Checklist Deployment](#12-checklist-deployment)

---

## 1. Prasyarat (Prerequisites)

Sebelum memulai instalasi, pastikan kamu sudah memenuhi prasyarat berikut:

### Software yang Diperlukan

| Software      | Versi Minimum | Keterangan                  |
|---------------|---------------|-----------------------------|
| **Node.js**   | 18+           | Runtime JavaScript          |
| **npm**       | 9+            | Package manager (bundled dengan Node.js) |
| **Git**       | 2.30+         | Version control             |

### Akun yang Diperlukan

| Layanan         | URL                       | Keterangan                                   |
|-----------------|---------------------------|----------------------------------------------|
| **GitHub**      | https://github.com        | Untuk source code repository                 |
| **Cloudflare**  | https://dash.cloudflare.com | Untuk deployment, custom domain & DNS      |
| **Neon**        | https://neon.tech         | Database PostgreSQL serverless (HTTP-based)  |

### Install Node.js (jika belum ada)

```bash
# Menggunakan nvm (Node Version Manager) — Direkomendasikan
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 18
nvm use 18

# Verifikasi
node --version   # harus >= 18.x
npm --version
```

### Install Git (jika belum ada)

```bash
# Ubuntu / Debian
sudo apt update && sudo apt install git

# macOS (via Homebrew)
brew install git

# Verifikasi
git --version
```

---

## 2. Clone & Install Dependencies

### Step 2.1 — Clone Repository

```bash
# Clone dari GitHub (setelah push, lihat Section 7)
git clone https://github.com/username/shorturl-platform.git

# Masuk ke direktori project
cd shorturl-platform
```

> **Note:** Jika belum push ke GitHub, kamu bisa langsung bekerja di direktori project yang sudah ada.

### Step 2.2 — Pastikan File `.npmrc` Ada

File `.npmrc` **WAJIB** ada di root project dengan isi berikut:

```ini
legacy-peer-deps=true
```

Jika file belum ada, buat manual:

```bash
echo "legacy-peer-deps=true" > .npmrc
```

> **PENTING:** Tanpa file ini, `npm install` bisa gagal karena konflik peer dependencies antara Next.js dan beberapa library.

### Step 2.3 — Install Dependencies

```bash
npm install --legacy-peer-deps
```

> **Catatan:** Flag `--legacy-peer-deps` **wajib** digunakan. Atau pastikan `.npmrc` sudah berisi `legacy-peer-deps=true`, sehingga cukup menjalankan `npm install`.

Dependencies utama yang terinstall:

| Library                     | Versi      | Fungsi                                       |
|-----------------------------|------------|----------------------------------------------|
| `next`                      | 15.3.4     | Framework React fullstack (App Router)       |
| `@prisma/client`            | 6.11.1     | ORM Client                                   |
| `prisma`                    | 6.11.1     | ORM CLI                                      |
| `@prisma/adapter-neon`      | latest     | HTTP-based Prisma adapter untuk edge runtime |
| `react-qr-code`             | latest     | QR Code generation (SVG-based, edge-compatible) |
| `@opennextjs/cloudflare`    | latest     | Adapter Next.js untuk Cloudflare Pages       |
| `shadcn/ui`                 | —          | Component library (Radix UI + Tailwind)      |
| `recharts`                  | latest     | Library untuk chart/visualisasi              |
| `zustand`                   | latest     | State management                             |

---

## 3. Setup Database Neon (PostgreSQL)

Neon menyediakan PostgreSQL serverless berbasis HTTP yang kompatibel dengan edge runtime seperti Cloudflare Workers. Ini adalah **satu-satunya database yang didukung** untuk deployment ini.

### Step 3.1 — Buat Akun Neon

1. Buka **https://neon.tech**
2. Klik tombol **Sign Up**
3. Pilih salah satu metode registrasi:
   - **GitHub** (direkomendasikan, 1 klik)
   - **Google**
   - **Email & Password**

### Step 3.2 — Buat Project Baru

1. Setelah login, klik **"Create a project"**
2. Isi konfigurasi project:

   | Field                    | Value yang Disarankan                          |
   |--------------------------|------------------------------------------------|
   | **Project name**         | `shorturl-db`                                  |
   | **Region**               | `AWS Asia Pacific (Singapore) — ap-southeast-1` |
   | **PostgreSQL version**   | Default (16) — biarkan sesuai default          |
   | **Branch name**          | `main` — biarkan default                       |

3. Klik **"Create project"**
4. Tunggu proses provisioning (~10-20 detik)

### Step 3.3 — Dapatkan Connection String

1. Setelah project dibuat, Neon akan menampilkan halaman dashboard
2. Klik tab **"Connection details"** atau lihat di sidebar
3. Salin **connection string** yang formatnya seperti:

```
postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
```

> **PENTING:** Pastikan connection string diakhiri dengan `?sslmode=require`. Parameter ini **wajib** ada untuk koneksi yang aman.

### Step 3.4 — Verifikasi Connection String

Pastikan format connection string kamu benar:

```
postgresql://[USER]:[PASSWORD]@[HOST]/[DATABASE]?sslmode=require
         ↑            ↑          ↑          ↑            ↑
       username     password    endpoint   db_name    wajib
```

Contoh valid:
```
postgresql://neondb_owner:abc123xyz@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
```

### Tips Neon

| Tips                | Deskripsi                                                                 |
|---------------------|---------------------------------------------------------------------------|
| **Auto-suspend**    | Database otomatis suspend setelah idle. Request pertama akan lebih lambat (~1-2 detik). |
| **HTTP-based**      | Neon menggunakan protokol HTTP untuk koneksi, kompatibel dengan edge runtime. |
| **Connection pooling** | Neon secara otomatis mengelola connection pooling. |
| **Free tier**       | 0.5 GiB storage, 1 project, auto-suspend. Cukup untuk project kecil-menengah. |

---

## 4. Konfigurasi Environment Variables

### Step 4.1 — Buat File `.env`

```bash
# Salin dari .env.example
cp .env.example .env

# Edit file .env sesuai konfigurasi kamu
nano .env
# atau
code .env
```

### Step 4.2 — Daftar Environment Variables (WAJIB untuk Production)

| Variable                  | Required | Deskripsi                                                     | Contoh                                                                |
|---------------------------|----------|---------------------------------------------------------------|-----------------------------------------------------------------------|
| `DATABASE_URL`            | ✅ Ya    | Connection string PostgreSQL Neon                              | `postgresql://user:pass@ep-xxx.neon.tech/neondb?sslmode=require`     |
| `DASHBOARD_TOKEN`         | ✅ Ya    | Auth token untuk login dashboard (**minimum 12 karakter**)     | `YourSecureToken123!`                                                 |
| `APP_DOMAIN`              | ✅ Ya    | Domain utama dashboard (untuk middleware routing)              | `yoii.me`                                                             |
| `CLOUDFLARE_ACCOUNT_ID`   | ✅ Ya*   | Cloudflare Account ID (untuk domain verification API)          | `abc123def456...`                                                     |
| `CLOUDFLARE_API_TOKEN`    | ✅ Ya*   | Cloudflare API Token dengan Zone:Read, Pages:Edit permissions  | `encrypted_token_value`                                                |
| `CLOUDFLARE_PAGES_PROJECT`| ✅ Ya*   | Nama project Cloudflare Pages                                 | `app-yoii`                                                            |

> \* Variable bertanda bintang diperlukan untuk fitur auto-verify domain di dashboard. Tanpa ini, kamu tetap bisa menggunakan platform tapi harus memverifikasi domain secara manual via Cloudflare dashboard.

### Step 4.3 — Contoh File `.env` Lengkap

```env
# ============================================
# ShortURL Platform - Environment Variables
# ============================================

# DATABASE (PostgreSQL - Neon)
DATABASE_URL="postgresql://neondb_owner:xxxxxxxxxxxx@ep-cool-name-123456.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"

# AUTH - Dashboard login token (MINIMUM 12 karakter!)
DASHBOARD_TOKEN="YourSecureToken123!"

# APP DOMAIN - Domain utama untuk dashboard (middleware routing)
APP_DOMAIN="yoii.me"

# CLOUDFLARE API (opsional, untuk auto-verify domain)
CLOUDFLARE_ACCOUNT_ID="abc123def456"
CLOUDFLARE_API_TOKEN="your_cf_api_token_here"
CLOUDFLARE_PAGES_PROJECT="app-yoii"
```

### Step 4.4 — Keamanan Token

> ⚠️ **PERINGATAN KEAMANAN:**

- **Jangan** pernah commit file `.env` ke Git
- **Jangan** gunakan token default di production
- Buat token yang kuat: minimal 12 karakter, kombinasi huruf besar, kecil, angka, dan simbol
- Gunakan password generator:

```bash
# Generate token yang kuat
openssl rand -base64 24
# Output contoh: xK9#mP2$vL5&nQ8@wR3!tY7*hJ0fA
```

---

## 5. Push Schema & Generate Prisma

### Step 5.1 — Pastikan Schema Prisma Benar

File `prisma/schema.prisma` **WAJIB** memiliki konfigurasi berikut:

```prisma
generator client {
  provider        = "prisma-client-js"
  previewFeatures = ["driverAdapters"]
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

> **PENTING:** 
> - `previewFeatures = ["driverAdapters"]` **wajib** ada agar Prisma bisa menggunakan adapter Neon untuk edge runtime.
> - `provider = "postgresql"` **wajib** karena kita menggunakan Neon (PostgreSQL), bukan SQLite atau database lain.

### Step 5.2 — Push Schema ke Database

```bash
# Push schema (membuat tabel di PostgreSQL Neon berdasarkan prisma/schema.prisma)
npx prisma db push
```

> **Penjelasan:** `db push` membaca `prisma/schema.prisma` dan membuat/memperbarui tabel di database tanpa membuat migration file. Cocok untuk development dan project tanpa migrasi formal.

Jika berhasil, outputnya kurang lebih:
```
🚀 Your database is now in sync with your Prisma schema.
```

### Step 5.3 — Generate Prisma Client

```bash
# Generate Prisma Client
npx prisma generate
```

> **Penjelasan:** `prisma generate` menghasilkan Prisma Client di `node_modules/.prisma/client` berdasarkan schema. Ini **wajib** dilakukan sebelum menjalankan aplikasi dan **wajib** juga dilakukan saat build di Cloudflare Pages.

Jika berhasil, outputnya kurang lebih:
```
✔ Generated Prisma Client (6.11.1) to ./node_modules/.prisma/client in 123ms
```

### Step 5.4 — Model Database

**File `prisma/schema.prisma` berisi 5 model utama:**

| Model         | Tabel Database   | Deskripsi                            |
|---------------|------------------|--------------------------------------|
| `AppSetting`  | `app_settings`   | Pengaturan aplikasi (key-value)      |
| `ShortDomain` | `short_domains`  | Domain yang digunakan untuk short URL |
| `ShortLink`   | `short_links`    | Link pendek dengan metadata lengkap  |
| `LinkTarget`  | `link_targets`   | Target URL untuk multi-target routing |
| `Click`       | `clicks`         | Data klik/analytics per pengunjung   |

### Step 5.5 — Verifikasi Database (Opsional)

```bash
# Buka Prisma Studio untuk melihat data
npx prisma studio
```

Prisma Studio akan terbuka di http://localhost:5555 dan kamu bisa melihat semua tabel.

---

## 6. Jalankan Development Server

### Step 6.1 — Jalankan Server

```bash
npm run dev
```

Server development akan berjalan di **http://localhost:3000**.

### Step 6.2 — Akses Dashboard

1. Buka browser → http://localhost:3000
2. Masukkan token dari `DASHBOARD_TOKEN` yang ada di file `.env`
3. Jika login berhasil, kamu akan diarahkan ke halaman Overview

### Step 6.3 — Verifikasi Instalasi Lokal

- [ ] Dashboard berhasil dimuat di http://localhost:3000
- [ ] Login dengan token berhasil
- [ ] Halaman Overview menampilkan statistik
- [ ] Bisa membuat link baru di halaman Links
- [ ] Bisa menambahkan domain di halaman Domains

---

## 7. Push ke GitHub

Menyimpan source code ke GitHub memudahkan kolaborasi, backup, dan integrasi dengan Cloudflare Pages untuk auto-deploy.

### Step 7.1 — Pastikan `.gitignore` Sudah Benar

Pastikan file berikut ada di `.gitignore`:

```gitignore
# Dependencies
node_modules/

# Next.js
.next/
.open-next/

# Production
build/
dist/

# Environment variables (PENTING!)
.env
.env*.local

# Database lokal
db/*.db
db/*.db-journal

# Prisma
node_modules/.prisma/

# IDE
.vscode/
.idea/

# Logs
*.log
dev.log
server.log

# Misc
.DS_Store
*.pem
```

### Step 7.2 — Inisialisasi Git & Commit

```bash
# Inisialisasi git repository (jika belum ada)
git init

# Tambahkan semua file ke staging
git add .

# Buat commit pertama
git commit -m "Initial commit: ShortURL Platform (Dub.co clone)"
```

### Step 7.3 — Buat Repository di GitHub

#### Opsi A: Melalui GitHub Web UI

1. Buka **https://github.com/new**
2. Isi form:
   - **Repository name:** `shorturl-platform`
   - **Description:** "Short URL Management Platform — Dub.co Clone built with Next.js + Prisma + Cloudflare Pages"
   - **Visibility:** `Private` (direkomendasikan) atau `Public`
   - **JANGAN centang** "Add a README", "Add .gitignore", "Choose a license"
3. Klik **"Create repository"**
4. Ikuti instruksi untuk push existing repository

#### Opsi B: Menggunakan GitHub CLI (`gh`)

```bash
# Install GitHub CLI
# macOS
brew install gh

# Ubuntu/Debian
sudo apt install gh

# Login ke GitHub
gh auth login

# Buat repository dan push sekaligus
gh repo create shorturl-platform --private --source=. --push
```

### Step 7.4 — Push ke GitHub

```bash
# Tambahkan remote origin
git remote add origin https://github.com/username/shorturl-platform.git

# Set branch utama ke main
git branch -M main

# Push ke GitHub
git push -u origin main
```

### Step 7.5 — Verifikasi

- [ ] Repository berhasil dibuat di GitHub
- [ ] Semua file ter-upload
- [ ] `.env` **TIDAK** ter-upload (cek di GitHub, file ini harus ada di .gitignore)
- [ ] `.npmrc` ter-upload ✓

---

## 8. Deploy ke Cloudflare Pages

Deployment menggunakan **@opennextjs/cloudflare** yang mengadaptasi Next.js App Router agar kompatibel dengan Cloudflare Pages runtime.

> ⚠️ **PENTING:** Baca setiap langkah dengan teliti. Kesalahan build command atau output directory akan menyebabkan deployment gagal.

### Step 8.1 — Pastikan File Konfigurasi Ada

Sebelum deploy, pastikan file-file konfigurasi berikut ada di root project:

#### File `wrangler.toml`
```toml
#:schema node_modules/wrangler/config-schema.json
name = "shorturl-platform"
compatibility_date = "2025-01-01"
compatibility_flags = ["nodejs_compat"]

pages_build_output_dir = ".open-next"
```

#### File `open-next.config.ts`
```typescript
import { defineCloudflareConfig } from "@opennextjs/cloudflare";

export default defineCloudflareConfig({
  incrementalCache: {
    tagCache: true,
  },
});
```

#### File `.npmrc`
```ini
legacy-peer-deps=true
```

### Step 8.2 — Buat Project Pages via Cloudflare Dashboard

#### Langkah 1: Login ke Cloudflare

1. Buka **https://dash.cloudflare.com**
2. Login menggunakan akun Cloudflare kamu

#### Langkah 2: Buat Project Pages Baru

1. Di sidebar kiri, klik **"Workers & Pages"**
2. Klik tombol **"Create"**
3. Pilih tab **"Pages"**
4. Klik **"Connect to Git"**

#### Langkah 3: Hubungkan Repository GitHub

1. Pilih **GitHub** sebagai Git provider
2. Klik **"Connect GitHub"** dan authorize Cloudflare
3. Pilih repository **`shorturl-platform`** dari daftar

#### Langkah 4: Konfigurasi Build Settings

Isi konfigurasi build **PERSIS** sebagai berikut:

| Setting                       | Value                                                         |
|-------------------------------|---------------------------------------------------------------|
| **Project name**              | `shorturl-platform` (atau nama yang kamu inginkan)           |
| **Production branch**         | `main`                                                        |
| **Framework preset**          | `None`                                                        |
| **Build command**             | `npx prisma generate && npx opennextjs-cloudflare build`      |
| **Build output directory**    | `.open-next`                                                  |
| **Root directory**            | `/`                                                           |

> 🔴 **KRITIS — Jangan sampai salah:**
> - Build command: `npx prisma generate && npx opennextjs-cloudflare build` — BUKAN `next build` atau `npm run build`
> - Output directory: `.open-next` — BUKAN `.next` atau `.vercel/output/static`

**Mengapa build command seperti itu?**
1. `npx prisma generate` — Menghasilkan Prisma Client terlebih dahulu (diperlukan agar `@prisma/client` bisa di-import)
2. `&&` — Menjalankan perintah kedua hanya jika perintah pertama berhasil
3. `npx opennextjs-cloudflare build` — Menjalankan `next build` lalu mengubah output-nya agar kompatibel dengan Cloudflare Pages

#### Langkah 5: Tambahkan Environment Variables

Klik **"Environment variables"** dan tambahkan **SEMUA** variable berikut:

| Variable                    | Value                                                                  |
|-----------------------------|------------------------------------------------------------------------|
| `DATABASE_URL`              | `postgresql://neondb_owner:xxx@ep-xxx.neon.tech/neondb?sslmode=require` |
| `DASHBOARD_TOKEN`           | Token yang kuat (min. 12 karakter)                                     |
| `APP_DOMAIN`                | Domain utama dashboard kamu (contoh: `yoii.me`)                        |
| `CLOUDFLARE_ACCOUNT_ID`     | Account ID Cloudflare kamu                                             |
| `CLOUDFLARE_API_TOKEN`      | API Token Cloudflare kamu                                              |
| `CLOUDFLARE_PAGES_PROJECT`  | Nama project CF Pages (contoh: `shorturl-platform`)                    |

> **Tips:** Setelah deployment, kamu juga bisa menambahkan/mengubah environment variables melalui: **Workers & Pages** → pilih project → **Settings** → **Environment variables**.

#### Langkah 6: Deploy

1. Klik **"Save and Deploy"**
2. Tunggu proses build (biasanya 3-5 menit untuk pertama kali)
3. Jika berhasil, kamu akan mendapatkan URL:
   ```
   https://shorturl-platform.pages.dev
   ```

### Step 8.3 — Verifikasi Deployment

- [ ] Build berhasil tanpa error
- [ ] Aplikasi bisa diakses via `https://shorturl-platform.pages.dev`
- [ ] Halaman login muncul
- [ ] Login dengan `DASHBOARD_TOKEN` berhasil
- [ ] Halaman Overview menampilkan statistik

### Step 8.4 — Auto-Deploy

Setelah pertama kali deploy, setiap push ke branch `main` akan otomatis trigger re-deploy:

```bash
# Buat perubahan kode
git add .
git commit -m "feat: update short URL logic"
git push origin main

# Cloudflare Pages akan otomatis build & deploy
```

### Step 8.5 — Cara Kerja @opennextjs/cloudflare

```
┌─────────────────┐     ┌──────────────────────┐     ┌─────────────────┐
│  next build      │────▶│  opennextjs-cloudflare │────▶│   .open-next/   │
│  (standard build)│     │  (adapter transform)  │     │  (CF-compatible)│
└─────────────────┘     └──────────────────────┘     └─────────────────┘
                                                             │
                                                             ▼
                                                   ┌─────────────────┐
                                                   │ Cloudflare Pages │
                                                   │  (edge deploy)   │
                                                   └─────────────────┘
```

Library `@opennextjs/cloudflare` mengubah output standar Next.js menjadi format yang kompatibel dengan Cloudflare Pages edge runtime. Ini mencakup:
- Konversi Server Components menjadi edge functions
- Penanganan middleware untuk edge
- Konfigurasi static assets
- Optimasi untuk cold start

---

## 9. Setup Custom Domain

Platform ini mendukung **multi-domain**: satu domain utama untuk dashboard dan beberapa domain kustom untuk short URL.

### Arsitektur Routing (Middleware)

```
APP_DOMAIN (yoii.me)
    ├── /dashboard  → Halaman dashboard
    ├── /links      → Manajemen link
    ├── /domains    → Manajemen domain
    └── /*          → Halaman dashboard lainnya

Custom Domain (go.yoii.me, link.example.com, dll.)
    └── /{slug}     → Redirect ke target URL
```

Middleware (`src/middleware.ts`) menentukan routing berdasarkan domain:
- Jika domain **sama** dengan `APP_DOMAIN` → arahkan ke dashboard
- Jika domain **berbeda** dari `APP_DOMAIN` → arahkan ke short URL redirect

### Step 9.1 — Tambahkan Domain ke Cloudflare

1. Login ke **https://dash.cloudflare.com**
2. Klik **"Add a site"** di sidebar
3. Masukkan nama domain kamu (contoh: `example.com`)
4. Pilih plan (**Free** sudah cukup)
5. Cloudflare akan menampilkan **2 NS records** (nameservers)
6. Login ke registrar domain kamu (Namecheap, GoDaddy, dll.)
7. **Ubah nameserver** domain ke nameserver Cloudflare:
   ```
   ns1.cloudflare.com
   ns2.cloudflare.com
   ```
8. Tunggu propagasi DNS (bisa memakan waktu 15 menit - 48 jam)

### Step 9.2 — Buat DNS CNAME Record

Setelah domain aktif di Cloudflare, tambahkan DNS record:

#### Untuk Subdomain Short URL (contoh: `go.example.com`)

| Type  | Name | Target                          | Proxy   | TTL  |
|-------|------|---------------------------------|---------|------|
| CNAME | go   | `shorturl-platform.pages.dev`   | Proxied | Auto |

> **Catatan:** Pastikan proxy status berwarna **oranye (Proxied)**, bukan abu-abu (DNS only).

### Step 9.3 — Tambahkan Custom Domain di Pages Project

1. Di Cloudflare dashboard, buka **Workers & Pages** → pilih project kamu
2. Klik **"Custom domains"**
3. Klik **"Set up a custom domain"**
4. Masukkan domain (contoh: `go.example.com`)
5. Klik **"Continue"** → **"Activate domain"**
6. Tunggu SSL certificate provisioning (~15 menit)

### Step 9.4 — Update Environment Variable `APP_DOMAIN`

Pastikan `APP_DOMAIN` di environment variables Cloudflare Pages diisi dengan domain utama dashboard kamu:

```
APP_DOMAIN="yoii.me"
```

> **PENTING:** `APP_DOMAIN` harus **persis sama** dengan domain dashboard yang digunakan. Jika kamu mengakses dashboard via `yoii.me`, maka `APP_DOMAIN` harus `yoii.me`. Jika menggunakan `www.yoii.me`, maka isikan `www.yoii.me`.

### Step 9.5 — Tambahkan Domain di Dashboard ShortURL

1. Login ke dashboard ShortURL kamu
2. Pergi ke menu **Domains**
3. Klik **"Add Domain"**
4. Isi form:

   | Field            | Value                   |
   |------------------|-------------------------|
   | **Domain**       | `go.example.com`        |
   | **Slug**         | `go` (opsional)         |
   | **Active**       | ✅ Centang              |

5. Klik **Save**
6. Jika `CLOUDFLARE_ACCOUNT_ID` dan `CLOUDFLARE_API_TOKEN` sudah dikonfigurasi, domain akan otomatis ter-verify
7. Jika belum, klik tombol **verify** secara manual

### Step 9.6 — Mulai Gunakan Short URL dengan Custom Domain

1. Pergi ke menu **Links** → **Create Link**
2. Di form, pilih domain `go.example.com`
3. Masukkan slug (contoh: `promo`)
4. Masukkan destination URL
5. Save

Short URL: `https://go.example.com/promo` → akan redirect ke destination URL

---

## 10. Cloudflare API Token Setup

API Token Cloudflare diperlukan untuk fitur **auto-verify domain** di dashboard. Token ini memungkinkan aplikasi untuk:
- Memverifikasi bahwa domain sudah terkonfigurasi dengan benar di Cloudflare DNS
- Mengecek status DNS record untuk custom domain

### Step 10.1 — Dapatkan Account ID

1. Login ke **https://dash.cloudflare.com**
2. Klik **"Workers & Pages"** di sidebar
3. Di halaman overview (pojok kanan), kamu akan melihat **Account ID**
4. Salin Account ID tersebut

```
Contoh: abc123def456789ghi012jkl345mno67
```

Atau melalui URL saat membuka Workers & Pages:
```
https://dash.cloudflare.com/<ACCOUNT_ID>/workers-and-pages
```

### Step 10.2 — Buat API Token

1. Buka **https://dash.cloudflare.com/profile/api-tokens**
2. Klik **"Create Token"**
3. Klik **"Get started"** pada **Custom token**
4. Isi konfigurasi:

   | Field                | Value                              |
   |----------------------|------------------------------------|
   | **Token name**       | `ShortURL Platform`                |
   | **Permissions**      | Lihat di bawah                     |
   | **Account Resources**| Include → All accounts (atau spesifik) |
   | **Zone Resources**   | Include → All zones (atau spesifik) |

5. Set **Permissions**:
   - **Account** → **Cloudflare Pages** → **Edit**
   - **Zone** → **DNS** → **Read**
   - **Zone** → **Zone** → **Read**

6. Klik **"Continue to summary"**
7. Klik **"Create Token"**
8. **SEGERA salin token** — token ini hanya ditampilkan sekali!

### Step 10.3 — Konfigurasi di Environment Variables

Tambahkan ke environment variables (di `.env` lokal dan di Cloudflare Pages dashboard):

```env
CLOUDFLARE_ACCOUNT_ID="abc123def456789ghi012jkl345mno67"
CLOUDFLARE_API_TOKEN="token_yang_baru_dibuat"
CLOUDFLARE_PAGES_PROJECT="shorturl-platform"
```

### Step 10.4 — Verifikasi API Token

Untuk memastikan token berfungsi, kamu bisa test menggunakan curl:

```bash
curl -X GET "https://api.cloudflare.com/client/v4/zones" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -H "Content-Type: application/json"
```

Jika berhasil, response akan berisi daftar zones di akun kamu.

### Keamanan API Token

> ⚠️ **PERINGATAN KEAMANAN:**

- **Jangan** pernah commit API token ke Git
- **Jangan** bagikan API token ke siapapun
- Gunakan **principle of least privilege** — berikan permission yang benar-benar diperlukan saja
- Jika token terkompromi, segera **revoke** dan buat token baru di dashboard Cloudflare
- Simpan token di environment variables, bukan di source code

---

## 11. Troubleshooting

Berikut adalah masalah umum yang mungkin dihadapi beserta solusinya.

### 11.1 — Build Infinite Loop / Gagal di Cloudflare Pages

**Gejala:**
- Build terus berjalan tanpa selesai
- Build gagal dengan exit code 1 tanpa error yang jelas

**Solusi:**

1. **Pastikan build command benar:**
   ```
   ❌ SALAH:   npm run build
   ❌ SALAH:   next build
   ❌ SALAH:   npx @cloudflare/next-on-pages
   ✅ BENAR:   npx prisma generate && npx opennextjs-cloudflare build
   ```

2. **Pastikan output directory benar:**
   ```
   ❌ SALAH:   .next
   ❌ SALAH:   .vercel/output/static
   ❌ SALAH:   out
   ✅ BENAR:   .open-next
   ```

3. **Pastikan framework preset set ke `None`** (bukan "Next.js")

4. **Pastikan `.npmrc` ada** dan berisi `legacy-peer-deps=true`

### 11.2 — Database Connection Error

**Gejala:**
```
Error: P1001 - Can't reach database server
```
atau
```
prisma client did not initialize properly
```

**Solusi:**

1. **Periksa format `DATABASE_URL`:**
   ```
   ✅ BENAR: postgresql://user:pass@ep-xxx.neon.tech/neondb?sslmode=require
   ❌ SALAH: postgres://user:pass@ep-xxx.neon.tech/neondb (tidak ada sslmode)
   ❌ SALAH: file:./db/custom.db (ini untuk SQLite, bukan Neon)
   ```

2. **Pastikan `?sslmode=require` ada di akhir URL**

3. **Test koneksi dari lokal:**
   ```bash
   npx prisma db execute --stdin <<< "SELECT 1 as test;"
   ```

4. **Cek apakah database Neon masih aktif** — buka dashboard Neon dan cek status project

### 11.3 — Prisma Generate Error

**Gejala:**
```
Error: The preview feature "driverAdapters" is not known
```
atau
```
@prisma/client did not initialize yet
```

**Solusi:**

1. **Pastikan `previewFeatures = ["driverAdapters"]` ada di `prisma/schema.prisma`:**
   ```prisma
   generator client {
     provider        = "prisma-client-js"
     previewFeatures = ["driverAdapters"]
   }
   ```

2. **Regenerate Prisma Client:**
   ```bash
   rm -rf node_modules/.prisma
   rm -rf node_modules/@prisma
   npx prisma generate
   ```

3. **Pastikan versi Prisma konsisten** — `@prisma/client` dan `prisma` harus versi yang sama (6.11.1)

### 11.4 — Domain Tidak Resolve / 404 pada Short Domain

**Gejala:**
- Custom domain menampilkan `ERR_NAME_NOT_RESOLVED`
- SSL certificate error
- Short URL mengembalikan 404

**Solusi:**

1. **Cek DNS propagation:**
   ```bash
   dig go.example.com
   # atau
   nslookup go.example.com
   ```

2. **Pastikan CNAME record sudah benar** di Cloudflare DNS:
   - Type: `CNAME`
   - Name: `go` (atau subdomain yang digunakan)
   - Target: `shorturl-platform.pages.dev`
   - Proxy: **Proxied** (oranye)

3. **Pastikan custom domain sudah ditambahkan di Pages project:**
   - Workers & Pages → project → Custom domains

4. **Pastikan `APP_DOMAIN` sesuai:**
   - Jika dashboard diakses via `yoii.me`, maka `APP_DOMAIN=yoii.me`
   - Jika salah, middleware akan salah merutekan request

5. **Tunggu propagasi DNS** — bisa memakan waktu 15 menit hingga 48 jam

### 11.5 — npm install Gagal (Peer Dependency Conflict)

**Gejala:**
```
npm ERR! ERESOLVE unable to resolve dependency tree
```

**Solusi:**

1. **Pastikan `.npmrc` ada** dengan isi `legacy-peer-deps=true`
2. **Jika sudah ada tapi tetap gagal:**
   ```bash
   npm install --legacy-peer-deps
   ```
3. **Clear cache dan coba lagi:**
   ```bash
   rm -rf node_modules package-lock.json
   npm install --legacy-peer-deps
   ```

### 11.6 — Login Error / Unauthorized

**Gejala:**
- Token benar tapi tetap "Unauthorized"
- Login gagal dengan pesan error

**Solusi:**

1. **Pastikan `DASHBOARD_TOKEN` minimal 12 karakter**
2. **Pastikan token sama** antara yang diketik di login dan yang di environment variable (case-sensitive)
3. **Cek apakah environment variable ter-load** — di Cloudflare Pages, pastikan variable sudah di-save
4. **Test endpoint auth:**
   ```bash
   curl -X POST https://your-domain.pages.dev/api/auth/check \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YourSecureToken123!"
   ```

### 11.7 — Port 3000 Already in Use

**Gejala:**
```
Error: Port 3000 is already in use
```

**Solusi:**

```bash
# Cek proses yang menggunakan port 3000
lsof -i :3000

# Kill proses
kill -9 <PID>
```

---

## 12. Checklist Deployment

Gunakan checklist berikut untuk memastikan deployment berjalan lancar. Cek setiap item satu per satu.

### ✅ Local Development

- [ ] Node.js terinstall (`node --version` → >= 18)
- [ ] npm terinstall (`npm --version`)
- [ ] Git terinstall (`git --version`)
- [ ] File `.npmrc` ada dengan isi `legacy-peer-deps=true`
- [ ] Dependencies terinstall (`npm install --legacy-peer-deps`)
- [ ] File `.env` sudah dibuat dan dikonfigurasi dengan benar
- [ ] `DATABASE_URL` menggunakan connection string Neon PostgreSQL
- [ ] `DASHBOARD_TOKEN` minimal 12 karakter
- [ ] `prisma/schema.prisma` memiliki `previewFeatures = ["driverAdapters"]`
- [ ] `prisma/schema.prisma` menggunakan `provider = "postgresql"`
- [ ] Prisma schema sudah di-push (`npx prisma db push`) — berhasil tanpa error
- [ ] Prisma Client ter-generate (`npx prisma generate`) — berhasil tanpa error
- [ ] Dev server berjalan (`npm run dev`)
- [ ] Dashboard bisa diakses di http://localhost:3000
- [ ] Login ke dashboard berhasil

### ✅ Database (Neon PostgreSQL)

- [ ] Akun Neon sudah dibuat di https://neon.tech
- [ ] Project Neon sudah dibuat (region Singapore recommended)
- [ ] Connection string sudah didapatkan
- [ ] Connection string diakhiri dengan `?sslmode=require`
- [ ] `DATABASE_URL` di `.env` menggunakan connection string yang benar
- [ ] `npx prisma db push` berhasil ke database Neon
- [ ] Tabel sudah terbuat (AppSetting, ShortDomain, ShortLink, LinkTarget, Click)

### ✅ GitHub

- [ ] `.gitignore` memuat `.env` dan `.env*.local`
- [ ] Git repository terinisialisasi (`git init`)
- [ ] Semua file committed
- [ ] File `.npmrc` termasuk dalam commit
- [ ] File `wrangler.toml` termasuk dalam commit
- [ ] File `open-next.config.ts` termasuk dalam commit
- [ ] Repository dibuat di GitHub
- [ ] Code berhasil di-push ke GitHub
- [ ] `.env` **TIDAK** ada di GitHub

### ✅ Cloudflare Pages

- [ ] Akun Cloudflare aktif
- [ ] Pages project dibuat via dashboard
- [ ] GitHub repository terhubung ke Pages project
- [ ] Build command: `npx prisma generate && npx opennextjs-cloudflare build`
- [ ] Build output directory: `.open-next`
- [ ] Root directory: `/`
- [ ] Framework preset: `None`
- [ ] Environment variable `DATABASE_URL` sudah di-set
- [ ] Environment variable `DASHBOARD_TOKEN` sudah di-set
- [ ] Environment variable `APP_DOMAIN` sudah di-set
- [ ] Environment variable `CLOUDFLARE_ACCOUNT_ID` sudah di-set
- [ ] Environment variable `CLOUDFLARE_API_TOKEN` sudah di-set
- [ ] Environment variable `CLOUDFLARE_PAGES_PROJECT` sudah di-set
- [ ] Deploy pertama berhasil tanpa error
- [ ] Aplikasi bisa diakses via `*.pages.dev`
- [ ] Login ke dashboard berhasil

### ✅ Custom Domain (Short URL)

- [ ] Domain sudah ditambahkan ke Cloudflare
- [ ] Nameserver domain sudah diubah ke Cloudflare (`ns1.cloudflare.com`, `ns2.cloudflare.com`)
- [ ] DNS sudah propagate
- [ ] CNAME record sudah dibuat di Cloudflare DNS (subdomain → `*.pages.dev`)
- [ ] Proxy status = Proxied (oranye)
- [ ] Custom domain sudah ditambahkan di Pages project
- [ ] SSL certificate aktif
- [ ] `APP_DOMAIN` di environment variables sesuai dengan domain dashboard
- [ ] Domain short URL sudah ditambahkan di dashboard ShortURL
- [ ] Domain ter-verify (status Verified ✅)
- [ ] Short URL berfungsi di custom domain (test akses `https://go.example.com/{slug}`)

### ✅ Cloudflare API Token (Opsional — untuk Auto-Verify Domain)

- [ ] Account ID sudah didapatkan dari Cloudflare dashboard
- [ ] API Token sudah dibuat dengan permissions:
  - [ ] Account → Cloudflare Pages → Edit
  - [ ] Zone → DNS → Read
  - [ ] Zone → Zone → Read
- [ ] `CLOUDFLARE_ACCOUNT_ID` sudah di-set di environment variables
- [ ] `CLOUDFLARE_API_TOKEN` sudah di-set di environment variables
- [ ] `CLOUDFLARE_PAGES_PROJECT` sudah di-set di environment variables
- [ ] Auto-verify domain berfungsi di dashboard

---

## Resource & Link Berguna

| Resource                      | URL                                                          |
|-------------------------------|--------------------------------------------------------------|
| Next.js Documentation         | https://nextjs.org/docs                                      |
| Next.js 15 Release Notes      | https://nextjs.org/blog/next-15                              |
| Prisma Documentation          | https://www.prisma.io/docs                                   |
| Prisma Driver Adapters        | https://www.prisma.io/docs/orm/overview/databases/postgresql |
| @prisma/adapter-neon          | https://www.prisma.io/docs/orm/overview/databases/neon       |
| Neon Documentation            | https://neon.tech/docs                                       |
| Cloudflare Pages Docs         | https://developers.cloudflare.com/pages/                     |
| OpenNext for Cloudflare       | https://opennext.js.org/cloudflare                           |
| @opennextjs/cloudflare        | https://www.npmjs.com/package/@opennextjs/cloudflare         |
| shadcn/ui Components          | https://ui.shadcn.com                                        |
| Tailwind CSS Docs             | https://tailwindcss.com/docs                                 |

---

> **Dibuat untuk:** ShortURL Platform (Dub.co Clone)
>
> **Stack:** Next.js 15.3.4 + Prisma 6.11.1 + Neon PostgreSQL + Cloudflare Pages
>
> **Terakhir diperbarui:** 2025

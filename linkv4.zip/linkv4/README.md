# ShortURL - Link Management Platform

A Dub.co-inspired short URL management platform built with Next.js 15, deployed on **Cloudflare Pages** with **Neon PostgreSQL**. Supports multiple custom domains, multi-target routing, analytics, and bulk operations.

## Features

- **Multi-Domain Support** — Use multiple short URL domains (e.g., `short-a.link`, `short-b.link`) from a single dashboard
- **Secure Domain Verification** — Cloudflare API-based verification proves domain ownership (zone check + Pages custom domain check)
- **Auto-Configure** — One-click domain setup: automatically adds domain to Cloudflare Pages + verifies + activates
- **Basic & Multi-Target Links** — Single target, random routing, sequential load balancing, geo-targeting, IP-based targeting
- **Real-Time Analytics** — Click tracking with country, device, browser, OS, and referrer data from Cloudflare HTTP headers
- **Bulk Operations** — Create, delete, activate, deactivate, and migrate links in bulk
- **Password Protection** — Protect individual links with passwords
- **Link Expiration** — Set expiration dates on links
- **UTM Parameters** — Append UTM source/medium/campaign/content/term to redirects
- **Import/Export** — Bulk import and export links with all metadata
- **QR Codes** — Generate QR codes for any short link
- **Dark/Light Mode** — System-aware theme support

## Architecture

```
domain-a.com (Dashboard) ─────┐
                              │    Cloudflare Pages
short-a.link (Short URLs) ───┤──── Single Deployment
                              │
short-b.link (Short URLs) ───┘
```

- **Dashboard domain** (`APP_DOMAIN`): Serves the React admin dashboard
- **Short domains**: Automatically routed to the redirect handler via middleware
- **Routing**: `short-a.link/abc` → middleware detects short domain → rewrite to `/s/abc` → redirect handler looks up slug in database → 301 redirect to target URL
- **Database**: Neon PostgreSQL via `@prisma/adapter-neon` + `@neondatabase/serverless` (edge-compatible HTTP driver)
- **Deployment**: `@opennextjs/cloudflare` converts Next.js to Cloudflare Workers

## Prerequisites

- Node.js 18+ (Cloudflare Pages uses npm)
- A [Neon](https://neon.tech) PostgreSQL database (free tier available)
- A [Cloudflare](https://cloudflare.com) account with Pages
- (Recommended) Cloudflare API token for automatic domain verification

## Tech Stack

| Component | Technology |
|-----------|-----------|
| Framework | Next.js 15.3 (App Router) |
| Runtime | Cloudflare Workers (via @opennextjs/cloudflare) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui |
| Database | Neon PostgreSQL |
| ORM | Prisma 6 + @prisma/adapter-neon |
| Charts | Recharts |
| State | Zustand |
| Icons | Lucide React |

---

## Local Development

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd shorturl
bun install
```

### 2. Create Neon PostgreSQL Database

1. Go to [neon.tech](https://neon.tech) → **Create Project**
2. Copy the **connection string** from Connection Details
3. Format: `postgresql://user:password@ep-xxx.region.neon.tech/dbname?sslmode=require`

### 3. Configure Environment Variables

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
# [REQUIRED] Dashboard login password
DASHBOARD_TOKEN=your_secure_password_here

# [REQUIRED] Dashboard domain (leave empty for local dev)
APP_DOMAIN=

# [REQUIRED] Neon PostgreSQL connection string
DATABASE_URL=postgresql://user:pass@ep-xxx.region.neon.tech/dbname?sslmode=require
```

### 4. Initialize Database

```bash
# Generate Prisma client
npx prisma generate

# Push schema to database (creates tables)
npx prisma db push
```

> Alternatively, run the SQL migration manually in Neon SQL Editor: copy and execute `prisma/migrations/0_init/migration.sql`

### 5. Run Development Server

```bash
bun run dev
```

Open `http://localhost:3000` and login with your `DASHBOARD_TOKEN`.

---

## Production Deployment (Cloudflare Pages)

### Step 1: Push Code to GitHub

```bash
git add .
git commit -m "Deploy to Cloudflare Pages"
git push origin main
```

> **Important**: Make sure `package-lock.json` is committed. This project uses it (not bun.lock) because Cloudflare Pages runs `npm install`.

### Step 2: Create Cloudflare Pages Project

1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com) → **Workers & Pages** → **Create**
2. **Connect to Git** → Select your GitHub repository
3. Set build settings:

| Setting | Value |
|---------|-------|
| **Framework preset** | `Next.js (Static)` |
| **Build command** | `npm install --legacy-peer-deps && npx prisma generate && npx opennextjs-cloudflare build` |
| **Build output directory** | `.open-next` |

> **Why `--legacy-peer-deps`?** Some packages have peer dependency version differences that don't affect functionality. This flag tells npm to proceed with installation.

### Step 3: Configure Environment Variables

In Pages project → **Settings** → **Environment variables** → **Add**:

| Variable | Required | Example |
|----------|----------|---------|
| `DASHBOARD_TOKEN` | **Yes** | `your_secure_password` |
| `APP_DOMAIN` | **Yes** | `yoii.me` |
| `DATABASE_URL` | **Yes** | `postgresql://user:pass@ep-xxx.neon.tech/dbname?sslmode=require` |
| `CLOUDFLARE_API_TOKEN` | Recommended | (see Step 4) |
| `CLOUDFLARE_ACCOUNT_ID` | Recommended | `abc123def456` |
| `CLOUDFLARE_PAGES_PROJECT` | Recommended | `my-shorturl-project` |

### Step 4: Create Cloudflare API Token (Recommended)

Required for automatic domain verification and auto-configure:

1. Go to [API Tokens](https://dash.cloudflare.com/profile/api-tokens) → **Create Token** → **Custom token**
2. Permissions:
   - Account → Cloudflare Pages → **Edit**
   - Zone → Zone → **Read**
   - Zone → DNS → **Edit**
3. Account Resources: Include → Your account
4. Zone Resources: Include → All zones (or specific zones)
5. Create and copy the token → Set as `CLOUDFLARE_API_TOKEN`

### Step 5: Add Custom Domain for Dashboard

1. In your Pages project → **Custom domains** → Add `yoii.me`
2. Cloudflare will auto-configure DNS (CNAME record)

### Step 6: Setup Database Tables

In [Neon Console](https://console.neon.tech) → **SQL Editor**, execute the contents of `prisma/migrations/0_init/migration.sql` to create all required tables.

### Step 7: Deploy

Click **Save and Deploy**. Cloudflare Pages will build and deploy your project.

---

## Adding Short URL Domains

After deployment, go to your dashboard (`yoii.me`):

### Method A: Auto-Configure (with Cloudflare API token)

1. Dashboard → Domains → **Add Domain**
2. Enter domain (e.g., `short-a.link`) → Enable **Auto-configure**
3. Click **Add & Auto-Configure**
4. System automatically: adds to Pages, verifies ownership, activates domain

### Method B: Manual

1. Dashboard → Domains → Add Domain (enter domain name)
2. Go to **Cloudflare Dashboard** → Workers & Pages → Your Project → Custom domains → Add domain
3. Back to Dashboard → Domains → Click **Verify** → Domain auto-activates

### Important

All short URL domains must have their **nameservers pointing to the same Cloudflare account** as your Pages project. The verification checks that the domain exists as a Zone in YOUR account.

---

## Domain Rules

| Rule | Description |
|------|-------------|
| New domains start as Inactive & Unverified | Security default |
| Must verify before activating | Prevents random domains from being used |
| Verification = Zone + Pages check | Proves both ownership AND connectivity |
| Verification auto-activates | On successful verify, domain is auto-activated |
| Renaming resets verification | New domain needs re-verification |
| Deleting removes from Pages | API automatically cleans up custom domain |

---

## Link Routing Strategies

| Strategy | Description |
|----------|-------------|
| Basic | Single target URL |
| Random | Randomly selects one target |
| Sequential | Routes to target with lowest click count (load balancing) |
| Country-based | Routes based on `CF-IPCountry` header |
| IP-based | Routes based on visitor's IP address |

Priority order: IP match → Country match → ALL targets (random/sequential)

---

## Analytics Data Source

Collected from **Cloudflare HTTP headers** (no external services needed):

| Data | Header |
|------|--------|
| Country | `CF-IPCountry` |
| IP Address | `CF-Connecting-IP` |
| Device/Browser/OS | Parsed from `User-Agent` |
| Referrer | `Referer` |

---

## Troubleshooting

### Build fails with `ERESOLVE` dependency conflict

**Cause**: npm strict peer dependency resolution.

**Fix**: Make sure your build command includes `--legacy-peer-deps`:
```
npm install --legacy-peer-deps && npx prisma generate && npx opennextjs-cloudflare build
```

### 404 on Cloudflare Pages after deployment

**Cause**: Wrong build output directory.

**Fix**: Build output directory must be `.open-next` (not `.next` or `.next/standalone`).

### wrangler.toml warning: "does not appear to be valid"

**Cause**: Old wrangler.toml with Worker-specific fields (like `main`).

**Fix**: Use the minimal Pages-compatible wrangler.toml:
```toml
name = "shorturl-platform"
compatibility_date = "2024-12-01"
compatibility_flags = ["nodejs_compat"]
pages_build_output_dir = ".open-next"
```

### Database connection errors

**Cause**: `DATABASE_URL` is not set or uses wrong format.

**Fix**: Set `DATABASE_URL` to your Neon PostgreSQL connection string ending with `?sslmode=require`.

### Domain verification fails

**Fix**:
1. Check nameservers point to your Cloudflare account
2. Verify `CLOUDFLARE_API_TOKEN` has Zone:Read + Pages:Edit permissions
3. Ensure domain is in the SAME Cloudflare account as Pages project

### Middleware not routing short domains

**Cause**: `APP_DOMAIN` environment variable is not set.

**Fix**: Set `APP_DOMAIN` to your dashboard domain. Leave empty for local development.

---

## Project Structure

```
src/
├── app/
│   ├── api/                    # API routes (edge-compatible)
│   │   ├── auth/               # Login, auth check
│   │   ├── domains/            # Domain CRUD + verification
│   │   ├── links/              # Link CRUD + bulk operations
│   │   ├── analytics/          # Overview analytics
│   │   ├── redirect/           # API redirect (JSON)
│   │   ├── import/             # Bulk import
│   │   ├── export/             # Bulk export
│   │   ├── settings/           # App settings
│   │   └── danger/             # Destructive operations
│   ├── s/[slug]/route.ts       # Catch-all redirect handler (HTML 301)
│   ├── page.tsx                # Dashboard SPA
│   ├── layout.tsx              # Root layout
│   └── globals.css             # Tailwind styles
├── components/
│   ├── domains/                # Domain management UI
│   ├── links/                  # Link management UI
│   ├── analytics/              # Charts and stats
│   ├── dashboard/              # Dashboard layout + sidebar
│   ├── pages/                  # Page components
│   └── ui/                     # shadcn/ui components
├── lib/
│   ├── cloudflare.ts           # Cloudflare API integration
│   ├── db.ts                   # Prisma + Neon adapter (edge)
│   ├── auth.ts                 # Dashboard authentication
│   ├── api.ts                  # Frontend API client
│   ├── store.ts                # Zustand state
│   ├── types.ts                # TypeScript types
│   └── utils.ts                # Utility functions
├── middleware.ts               # Domain routing (dashboard vs short URLs)
├── prisma/
│   ├── schema.prisma           # PostgreSQL schema
│   └── migrations/0_init/      # SQL migration
├── open-next.config.ts         # @opennextjs/cloudflare config
├── wrangler.toml               # Cloudflare Worker/Pages config
├── .env.example                # Environment variable template
└── package-lock.json           # Lock file (required for CF Pages npm install)
```

"use client";

import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import {
  Loader2,
  Server,
  Globe,
  ShieldCheck,
  ArrowRight,
  Cloud,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ExternalLink,
} from "lucide-react";
import {
  Alert,
  AlertDescription,
} from "@/components/ui/alert";

interface PagesResult {
  success: boolean;
  status?: string;
  error?: string;
}

interface AddResponse {
  id: string;
  domain: string;
  slug: string;
  isActive: boolean;
  isVerified: boolean;
  verifiedAt: string | null;
  createdAt: string;
  _pagesResult?: PagesResult;
  _cloudflareConfigured?: boolean;
}

interface AddDomainDialogProps {
  open: boolean;
  onClose: () => void;
  onAdd: (domain: string, slug: string, autoConfigure: boolean) => Promise<AddResponse>;
  cloudflareConfigured: boolean;
}

type SetupPhase = "form" | "result";

export default function AddDomainDialog({
  open,
  onClose,
  onAdd,
  cloudflareConfigured,
}: AddDomainDialogProps) {
  const [domain, setDomain] = useState("");
  const [slug, setSlug] = useState("");
  const [autoConfigure, setAutoConfigure] = useState(true);
  const [saving, setSaving] = useState(false);
  const [phase, setPhase] = useState<SetupPhase>("form");
  const [result, setResult] = useState<AddResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const resetAndClose = () => {
    setDomain("");
    setSlug("");
    setAutoConfigure(true);
    setSaving(false);
    setPhase("form");
    setResult(null);
    setErrorMsg(null);
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!domain.trim()) return;
    setSaving(true);
    setErrorMsg(null);

    try {
      const res = await onAdd(domain.trim().toLowerCase(), slug, autoConfigure);
      setResult(res);
      setPhase("result");
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to add domain");
    } finally {
      setSaving(false);
    }
  };

  // ─── Result Screen ──────────────────────────────────────────────────────────

  if (phase === "result" && result) {
    const pagesOk = result._pagesResult?.success;
    const pagesErr = result._pagesResult?.error;
    const autoVerified = result.isVerified;

    return (
      <Dialog open={open} onOpenChange={resetAndClose}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {autoVerified ? (
                <ShieldCheck className="h-5 w-5 text-green-500" />
              ) : (
                <Globe className="h-5 w-5" />
              )}
              Domain Added
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Status Summary */}
            <div className="flex items-center gap-3 rounded-lg border p-3">
              <Globe className="h-5 w-5 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <p className="font-medium truncate">{result.domain}</p>
                <p className="text-xs text-muted-foreground">
                  {autoVerified ? (
                    <span className="text-green-600 dark:text-green-400">Verified & configured</span>
                  ) : (
                    <span>Saved to database</span>
                  )}
                </p>
              </div>
              {autoVerified && (
                <CheckCircle2 className="h-5 w-5 text-green-500 shrink-0" />
              )}
            </div>

            {/* Auto-Configure Results */}
            {autoConfigure && cloudflareConfigured && (
              <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                <h4 className="font-medium text-sm flex items-center gap-2">
                  <Cloud className="h-4 w-4" />
                  Cloudflare Pages Configuration
                </h4>

                {pagesOk ? (
                  <div className="flex items-start gap-2 text-sm text-green-600 dark:text-green-400">
                    <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0" />
                    <div>
                      <p>Custom domain added to Pages project successfully.</p>
                      {result._pagesResult?.status && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Status: {result._pagesResult.status}
                        </p>
                      )}
                    </div>
                  </div>
                ) : pagesErr ? (
                  <div className="flex items-start gap-2 text-sm text-destructive">
                    <XCircle className="h-4 w-4 mt-0.5 shrink-0" />
                    <div>
                      <p>Failed to auto-configure on Cloudflare Pages:</p>
                      <p className="text-xs mt-1 font-mono bg-destructive/10 rounded p-2">{pagesErr}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        You may need to add it manually in the Cloudflare Dashboard.
                      </p>
                    </div>
                  </div>
                ) : null}

                {autoVerified && (
                  <div className="flex items-start gap-2 text-sm text-green-600 dark:text-green-400">
                    <ShieldCheck className="h-4 w-4 mt-0.5 shrink-0" />
                    <p>Domain ownership verified via Cloudflare API (zone + Pages domain confirmed).</p>
                  </div>
                )}
              </div>
            )}

            {/* No Cloudflare API Warning */}
            {!cloudflareConfigured && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  <strong>Cloudflare API not configured.</strong> The domain was saved but not auto-configured.
                  To enable automatic domain setup and secure verification, add these environment variables:
                </AlertDescription>
              </Alert>
            )}

            {/* Manual Setup Steps (only shown if auto-configure failed or was skipped) */}
            {(!autoVerified) && (
              <div className="space-y-3">
                <h4 className="font-medium text-sm">Manual Setup Required</h4>

                {!cloudflareConfigured ? (
                  <>
                    {/* Step 0: Configure API */}
                    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-500 text-white text-xs font-bold">!</span>
                        <h4 className="font-medium text-sm">Configure Cloudflare API (Recommended)</h4>
                      </div>
                      <div className="ml-8 space-y-2 text-sm text-muted-foreground">
                        <p>Add these env variables to your Cloudflare Pages project:</p>
                        <div className="rounded bg-background border p-3 font-mono text-xs space-y-2">
                          <p><span className="text-muted-foreground">CLOUDFLARE_API_TOKEN=</span><br />
                            <span className="text-xs text-muted-foreground">Create at: My Profile → API Tokens → Create Token</span><br />
                            <span className="text-xs text-muted-foreground">Permissions: Zone:Read, Workers Routes:Edit</span>
                          </p>
                          <p><span className="text-muted-foreground">CLOUDFLARE_ACCOUNT_ID=</span><br />
                            <span className="text-xs text-muted-foreground">Found at: Workers & Pages → Overview (right sidebar)</span>
                          </p>
                          <p><span className="text-muted-foreground">CLOUDFLARE_PAGES_PROJECT=</span><br />
                            <span className="text-xs text-muted-foreground">Your project name (e.g., &quot;bebastesting&quot; from bebastesting.pages.dev)</span>
                          </p>
                        </div>
                        <p className="text-xs">
                          After configuring, you can auto-add & auto-verify domains with one click.
                        </p>
                      </div>
                    </div>

                    {/* Manual steps fallback */}
                    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">1</span>
                        <h4 className="font-medium text-sm">Add in Cloudflare Pages</h4>
                      </div>
                      <div className="ml-8 text-sm text-muted-foreground">
                        <p>Cloudflare Dashboard → Workers & Pages → Your Project → Custom domains → Add <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">{result.domain}</code></p>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Auto-configure was attempted but failed */}
                    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">1</span>
                        <h4 className="font-medium text-sm">Add Custom Domain in Cloudflare</h4>
                      </div>
                      <div className="ml-8 text-sm text-muted-foreground">
                        <p>
                          Go to{" "}
                          <a href="https://dash.cloudflare.com" target="_blank" rel="noopener noreferrer" className="underline inline-flex items-center gap-1">
                            Cloudflare Dashboard <ExternalLink className="h-3 w-3" />
                          </a>{" "}
                          → Workers & Pages → Your Project → Custom domains → Set up <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono">{result.domain}</code>
                        </p>
                      </div>
                    </div>

                    <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">2</span>
                        <h4 className="font-medium text-sm">Verify Domain</h4>
                      </div>
                      <div className="ml-8 text-sm text-muted-foreground">
                        <p>After adding in Cloudflare, go back to Domains page and click <strong>Verify</strong>.</p>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* How it works */}
            <Alert>
              <Server className="h-4 w-4" />
              <AlertDescription className="text-xs">
                <strong>How routing works:</strong> When someone visits <code className="rounded bg-muted px-1 py-0.5">{result.domain}/abc</code>,
                Cloudflare routes the request to your app. The middleware detects it&apos;s a short domain
                (not your dashboard domain set in <code className="rounded bg-muted px-1 py-0.5">APP_DOMAIN</code>) and routes to the redirect handler.
              </AlertDescription>
            </Alert>
          </div>

          <DialogFooter>
            <Button onClick={resetAndClose} className="gap-2">
              {autoVerified ? "Done" : "I'll Set Up Manually"}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  // ─── Form Screen ────────────────────────────────────────────────────────────

  return (
    <Dialog open={open} onOpenChange={resetAndClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Add Domain
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="domain-input">Domain *</Label>
            <Input
              id="domain-input"
              placeholder="short-a.link"
              value={domain}
              onChange={(e) => setDomain(e.target.value.toLowerCase())}
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              Must be a domain with nameservers pointing to your Cloudflare account.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="slug-input">Slug (optional)</Label>
            <Input
              id="slug-input"
              placeholder="Custom prefix (e.g., 'm' → short-a.link/m/abc)"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
            />
          </div>

          {/* Auto-Configure Toggle */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="space-y-0.5">
              <Label htmlFor="auto-config" className="text-sm cursor-pointer">
                Auto-configure on Cloudflare Pages
              </Label>
              <p className="text-xs text-muted-foreground">
                Automatically add this domain to your Pages project and verify ownership.
              </p>
            </div>
            <Switch
              id="auto-config"
              checked={autoConfigure && cloudflareConfigured}
              disabled={!cloudflareConfigured}
              onCheckedChange={setAutoConfigure}
            />
          </div>

          {!cloudflareConfigured && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-xs">
                <strong>Cloudflare API not configured.</strong> Auto-configure is disabled.
                Set <code className="rounded bg-muted px-1 py-0.5">CLOUDFLARE_API_TOKEN</code>,{" "}
                <code className="rounded bg-muted px-1 py-0.5">CLOUDFLARE_ACCOUNT_ID</code>, and{" "}
                <code className="rounded bg-muted px-1 py-0.5">CLOUDFLARE_PAGES_PROJECT</code>{" "}
                in your environment variables to enable it.
              </AlertDescription>
            </Alert>
          )}

          {errorMsg && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription className="text-xs">{errorMsg}</AlertDescription>
            </Alert>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={resetAndClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !domain.trim()}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {autoConfigure && cloudflareConfigured ? "Add & Auto-Configure" : "Add Domain"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

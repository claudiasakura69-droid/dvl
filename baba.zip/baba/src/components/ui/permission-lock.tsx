'use client'

import { useState } from 'react'
import { Lock, Unlock, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { PERMISSION_LEVELS, type PermissionLevel } from '@/lib/permissions'
import { getPermissions } from '@/lib/permissions'

interface PermissionLockProps {
  userRole: string | undefined
  requiredLevel: PermissionLevel
  children: React.ReactNode
  actionType?: 'add' | 'edit' | 'delete' | 'view'
  label?: string
  onLockedClick?: () => void
}

const actionLabels = {
  add: 'Tambah',
  edit: 'Edit',
  delete: 'Hapus',
  view: 'Lihat'
}

const permissionDescriptions: Record<PermissionLevel, string> = {
  VIEW: 'Hanya bisa melihat data',
  ADMIN: 'Bisa menambah dan melihat data',
  SUPPORT: 'Bisa menambah, edit, dan melihat data',
  SUPERVISOR: 'Bisa menambah, edit, hapus, dan mengubah status bank',
  MASTER: 'Full access termasuk hapus bank dan edit tipe bank'
}

export function PermissionLock({
  userRole,
  requiredLevel,
  children,
  actionType = 'add',
  label,
  onLockedClick
}: PermissionLockProps) {
  const [dialogOpen, setDialogOpen] = useState(false)

  const userLevel = userRole ? (PERMISSION_LEVELS[userRole as PermissionLevel] ?? 0) : 0
  const requiredPermissionValue = PERMISSION_LEVELS[requiredLevel]

  const hasPermission = userLevel >= requiredPermissionValue
  const isLocked = !hasPermission

  if (hasPermission) {
    // User memiliki permission - tampilkan konten langsung
    return <>{children}</>
  }

  // User tidak memiliki permission - tampilkan gembok terkunci
  return (
    <>
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogTrigger asChild>
          <div className="relative inline-flex items-center justify-center">
            <div className="absolute inset-0 bg-black/5 rounded-lg pointer-events-none" />
            <div
              onClick={(e) => {
                if (onLockedClick) {
                  e.preventDefault()
                  onLockedClick()
                }
              }}
              className="opacity-50 pointer-events-auto cursor-not-allowed hover:opacity-60 transition-opacity"
            >
              {children}
            </div>
            {/* Lock Icon Overlay */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="bg-background/90 rounded-full p-3 shadow-lg border">
                <Lock className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </div>
        </DialogTrigger>

        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-destructive" />
              Fitur Terkunci
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Current User Info */}
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Role Anda:</span>
                <Badge variant="outline" className="font-semibold">
                  {userRole || 'Tidak login'}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Aksi:</span>
                <span className="text-sm font-medium">{label || actionLabels[actionType]}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Diperlukan:</span>
                <Badge className="bg-destructive text-destructive-foreground">
                  {requiredLevel}
                </Badge>
              </div>
            </div>

            {/* Permission Description */}
            <div className="space-y-3">
              <h3 className="font-semibold flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Level Permission
              </h3>
              <div className="space-y-2 text-sm">
                {Object.entries(PERMISSION_LEVELS)
                  .sort(([, a], [, b]) => a - b)
                  .map(([role, level]) => (
                    <div
                      key={role}
                      className={`flex items-center justify-between p-2 rounded ${
                        level === requiredPermissionValue
                          ? 'bg-destructive/10 border border-destructive'
                          : userLevel >= level
                          ? 'bg-green-50 border border-green-200'
                          : 'bg-muted'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {level >= requiredPermissionValue ? (
                          <Unlock className="h-4 w-4 text-green-600" />
                        ) : (
                          <Lock className="h-4 w-4 text-muted-foreground" />
                        )}
                        {role}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {permissionDescriptions[role as PermissionLevel]}
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            {/* Info Message */}
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
              <p className="text-sm text-blue-800">
                Untuk mengakses fitur ini, Anda perlu login dengan role{' '}
                <strong>{requiredLevel}</strong> atau lebih tinggi.
                Silakan hubungi administrator untuk mendapatkan akses.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              onClick={() => setDialogOpen(false)}
              className="w-full"
            >
              Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

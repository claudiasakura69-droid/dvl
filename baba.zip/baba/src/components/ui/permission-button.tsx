'use client'

import { Button } from '@/components/ui/button'
import { PermissionLock } from '@/components/ui/permission-lock'
import { Plus, Pencil, Trash2 } from 'lucide-react'
import type { PermissionLevel } from '@/lib/permissions'

interface PermissionButtonProps {
  userRole: string | undefined
  requiredLevel: PermissionLevel
  action: 'add' | 'edit' | 'delete'
  label?: string
  icon?: React.ReactNode
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
  children?: React.ReactNode
  onClick?: () => void
}

const actionIcons = {
  add: Plus,
  edit: Pencil,
  delete: Trash2
}

export function PermissionButton({
  userRole,
  requiredLevel,
  action,
  label,
  icon,
  variant = 'default',
  size = 'default',
  className = '',
  children,
  onClick,
}: PermissionButtonProps) {
  const IconComponent = icon || actionIcons[action]

  const buttonContent = children || (
    <>
      {IconComponent && <IconComponent className={size === 'icon' ? '' : 'mr-2 h-4 w-4'} />}
      {label && size !== 'icon' && <span>{label}</span>}
    </>
  )

  return (
    <PermissionLock
      userRole={userRole}
      requiredLevel={requiredLevel}
      actionType={action}
      label={label}
    >
      <Button
        variant={variant}
        size={size}
        className={className}
        onClick={onClick}
      >
        {buttonContent}
      </Button>
    </PermissionLock>
  )
}

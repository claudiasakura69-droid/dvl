'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Receipt, Plus, Edit, Trash2, Calendar } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, Permissions } from '@/lib/permissions'
import { PermissionButton } from '@/components/ui/permission-button'

interface ExpenseManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Expense {
  id: string
  amount: number
  operation: string
  notes: string | null
  category: string | null
  bankId: string | null
  bankName: string | null
  createdAt: string
  updatedAt: string
  bank?: {
    id: string
    name: string
    accountName: string
  }
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
  type: string
}

export default function ExpenseManagementContent({ sessionId, user }: ExpenseManagementContentProps) {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null)
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  
  // Date range filter
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  
  const [formData, setFormData] = useState({
    bankId: '',
    operation: 'decrease',
    amount: '',
    notes: '',
    category: ''
  })

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user?.role])

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchExpenses()
    }
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.data || [])
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchExpenses = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/expense?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setExpenses(data.data || data.expenses || [])
      }
    } catch (error) {
      console.error('Error fetching expenses:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/expense', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          bankId: formData.bankId === 'all' ? null : formData.bankId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil ditambahkan')
        setDialogOpen(false)
        setFormData({
          bankId: '',
          operation: 'decrease',
          amount: '',
          notes: '',
          category: ''
        })
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menambahkan expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditExpense = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user || !selectedExpense) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/expense', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          expenseId: selectedExpense.id,
          ...formData,
          bankId: formData.bankId === 'all' ? null : formData.bankId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil diubah')
        setEditDialogOpen(false)
        setSelectedExpense(null)
        setFormData({
          bankId: '',
          operation: 'decrease',
          amount: '',
          notes: '',
          category: ''
        })
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mengubah expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteExpense = async () => {
    if (!sessionId || !user || !selectedExpense) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/expense?sessionId=${sessionId}&expenseId=${selectedExpense.id}&userId=${user.id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Expense berhasil dihapus')
        setDeleteDialogOpen(false)
        setSelectedExpense(null)
        fetchExpenses()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus expense')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (expense: Expense) => {
    setSelectedExpense(expense)
    setFormData({
      bankId: expense.bankId || '',
      operation: expense.operation,
      amount: expense.amount.toString(),
      notes: expense.notes || '',
      category: expense.category || ''
    })
    setEditDialogOpen(true)
  }

  const openDeleteDialog = (expense: Expense) => {
    setSelectedExpense(expense)
    setDeleteDialogOpen(true)
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getBankDisplayName = (bank: { name: string, accountName: string } | null, bankName: string | null) => {
    if (bank && bank.name) {
      return { name: bank.name, accountName: bank.accountName || '' }
    }
    if (bankName) {
      const parts = bankName.split(' - ')
      return { name: parts[0] || bankName, accountName: parts[1] || '' }
    }
    return { name: 'Bank Tidak Dikenal', accountName: '' }
  }

  // Filter expenses by date range
  const filteredExpenses = expenses.filter(expense => {
    if (!startDate && !endDate) return true
    
    const expenseDate = new Date(expense.createdAt)
    const start = startDate ? new Date(startDate) : null
    const end = endDate ? new Date(endDate) : null
    
    if (start && end) {
      return expenseDate >= start && expenseDate <= end
    }
    if (start) {
      return expenseDate >= start
    }
    if (end) {
      return expenseDate <= end
    }
    return true
  })

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <Receipt className="h-6 w-6 sm:h-8 sm:w-8" />
            Expense
          </h1>
          <p className="text-muted-foreground text-sm sm:text-base">
            Catat pengeluaran operasional dan biaya lainnya
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <PermissionButton
              userRole={user?.role}
              requiredLevel="ADMIN"
              action="add"
              label="Tambah Expense"
              icon={Plus}
              className="w-full sm:w-auto min-h-[44px] sm:min-h-0"
            >
              <Plus className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Tambah Expense</span>
              <span className="sm:hidden">Tambah</span>
            </PermissionButton>
          </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle className="text-base sm:text-lg">Tambah Expense</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddExpense} className="space-y-4">
                <div>
                  <Label htmlFor="bank" className="text-sm">Pilih Bank (Opsional)</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tidak ada bank</SelectItem>
                      {banks && banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName} ({bank.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="operation" className="text-sm">Operasi</Label>
                  <Select
                    value={formData.operation}
                    onValueChange={(value) => setFormData({ ...formData, operation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih operasi" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="increase">Tambah (Increase)</SelectItem>
                      <SelectItem value="decrease">Kurang (Decrease)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="category" className="text-sm">Kategori (Opsional)</Label>
                  <Input
                    id="category"
                    placeholder="Contoh: Listrik, Sewa, Internet"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="amount" className="text-sm">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="notes" className="text-sm">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Catatan untuk pengeluaran ini"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
                <Button type="submit" className="w-full">
                  Simpan
                </Button>
              </form>
            </DialogContent>
          </Dialog>
      </div>

      {/* Date Range Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Filter Tanggal
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startDate" className="text-sm">Tanggal Mulai</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="endDate" className="text-sm">Tanggal Akhir</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
          {(startDate || endDate) && (
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => {
                setStartDate('')
                setEndDate('')
              }}
            >
              Reset Filter
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Expenses Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg flex items-center justify-between">
            <span>Riwayat Pengeluaran</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0))}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px]">
            {loading ? (
              <p className="text-center py-8">Memuat data...</p>
            ) : filteredExpenses.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada expense</p>
            ) : (
              <div className="min-w-full">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs sm:text-sm">Waktu</TableHead>
                      <TableHead className="text-xs sm:text-sm">Bank</TableHead>
                      <TableHead className="text-xs sm:text-sm">Operasi</TableHead>
                      <TableHead className="text-xs sm:text-sm">Kategori</TableHead>
                      <TableHead className="text-xs sm:text-sm">Catatan</TableHead>
                      <TableHead className="text-xs sm:text-sm text-right">Nominal</TableHead>
                      <TableHead className="hidden sm:table-cell text-xs sm:text-sm">User</TableHead>
                      {(permissions.canEdit || permissions.canDelete) && (
                        <TableHead className="text-xs sm:text-sm">Aksi</TableHead>
                      )}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenses.map((expense) => {
                      const bankDisplay = getBankDisplayName(expense.bank, expense.bankName)
                      
                      return (
                        <TableRow key={expense.id}>
                          <TableCell className="text-xs sm:text-sm">
                            <div className="hidden sm:block">{formatDate(expense.createdAt)}</div>
                            <div className="sm:hidden text-xs">{new Date(expense.createdAt).toLocaleDateString('id-ID')}</div>
                          </TableCell>
                          <TableCell>
                            <div className="font-medium text-xs sm:text-sm">{bankDisplay.name}</div>
                            {bankDisplay.accountName && (
                              <div className="text-xs text-muted-foreground">{bankDisplay.accountName}</div>
                            )}
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs ${expense.operation === 'increase' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              {expense.operation === 'increase' ? 'Tambah' : 'Kurang'}
                            </span>
                          </TableCell>
                          <TableCell>
                            <span className="px-2 py-1 rounded-full bg-secondary text-secondary-foreground text-xs">
                              {expense.category || 'Umum'}
                            </span>
                          </TableCell>
                          <TableCell className="text-xs sm:text-sm">{expense.notes || '-'}</TableCell>
                          <TableCell className={`text-right font-semibold text-xs sm:text-sm ${expense.operation === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(expense.amount)}
                          </TableCell>
                          <TableCell className="hidden sm:table-cell text-xs sm:text-sm">{expense.user.username}</TableCell>
                          <TableCell>
                            <div className="flex gap-1 sm:gap-2">
                              <PermissionButton
                                userRole={user?.role}
                                requiredLevel="SUPPORT"
                                action="edit"
                                size="icon"
                                className="h-8 w-8 sm:h-9 sm:w-9"
                                onClick={() => openEditDialog(expense)}
                              >
                                <Edit className="h-4 w-4" />
                              </PermissionButton>
                              <PermissionButton
                                userRole={user?.role}
                                requiredLevel="SUPERVISOR"
                                action="delete"
                                size="icon"
                                className="h-8 w-8 sm:h-9 sm:w-9 text-destructive hover:text-destructive"
                                onClick={() => openDeleteDialog(expense)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </PermissionButton>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Edit Expense</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditExpense} className="space-y-4">
            <div>
              <Label htmlFor="editBank" className="text-sm">Pilih Bank (Opsional)</Label>
              <Select
                value={formData.bankId}
                onValueChange={(value) => setFormData({ ...formData, bankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tidak ada bank</SelectItem>
                  {banks && banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName} ({bank.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editOperation" className="text-sm">Operasi</Label>
              <Select
                value={formData.operation}
                onValueChange={(value) => setFormData({ ...formData, operation: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih operasi" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="increase">Tambah (Increase)</SelectItem>
                  <SelectItem value="decrease">Kurang (Decrease)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editCategory" className="text-sm">Kategori (Opsional)</Label>
              <Input
                id="editCategory"
                placeholder="Contoh: Listrik, Sewa, Internet"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="editAmount" className="text-sm">Nominal</Label>
              <Input
                id="editAmount"
                type="number"
                placeholder="0"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="editNotes" className="text-sm">Catatan (Opsional)</Label>
              <Input
                id="editNotes"
                placeholder="Catatan untuk pengeluaran ini"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
            <DialogFooter>
              <Button type="submit" className="w-full sm:w-auto">
                Simpan Perubahan
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-sm sm:max-w-md p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Hapus Expense</DialogTitle>
          </DialogHeader>
          {selectedExpense && (
            <div className="space-y-2 text-sm">
              <p>Apakah Anda yakin ingin menghapus expense ini?</p>
              <div className="bg-muted p-3 rounded-md">
                <p><strong>Nominal:</strong> {formatCurrency(selectedExpense.amount)}</p>
                <p><strong>Operasi:</strong> {selectedExpense.operation === 'increase' ? 'Tambah' : 'Kurang'}</p>
                <p><strong>Kategori:</strong> {selectedExpense.category || 'Umum'}</p>
                <p><strong>Bank:</strong> {selectedExpense.bankName || selectedExpense.bank?.name || 'Tidak ada'}</p>
              </div>
              <p className="text-destructive">Saldo bank akan dikembalikan ke nilai sebelum transaksi.</p>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteExpense}
              className="w-full sm:w-auto"
            >
              Hapus
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

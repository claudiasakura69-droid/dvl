'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { AlertCircle, Plus, Pencil, Trash2, Calendar } from 'lucide-react'
import { toast } from 'sonner'
import { getPermissions, type Permissions } from '@/lib/permissions'
import { PermissionButton } from '@/components/ui/permission-button'

interface MistakeManagementContentProps {
  sessionId: string | null
  user: { id: string, username: string, role?: string } | null
}

interface Mistake {
  id: string
  amount: number
  notes: string | null
  bankId: string | null
  bankName: string | null
  transactionId: string | null
  createdAt: string
  user: {
    id: string
    username: string
  }
}

interface Bank {
  id: string
  name: string
  accountName: string
}

interface DailyTransaction {
  id: string
  date: string
  name: string
  amount: number
  type: string
}

export default function MistakeManagementContent({ sessionId, user }: MistakeManagementContentProps) {
  const [mistakes, setMistakes] = useState<Mistake[]>([])
  const [banks, setBanks] = useState<Bank[]>([])
  const [dailyTransactions, setDailyTransactions] = useState<DailyTransaction[]>([])
  const [loading, setLoading] = useState(true)
  const [permissions, setPermissions] = useState<Permissions>(getPermissions('VIEW'))
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedMistake, setSelectedMistake] = useState<Mistake | null>(null)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [formData, setFormData] = useState({
    amount: '',
    notes: '',
    bankId: '',
    transactionId: ''
  })
  const [editFormData, setEditFormData] = useState({
    amount: '',
    notes: '',
    bankId: ''
  })

  useEffect(() => {
    if (user?.role) {
      setPermissions(getPermissions(user.role))
    }
  }, [user])

  useEffect(() => {
    if (sessionId) {
      fetchBanks()
      fetchDailyTransactions()
      fetchMistakes()
    }
  }, [sessionId])

  const fetchBanks = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/banks?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setBanks(data.banks || data.data || [])
      }
    } catch (error) {
      console.error('Error fetching banks:', error)
    }
  }

  const fetchDailyTransactions = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/daily-transactions?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setDailyTransactions(data.transactions || data.data || [])
      }
    } catch (error) {
      console.error('Error fetching daily transactions:', error)
    }
  }

  const fetchMistakes = async () => {
    if (!sessionId) return

    setLoading(true)
    try {
      const response = await fetch(`/api/mistake?sessionId=${sessionId}`)
      const data = await response.json()

      if (data.success) {
        setMistakes(data.data || [])
      }
    } catch (error) {
      console.error('Error fetching mistakes:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user) {
      toast.error('Session atau user tidak valid')
      return
    }

    try {
      const response = await fetch('/api/mistake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          sessionId,
          bankId: formData.bankId === 'none' ? null : formData.bankId,
          transactionId: formData.transactionId === 'none' ? null : formData.transactionId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dicatat')
        setDialogOpen(false)
        setFormData({
          amount: '',
          notes: '',
          bankId: '',
          transactionId: ''
        })
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal mencatat mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleEditMistake = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!sessionId || !user || !selectedMistake) {
      toast.error('Session, user, atau mistake tidak valid')
      return
    }

    try {
      const response = await fetch('/api/mistake', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          mistakeId: selectedMistake.id,
          amount: editFormData.amount,
          notes: editFormData.notes,
          bankId: editFormData.bankId === 'none' ? null : editFormData.bankId,
          userId: user.id
        })
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil diperbarui')
        setEditDialogOpen(false)
        setSelectedMistake(null)
        setEditFormData({
          amount: '',
          notes: '',
          bankId: ''
        })
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal memperbarui mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const handleDeleteMistake = async () => {
    if (!sessionId || !user || !selectedMistake) {
      toast.error('Session, user, atau mistake tidak valid')
      return
    }

    try {
      const response = await fetch(`/api/mistake?sessionId=${sessionId}&mistakeId=${selectedMistake.id}&userId=${user.id}`, {
        method: 'DELETE'
      })

      const data = await response.json()

      if (data.success) {
        toast.success('Mistake berhasil dihapus')
        setDeleteDialogOpen(false)
        setSelectedMistake(null)
        fetchMistakes()
        fetchBanks()
      } else {
        toast.error(data.error || 'Gagal menghapus mistake')
      }
    } catch (error) {
      toast.error('Terjadi kesalahan')
    }
  }

  const openEditDialog = (mistake: Mistake) => {
    setSelectedMistake(mistake)
    setEditFormData({
      amount: mistake.amount.toString(),
      notes: mistake.notes || '',
      bankId: mistake.bankId || ''
    })
    setEditDialogOpen(true)
  }

  const openDeleteDialog = (mistake: Mistake) => {
    setSelectedMistake(mistake)
    setDeleteDialogOpen(true)
  }

  const formatCurrency = (amount: number) => `Rp ${amount.toLocaleString('id-ID')}`
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getBankDisplayName = (bankId: string | null, bankName: string | null) => {
    if (!bankId && !bankName) return '-'

    const bank = banks.find(b => b.id === bankId)
    if (bank) {
      return `${bank.name} - ${bank.accountName}`
    }

    if (bankName) {
      const match = bankName.match(/^(.+?)\s*-\s*(.+)$/)
      if (match) {
        return `${match[1]} - ${match[2]}`
      }
      return bankName
    }

    return '-'
  }

  const getTransactionDisplayName = (transactionId: string | null) => {
    if (!transactionId) return '-'
    const transaction = dailyTransactions.find(t => t.id === transactionId)
    if (transaction) {
      return `${transaction.name} (${formatDate(transaction.date)})`
    }
    return '-'
  }

  const filteredMistakes = mistakes.filter(mistake => {
    const mistakeDate = new Date(mistake.createdAt)
    if (startDate && mistakeDate < new Date(startDate)) return false
    if (endDate && mistakeDate > new Date(endDate + 'T23:59:59')) return false
    return true
  })

  const totalMistake = filteredMistakes.reduce((sum, m) => sum + m.amount, 0)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight flex items-center gap-2">
            <AlertCircle className="h-6 w-6 sm:h-8 sm:w-8" />
            Mistake
          </h1>
          <p className="text-muted-foreground">
            Catat kesalahan transaksi dan beban biaya kekurangan
          </p>
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <PermissionButton
              userRole={user?.role}
              requiredLevel="ADMIN"
              action="add"
              label="Catat Mistake"
              icon={Plus}
              variant="destructive"
              className="min-h-[44px]"
            >
              <Plus className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Catat Mistake</span>
              <span className="sm:hidden">Catat</span>
            </PermissionButton>
          </DialogTrigger>
            <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
              <DialogHeader>
                <DialogTitle className="text-base sm:text-lg">Catat Mistake</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddMistake} className="space-y-4">
                <div>
                  <Label htmlFor="transaction" className="text-sm">Referensi Transaksi (Opsional)</Label>
                  <Select
                    value={formData.transactionId}
                    onValueChange={(value) => setFormData({ ...formData, transactionId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih transaksi yang salah" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Tidak ada</SelectItem>
                      {dailyTransactions && dailyTransactions.map((transaction) => (
                        <SelectItem key={transaction.id} value={transaction.id}>
                          {transaction.name} - {formatCurrency(transaction.amount)} ({transaction.type})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="bank" className="text-sm">Bank (Opsional)</Label>
                  <Select
                    value={formData.bankId}
                    onValueChange={(value) => setFormData({ ...formData, bankId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Tidak ada</SelectItem>
                      {banks && banks.map((bank) => (
                        <SelectItem key={bank.id} value={bank.id}>
                          {bank.name} - {bank.accountName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="amount" className="text-sm">Nominal</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                    className="text-sm"
                  />
                </div>
                <div>
                  <Label htmlFor="notes" className="text-sm">Catatan (Opsional)</Label>
                  <Input
                    id="notes"
                    placeholder="Jelaskan kesalahan yang terjadi"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="text-sm"
                  />
                </div>
                <Button type="submit" className="w-full" variant="destructive">
                  Catat
                </Button>
              </form>
            </DialogContent>
          </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">
            <span>Riwayat Kesalahan</span>
            <span className="text-sm font-normal text-muted-foreground">
              Total: {formatCurrency(totalMistake)}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 space-y-2">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <Label htmlFor="startDate" className="text-sm">Dari Tanggal</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="text-sm"
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="endDate" className="text-sm">Sampai Tanggal</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="text-sm"
                />
              </div>
              <div className="flex items-end">
                <Button
                  variant="outline"
                  onClick={() => { setStartDate(''); setEndDate('') }}
                  className="w-full sm:w-auto"
                >
                  Reset
                </Button>
              </div>
            </div>
          </div>

          <ScrollArea className="h-[400px] sm:h-[500px] md:h-[600px]">
            {loading ? (
              <p>Memuat data...</p>
            ) : filteredMistakes.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Belum ada mistake</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs sm:text-sm">Waktu</TableHead>
                    <TableHead className="text-xs sm:text-sm hidden md:table-cell">Catatan</TableHead>
                    <TableHead className="text-xs sm:text-sm text-right">Nominal</TableHead>
                    <TableHead className="text-xs sm:text-sm">Bank</TableHead>
                    <TableHead className="text-xs sm:text-sm hidden sm:table-cell">User</TableHead>
                    <TableHead className="text-xs sm:text-sm text-right">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMistakes.map((mistake) => (
                    <TableRow key={mistake.id}>
                      <TableCell className="text-xs sm:text-sm">
                        {formatDate(mistake.createdAt)}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm hidden md:table-cell">
                        {mistake.notes || '-'}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm text-right font-semibold text-red-600">
                        {formatCurrency(mistake.amount)}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm">
                        {getBankDisplayName(mistake.bankId, mistake.bankName)}
                      </TableCell>
                      <TableCell className="text-xs sm:text-sm hidden sm:table-cell">
                        {mistake.user.username}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1 sm:gap-2">
                          <PermissionButton
                            userRole={user?.role}
                            requiredLevel="SUPPORT"
                            action="edit"
                            size="icon"
                            className="h-8 w-8 sm:h-9 sm:w-9"
                            onClick={() => openEditDialog(mistake)}
                          >
                            <Pencil className="h-3 w-3 sm:h-4 sm:w-4" />
                          </PermissionButton>
                          <PermissionButton
                            userRole={user?.role}
                            requiredLevel="SUPERVISOR"
                            action="delete"
                            size="icon"
                            className="h-8 w-8 sm:h-9 sm:w-9 text-red-600 hover:text-red-700"
                            onClick={() => openDeleteDialog(mistake)}
                          >
                            <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                          </PermissionButton>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-md sm:max-w-lg p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Edit Mistake</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleEditMistake} className="space-y-4">
            <div>
              <Label htmlFor="edit-bank" className="text-sm">Bank (Opsional)</Label>
              <Select
                value={editFormData.bankId}
                onValueChange={(value) => setEditFormData({ ...editFormData, bankId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pilih bank yang terkena kesalahan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Tidak ada</SelectItem>
                  {banks && banks.map((bank) => (
                    <SelectItem key={bank.id} value={bank.id}>
                      {bank.name} - {bank.accountName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="edit-amount" className="text-sm">Nominal</Label>
              <Input
                id="edit-amount"
                type="number"
                placeholder="0"
                value={editFormData.amount}
                onChange={(e) => setEditFormData({ ...editFormData, amount: e.target.value })}
                required
                className="text-sm"
              />
            </div>
            <div>
              <Label htmlFor="edit-notes" className="text-sm">Catatan (Opsional)</Label>
              <Input
                id="edit-notes"
                placeholder="Jelaskan kesalahan yang terjadi"
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                className="text-sm"
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                Batal
              </Button>
              <Button type="submit" variant="destructive">
                Simpan
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-md p-4 sm:p-6">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">Hapus Mistake</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Apakah Anda yakin ingin menghapus mistake ini?
            </p>
            {selectedMistake && (
              <div className="space-y-2 text-sm bg-muted p-4 rounded-lg">
                <div className="flex justify-between">
                  <span className="font-medium">Nominal:</span>
                  <span className="text-red-600 font-semibold">{formatCurrency(selectedMistake.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Catatan:</span>
                  <span>{selectedMistake.notes || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Bank:</span>
                  <span>{getBankDisplayName(selectedMistake.bankId, selectedMistake.bankName)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Waktu:</span>
                  <span>{formatDate(selectedMistake.createdAt)}</span>
                </div>
              </div>
            )}
            <p className="text-sm text-red-600">
              Peringatan: Balance bank akan dikembalikan (ditambah) setelah menghapus mistake ini.
            </p>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Batal
            </Button>
            <Button type="button" variant="destructive" onClick={handleDeleteMistake}>
              Hapus
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

# Sistem Kunci/Gembok (Permission Lock)

## Konsep

Sistem ini memberikan visual feedback yang jelas tentang permission user melalui ikon kunci/gembok. Fitur yang tidak bisa diakses akan ditampilkan dengan gembok terkunci, dan ketika diklik akan menampilkan informasi tentang permission yang diperlukan.

## Kelebihan

1. **Visual Feedback** - User langsung tahu fitur mana yang bisa diakses
2. **User-Friendly** - Tidak menyembunyikan tombol, hanya menguncinya
3. **Edukasi** - Dialog menjelaskan permission hierarchy
4. **Reactive** - Otomatis terbuka/terkunci ketika role berubah

## Role & Permission Level

| Role | Level | Can Add | Can Edit | Can Delete | Bank Ops |
|------|-------|---------|---------|-----------|----------|
| VIEW | 0 | ❌ | ❌ | ❌ | ❌ |
| ADMIN | 1 | ✅ | ❌ | ❌ | ❌ |
| SUPPORT | 2 | ✅ | ✅ | ❌ | ❌ |
| SUPERVISOR | 3 | ✅ | ✅ | ✅ | ✅ Status |
| MASTER | 4 | ✅ | ✅ | ✅ | ✅ Full |

## Cara Kerja

### 1. PermissionButton Component

Komponen ini membungkus Button dan otomatis:
- Membuka gembok jika user memiliki permission
- Mengunci gembok jika user tidak memiliki permission
- Menampilkan dialog permission info saat diklik

### 2. Contoh Penggunaan

```tsx
import { PermissionButton } from '@/components/ui/permission-button'

// Tombol Add Bank - membutuhkan role ADMIN ke atas
<PermissionButton
  userRole={user?.role}
  requiredLevel="ADMIN"
  action="add"
  label="Tambah Bank"
  icon={Plus}
>
  <Plus className="mr-2 h-4 w-4" />
  <span>Tambah Bank</span>
</PermissionButton>

// Tombol Delete Bank - membutuhkan role MASTER
<PermissionButton
  userRole={user?.role}
  requiredLevel="MASTER"
  action="delete"
  icon={Trash2}
  size="sm"
>
  <Trash2 className="h-4 w-4" />
</PermissionButton>

// Tombol Edit Status Bank - membutuhkan role SUPERVISOR ke atas
<PermissionButton
  userRole={user?.role}
  requiredLevel="SUPERVISOR"
  action="edit"
  size="sm"
>
  <Power className="h-4 w-4" />
</PermissionButton>
```

### 3. PermissionLock Component

Untuk kasus yang lebih kompleks, gunakan PermissionLock:

```tsx
import { PermissionLock } from '@/components/ui/permission-lock'

<PermissionLock
  userRole={user?.role}
  requiredLevel="ADMIN"
  actionType="add"
>
  <Button>
    <Plus className="mr-2 h-4 w-4" />
    Tambah Transaksi
  </Button>
</PermissionLock>
```

## Fitur per Menu

### Bank Management

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Tambah Bank | Add | ADMIN |
| Toggle Status (Online/Offline) | Status | SUPERVISOR |
| Move Bank (Deposit/Withdraw) | Move | MASTER |
| Delete Bank | Delete | MASTER |
| View History | History | Semua Role |

### Day Transactions

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Tambah Transaksi | Add | ADMIN |
| Edit Transaksi | Edit | SUPPORT |
| Delete Transaksi | Delete | SUPERVISOR |
| Bulk Add | Bulk | ADMIN |
| Export | Export | ADMIN |

### In/Out Management

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Tambah In/Out | Add | ADMIN |
| Edit In/Out | Edit | SUPPORT |
| Delete In/Out | Delete | SUPERVISOR |

### Expense Management

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Tambah Expense | Add | ADMIN |
| Edit Expense | Edit | SUPPORT |
| Delete Expense | Delete | SUPERVISOR |

### Mistake Management

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Catat Mistake | Add | ADMIN |
| Edit Mistake | Edit | SUPPORT |
| Delete Mistake | Delete | SUPERVISOR |

### User Management

| Fitur | Tombol | Required Level |
|-------|--------|----------------|
| Tambah User | Add | ADMIN |

## Cara Mengetest Permission

### 1. Login dengan Role Berbeda

**Role VIEW:**
- Semua fitur terkunci kecuali view
- Hanya bisa melihat data

**Role ADMIN:**
- Tombol Add terbuka
- Tombol Edit/Delete terkunci

**Role SUPPORT:**
- Tombol Add/Edit terbuka
- Tombol Delete terkunci

**Role SUPERVISOR:**
- Semua tombol terbuka kecuali bank ops khusus

**Role MASTER:**
- Semua tombol terbuka
- Full access

### 2. Test Automatic Lock/Unlock

1. Login sebagai role MASTER
2. Semua gembok terbuka ✅
3. Logout
4. Login sebagai role VIEW
5. Semua gembok otomatis terkunci 🔒
6. Refresh halaman - gembok tetap terkunci (berdasarkan role session)

## Dialog Permission Info

Ketika user mengklik fitur yang terkunci, dialog akan muncul berisi:

### User Info
- Role user saat ini
- Aksi yang dicoba (Add/Edit/Delete)
- Role yang diperlukan

### Permission Levels Table
Tabel yang menunjukkan semua role dengan:
- Ikon kunci (Lock/Unlock)
- Deskripsi permission untuk setiap role
- Highlight pada role yang diperlukan

### Info Message
Pesan yang menjelaskan cara mendapatkan akses:
> "Untuk mengakses fitur ini, Anda perlu login dengan role [ROLE] atau lebih tinggi.
> Silakan hubungi administrator untuk mendapatkan akses."

## Troubleshooting

### Gembok Tidak Muncul

**Masalah**: Tombol ditampilkan tapi tidak ada gembok

**Solusi**:
1. Pastikan user login (session valid)
2. Pastikan user?.role terisi dengan benar
3. Cek komponen menggunakan PermissionButton dengan benar

### Gembok Selalu Terkunci

**Masalah**: Seharusnya bisa akses tapi tetap terkunci

**Solusi**:
1. Cek role user di database via Prisma Studio:
   ```bash
   npx prisma studio
   ```
2. Pastikan kolom `role` berisi value yang benar (VIEW, ADMIN, SUPPORT, SUPERVISOR, MASTER)
3. Logout dan login ulang

### Gembok Selalu Terbuka

**Masalah**: Seharusnya terkunci tapi tetap terbuka

**Solusi**:
1. Pastikan `requiredLevel` diset dengan benar
2. Cek PERMISSION_LEVELS di `lib/permissions.ts`
3. Pastikan value role sesuai (case-sensitive)

## Migration dari Permission Check Lama

### Sebelum (Sembunyi Tombol)

```tsx
{permissions.canAdd && (
  <Button onClick={handleAdd}>
    <Plus className="mr-2 h-4 w-4" />
    Tambah
  </Button>
)}
```

### Sesudah (Sistem Gembok)

```tsx
<PermissionButton
  userRole={user?.role}
  requiredLevel="ADMIN"
  action="add"
  label="Tambah"
  icon={Plus}
  onClick={handleAdd}
>
  <Plus className="mr-2 h-4 w-4" />
  Tambah
</PermissionButton>
```

## Best Practices

1. **Selalu userRole** dari user yang login, jangan hardcode
2. **Required level** sesuaikan dengan kebutuhan fitur
3. **Action type** set untuk memberikan feedback yang benar
4. **Icon** dan **label** set untuk visual yang konsisten
5. **Test** dengan semua role untuk memastikan bekerja dengan benar

## Components

1. **PermissionButton** - Untuk tombol sederhana
   - Props: userRole, requiredLevel, action, label, icon, variant, size, className, onClick, children

2. **PermissionLock** - Untuk konten kompleks
   - Props: userRole, requiredLevel, actionType, label, children, onLockedClick

## Catatan Penting

1. **Session Valid** - Pastikan session valid sebelum cek permission
2. **Role Case-Sensitive** - Role harus uppercase (VIEW, ADMIN, dll)
3. **Permission Levels** - Cek di `lib/permissions.ts` untuk level yang benar
4. **Auto Unlock** - Gembok otomatis terbuka/terkunci berdasarkan role di session
5. **No Race Condition** - Permission dicek setiap render, reaktif terhadap perubahan role

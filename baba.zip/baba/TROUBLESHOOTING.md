# Troubleshooting - Tombol & Icon Tidak Muncul

## Masalah: Icons dan tombol tidak muncul di dashboard

### Kemungkinan Penyebab:

1. **User login dengan role VIEW**
2. **Browser cache perlu di-clear**
3. **LocalStorage error**

---

## Solusi 1: Cek Role User yang Sedang Login

### Cara Cek Role via Database

Buka terminal dan jalankan:

```bash
cd /home/z/my-project
npx prisma studio
```

Buka `http://localhost:5555` dan lihat di tabel `User`:

| Username | Role | Permissions |
|----------|------|-------------|
| admin | MASTER | ✅ Full Access |
| support | SUPPORT | ✅ Add, Edit, View |
| supervisor | SUPERVISOR | ✅ Add, Edit, Delete |
| viewonly | VIEW | ❌ View Only |

**Jika role Anda adalah VIEW**, semua tombol add/edit/delete TIDAK akan muncul!

### Solusi: Membuat User dengan Role MASTER atau ADMIN

**Cara 1: Menggunakan Prisma Studio**

1. Buka Prisma Studio:
   ```bash
   npx prisma studio
   ```

2. Buka `http://localhost:5555`

3. Klik tabel `User`

4. Klik tombol **Add record**

5. Isi data:
   - `username`: admin
   - `password`: admin123 (atau password pilihan Anda)
   - `role`: MASTER
   - `isActive`: true
   - `token`: admin123 (sama dengan password untuk sekarang)

6. Klik **Save**

**Cara 2: Menggunakan Script**

Buat file `create-admin-user.ts`:

```typescript
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Cek apakah user admin sudah ada
  const existingAdmin = await prisma.user.findUnique({
    where: { username: 'admin' }
  })

  if (existingAdmin) {
    console.log('User admin sudah ada!')
    return
  }

  // Buat user admin baru
  const admin = await prisma.user.create({
    data: {
      username: 'admin',
      password: 'admin123',
      token: 'admin123',
      role: 'MASTER',
      isActive: true,
    },
  })

  console.log('User admin berhasil dibuat:', admin)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
```

Run script:
```bash
cd /home/z/my-project
bun run create-admin-user.ts
```

**Cara 3: Menggunakan API POST**

Buat file `create-admin.sh`:

```bash
curl -X POST http://localhost:3000/api/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123",
    "role": "MASTER",
    "sessionId": "temp-session-id",
    "creatorId": "temp-creator-id"
  }'
```

---

## Solusi 2: Clear Browser Cache & LocalStorage

### Hard Refresh Browser

**Windows:**
- Tekan `Ctrl + Shift + R`
- Atau `Ctrl + F5`

**Mac:**
- Tekan `Cmd + Shift + R`
- Atau `Cmd + Option + E` (empty cache lalu refresh)

### Clear LocalStorage via Browser Console

1. Buka Developer Tools:
   - Windows/Linux: `F12` atau `Ctrl + Shift + I`
   - Mac: `Cmd + Option + I`

2. Pilih tab **Console**

3. Jalankan perintah:
   ```javascript
   // Clear semua localStorage
   localStorage.clear()

   // Reload halaman
   location.reload()
   ```

### Clear Cache via Browser Settings

**Chrome:**
1. Klik tiga titik di pojok kanan atas
2. Settings > Privacy and security
3. Clear browsing data
4. Pilih "All time"
5. Centang "Cached images and files"
6. Klik "Clear data"

**Firefox:**
1. Klik tiga garis di pojok kanan atas
2. Settings > Privacy & Security
3. Cookies and Site Data > Clear Data
4. Pilih "All time"
5. Centang "Cache"
6. Klik "Clear"

---

## Solusi 3: Login dengan Role yang Benar

Setelah membuat user dengan role MASTER/ADMIN:

1. Buka aplikasi: `http://localhost:3000`

2. Login dengan:
   - Username: `admin`
   - Token/Password: `admin123`

3. Sekarang semua tombol dan icons seharusnya muncul!

---

## Solusi 4: Cek Server Status

### Cek apakah server berjalan

```bash
ps aux | grep "next dev" | grep -v grep
```

Jika tidak ada output, restart server:

```bash
cd /home/z/my-project
bun run dev
```

### Cek server logs

```bash
tail -50 /home/z/my-project/dev-server.log
```

Pastikan tidak ada error di log.

---

## Solusi 5: Inspect Browser Console untuk Error

1. Buka aplikasi di browser

2. Buka Developer Tools: `F12`

3. Pilih tab **Console**

4. Lihat apakah ada error merah

Error yang mungkin muncul:

- `ReferenceError: React is not defined`
- `TypeError: Cannot read property of undefined`
- `403 Forbidden` - Permission error

### Contoh Error dan Solusi

**Error: `GET /api/users?sessionId=... 403`**
- **Penyebab**: Role user tidak memiliki permission untuk melihat users
- **Solusi**: Login dengan role ADMIN atau lebih tinggi

**Error: `ReferenceError: cn is not defined`**
- **Penyebab**: Fungsi `cn` tidak di-import
- **Solusi**: Ini sudah diperbaiki di code terbaru

---

## Role & Permissions Lengkap

| Role | Level | Can View | Can Add | Can Edit | Can Delete | Bank Status | Bank Type | Delete Bank |
|------|-------|----------|---------|----------|-----------|-------------|-----------|------------|
| **VIEW** | 0 | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **ADMIN** | 1 | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **SUPPORT** | 2 | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **SUPERVISOR** | 3 | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| **MASTER** | 4 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

**Catatan Penting:**
- Tombol **Add** hanya muncul untuk role **ADMIN ke atas**
- Tombol **Edit** hanya muncul untuk role **SUPPORT ke atas**
- Tombol **Delete** hanya muncul untuk role **SUPERVISOR ke atas**
- Tombol **Delete Bank** dan **Edit Bank Type** hanya muncul untuk role **MASTER**

---

## Checklist Troubleshooting

Sebelum melaporkan masalah, pastikan:

- [ ] Server berjalan di port 3000
- [ ] User login dengan role bukan VIEW
- [ ] Browser sudah di-hard refresh
- [ ] LocalStorage sudah di-clear
- [ ] Browser console tidak ada error
- [ ] Network tab tidak ada failed requests
- [ ] User ada di database dengan role yang benar
- [ ] Prisma client sudah di-generate (`bun run db:generate`)
- [ ] Database sudah di-sync (`bun run db:push`)

---

## Quick Fix Commands

```bash
# 1. Restart server
cd /home/z/my-project
pkill -f "next dev"
bun run dev

# 2. Regenerate Prisma client
bun run db:generate

# 3. Push schema ke database
bun run db:push

# 4. Buka Prisma Studio untuk cek user
npx prisma studio

# 5. Buat user admin jika belum ada
# (Lihat cara di atas)
```

---

## Contact Support

Jika setelah mencoba semua solusi di atas masih mengalami masalah:

1. Screenshot error di browser console
2. Screenshot tampilan dashboard
3. Copy server logs: `tail -100 /home/z/my-project/dev-server.log`
4. Cek role user di Prisma Studio
5. Berikan info browser dan OS yang digunakan
